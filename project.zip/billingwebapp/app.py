# app.py
from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify, send_from_directory, send_file, g, abort, has_app_context
from datetime import datetime, time, timedelta, date, timezone
from functools import wraps
from contextlib import contextmanager
import contextvars
import json
import math
import re
import os
import secrets
import hashlib
from io import BytesIO
from decimal import Decimal, ROUND_HALF_UP
try:
    from zoneinfo import ZoneInfo
except Exception:  # pragma: no cover
    ZoneInfo = None
from werkzeug.utils import secure_filename
from werkzeug.security import check_password_hash, generate_password_hash
from sqlalchemy import text, or_, and_, inspect, cast, String, event
from sqlalchemy.exc import IntegrityError, SQLAlchemyError
from sqlalchemy.orm import Session as SASession, with_loader_criteria
from itsdangerous import BadSignature, URLSafeSerializer

try:
    from .local_launch import prepare_local_server, schedule_browser_open
except ImportError:  # pragma: no cover - direct `python app.py` startup
    from local_launch import prepare_local_server, schedule_browser_open

try:
    from flask_migrate import Migrate
except Exception:  # pragma: no cover
    Migrate = None

try:
    from .models import (
        db,
        Tenant,
        TenantSettings,
        SubscriptionHistory,
        User,
        Medicine,
        StockHistory,
        Invoice,
        InvoiceItem,
        Return,
        ReturnItem,
        HoldBill,
        PendingBillStore,
        Patient,
        Appointment,
        LabTest,
        LabOrder,
        LabOrderItem,
        LabReport,
        PortalOtpChallenge,
        AppointmentBookingSettings,
        PublicAppointmentBooking,
        PublicAppointmentDayLock,
        Vendor,
        VendorPurchase,
        VendorPurchaseItem,
        SalesAllocation,
        VendorNote,
        VendorNoteItem,
        VendorNoteAllocation,
        VendorLedgerEntry,
        AuditLog,
        LoginSecurityEvent,
        VoiceCall,
        VoiceCallEvent,
        AIAPIClient,
        AIAccessToken,
        AIAPIRequestAudit,
        AIIdempotencyRecord,
        OmnidimGatewayAction,
        ReturnLotAllocation,
        QuarantineStock,
    )
    from .routes.appointments import mark_appointment_paid as handle_mark_appointment_paid
    from .routes.appointments import render_appointments_page
    from .routes.billing import prepare_billing_context
    from .routes.reports import render_reports_page
    from .services.reports import doctor_name_suggestions, load_doctor_wise_report
    from .routes.vendors import render_vendor_reports_page
    from .routes.telephony import handle_generic_telephony_webhook
    from .routes.ai_api import ai_api_bp
    from .routes.ai_admin import ai_admin_bp
    from .routes.omnidim_gateway import omnidim_gateway_bp
    from .services.background_jobs import init_background_jobs, queue_report_export_job
    from .services.infra_safety import (
        build_backup_snapshot,
        build_restore_commands,
        ensure_runtime_indexes,
        get_backup_summary,
        list_backup_snapshots,
        restore_backup_snapshot,
    )
    from .services.monitoring import configure_monitoring
    from .services.public_portal import mask_mobile, send_portal_otp
    from .services.validation import (
        ACCESS_PROFILE_PRESETS,
        USER_PERMISSION_FIELDS,
        derive_access_profile,
        validate_billing_submission,
        validate_mark_paid_transition,
        validate_report_request,
        validate_return_submission,
        validate_user_form,
    )
except ImportError:  # pragma: no cover - script/local fallback
    from models import (
        db,
        Tenant,
        TenantSettings,
        SubscriptionHistory,
        User,
        Medicine,
        StockHistory,
        Invoice,
        InvoiceItem,
        Return,
        ReturnItem,
        HoldBill,
        PendingBillStore,
        Patient,
        Appointment,
        LabTest,
        LabOrder,
        LabOrderItem,
        LabReport,
        PortalOtpChallenge,
        AppointmentBookingSettings,
        PublicAppointmentBooking,
        PublicAppointmentDayLock,
        Vendor,
        VendorPurchase,
        VendorPurchaseItem,
        SalesAllocation,
        VendorNote,
        VendorNoteItem,
        VendorNoteAllocation,
        VendorLedgerEntry,
        AuditLog,
        LoginSecurityEvent,
        VoiceCall,
        VoiceCallEvent,
        AIAPIClient,
        AIAccessToken,
        AIAPIRequestAudit,
        AIIdempotencyRecord,
        OmnidimGatewayAction,
        ReturnLotAllocation,
        QuarantineStock,
    )
    from routes.appointments import mark_appointment_paid as handle_mark_appointment_paid
    from routes.appointments import render_appointments_page
    from routes.billing import prepare_billing_context
    from routes.reports import render_reports_page
    from services.reports import doctor_name_suggestions, load_doctor_wise_report
    from routes.vendors import render_vendor_reports_page
    from routes.telephony import handle_generic_telephony_webhook
    from routes.ai_api import ai_api_bp
    from routes.ai_admin import ai_admin_bp
    from routes.omnidim_gateway import omnidim_gateway_bp
    from services.background_jobs import init_background_jobs, queue_report_export_job
    from services.infra_safety import (
        build_backup_snapshot,
        build_restore_commands,
        ensure_runtime_indexes,
        get_backup_summary,
        list_backup_snapshots,
        restore_backup_snapshot,
    )
    from services.monitoring import configure_monitoring
    from services.public_portal import mask_mobile, send_portal_otp
    from services.validation import (
        ACCESS_PROFILE_PRESETS,
        USER_PERMISSION_FIELDS,
        derive_access_profile,
        validate_billing_submission,
        validate_mark_paid_transition,
        validate_report_request,
        validate_return_submission,
        validate_user_form,
    )

IS_PROD = bool(
    os.environ.get("RAILWAY_ENVIRONMENT")
    or os.environ.get("RAILWAY_PUBLIC_DOMAIN")
    or os.environ.get("RENDER")
    or os.environ.get("FLY_APP_NAME")
    or os.environ.get("VERCEL")
    or (os.environ.get("VERCEL_ENV") or "").lower() == "production"
)
IS_SERVERLESS = bool(os.environ.get("VERCEL") or os.environ.get("AWS_LAMBDA_FUNCTION_NAME"))

APP_TIMEZONE = (os.environ.get("APP_TIMEZONE") or "Asia/Kolkata").strip() or "Asia/Kolkata"
APP_ENV = (os.environ.get("APP_ENV") or ("production" if IS_PROD else "local")).strip().lower() or "local"


def clinic_now():
    if ZoneInfo is not None:
        try:
            return datetime.now(ZoneInfo(APP_TIMEZONE))
        except Exception:
            pass
    return datetime.now()


APP_BASE_DIR = os.path.dirname(os.path.abspath(__file__))

try:
    from dotenv import load_dotenv
except Exception:  # pragma: no cover
    load_dotenv = None

if load_dotenv is not None:
    load_dotenv(os.path.join(APP_BASE_DIR, ".env"), override=False)

app = Flask(
    __name__,
    template_folder=os.path.join(APP_BASE_DIR, "templates"),
    static_folder=os.path.join(APP_BASE_DIR, "static"),
    static_url_path="/static"
)
def resolve_app_secret_key():
    """Return a strong secret key.

    Production must provide SECRET_KEY explicitly; starting with a guessable
    fallback would let anyone forge login sessions and invoice share links.
    Local installs get a random key that is persisted under instance/ so that
    logins survive restarts without ever using a shared hard-coded value.
    """
    configured = (os.environ.get("SECRET_KEY") or "").strip()
    weak_values = {"", "dev-secret", "secret", "changeme", "change-me"}
    lowered = configured.lower()
    if lowered.startswith(("replace-with", "change-this", "your-secret")):
        weak_values.add(lowered)  # placeholder copied from .env.example
    if configured and lowered not in weak_values and len(configured) >= 16:
        return configured
    if IS_PROD:
        raise RuntimeError(
            "SECRET_KEY environment variable is missing or too weak. "
            "Set a random value of at least 32 characters before starting in production."
        )
    if configured and lowered not in weak_values:
        # Short but explicit keys are tolerated locally (tests use these).
        return configured
    key_dir = os.path.join(APP_BASE_DIR, "instance")
    key_path = os.path.join(key_dir, ".secret_key")
    try:
        if os.path.exists(key_path):
            with open(key_path, "r", encoding="utf-8") as handle:
                stored = handle.read().strip()
            if len(stored) >= 32:
                return stored
        os.makedirs(key_dir, exist_ok=True)
        generated = secrets.token_urlsafe(48)
        with open(key_path, "w", encoding="utf-8") as handle:
            handle.write(generated)
        try:
            os.chmod(key_path, 0o600)
        except OSError:
            pass
        return generated
    except OSError:
        # Read-only filesystem: fall back to a per-process random key.
        return secrets.token_urlsafe(48)


app.secret_key = resolve_app_secret_key()
try:
    max_upload_mb = max(1, int(str(os.environ.get("MAX_CONTENT_LENGTH_MB", "12")).strip()))
except (TypeError, ValueError):
    max_upload_mb = 12
try:
    session_idle_minutes = max(5, int(str(os.environ.get("SESSION_IDLE_MINUTES", "90")).strip()))
except (TypeError, ValueError):
    session_idle_minutes = 90
try:
    session_absolute_hours = max(1, int(str(os.environ.get("SESSION_ABSOLUTE_HOURS", "24")).strip()))
except (TypeError, ValueError):
    session_absolute_hours = 24
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
app.config["SESSION_COOKIE_SECURE"] = IS_PROD
app.config["PREFERRED_URL_SCHEME"] = "https" if IS_PROD else "http"
app.config["MAX_CONTENT_LENGTH"] = max_upload_mb * 1024 * 1024
app.config["JSON_SORT_KEYS"] = False
app.config["PERMANENT_SESSION_LIFETIME"] = timedelta(hours=session_absolute_hours)
app.config["APP_ENV"] = APP_ENV

INVOICE_SHARE_SALT = "invoice-share-link"


def invoice_share_serializer():
    return URLSafeSerializer(app.secret_key, salt=INVOICE_SHARE_SALT)


def build_invoice_share_token(invoice_id):
    return invoice_share_serializer().dumps({"invoice_id": int(invoice_id)})


def read_invoice_share_token(token):
    try:
        payload = invoice_share_serializer().loads(token or "")
    except BadSignature:
        return 0
    return to_int_safe(payload.get("invoice_id"), 0) if isinstance(payload, dict) else 0

ASYNC_REDIRECT_STATUSES = {301, 302, 303, 307, 308}

TMP_BASE_DIR = os.path.join("/tmp", "billingwebapp")
HOLD_BILL_FALLBACK_FILE = os.path.join(TMP_BASE_DIR, "hold_bills_fallback.json")


def ensure_writable_dir(preferred_path, fallback_path):
    try:
        os.makedirs(preferred_path, exist_ok=True)
        return preferred_path
    except OSError:
        os.makedirs(fallback_path, exist_ok=True)
        return fallback_path


def env_flag(name, default=False):
    raw = os.environ.get(name)
    if raw is None:
        return default
    return str(raw).strip().lower() in {"1", "true", "yes", "on"}


def env_int(name, default, minimum=None, maximum=None):
    try:
        value = int(str(os.environ.get(name, default)).strip())
    except (TypeError, ValueError):
        value = int(default)
    if minimum is not None:
        value = max(int(minimum), value)
    if maximum is not None:
        value = min(int(maximum), value)
    return value


# AI integration is deliberately opt-in. Enabling it exposes only the
# versioned API boundary; every functional endpoint still requires a scoped,
# short-lived machine token.
app.config["AI_API_ENABLED"] = env_flag("AI_API_ENABLED", False)
app.config["AI_ACCESS_TOKEN_TTL_SECONDS"] = env_int(
    "AI_ACCESS_TOKEN_TTL_SECONDS", 900, minimum=60, maximum=3600
)
app.config["AI_AUTH_RATE_LIMIT_PER_MINUTE"] = env_int(
    "AI_AUTH_RATE_LIMIT_PER_MINUTE", 20, minimum=5, maximum=100
)
app.config["AI_API_TRUST_PROXY_HEADERS"] = env_flag("AI_API_TRUST_PROXY_HEADERS", False)
app.config["AI_AUDIT_FINGERPRINT_SECRET"] = (
    os.environ.get("AI_AUDIT_FINGERPRINT_SECRET") or app.secret_key
)
app.config["IS_PRODUCTION"] = IS_PROD
app.config["AI_OTP_ENABLED"] = env_flag("AI_OTP_ENABLED", False)
app.config["AI_SECURE_REPORT_DELIVERY_ENABLED"] = env_flag(
    "AI_SECURE_REPORT_DELIVERY_ENABLED", False
)
app.config["AI_CALLBACKS_ENABLED"] = env_flag("AI_CALLBACKS_ENABLED", False)
app.config["AI_COMPLAINTS_ENABLED"] = env_flag("AI_COMPLAINTS_ENABLED", False)
app.config["AI_NOTIFICATIONS_ENABLED"] = env_flag("AI_NOTIFICATIONS_ENABLED", False)
# OmniDimension uses a long-lived static header for Custom API actions.  Keep
# this separate from the internal AI API's short-lived bearer-token boundary
# so enabling the voice gateway does not expose the general integration API.
app.config["OMNIDIM_GATEWAY_ENABLED"] = env_flag("OMNIDIM_GATEWAY_ENABLED", False)
app.config["OMNIDIM_GATEWAY_SECRET"] = (os.environ.get("OMNIDIM_GATEWAY_SECRET") or "").strip()
app.config["OMNIDIM_GATEWAY_RATE_LIMIT_PER_MINUTE"] = env_int(
    "OMNIDIM_GATEWAY_RATE_LIMIT_PER_MINUTE", 60, minimum=5, maximum=300
)
app.config["OMNIDIM_GATEWAY_TRUST_PROXY_HEADERS"] = env_flag(
    "OMNIDIM_GATEWAY_TRUST_PROXY_HEADERS", False
)
# The OmniDimension dashboard's Test API tool runs at this browser origin.
# Keep this a single explicit origin; the gateway must never reflect arbitrary
# web origins because its shared key is configured in the dashboard.
app.config["OMNIDIM_GATEWAY_CORS_ORIGIN"] = (
    os.environ.get("OMNIDIM_GATEWAY_CORS_ORIGIN") or "https://omnidim.io"
).strip().rstrip("/")
app.config["OTP_EXPIRY_SECONDS"] = env_int("OTP_EXPIRY_SECONDS", 300, minimum=60, maximum=900)
app.config["OTP_MAX_ATTEMPTS"] = env_int("OTP_MAX_ATTEMPTS", 5, minimum=1, maximum=10)
app.config["OTP_RESEND_COOLDOWN_SECONDS"] = env_int(
    "OTP_RESEND_COOLDOWN_SECONDS", 60, minimum=30, maximum=900
)
app.config["AI_PATIENT_SESSION_TTL_SECONDS"] = env_int(
    "AI_PATIENT_SESSION_TTL_SECONDS", 900, minimum=300, maximum=3600
)
app.config["SECURE_DOCUMENT_EXPIRY_MINUTES"] = env_int(
    "SECURE_DOCUMENT_EXPIRY_MINUTES", 10, minimum=1, maximum=60
)
app.config["APPLICATION_BASE_URL"] = (os.environ.get("APPLICATION_BASE_URL") or "").strip()


def normalize_database_url(raw_url):
    db_url = (raw_url or "").strip()
    if db_url.startswith("postgres://"):
        db_url = db_url.replace("postgres://", "postgresql://", 1)
    return db_url


def resolve_database_url(default_db):
    for env_name in ("DATABASE_URL", "POSTGRES_URL_NON_POOLING", "POSTGRES_URL"):
        candidate = normalize_database_url(os.environ.get(env_name))
        if candidate:
            return candidate
    if IS_PROD:
        raise RuntimeError(
            "Database URL is missing. Set DATABASE_URL or POSTGRES_URL in environment variables."
        )
    return default_db

# ---------------- UPLOADS ----------------
UPLOAD_STORAGE_ROOT = os.path.abspath(
    (os.environ.get("APP_STORAGE_ROOT") or os.path.join(APP_BASE_DIR, "static", "uploads")).strip()
)


def resolve_upload_dir(*parts):
    return ensure_writable_dir(
        os.path.join(UPLOAD_STORAGE_ROOT, *parts),
        os.path.join(TMP_BASE_DIR, "uploads", *parts)
    )


UPLOAD_FOLDER = resolve_upload_dir("vendors")
VENDOR_BILL_UPLOAD_FOLDER = resolve_upload_dir("vendor_bills")
PRIVATE_STORAGE_ROOT = os.path.abspath(
    (os.environ.get("APP_PRIVATE_STORAGE_ROOT") or os.path.join(app.instance_path, "private")).strip()
)
LAB_REPORT_UPLOAD_FOLDER = ensure_writable_dir(
    os.path.join(PRIVATE_STORAGE_ROOT, "lab_reports"),
    os.path.join(TMP_BASE_DIR, "private_lab_reports"),
)
BACKUP_ROOT = os.path.abspath(
    (os.environ.get("APP_BACKUP_ROOT") or os.path.join(app.instance_path, "backups")).strip()
)
app.config["APP_BASE_DIR"] = APP_BASE_DIR
app.config["APP_STORAGE_ROOT"] = UPLOAD_STORAGE_ROOT
app.config["APP_PRIVATE_STORAGE_ROOT"] = PRIVATE_STORAGE_ROOT
app.config["BACKUP_ROOT"] = BACKUP_ROOT
app.config["INFRA_UPLOAD_DIRECTORIES"] = {
    "vendor_uploads": UPLOAD_FOLDER,
    "vendor_bill_uploads": VENDOR_BILL_UPLOAD_FOLDER,
    "private_lab_reports": LAB_REPORT_UPLOAD_FOLDER,
}
ALLOWED_EXTENSIONS = {"pdf", "png", "jpg", "jpeg"}
LAB_REPORT_EXTENSIONS = {"pdf"}

def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def _tenant_storage_dir(upload_dir, tenant_id=None):
    resolved_tenant_id = tenant_id
    if resolved_tenant_id in (None, "", 0):
        try:
            resolved_tenant_id = current_tenant_id()
        except NameError:
            resolved_tenant_id = None
    if resolved_tenant_id in (None, "", 0):
        return upload_dir
    tenant_dir = os.path.join(upload_dir, f"tenant-{int(resolved_tenant_id)}")
    os.makedirs(tenant_dir, exist_ok=True)
    return tenant_dir


def _safe_stored_filename(filename):
    raw_name = (filename or "").strip()
    cleaned_name = secure_filename(raw_name)
    if not cleaned_name or cleaned_name != raw_name:
        return ""
    return cleaned_name


def _tenant_file_candidates(upload_dir, filename, tenant_id=None):
    cleaned_name = _safe_stored_filename(filename)
    if not cleaned_name:
        return "", []
    candidates = []
    tenant_dir = _tenant_storage_dir(upload_dir, tenant_id)
    candidates.append((tenant_dir, os.path.join(tenant_dir, cleaned_name)))
    legacy_path = os.path.join(upload_dir, cleaned_name)
    if os.path.abspath(tenant_dir) != os.path.abspath(upload_dir):
        candidates.append((upload_dir, legacy_path))
    return cleaned_name, candidates


def save_uploaded_file(file_storage, upload_dir, prefix):
    if not file_storage or not (file_storage.filename or "").strip():
        return ""
    if not allowed_file(file_storage.filename):
        raise ValueError("Only PDF, JPG and PNG files are allowed")
    original_name = secure_filename(file_storage.filename)
    name_root, ext = os.path.splitext(original_name)
    safe_root = secure_filename(name_root)[:80] or "file"
    stamp = clinic_now().strftime("%Y%m%d%H%M%S")
    token = secrets.token_hex(4)
    saved_name = f"{prefix}_{stamp}_{token}_{safe_root}{ext.lower()}"
    file_storage.save(os.path.join(_tenant_storage_dir(upload_dir), saved_name))
    return saved_name


def delete_uploaded_file(upload_dir, filename):
    cleaned_name, candidates = _tenant_file_candidates(upload_dir, filename)
    if not cleaned_name:
        return
    for _base_dir, file_path in candidates:
        try:
            if os.path.exists(file_path):
                os.remove(file_path)
                return
        except OSError:
            pass


def resolve_tenant_upload_file(upload_dir, filename, tenant_id=None):
    cleaned_name, candidates = _tenant_file_candidates(upload_dir, filename, tenant_id)
    if not cleaned_name:
        return "", "", ""
    for base_dir, file_path in candidates:
        if os.path.exists(file_path):
            return cleaned_name, base_dir, file_path
    return cleaned_name, candidates[0][0], candidates[0][1]


def save_private_lab_report_file(file_storage, order_id):
    """Persist a report PDF outside the public static directory."""
    if not file_storage or not (file_storage.filename or "").strip():
        raise ValueError("Please choose a PDF report file.")
    original_name = secure_filename(file_storage.filename)
    extension = original_name.rsplit(".", 1)[-1].lower() if "." in original_name else ""
    if extension not in LAB_REPORT_EXTENSIONS:
        raise ValueError("Only PDF lab reports are allowed.")
    try:
        header = file_storage.stream.read(5)
        file_storage.stream.seek(0)
    except Exception as exc:
        raise ValueError("Unable to read the uploaded report file.") from exc
    if header != b"%PDF-":
        raise ValueError("The uploaded file is not a valid PDF report.")

    safe_root = secure_filename(os.path.splitext(original_name)[0])[:80] or "report"
    stored_name = (
        f"labreport_{int(order_id)}_{clinic_now().strftime('%Y%m%d%H%M%S')}_"
        f"{secrets.token_hex(8)}_{safe_root}.pdf"
    )
    target_path = os.path.join(_tenant_storage_dir(LAB_REPORT_UPLOAD_FOLDER), stored_name)
    file_storage.save(target_path)
    digest = hashlib.sha256()
    file_size = 0
    try:
        with open(target_path, "rb") as report_file:
            for chunk in iter(lambda: report_file.read(1024 * 1024), b""):
                file_size += len(chunk)
                digest.update(chunk)
    except Exception:
        try:
            os.remove(target_path)
        except OSError:
            pass
        raise
    return {
        "storage_key": stored_name,
        "original_filename": original_name,
        "file_size": file_size,
        "file_sha256": digest.hexdigest(),
        "mime_type": "application/pdf",
    }


def delete_private_lab_report_file(storage_key):
    cleaned_name, candidates = _tenant_file_candidates(LAB_REPORT_UPLOAD_FOLDER, storage_key)
    if not cleaned_name:
        return
    for _base_dir, file_path in candidates:
        try:
            if os.path.exists(file_path):
                os.remove(file_path)
                return
        except OSError:
            pass

def is_async_request():
    return request.headers.get("X-Requested-With") == "XMLHttpRequest"


# ---------------- CSRF PROTECTION ----------------
CSRF_SESSION_KEY = "_csrf_token"
CSRF_FORM_FIELD = "_csrf_token"
CSRF_HEADER = "X-CSRF-Token"
CSRF_UNSAFE_METHODS = {"POST", "PUT", "PATCH", "DELETE"}
# Token-authenticated machine APIs and webhooks never rely on the staff
# browser session, so they are verified by their own signatures instead.
CSRF_EXEMPT_BLUEPRINTS = {"ai_api", "omnidim_gateway", "ai_admin"}
CSRF_EXEMPT_ENDPOINTS = {"login", "generic_telephony_inbound"}
app.config["CSRF_PROTECTION"] = env_flag("CSRF_PROTECTION", True)


def get_csrf_token():
    token = session.get(CSRF_SESSION_KEY)
    if not token:
        token = secrets.token_urlsafe(32)
        session[CSRF_SESSION_KEY] = token
    return token


@app.context_processor
def inject_csrf_token():
    return {"app_csrf_token": get_csrf_token}


def csrf_failure_response():
    message = "Security check failed (form expired). Please reload the page and try again."
    wants_json = (
        is_async_request()
        or request.path.startswith("/api/")
        or "application/json" in (request.headers.get("Accept") or "")
        or request.is_json
    )
    if wants_json:
        response = jsonify({"ok": False, "error": message, "messages": [{"category": "danger", "message": message}]})
        response.status_code = 400
        return response
    flash(message, "danger")
    target = request.referrer or "/"
    try:
        from urllib.parse import urlparse as _urlparse
        parsed = _urlparse(target)
        if parsed.netloc and parsed.netloc != request.host:
            target = "/"
    except Exception:
        target = "/"
    return redirect(target)


@app.before_request
def enforce_csrf_protection():
    if not app.config.get("CSRF_PROTECTION", True):
        return None
    if request.method not in CSRF_UNSAFE_METHODS:
        return None
    if request.blueprint in CSRF_EXEMPT_BLUEPRINTS or request.endpoint in CSRF_EXEMPT_ENDPOINTS:
        return None
    # Only browser sessions of logged-in staff can be abused through CSRF.
    if not session.get("user_id"):
        return None
    expected = session.get(CSRF_SESSION_KEY) or ""
    supplied = (
        request.headers.get(CSRF_HEADER)
        or request.form.get(CSRF_FORM_FIELD)
        or ""
    )
    if not expected or not supplied or not secrets.compare_digest(str(expected), str(supplied)):
        app.logger.warning("CSRF check failed for %s %s", request.method, request.path)
        return csrf_failure_response()
    return None

@app.after_request
def adapt_redirect_for_async(response):
    if not is_async_request():
        final_response = response
    elif response.status_code not in ASYNC_REDIRECT_STATUSES:
        final_response = response
    else:
        flashes = session.get("_flashes", []) or []
        messages = []
        has_error = False
        for category, message in flashes:
            cat = str(category or "info").lower()
            msg = str(message or "").strip()
            if not msg:
                continue
            if cat in ("danger", "error"):
                has_error = True
            messages.append({
                "category": cat,
                "message": msg
            })

        if "_flashes" in session:
            session.pop("_flashes", None)

        payload = {
            "ok": not has_error,
            "redirect_url": response.headers.get("Location"),
            "messages": messages
        }
        async_response = jsonify(payload)
        async_response.status_code = 200
        final_response = async_response

    # Ensure browsers/CDNs don't keep serving stale HTML after redeploy.
    if request.method == "GET" and str(final_response.mimetype or "").lower() == "text/html":
        final_response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
        final_response.headers["Pragma"] = "no-cache"
        final_response.headers["Expires"] = "0"

    final_response.headers["X-App-Release"] = os.environ.get("RAILWAY_GIT_COMMIT_SHA", "local")
    return final_response

def to_int(val):
    return int(val) if val not in (None, "", " ") else 0

def to_float(val):
    return float(val) if val not in (None, "", " ") else 0.0

def is_cash_payment_mode(value):
    return ((value or "CASH").strip().upper() or "CASH") == "CASH"


def is_non_collection_payment_mode(value):
    return ((value or "").strip().upper()) in {"ADJUSTMENT", "CREDIT"}

def to_decimal(val, default="0"):
    if val in (None, "", " "):
        return Decimal(default)
    try:
        return Decimal(str(val))
    except Exception:
        return Decimal(default)

def quantize_decimal(val, places="0.0001"):
    return to_decimal(val).quantize(Decimal(places), rounding=ROUND_HALF_UP)

def decimal_str(val):
    if val is None:
        return "0"
    try:
        return format(val, "f")
    except Exception:
        return str(val)

def parse_pack_qty(val):
    if val in (None, "", " "):
        return None
    v = str(val).strip()
    if not v:
        return None
    try:
        return int(v)
    except ValueError:
        return None


def normalize_medicine_name(value):
    return " ".join(str(value or "").strip().split())


def normalize_medicine_code(value):
    return "".join(str(value or "").strip().upper().split())


AUTO_MEDICINE_CODE_RE = re.compile(r"^([A-Z0-9]{3})(\d{3,})$")


def build_medicine_code_prefix(name):
    normalized_name = normalize_medicine_name(name).upper()
    if not normalized_name:
        return "MED"

    letters = [char for char in normalized_name if char.isalpha()]
    prefix_chars = letters[:3]
    if len(prefix_chars) < 3:
        digits = [char for char in normalized_name if char.isdigit()]
        prefix_chars.extend(digits[: max(0, 3 - len(prefix_chars))])
    while len(prefix_chars) < 3:
        prefix_chars.append("X")
    return "".join(prefix_chars[:3])


def parse_auto_medicine_code(code):
    normalized_code = normalize_medicine_code(code)
    if not normalized_code:
        return "", 0
    match = AUTO_MEDICINE_CODE_RE.fullmatch(normalized_code)
    if not match:
        return "", 0
    return match.group(1), to_int_safe(match.group(2), 0)


def normalize_medicine_name_key(name):
    normalized_name = normalize_medicine_name(name)
    return normalized_name.casefold()


def build_exact_medicine_name_match_expr(column, normalized_name):
    return db.func.lower(db.func.trim(db.func.coalesce(column, ""))) == normalized_name.casefold()


def load_medicines_for_exact_name(normalized_name):
    if not normalized_name:
        return []
    return Medicine.query.filter(
        build_exact_medicine_name_match_expr(Medicine.name, normalized_name)
    ).order_by(Medicine.id.asc()).all()


def load_purchase_items_for_exact_name(normalized_name):
    if not normalized_name:
        return []
    return VendorPurchaseItem.query.filter(
        build_exact_medicine_name_match_expr(VendorPurchaseItem.medicine_name, normalized_name)
    ).order_by(VendorPurchaseItem.id.asc()).all()


def find_next_medicine_code_for_prefix(prefix):
    normalized_prefix = normalize_medicine_code(prefix)[:3]
    if not normalized_prefix:
        normalized_prefix = "MED"

    max_serial = 0
    medicine_prefix_expr = db.func.upper(db.func.coalesce(Medicine.medicine_code, "")).like(f"{normalized_prefix}%")
    purchase_prefix_expr = db.func.upper(db.func.coalesce(VendorPurchaseItem.medicine_code, "")).like(f"{normalized_prefix}%")

    for code_value in db.session.query(Medicine.medicine_code).filter(medicine_prefix_expr).all():
        code_prefix, serial = parse_auto_medicine_code(code_value[0])
        if code_prefix == normalized_prefix and serial > max_serial:
            max_serial = serial
    for code_value in db.session.query(VendorPurchaseItem.medicine_code).filter(purchase_prefix_expr).all():
        code_prefix, serial = parse_auto_medicine_code(code_value[0])
        if code_prefix == normalized_prefix and serial > max_serial:
            max_serial = serial
    return f"{normalized_prefix}{max_serial + 1:03d}"


def resolve_target_medicine_code_for_name(name):
    normalized_name = normalize_medicine_name(name)
    if not normalized_name:
        return ""

    prefix = build_medicine_code_prefix(normalized_name)
    medicine_rows = load_medicines_for_exact_name(normalized_name)
    purchase_rows = load_purchase_items_for_exact_name(normalized_name)

    auto_candidates = []
    for row in medicine_rows + purchase_rows:
        normalized_code = normalize_medicine_code(getattr(row, "medicine_code", ""))
        code_prefix, serial = parse_auto_medicine_code(normalized_code)
        if code_prefix == prefix and serial > 0:
            auto_candidates.append((serial, normalized_code))

    auto_candidates.sort()
    if auto_candidates:
        return auto_candidates[0][1]
    return find_next_medicine_code_for_prefix(prefix)


def sync_medicine_code_for_name(name, target_code=""):
    normalized_name = normalize_medicine_name(name)
    if not normalized_name:
        return {"medicine_updates": 0, "purchase_item_updates": 0, "group_count": 0, "target_code": ""}

    resolved_target_code = normalize_medicine_code(target_code) or resolve_target_medicine_code_for_name(normalized_name)
    medicine_updates = 0
    purchase_item_updates = 0

    for med in load_medicines_for_exact_name(normalized_name):
        if normalize_medicine_code(getattr(med, "medicine_code", "")) != resolved_target_code:
            med.medicine_code = resolved_target_code
            medicine_updates += 1
    for item in load_purchase_items_for_exact_name(normalized_name):
        if normalize_medicine_code(getattr(item, "medicine_code", "")) != resolved_target_code:
            item.medicine_code = resolved_target_code
            purchase_item_updates += 1

    return {
        "medicine_updates": medicine_updates,
        "purchase_item_updates": purchase_item_updates,
        "group_count": 1,
        "target_code": resolved_target_code,
    }


def sync_medicine_codes_to_current_names():
    try:
        db.session.flush()
    except Exception:
        db.session.rollback()
        raise

    medicines = Medicine.query.order_by(Medicine.id.asc()).all()
    if not medicines:
        return {"medicine_updates": 0, "purchase_item_updates": 0, "group_count": 0}

    groups = {}
    for med in medicines:
        normalized_name = normalize_medicine_name(getattr(med, "name", ""))
        if not normalized_name:
            continue
        group_key = normalize_medicine_name_key(normalized_name)
        group = groups.setdefault(group_key, {
            "name": normalized_name,
            "prefix": build_medicine_code_prefix(normalized_name),
            "medicines": [],
            "earliest_id": getattr(med, "id", 0) or 0,
        })
        group["medicines"].append(med)
        med_id = getattr(med, "id", 0) or 0
        if not group["earliest_id"] or (med_id and med_id < group["earliest_id"]):
            group["earliest_id"] = med_id

    sorted_groups = sorted(
        groups.values(),
        key=lambda group: (group.get("earliest_id", 0), group.get("name", "").lower())
    )

    used_codes = set()
    used_serials_by_prefix = {}
    code_map = {}

    for group in sorted_groups:
        prefix = group["prefix"]
        candidates = []
        for med in group["medicines"]:
            code_prefix, serial = parse_auto_medicine_code(getattr(med, "medicine_code", ""))
            if code_prefix == prefix and serial > 0:
                candidates.append((serial, f"{code_prefix}{serial:03d}"))
        candidates.sort()
        for serial, candidate_code in candidates:
            used_serials = used_serials_by_prefix.setdefault(prefix, set())
            if candidate_code in used_codes or serial in used_serials:
                continue
            group["target_code"] = candidate_code
            used_codes.add(candidate_code)
            used_serials.add(serial)
            break

    for group in sorted_groups:
        if group.get("target_code"):
            continue
        prefix = group["prefix"]
        used_serials = used_serials_by_prefix.setdefault(prefix, set())
        next_serial = 1
        while next_serial in used_serials:
            next_serial += 1
        target_code = f"{prefix}{next_serial:03d}"
        group["target_code"] = target_code
        used_codes.add(target_code)
        used_serials.add(next_serial)

    medicine_updates = 0
    for group in sorted_groups:
        code_map[normalize_medicine_name_key(group["name"])] = group["target_code"]
        for med in group["medicines"]:
            if normalize_medicine_code(getattr(med, "medicine_code", "")) != group["target_code"]:
                med.medicine_code = group["target_code"]
                medicine_updates += 1

    purchase_item_updates = 0
    for item in VendorPurchaseItem.query.order_by(VendorPurchaseItem.id.asc()).all():
        name_key = normalize_medicine_name_key(getattr(item, "medicine_name", ""))
        target_code = code_map.get(name_key)
        if not target_code:
            continue
        if normalize_medicine_code(getattr(item, "medicine_code", "")) != target_code:
            item.medicine_code = target_code
            purchase_item_updates += 1

    return {
        "medicine_updates": medicine_updates,
        "purchase_item_updates": purchase_item_updates,
        "group_count": len(sorted_groups),
    }


def build_scoped_medicine_code_sync(names):
    try:
        db.session.flush()
    except Exception:
        db.session.rollback()
        raise

    normalized_names = []
    seen_names = set()
    for name in names or []:
        normalized_name = normalize_medicine_name(name)
        if not normalized_name:
            continue
        name_key = normalized_name.casefold()
        if name_key in seen_names:
            continue
        seen_names.add(name_key)
        normalized_names.append(normalized_name)

    if not normalized_names:
        return {"medicine_updates": 0, "purchase_item_updates": 0, "group_count": 0}

    medicine_updates = 0
    purchase_item_updates = 0

    for normalized_name in normalized_names:
        sync_result = sync_medicine_code_for_name(normalized_name)
        medicine_updates += sync_result["medicine_updates"]
        purchase_item_updates += sync_result["purchase_item_updates"]

    return {
        "medicine_updates": medicine_updates,
        "purchase_item_updates": purchase_item_updates,
        "group_count": len(normalized_names),
    }


def persist_medicine_code_sync():
    try:
        sync_result = sync_medicine_codes_to_current_names()
        db.session.commit()
        return sync_result
    except Exception:
        db.session.rollback()
        app.logger.exception("Unable to persist medicine code sync.")
        return {
            "medicine_updates": 0,
            "purchase_item_updates": 0,
            "group_count": 0,
        }


def persist_medicine_code_sync_for_names(names):
    try:
        sync_result = build_scoped_medicine_code_sync(names)
        db.session.commit()
        return sync_result
    except Exception:
        db.session.rollback()
        app.logger.exception("Unable to persist scoped medicine code sync.")
        return {
            "medicine_updates": 0,
            "purchase_item_updates": 0,
            "group_count": 0,
        }


def summarize_exception_message(exc, limit=180):
    raw_text = str(getattr(exc, "orig", exc) or exc).strip()
    if not raw_text:
        return exc.__class__.__name__
    first_line = " ".join(raw_text.splitlines()[:1]).strip()
    compact = " ".join(first_line.split())
    return compact[:limit]


def build_medicine_name_suggestions(medicines):
    unique_names = {}
    for med in medicines:
        cleaned_name = normalize_medicine_name(getattr(med, "name", ""))
        if not cleaned_name:
            continue
        unique_names.setdefault(cleaned_name.casefold(), cleaned_name)
    return sorted(unique_names.values(), key=str.lower)


def build_medicine_code_lookup(medicines):
    grouped = {}
    for med in medicines:
        code = normalize_medicine_code(getattr(med, "medicine_code", ""))
        name = normalize_medicine_name(getattr(med, "name", ""))
        if not code or not name:
            continue
        grouped.setdefault(code, {})
        grouped[code][name.casefold()] = name

    lookup = {}
    for code, names in grouped.items():
        if len(names) == 1:
            lookup[code] = {"name": next(iter(names.values()))}
    return lookup


def build_medicine_purchase_catalog(medicines):
    catalog = []
    seen = set()
    for med in medicines:
        medicine_name = normalize_medicine_name(getattr(med, "name", ""))
        if not medicine_name:
            continue
        medicine_code = normalize_medicine_code(getattr(med, "medicine_code", ""))
        company = (getattr(med, "company", "") or "").strip()
        pack_type = (getattr(med, "pack_type", "") or "").strip()
        pack_qty = getattr(med, "pack_qty", None)
        barcode = (getattr(med, "barcode", "") or "").strip()
        key = (
            medicine_code
            or f"{medicine_name.casefold()}|{company.casefold()}|{pack_type.casefold()}|{pack_qty or ''}"
        )
        if key in seen:
            continue
        seen.add(key)
        catalog.append({
            "medicine_id": getattr(med, "id", None),
            "medicine_code": medicine_code,
            "medicine_name": medicine_name,
            "barcode": barcode,
            "composition": (getattr(med, "composition", "") or "").strip(),
            "company": company,
            "pack_type": pack_type,
            "pack_qty": pack_qty,
            "mrp": to_float_safe(getattr(med, "mrp", 0), 0),
            "discount_percent": to_float_safe(getattr(med, "discount_percent", 0), 0),
        })
    catalog.sort(key=lambda item: ((0 if item["medicine_code"] else 1), item["medicine_name"].lower()))
    return catalog


def build_recent_purchase_medicine_chips(purchase_items, limit=10):
    chips = []
    seen = set()
    for item in purchase_items:
        medicine_name = normalize_medicine_name(getattr(item, "medicine_name", ""))
        medicine_code = normalize_medicine_code(getattr(item, "medicine_code", ""))
        if not medicine_name:
            continue
        chip_key = medicine_code or medicine_name.casefold()
        if chip_key in seen:
            continue
        seen.add(chip_key)
        chips.append({
            "medicine_code": medicine_code,
            "medicine_name": medicine_name,
        })
        if len(chips) >= limit:
            break
    return chips

def to_int_safe(val, default=0):
    try:
        return int(str(val).strip())
    except (TypeError, ValueError):
        return default

def to_float_safe(val, default=0.0):
    try:
        parsed = float(str(val).strip())
        if not math.isfinite(parsed):
            return default
        return parsed
    except (TypeError, ValueError):
        return default


PUBLIC_PORTAL_OTP_TTL_MINUTES = 5
PUBLIC_PORTAL_SESSION_TTL_MINUTES = 15
PUBLIC_PORTAL_OTP_RESEND_SECONDS = 60
PUBLIC_PORTAL_OTP_WINDOW_MINUTES = 15
PUBLIC_PORTAL_OTP_MAX_SENDS = 3
PUBLIC_PORTAL_OTP_MAX_ATTEMPTS = 5


def portal_request_ip():
    forwarded = (request.headers.get("X-Forwarded-For") or "").split(",")[0].strip()
    return (forwarded or request.remote_addr or "")[:80]


def create_portal_otp_challenge(*, mobile, purpose, context_ref=None):
    normalized_mobile = normalize_portal_mobile(mobile)
    normalized_purpose = (purpose or "").strip().upper()[:30]
    context_value = (context_ref or "").strip()[:100] or None
    if len(normalized_mobile) < 10 or not normalized_purpose:
        return None, "", "Please enter a valid mobile number."

    now = datetime.utcnow()
    query = PortalOtpChallenge.query.filter_by(
        mobile=normalized_mobile,
        purpose=normalized_purpose,
    )
    if context_value:
        query = query.filter(PortalOtpChallenge.context_ref == context_value)
    else:
        query = query.filter(PortalOtpChallenge.context_ref.is_(None))
    latest = query.order_by(PortalOtpChallenge.sent_at.desc(), PortalOtpChallenge.id.desc()).first()
    if latest and latest.sent_at and (now - latest.sent_at).total_seconds() < PUBLIC_PORTAL_OTP_RESEND_SECONDS:
        return None, "", "Please wait one minute before requesting another OTP."

    window_start = now - timedelta(minutes=PUBLIC_PORTAL_OTP_WINDOW_MINUTES)
    sent_count = PortalOtpChallenge.query.filter(
        PortalOtpChallenge.mobile == normalized_mobile,
        PortalOtpChallenge.sent_at >= window_start,
    ).count()
    if sent_count >= PUBLIC_PORTAL_OTP_MAX_SENDS:
        return None, "", "Too many OTP requests. Please try again after 15 minutes."

    otp_code = f"{secrets.randbelow(900000) + 100000:06d}"
    challenge = PortalOtpChallenge(
        purpose=normalized_purpose,
        context_ref=context_value,
        mobile=normalized_mobile,
        otp_hash=generate_password_hash(otp_code, method="pbkdf2:sha256"),
        attempt_count=0,
        max_attempts=PUBLIC_PORTAL_OTP_MAX_ATTEMPTS,
        sent_at=now,
        expires_at=now + timedelta(minutes=PUBLIC_PORTAL_OTP_TTL_MINUTES),
        request_ip=portal_request_ip(),
        request_user_agent=(request.headers.get("User-Agent") or "")[:255],
    )
    try:
        db.session.add(challenge)
        db.session.commit()
    except Exception:
        db.session.rollback()
        app.logger.exception("Unable to create public portal OTP challenge")
        return None, "", "Unable to start verification right now. Please try again."

    sent, development_code, delivery_error = send_portal_otp(
        mobile=normalized_mobile,
        code=otp_code,
        purpose=normalized_purpose.replace("_", " ").title(),
        is_production=IS_PROD,
        testing=bool(app.config.get("TESTING")),
    )
    if sent:
        return challenge, development_code, ""

    try:
        db.session.delete(challenge)
        db.session.commit()
    except Exception:
        db.session.rollback()
    return None, "", delivery_error or "Unable to send the verification code right now."


def verify_portal_otp_challenge(*, mobile, purpose, otp_code, context_ref=None):
    normalized_mobile = normalize_portal_mobile(mobile)
    normalized_purpose = (purpose or "").strip().upper()[:30]
    context_value = (context_ref or "").strip()[:100] or None
    submitted_code = (otp_code or "").strip()
    if not normalized_mobile or not normalized_purpose or len(submitted_code) != 6 or not submitted_code.isdigit():
        return None, "Enter the six-digit verification code."

    query = PortalOtpChallenge.query.filter_by(
        mobile=normalized_mobile,
        purpose=normalized_purpose,
    )
    if context_value:
        query = query.filter(PortalOtpChallenge.context_ref == context_value)
    else:
        query = query.filter(PortalOtpChallenge.context_ref.is_(None))
    challenge = query.order_by(PortalOtpChallenge.sent_at.desc(), PortalOtpChallenge.id.desc()).first()
    now = datetime.utcnow()
    if not challenge or not challenge.expires_at or challenge.expires_at < now:
        return None, "This verification code has expired. Please request a new OTP."
    if challenge.verified_at or challenge.attempt_count >= challenge.max_attempts:
        return None, "This verification code is no longer valid. Please request a new OTP."

    challenge.attempt_count += 1
    try:
        valid = check_password_hash(challenge.otp_hash, submitted_code)
    except (ValueError, AttributeError):
        valid = False
    if not valid:
        try:
            db.session.commit()
        except Exception:
            db.session.rollback()
        remaining = max(0, challenge.max_attempts - challenge.attempt_count)
        return None, "Invalid verification code." if remaining else "Too many invalid attempts. Please request a new OTP."

    challenge.verified_at = now
    try:
        db.session.commit()
    except Exception:
        db.session.rollback()
        return None, "Unable to complete verification right now. Please try again."
    return challenge, ""


def set_public_portal_session(session_key, mobile):
    session[session_key] = {
        "mobile": normalize_portal_mobile(mobile),
        "expires_at": (datetime.utcnow() + timedelta(minutes=PUBLIC_PORTAL_SESSION_TTL_MINUTES)).timestamp(),
    }
    session.modified = True


def get_public_portal_session_mobile(session_key):
    payload = session.get(session_key)
    if not isinstance(payload, dict):
        return ""
    mobile = normalize_portal_mobile(payload.get("mobile"))
    expires_at = to_float_safe(payload.get("expires_at"), 0)
    if not mobile or expires_at <= datetime.utcnow().timestamp():
        session.pop(session_key, None)
        session.modified = True
        return ""
    return mobile


def build_lab_report_audit_snapshot(report):
    """Return the non-file metadata needed to audit a lab-report action."""
    if not report:
        return None
    return {
        "id": report.id,
        "lab_order_id": report.lab_order_id,
        "patient_id": report.patient_id,
        "patient_name": (report.patient_name or "").strip(),
        "mobile": mask_mobile(report.mobile),
        "title": (report.title or "").strip(),
        "report_date": report.report_date.isoformat() if report.report_date else None,
        "original_filename": (report.original_filename or "").strip(),
        "file_size": to_int_safe(report.file_size, 0),
        "file_sha256": (report.file_sha256 or "").strip(),
        "status": (report.status or "").strip().upper(),
        "uploaded_by": (report.uploaded_by or "").strip(),
        "published_by": (report.published_by or "").strip(),
        "revoked_by": (report.revoked_by or "").strip(),
        "download_count": to_int_safe(report.download_count, 0),
    }


def normalize_public_report_mobile(value):
    """Canonical Indian mobile number used only by the public report portal."""
    digits = "".join(ch for ch in str(value or "") if ch.isdigit())
    if len(digits) == 12 and digits.startswith("91"):
        digits = digits[2:]
    return digits if len(digits) == 10 else ""


def resolve_public_portal_tenant_id():
    raw_identifier = (
        request.args.get("tenant")
        or request.form.get("tenant")
        or session.get("lab_report_portal_tenant")
        or ""
    ).strip()
    tenant = tenant_from_identifier(raw_identifier) if raw_identifier else None
    if not tenant:
        with tenant_scope_disabled():
            tenant = Tenant.query.order_by(Tenant.id.asc()).first() if Tenant.query.count() == 1 else None
    if tenant and tenant_login_allowed(tenant):
        session["lab_report_portal_tenant"] = tenant.tenant_code
        session["lab_report_portal_tenant_id"] = tenant.id
        session.modified = True
        return tenant.id
    session.pop("lab_report_portal_tenant", None)
    session.pop("lab_report_portal_tenant_id", None)
    session.modified = True
    return None


def private_lab_report_path(storage_key):
    """Resolve a report key only when it is a safe filename inside private storage."""
    cleaned_key, _base_dir, file_path = resolve_tenant_upload_file(LAB_REPORT_UPLOAD_FOLDER, storage_key)
    return cleaned_key, file_path


def lab_report_download_name(report):
    filename = secure_filename((report.original_filename or "").strip())
    if not filename:
        filename = f"lab-report-{report.id}.pdf"
    if not filename.lower().endswith(".pdf"):
        filename = f"{filename}.pdf"
    return filename


POS_PAYMENT_MODES = ("CASH", "ONLINE", "UPI", "CARD", "WALLET", "ADJUSTMENT", "CREDIT")
INVOICE_PRINT_PROFILE_CUTOVER = date(2026, 7, 1)
OPERATIONS_FRESH_START_DATE = INVOICE_PRINT_PROFILE_CUTOVER
FRESH_START_PUBLIC_NUMBER_WIDTH = 5
STOCK_SALE_REENTRY_VENDOR_NAME = "DR ABHISHEK PRAKASH"
STOCK_SALE_DEFAULT_CUSTOMER = "STOCK SALE"
STOCK_SALE_DEFAULT_PAYMENT_MODE = "ADJUSTMENT"
STOCK_SALE_DEFAULT_LINES_PER_INVOICE = 50
STOCK_SALE_MAX_LINES_PER_INVOICE = 200
LEGACY_INVOICE_PRINT_PROFILE = {
    "profile_code": "legacy_pre_2026_07",
    "address_line_1": "FF22 SECOND FLOOR, MANGALAM ANANDA PLAZA, SANGANER",
    "address_line_2": "JAIPUR, RAJASTHAN",
    "mobile": "9024648186",
    "gst_no": "08BPWPP5023C1ZP",
    "licence_no": "",
    "logo_path": "/static/endo-pharmacy-logo.png",
}
CURRENT_INVOICE_PRINT_PROFILE = {
    "profile_code": "endo_pharmacy_2026_07",
    "address_line_1": "SHOP NO. FF12, 2ND FLOOR, MANGLAM AANANDA PLAZA, SANGANER",
    "address_line_2": "JAIPUR, RAJASTHAN",
    "mobile": "9024648186",
    "gst_no": "08ABAFT0637R1ZP",
    "licence_no": "DRUG/2026-27/154505",
    "logo_path": "/static/endo-pharmacy-logo.png",
}


def tenant_settings_dict(tenant=None):
    if tenant is None:
        tenant_id = None
        try:
            tenant_id = current_tenant_id()
        except NameError:
            tenant_id = None
        if tenant_id:
            tenant = Tenant.query.filter(Tenant.id == tenant_id).first()
    raw_settings = getattr(getattr(tenant, "settings", None), "settings_json", "") or "{}"
    try:
        parsed = json.loads(raw_settings)
    except (TypeError, ValueError):
        parsed = {}
    return parsed if isinstance(parsed, dict) else {}


def tenant_business_identity(tenant=None):
    if tenant is None:
        tenant_id = current_tenant_id()
        if tenant_id:
            tenant = Tenant.query.filter(Tenant.id == tenant_id).first()
    settings = tenant_settings_dict(tenant)
    address_lines = [
        line.strip()
        for line in re.split(r"[\r\n]+", getattr(tenant, "business_address", "") or "")
        if line.strip()
    ]
    locality = ", ".join(
        value for value in (
            str(settings.get("city") or "").strip(),
            str(settings.get("state") or "").strip(),
            str(settings.get("pin_code") or "").strip(),
        ) if value
    )
    if locality:
        address_lines.append(locality)
    logo_path = str(settings.get("logo_path") or "").strip()
    if logo_path.startswith("/tenant-business-logo/"):
        filename = logo_path.rsplit("/", 1)[-1]
        if not _safe_stored_filename(filename) or "/" in filename:
            logo_path = ""
    elif (
        not logo_path.startswith("/static/")
        or ".." in logo_path.split("/")
        or any(character in logo_path for character in "?#\\")
    ):
        logo_path = ""
    return {
        "pharmacy_name": (getattr(tenant, "pharmacy_name", "") or "").strip(),
        "legal_business_name": (settings.get("legal_business_name") or "").strip(),
        "owner_name": (getattr(tenant, "owner_name", "") or "").strip(),
        "business_type": (settings.get("business_type") or "").strip(),
        "mobile": (getattr(tenant, "contact_number", "") or "").strip(),
        "alternate_mobile": (settings.get("alternate_mobile") or "").strip(),
        "email": (getattr(tenant, "email", "") or "").strip(),
        "address_line_1": address_lines[0] if address_lines else "",
        "address_line_2": ", ".join(address_lines[1:]) if len(address_lines) > 1 else "",
        "gst_no": (getattr(tenant, "gstin", "") or "").strip(),
        "licence_no": (getattr(tenant, "drug_license", "") or "").strip(),
        "logo_path": logo_path,
        "invoice_header": (settings.get("invoice_header") or "").strip(),
        "invoice_footer": (settings.get("invoice_footer") or "").strip(),
        "invoice_terms": (settings.get("invoice_terms") or "").strip(),
        "authorized_signatory": (settings.get("authorized_signatory") or "").strip(),
        "invoice_prefix": (settings.get("invoice_prefix") or "INV").strip(),
    }


def update_tenant_settings(tenant, updates):
    if not tenant:
        return {}
    settings = tenant.settings
    if not settings:
        settings = TenantSettings(settings_json="{}")
        db.session.add(settings)
        tenant.settings = settings
    current = tenant_settings_dict(tenant)
    for key, value in (updates or {}).items():
        current[key] = value
    settings.settings_json = json.dumps(current, sort_keys=True)
    return current


def tenant_business_prefix(kind, tenant=None):
    settings = tenant_settings_dict(tenant)
    default_prefix = {"invoice": "INV", "purchase": "PB", "return": "RB"}.get(kind, "INV")
    raw_prefix = settings.get(f"{kind}_prefix") or default_prefix
    prefix = re.sub(r"[^A-Za-z0-9]+", "", str(raw_prefix).upper())[:8]
    return prefix or default_prefix


def tenant_invoice_print_profile(base_profile, tenant=None):
    if tenant is None:
        tenant_id = None
        try:
            tenant_id = current_tenant_id()
        except NameError:
            tenant_id = None
        if tenant_id:
            tenant = Tenant.query.filter(Tenant.id == tenant_id).first()
    if not tenant:
        return base_profile
    identity = tenant_business_identity(tenant)
    base_profile.update({
        "profile_code": f"tenant_{tenant.id}",
        "pharmacy_name": identity["pharmacy_name"],
        "legal_business_name": identity["legal_business_name"],
        "address_line_1": identity["address_line_1"],
        "address_line_2": identity["address_line_2"],
        "mobile": identity["mobile"],
        "alternate_mobile": identity["alternate_mobile"],
        "gst_no": identity["gst_no"],
        "licence_no": identity["licence_no"],
        "logo_path": identity["logo_path"],
        "invoice_header": identity["invoice_header"],
        "invoice_footer": identity["invoice_footer"],
        "invoice_terms": identity["invoice_terms"],
        "authorized_signatory": identity["authorized_signatory"],
        "invoice_terms": identity["invoice_terms"],
    })
    return base_profile


def normalize_payment_mode(value, default="CASH"):
    mode = (value or default).strip().upper() or default
    if mode not in POS_PAYMENT_MODES:
        return default
    return mode


def round_currency(value):
    return round(to_float_safe(value, 0.0), 2)


def _clone_invoice_print_profile(profile):
    return {
        "profile_code": profile.get("profile_code", ""),
        "pharmacy_name": profile.get("pharmacy_name", ""),
        "legal_business_name": profile.get("legal_business_name", ""),
        "address_line_1": profile.get("address_line_1", ""),
        "address_line_2": profile.get("address_line_2", ""),
        "mobile": profile.get("mobile", ""),
        "alternate_mobile": profile.get("alternate_mobile", ""),
        "gst_no": profile.get("gst_no", ""),
        "licence_no": profile.get("licence_no", ""),
        "logo_path": profile.get("logo_path", ""),
        "invoice_header": profile.get("invoice_header", ""),
        "invoice_footer": profile.get("invoice_footer", ""),
        "invoice_terms": profile.get("invoice_terms", ""),
        "authorized_signatory": profile.get("authorized_signatory", ""),
    }


def _invoice_profile_local_date(value=None):
    if isinstance(value, datetime):
        return storage_datetime_to_local_date(value) or value.date()
    if isinstance(value, date):
        return value
    return clinic_now().date()


def get_operations_fresh_start_date():
    return OPERATIONS_FRESH_START_DATE


def is_post_operations_fresh_start(value=None):
    return _invoice_profile_local_date(value) >= get_operations_fresh_start_date()


def floor_start_date_to_operations_fresh_start(start_date, end_date=None):
    if not start_date:
        return start_date
    fresh_start = get_operations_fresh_start_date()
    if end_date and end_date < fresh_start:
        return start_date
    return max(start_date, fresh_start)


def _extract_fresh_start_public_sequence(value, prefix):
    raw_value = str(value or "").strip().upper()
    match = re.fullmatch(
        rf"{re.escape(prefix)}-(\d{{{FRESH_START_PUBLIC_NUMBER_WIDTH}}})",
        raw_value,
    )
    if not match:
        return None
    return to_int_safe(match.group(1), 0) or None


def _next_fresh_start_public_sequence(model, field_name, prefix, effective_date, date_field_name, tenant_id=None):
    if not is_post_operations_fresh_start(effective_date):
        return None
    fresh_start_date = get_operations_fresh_start_date()
    start_bound, _unused_end = local_date_range_to_storage_bounds(fresh_start_date, fresh_start_date)
    field = getattr(model, field_name)
    date_field = getattr(model, date_field_name)
    query = db.session.query(field).filter(date_field >= start_bound)
    if hasattr(model, "tenant_id"):
        scoped_tenant_id = tenant_id if tenant_id not in (None, "", 0) else current_tenant_id()
        if scoped_tenant_id not in (None, "", 0):
            query = query.filter(model.tenant_id == int(scoped_tenant_id))
    values = query.all()
    max_sequence = 0
    for (raw_value,) in values:
        parsed_sequence = _extract_fresh_start_public_sequence(raw_value, prefix)
        if parsed_sequence and parsed_sequence > max_sequence:
            max_sequence = parsed_sequence
    return max_sequence + 1


def build_fresh_start_invoice_no(effective_date=None, tenant=None):
    prefix = tenant_business_prefix("invoice", tenant)
    sequence = _next_fresh_start_public_sequence(
        Invoice,
        "invoice_no",
        prefix,
        effective_date,
        "created_at",
        getattr(tenant, "id", None),
    )
    if not sequence:
        return None
    return f"{prefix}-{sequence:0{FRESH_START_PUBLIC_NUMBER_WIDTH}d}"


def build_fresh_start_purchase_no(effective_date=None, tenant=None):
    prefix = tenant_business_prefix("purchase", tenant)
    sequence = _next_fresh_start_public_sequence(
        VendorPurchase,
        "purchase_no",
        prefix,
        effective_date,
        "purchase_date",
        getattr(tenant, "id", None),
    )
    if not sequence:
        return None
    return f"{prefix}-{sequence:0{FRESH_START_PUBLIC_NUMBER_WIDTH}d}"


def assign_return_number(return_bill, effective_date=None):
    tenant = None
    tenant_id = getattr(return_bill, "tenant_id", None) or current_tenant_id()
    if tenant_id:
        tenant = Tenant.query.filter(Tenant.id == int(tenant_id)).first()
    prefix = tenant_business_prefix("return", tenant)
    return_bill.return_no = f"{prefix}-{return_bill.id:06d}"
    return return_bill.return_no


def assign_invoice_number(invoice, effective_date=None):
    local_date = _invoice_profile_local_date(effective_date or getattr(invoice, "created_at", None))
    tenant = None
    tenant_id = getattr(invoice, "tenant_id", None) or current_tenant_id()
    if tenant_id:
        tenant = Tenant.query.filter(Tenant.id == int(tenant_id)).first()
    if is_post_operations_fresh_start(local_date):
        invoice.invoice_no = build_fresh_start_invoice_no(local_date, tenant)
    else:
        invoice.invoice_no = f"{tenant_business_prefix('invoice', tenant)}-{local_date.year}-{1000 + invoice.id}"
    return invoice.invoice_no


def assign_purchase_number(purchase, effective_date=None):
    purchase_date = effective_date or getattr(purchase, "purchase_date", None) or getattr(purchase, "created_at", None)
    local_date = _invoice_profile_local_date(purchase_date)
    tenant = None
    tenant_id = getattr(purchase, "tenant_id", None) or current_tenant_id()
    if tenant_id:
        tenant = Tenant.query.filter(Tenant.id == int(tenant_id)).first()
    if is_post_operations_fresh_start(local_date):
        if tenant_id and db.engine.dialect.name.lower() == "postgresql":
            db.session.execute(
                text("SELECT pg_advisory_xact_lock(:lock_scope, :tenant_id)"),
                {"lock_scope": 74101, "tenant_id": int(tenant_id)},
            )
        purchase.purchase_no = build_fresh_start_purchase_no(local_date, tenant)
    else:
        purchase.purchase_no = f"{tenant_business_prefix('purchase', tenant)}-{purchase.id:06d}"
    return purchase.purchase_no


def get_invoice_print_profile_for_date(value=None):
    effective_date = _invoice_profile_local_date(value)
    if effective_date < INVOICE_PRINT_PROFILE_CUTOVER:
        profile = _clone_invoice_print_profile(LEGACY_INVOICE_PRINT_PROFILE)
    else:
        profile = _clone_invoice_print_profile(CURRENT_INVOICE_PRINT_PROFILE)
    return tenant_invoice_print_profile(profile)


def build_invoice_print_profile_snapshot(value=None):
    profile = get_invoice_print_profile_for_date(value)
    return {
        "print_profile_code": profile["profile_code"],
        "print_pharmacy_name": profile.get("pharmacy_name", ""),
        "print_legal_business_name": profile.get("legal_business_name", ""),
        "print_address_line_1": profile["address_line_1"],
        "print_address_line_2": profile["address_line_2"],
        "print_mobile": profile["mobile"],
        "print_alternate_mobile": profile.get("alternate_mobile", ""),
        "print_gst_no": profile["gst_no"],
        "print_licence_no": profile["licence_no"],
        "print_logo_path": profile["logo_path"],
        "print_invoice_header": profile.get("invoice_header", ""),
        "print_invoice_footer": profile.get("invoice_footer", ""),
        "print_invoice_terms": profile.get("invoice_terms", ""),
        "print_authorized_signatory": profile.get("authorized_signatory", ""),
    }


def apply_invoice_print_profile(invoice, value=None, *, include_business_identity=True):
    snapshot = build_invoice_print_profile_snapshot(value or getattr(invoice, "created_at", None))
    if not include_business_identity:
        for field in (
            "print_pharmacy_name",
            "print_legal_business_name",
            "print_alternate_mobile",
            "print_invoice_header",
            "print_invoice_footer",
            "print_invoice_terms",
            "print_authorized_signatory",
        ):
            snapshot.pop(field, None)
    for field, field_value in snapshot.items():
        setattr(invoice, field, field_value)
    return snapshot


def resolve_invoice_print_profile(invoice):
    tenant = None
    tenant_id = getattr(invoice, "tenant_id", None) or current_tenant_id()
    if tenant_id:
        tenant = Tenant.query.filter(Tenant.id == int(tenant_id)).first()
    base_profile = _clone_invoice_print_profile(
        LEGACY_INVOICE_PRINT_PROFILE
        if _invoice_profile_local_date(getattr(invoice, "created_at", None)) < INVOICE_PRINT_PROFILE_CUTOVER
        else CURRENT_INVOICE_PRINT_PROFILE
    )
    has_business_snapshot = getattr(invoice, "print_pharmacy_name", None) is not None
    profile = tenant_invoice_print_profile(
        base_profile, tenant if has_business_snapshot else None
    )
    field_mapping = {
        "profile_code": "print_profile_code",
        "pharmacy_name": "print_pharmacy_name",
        "legal_business_name": "print_legal_business_name",
        "address_line_1": "print_address_line_1",
        "address_line_2": "print_address_line_2",
        "mobile": "print_mobile",
        "alternate_mobile": "print_alternate_mobile",
        "gst_no": "print_gst_no",
        "licence_no": "print_licence_no",
        "logo_path": "print_logo_path",
        "invoice_header": "print_invoice_header",
        "invoice_footer": "print_invoice_footer",
        "invoice_terms": "print_invoice_terms",
        "authorized_signatory": "print_authorized_signatory",
    }
    for profile_key, invoice_field in field_mapping.items():
        raw_value = getattr(invoice, invoice_field, None)
        if raw_value is None:
            if profile_key in {
                "pharmacy_name", "legal_business_name", "alternate_mobile",
                "invoice_header", "invoice_footer", "invoice_terms",
                "authorized_signatory",
            }:
                profile[profile_key] = ""
            continue
        if isinstance(raw_value, str):
            if (
                not raw_value.strip()
                and profile_key != "licence_no"
                and not has_business_snapshot
            ):
                continue
            profile[profile_key] = raw_value.strip()
            continue
        profile[profile_key] = raw_value
    return profile


def backfill_invoice_print_profiles():
    invoices = Invoice.query.filter(
        or_(
            Invoice.print_profile_code.is_(None),
            Invoice.print_address_line_1.is_(None),
            Invoice.print_address_line_2.is_(None),
            Invoice.print_mobile.is_(None),
            Invoice.print_gst_no.is_(None),
            Invoice.print_licence_no.is_(None),
            Invoice.print_logo_path.is_(None),
        )
    ).all()
    updated = 0
    for invoice in invoices:
        apply_invoice_print_profile(
            invoice,
            getattr(invoice, "created_at", None),
            include_business_identity=False,
        )
        updated += 1
    if updated:
        db.session.commit()
    return updated


def sync_invoice_print_profiles_to_cutover():
    invoices = Invoice.query.all()
    updated = 0
    for invoice in invoices:
        expected_snapshot = build_invoice_print_profile_snapshot(getattr(invoice, "created_at", None))
        for field in (
            "print_pharmacy_name",
            "print_legal_business_name",
            "print_alternate_mobile",
            "print_invoice_header",
            "print_invoice_footer",
            "print_invoice_terms",
            "print_authorized_signatory",
        ):
            expected_snapshot.pop(field, None)
        changed = False
        for field, expected_value in expected_snapshot.items():
            if getattr(invoice, field, None) != expected_value:
                setattr(invoice, field, expected_value)
                changed = True
        if changed:
            updated += 1
    if updated:
        db.session.commit()
    return updated


def compute_invoice_rounded_total(total_amount):
    rounded_amount = to_decimal(total_amount).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
    return float(rounded_amount.quantize(Decimal("0.00"), rounding=ROUND_HALF_UP))


def build_expiring_medicines_query(reference_date=None):
    current_day = reference_date or clinic_now().date()
    today_iso = current_day.isoformat()
    expiry_limit_iso = (current_day + timedelta(days=30)).isoformat()
    return Medicine.query.filter(
        Medicine.expiry >= today_iso,
        Medicine.expiry <= expiry_limit_iso,
    )


def parse_optional_money(raw_value):
    if raw_value in (None, "", " "):
        return None, None
    raw_text = str(raw_value).strip()
    if not raw_text:
        return None, None
    try:
        amount = Decimal(raw_text)
    except Exception:
        return None, "Cash amount must be a valid number."
    if amount < 0:
        return None, "Cash amount cannot be negative."
    return float(amount.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)), None


def calculate_invoice_payment_breakdown(*, payment_mode="CASH", rounded_amount=0, split_cash_amount_raw=None):
    normalized_mode = normalize_payment_mode(payment_mode)
    payable_amount = max(round_currency(rounded_amount), 0.0)
    split_cash_amount, split_error = parse_optional_money(split_cash_amount_raw)
    if split_error:
        return None, split_error
    split_cash_amount = split_cash_amount or 0.0
    if split_cash_amount > payable_amount:
        return None, "Cash amount cannot exceed total bill amount."

    if split_cash_amount > 0 and split_cash_amount < payable_amount and (
        is_cash_payment_mode(normalized_mode) or is_non_collection_payment_mode(normalized_mode)
    ):
        return None, "Select an online payment mode for the online portion of split payment."

    if split_cash_amount <= 0:
        cash_amount = payable_amount if is_cash_payment_mode(normalized_mode) else 0.0
        if is_cash_payment_mode(normalized_mode) or is_non_collection_payment_mode(normalized_mode):
            online_amount = 0.0
        else:
            online_amount = payable_amount
    else:
        cash_amount = split_cash_amount
        online_amount = round_currency(payable_amount - split_cash_amount)

    effective_mode = normalized_mode
    if online_amount <= 0 and cash_amount > 0:
        effective_mode = "CASH"

    return {
        "payment_mode": effective_mode,
        "cash_amount": round_currency(cash_amount),
        "online_amount": round_currency(online_amount),
        "rounded_amount": payable_amount,
        "is_split_payment": cash_amount > 0 and online_amount > 0,
    }, None


def build_invoice_payment_breakdown(invoice, rounded_amount=None):
    normalized_mode = normalize_payment_mode(getattr(invoice, "payment_mode", "CASH"))
    payable_amount = compute_invoice_rounded_total(
        rounded_amount
        if rounded_amount is not None
        else getattr(invoice, "total", getattr(invoice, "subtotal", 0))
    )
    stored_cash_amount = round_currency(getattr(invoice, "cash_amount", 0))
    stored_online_amount = round_currency(getattr(invoice, "online_amount", 0))
    stored_is_split = bool(getattr(invoice, "is_split_payment", False))
    has_explicit_breakdown = stored_is_split or stored_cash_amount > 0 or stored_online_amount > 0

    if not has_explicit_breakdown:
        if is_cash_payment_mode(normalized_mode):
            stored_cash_amount = payable_amount
            stored_online_amount = 0.0
        elif is_non_collection_payment_mode(normalized_mode):
            stored_cash_amount = 0.0
            stored_online_amount = 0.0
        else:
            stored_cash_amount = 0.0
            stored_online_amount = payable_amount

    is_split = stored_cash_amount > 0 and stored_online_amount > 0
    if is_split:
        payment_type = "Split Payment"
        display_mode = f"Cash + {normalized_mode}"
    elif stored_cash_amount > 0 and stored_online_amount <= 0:
        payment_type = "Cash"
        display_mode = "CASH"
    else:
        payment_type = normalized_mode
        display_mode = normalized_mode

    return {
        "rounded_amount": payable_amount,
        "cash_amount": round_currency(stored_cash_amount),
        "online_amount": round_currency(stored_online_amount),
        "is_split_payment": is_split,
        "payment_mode": normalized_mode,
        "payment_type": payment_type,
        "display_mode": display_mode,
    }


def build_return_payment_breakdown(return_bill, refund_amount=None):
    normalized_mode = normalize_payment_mode(getattr(return_bill, "payment_mode", "CASH"))
    refundable_amount = max(
        round_currency(
            refund_amount
            if refund_amount is not None
            else getattr(return_bill, "total_refund", 0)
        ),
        0.0,
    )
    stored_cash_amount = round_currency(getattr(return_bill, "cash_refund_amount", 0))
    stored_online_amount = round_currency(getattr(return_bill, "online_refund_amount", 0))
    stored_is_split = bool(getattr(return_bill, "is_split_refund", False))
    has_explicit_breakdown = stored_is_split or stored_cash_amount > 0 or stored_online_amount > 0

    if not has_explicit_breakdown:
        if is_cash_payment_mode(normalized_mode):
            stored_cash_amount = refundable_amount
            stored_online_amount = 0.0
        elif is_non_collection_payment_mode(normalized_mode):
            stored_cash_amount = 0.0
            stored_online_amount = 0.0
        else:
            stored_cash_amount = 0.0
            stored_online_amount = refundable_amount

    is_split = stored_cash_amount > 0 and stored_online_amount > 0
    if is_split:
        refund_type = "Split Refund"
        display_mode = f"Cash + {normalized_mode}"
    elif stored_cash_amount > 0 and stored_online_amount <= 0:
        refund_type = "Cash Refund"
        display_mode = "CASH"
    elif stored_online_amount > 0 and stored_cash_amount <= 0:
        refund_type = f"{normalized_mode} Refund"
        display_mode = normalized_mode
    else:
        refund_type = "Adjustment Refund" if is_non_collection_payment_mode(normalized_mode) else normalized_mode
        display_mode = normalized_mode

    return {
        "refund_amount": refundable_amount,
        "cash_refund_amount": round_currency(stored_cash_amount),
        "online_refund_amount": round_currency(stored_online_amount),
        "is_split_refund": is_split,
        "payment_mode": normalized_mode,
        "refund_type": refund_type,
        "display_mode": display_mode,
    }


def return_window_days():
    return env_int("RETURN_WINDOW_DAYS", 15, minimum=0, maximum=365)


def is_invoice_return_window_open(invoice):
    if not invoice or not getattr(invoice, "created_at", None):
        return True
    local_created = storage_datetime_to_local(invoice.created_at) or invoice.created_at
    return local_created.date() >= clinic_now().date() - timedelta(days=return_window_days())


def is_cold_chain_medicine(medicine=None, item=None):
    values = []
    if medicine:
        values.extend([
            getattr(medicine, "name", ""),
            getattr(medicine, "composition", ""),
            getattr(medicine, "company", ""),
            getattr(medicine, "pack_type", ""),
        ])
    if item:
        values.extend([getattr(item, "name", "")])
    haystack = " ".join(str(v or "") for v in values).lower()
    cold_keywords = (
        "cold chain",
        "cold-chain",
        "refrigerated",
        "refrigeration",
        "fridge",
        "insulin",
        "vaccine",
    )
    return any(keyword in haystack for keyword in cold_keywords)


# ---------------- GST (MRP is GST-inclusive) ----------------
GST_RATE_CHOICES = (0, 5, 12, 18, 28, 40)
SCHEDULE_TYPE_CHOICES = ("", "H", "H1", "X")


def default_gst_percent():
    try:
        value = float(str(os.environ.get("DEFAULT_GST_PERCENT", "5")).strip())
    except (TypeError, ValueError):
        value = 5.0
    return min(max(value, 0.0), 40.0)


def normalize_gst_percent(value, default=None):
    """Return a GST rate between 0 and 40, or ``default`` when blank/invalid."""
    if value is None or (isinstance(value, str) and not value.strip()):
        return default
    try:
        rate = float(str(value).strip().rstrip("%"))
    except (TypeError, ValueError):
        return default
    if rate < 0 or rate > 40:
        return default
    return round(rate, 2)


def normalize_schedule_type(value):
    cleaned = str(value or "").strip().upper().replace("SCHEDULE", "").replace(" ", "")
    return cleaned if cleaned in SCHEDULE_TYPE_CHOICES else ""


def backfill_medicine_gst_from_purchases():
    """One-time fill of empty medicine GST rates from their latest purchase lot."""
    pending = Medicine.query.filter(Medicine.gst_percent.is_(None)).all()
    if not pending:
        return 0
    updated = 0
    for med in pending:
        lot = (
            VendorPurchaseItem.query.filter(
                VendorPurchaseItem.medicine_id == med.id,
                VendorPurchaseItem.gst_percent > 0,
            )
            .order_by(VendorPurchaseItem.created_at.desc(), VendorPurchaseItem.id.desc())
            .first()
        )
        med.gst_percent = normalize_gst_percent(getattr(lot, "gst_percent", None), default_gst_percent())
        updated += 1
    db.session.commit()
    return updated


def medicine_form_choices():
    return {
        "gst_rate_choices": GST_RATE_CHOICES,
        "schedule_choices": [
            ("", "Not scheduled (OTC / general)"),
            ("H", "Schedule H (prescription)"),
            ("H1", "Schedule H1 (register required)"),
            ("X", "Schedule X (register required)"),
        ],
    }


def medicine_gst_percent(medicine):
    rate = normalize_gst_percent(getattr(medicine, "gst_percent", None), None)
    return default_gst_percent() if rate is None else rate


def split_inclusive_gst(inclusive_amount, gst_percent):
    """Split a GST-inclusive amount into taxable value, CGST and SGST.

    Example: ₹105 at 5% -> taxable ₹100, GST ₹5 (CGST ₹2.50 + SGST ₹2.50).
    """
    amount = to_float_safe(inclusive_amount, 0)
    rate = max(to_float_safe(gst_percent, 0), 0.0)
    tax = amount * rate / (100 + rate) if rate else 0.0
    # CGST and SGST are always equal halves on the printed bill.
    cgst = round_currency(tax / 2)
    sgst = cgst
    gst_amount = round_currency(cgst + sgst)
    taxable = round_currency(amount - gst_amount)
    return {
        "gst_percent": round(rate, 2),
        "taxable_amount": taxable,
        "gst_amount": gst_amount,
        "cgst": cgst,
        "sgst": sgst,
    }


def snap_gst_slab(value):
    """Old records stored derived rates like 5.00475%; report them on the real slab."""
    rate = max(to_float_safe(value, 0), 0.0)
    nearest = min(GST_RATE_CHOICES, key=lambda slab: abs(slab - rate))
    return float(nearest) if abs(nearest - rate) <= 0.5 else round(rate, 2)


def invoice_item_gst_percent(invoice, item):
    """GST rate used on the original sale line (legacy invoices: derived)."""
    stored = normalize_gst_percent(getattr(item, "gst_percent", None), None)
    if stored is not None:
        return stored
    subtotal = to_float_safe(getattr(invoice, "subtotal", 0), 0) if invoice else 0
    tax_total = (
        to_float_safe(getattr(invoice, "cgst", 0), 0) + to_float_safe(getattr(invoice, "sgst", 0), 0)
        if invoice else 0
    )
    if subtotal > 0 and tax_total > 0:
        # Legacy invoices stored GST as a flat % of the subtotal; snap to the
        # nearest standard slab so tiny rounding noise does not leak through.
        derived = tax_total / subtotal * 100
        return min(GST_RATE_CHOICES, key=lambda slab: abs(slab - derived))
    return 0.0 if invoice else default_gst_percent()


def return_item_amount_snapshot(invoice, item, qty):
    qty = to_int_safe(qty, 0)
    amount = round_currency(qty * to_float_safe(getattr(item, "price", 0), 0))
    discount_percent = to_float_safe(getattr(item, "discount_percent", 0), 0)
    discount_amount = round_currency(amount * discount_percent / 100)
    net_amount = round_currency(amount - discount_amount)
    gst = split_inclusive_gst(net_amount, invoice_item_gst_percent(invoice, item))
    return {
        "amount": amount,
        "discount_percent": discount_percent,
        "discount_amount": discount_amount,
        "net_amount": net_amount,
        "gst_percent": gst["gst_percent"],
        "taxable_amount": gst["taxable_amount"],
        "cgst": gst["cgst"],
        "sgst": gst["sgst"],
    }


def returned_qty_map_for_invoice(invoice_id):
    return dict(
        db.session.query(ReturnItem.invoice_item_id, db.func.sum(ReturnItem.qty))
        .join(Return, Return.id == ReturnItem.return_id)
        .filter(
            Return.invoice_id == invoice_id,
            falsey_or_null_column_expr(Return.is_cancelled),
        )
        .group_by(ReturnItem.invoice_item_id)
        .all()
    )


def build_returnable_invoice_payload(invoice):
    returned_map = returned_qty_map_for_invoice(invoice.id)
    items = InvoiceItem.query.filter_by(invoice_id=invoice.id).order_by(InvoiceItem.id.asc()).all()
    window_open = is_invoice_return_window_open(invoice)
    rows = []
    for item in items:
        already_returned = to_int_safe(returned_map.get(item.id), 0)
        sold_qty = to_int_safe(item.qty, 0)
        returnable_qty = max(sold_qty - already_returned, 0)
        med = Medicine.query.filter_by(name=item.name, batch=item.batch, expiry=item.expiry).first()
        cold_chain_med = med or Medicine.query.filter_by(name=item.name, batch=item.batch).first()
        cold_chain = is_cold_chain_medicine(cold_chain_med, item)
        amount_snapshot = return_item_amount_snapshot(invoice, item, 1)
        rows.append({
            "invoice_item_id": item.id,
            "medicine_name": item.name,
            "batch": item.batch,
            "expiry": item.expiry,
            "sold_qty": sold_qty,
            "already_returned_qty": already_returned,
            "returnable_qty": 0 if cold_chain or not window_open else returnable_qty,
            "raw_returnable_qty": returnable_qty,
            "price": round_currency(item.price),
            "discount_percent": round_currency(item.discount_percent),
            "gst_percent": amount_snapshot["gst_percent"],
            "unit_net_amount": amount_snapshot["net_amount"],
            "cold_chain": cold_chain,
            "window_open": window_open,
        })
    created_at = storage_datetime_to_local(invoice.created_at) or invoice.created_at
    return {
        "id": invoice.id,
        "invoice_no": invoice.invoice_no,
        "customer": invoice.customer,
        "mobile": invoice.mobile,
        "created_at": created_at.strftime("%d-%m-%Y") if created_at else "",
        "total": round_currency(invoice.total),
        "window_open": window_open,
        "return_window_days": return_window_days(),
        "items": rows,
    }


def build_exchange_return_requests(form):
    invoice_id = to_int_safe(form.get("exchange_return_invoice_id"), 0)
    if invoice_id <= 0:
        return None, [], None
    invoice = Invoice.query.get(invoice_id)
    if not invoice:
        return None, [], "Original invoice for return adjustment was not found."
    if bool(getattr(invoice, "is_cancelled", False)):
        return invoice, [], "The original invoice is cancelled, so its items cannot be returned."
    override_window = (
        (form.get("exchange_return_override_window") or "").strip() == "1"
        and (session.get("role") or "").strip().lower() == "admin"
    )

    items = {item.id: item for item in InvoiceItem.query.filter_by(invoice_id=invoice.id).all()}
    returned_map = returned_qty_map_for_invoice(invoice.id)
    requests = []
    for item_id, item in items.items():
        qty = to_int_safe(form.get(f"exchange_return_qty_{item_id}"), 0)
        if qty < 0:
            return invoice, [], f"Invalid return quantity for {item.name}."
        if qty <= 0:
            continue
        if not override_window and not is_invoice_return_window_open(invoice):
            return invoice, [], f"Return is allowed only within {return_window_days()} days of invoice date."
        already_returned = to_int_safe(returned_map.get(item.id), 0)
        returnable_qty = max(to_int_safe(item.qty, 0) - already_returned, 0)
        if qty > returnable_qty:
            return invoice, [], f"Return qty cannot exceed returnable qty for {item.name} ({item.batch})."
        med = Medicine.query.filter_by(name=item.name, batch=item.batch, expiry=item.expiry).first()
        cold_chain_med = med or Medicine.query.filter_by(name=item.name, batch=item.batch).first()
        if is_cold_chain_medicine(cold_chain_med, item):
            return invoice, [], f"Cold-chain/refrigerated item cannot be returned: {item.name}."
        amount_snapshot = return_item_amount_snapshot(invoice, item, qty)
        requests.append({
            "item": item,
            "qty": qty,
            "reason": (form.get(f"exchange_return_reason_{item_id}") or "Exchange adjustment").strip(),
            "disposition": normalize_return_disposition(form.get(f"exchange_return_disposition_{item_id}")),
            "amounts": amount_snapshot,
            "medicine": med,
            "window_override": override_window,
        })
    return invoice, requests, None


def build_return_invoice_context(return_bill):
    """Build one authoritative, presentation-ready return invoice snapshot.

    ReturnItem rows are the source of truth for what was returned. The linked
    Invoice contributes only metadata that Return does not store (print profile,
    doctor, gender and party GST). This prevents later invoice edits from
    changing historical return quantities or refund values.
    """
    linked_invoice = None
    if to_int_safe(getattr(return_bill, "invoice_id", 0), 0) > 0:
        linked_invoice = db.session.get(Invoice, return_bill.invoice_id)
    adjusted_invoice = None
    if to_int_safe(getattr(return_bill, "adjusted_invoice_id", 0), 0) > 0:
        adjusted_invoice = db.session.get(Invoice, return_bill.adjusted_invoice_id)

    return_items = ReturnItem.query.filter_by(return_id=return_bill.id).order_by(ReturnItem.id.asc()).all()
    prepared_items = []
    gross_total = 0.0
    discount_total = 0.0
    net_total = 0.0

    for item in return_items:
        qty = max(to_int_safe(item.qty, 0), 0)
        selling_rate = max(
            to_float_safe(
                item.selling_rate
                if item.selling_rate not in (None, "", 0)
                else item.price,
                0,
            ),
            0.0,
        )
        amount = max(
            to_float_safe(
                item.amount if item.amount is not None else qty * selling_rate,
                qty * selling_rate,
            ),
            0.0,
        )
        discount_percent = max(to_float_safe(item.discount_percent, 0), 0.0)
        stored_net = item.net_amount
        if stored_net is None:
            net_amount = max(amount - (amount * discount_percent / 100), 0.0)
        else:
            net_amount = max(to_float_safe(stored_net, 0), 0.0)

        stored_discount = to_float_safe(item.discount_amount, 0)
        if stored_discount > 0:
            discount_amount = stored_discount
        else:
            # amount - net is the most reliable legacy fallback because both
            # values were snapshotted when the return was created.
            discount_amount = max(amount - net_amount, 0.0)

        gst_percent = max(to_float_safe(item.gst_percent, 0), 0.0)
        item_gst = split_inclusive_gst(net_amount, gst_percent)
        cgst_amount = item_gst["cgst"]
        sgst_amount = item_gst["sgst"]

        prepared_items.append({
            "id": item.id,
            "medicine_name": (item.medicine_name or "").strip(),
            "qty": qty,
            "batch": (item.batch or "").strip(),
            "expiry": (item.expiry or "").strip(),
            "selling_rate": round_currency(selling_rate),
            "amount": round_currency(amount),
            "discount_percent": discount_percent,
            "discount_amount": round_currency(discount_amount),
            "net_amount": round_currency(net_amount),
            "gst_percent": gst_percent,
            "cgst_amount": cgst_amount,
            "sgst_amount": sgst_amount,
            "reason": (item.reason or "").strip(),
            "disposition": (getattr(item, "disposition", "") or "RESTOCK").strip().upper(),
        })
        gross_total += amount
        discount_total += discount_amount
        net_total += net_amount

    refund_total = round_currency(
        return_bill.total_refund
        if return_bill.total_refund is not None
        else net_total
    )
    payment_breakdown = build_return_payment_breakdown(return_bill, refund_total)

    return_at = storage_datetime_to_local(return_bill.created_at) or return_bill.created_at
    original_at = None
    if linked_invoice and linked_invoice.created_at:
        original_at = storage_datetime_to_local(linked_invoice.created_at) or linked_invoice.created_at

    if linked_invoice:
        print_profile = resolve_invoice_print_profile(linked_invoice)
    else:
        print_profile = get_invoice_print_profile_for_date(return_bill.created_at)

    return {
        "ret": return_bill,
        "original_invoice": linked_invoice,
        "adjusted_invoice": adjusted_invoice,
        "items": prepared_items,
        "print_profile": print_profile,
        "return_no": return_bill.return_no or f"RB-{return_bill.id:06d}",
        "invoice_no": (return_bill.invoice_no or (linked_invoice.invoice_no if linked_invoice else "") or "Manual"),
        "customer": (return_bill.customer or "").strip(),
        "customer_gst_no": ((linked_invoice.customer_gst_no if linked_invoice else "") or "").strip(),
        "mobile": (return_bill.mobile or "").strip(),
        "doctor": ((linked_invoice.doctor if linked_invoice else "") or "").strip(),
        "gender": ((linked_invoice.gender if linked_invoice else "") or "").strip(),
        "payment_breakdown": payment_breakdown,
        "return_date": return_at.strftime("%d-%m-%Y") if return_at else "-",
        "return_time": return_at.strftime("%I:%M %p") if return_at else "",
        "original_invoice_date": original_at.strftime("%d-%m-%Y") if original_at else "-",
        "gross_total": round_currency(gross_total),
        "discount_total": round_currency(discount_total),
        "net_total": round_currency(net_total),
        "refund_total": refund_total,
        "adjusted_amount": round_currency(getattr(return_bill, "adjusted_amount", 0)),
        "refund_due": round_currency(getattr(return_bill, "refund_amount", 0)),
        "cgst_total": round_currency(return_bill.cgst),
        "sgst_total": round_currency(return_bill.sgst),
        "is_cancelled": bool(return_bill.is_cancelled),
        "cancelled_by": (return_bill.cancelled_by or "").strip(),
        "cancelled_at": (
            (storage_datetime_to_local(return_bill.cancelled_at) or return_bill.cancelled_at).strftime("%d-%m-%Y %I:%M %p")
            if return_bill.cancelled_at
            else ""
        ),
    }


def resolve_invoice_edit_payment_update(invoice, requested_payment_mode):
    normalized_mode = normalize_payment_mode(requested_payment_mode)
    current_breakdown = build_invoice_payment_breakdown(invoice)

    if current_breakdown["is_split_payment"]:
        if is_cash_payment_mode(normalized_mode):
            return None, "Split-payment invoices must keep an online payment mode."
        return {
            "payment_mode": normalized_mode,
            "cash_amount": current_breakdown["cash_amount"],
            "online_amount": current_breakdown["online_amount"],
            "is_split_payment": True,
        }, None

    payable_amount = current_breakdown["rounded_amount"]
    if is_cash_payment_mode(normalized_mode):
        cash_amount = payable_amount
        online_amount = 0.0
    else:
        cash_amount = 0.0
        online_amount = payable_amount

    return {
        "payment_mode": normalized_mode,
        "cash_amount": round_currency(cash_amount),
        "online_amount": round_currency(online_amount),
        "is_split_payment": False,
    }, None


def normalize_stock_sale_lines_per_invoice(raw_value):
    chunk_size = to_int_safe(raw_value, STOCK_SALE_DEFAULT_LINES_PER_INVOICE)
    if chunk_size < 1:
        chunk_size = STOCK_SALE_DEFAULT_LINES_PER_INVOICE
    if chunk_size > STOCK_SALE_MAX_LINES_PER_INVOICE:
        chunk_size = STOCK_SALE_MAX_LINES_PER_INVOICE
    return chunk_size


def chunk_sequence(items, chunk_size):
    size = max(1, to_int_safe(chunk_size, 1))
    for index in range(0, len(items), size):
        yield items[index:index + size]


def build_stock_sale_purchase_context(medicines):
    medicine_rows = list(medicines or [])
    if not medicine_rows:
        return {}

    rate_lookup = build_medicine_purchase_rate_lookup(medicine_rows)
    medicine_ids = {med.id for med in medicine_rows if getattr(med, "id", None)}
    medicine_name_keys = {
        (
            normalize_medicine_name(getattr(med, "name", "")).casefold(),
            (getattr(med, "batch", "") or "").strip().casefold(),
        )
        for med in medicine_rows
        if normalize_medicine_name(getattr(med, "name", "")) and (getattr(med, "batch", "") or "").strip()
    }

    filters = []
    if medicine_ids:
        filters.append(VendorPurchaseItem.medicine_id.in_(medicine_ids))
    if medicine_name_keys:
        medicine_name_values = sorted({name for name, _batch in medicine_name_keys})
        batch_values = sorted({batch for _name, batch in medicine_name_keys})
        filters.append(
            and_(
                db.func.lower(db.func.trim(db.func.coalesce(VendorPurchaseItem.medicine_name, ""))).in_(medicine_name_values),
                db.func.lower(db.func.trim(db.func.coalesce(VendorPurchaseItem.batch, ""))).in_(batch_values),
            )
        )

    latest_item_by_medicine_id = {}
    latest_item_by_name_batch = {}
    if filters:
        purchase_items = VendorPurchaseItem.query.filter(
            or_(*filters)
        ).order_by(
            VendorPurchaseItem.created_at.desc(),
            VendorPurchaseItem.id.desc()
        ).all()
        for item in purchase_items:
            item_medicine_id = getattr(item, "medicine_id", None)
            if item_medicine_id and item_medicine_id in medicine_ids and item_medicine_id not in latest_item_by_medicine_id:
                latest_item_by_medicine_id[item_medicine_id] = item

            fallback_key = (
                normalize_medicine_name(getattr(item, "medicine_name", "")).casefold(),
                (getattr(item, "batch", "") or "").strip().casefold(),
            )
            if fallback_key in medicine_name_keys and fallback_key not in latest_item_by_name_batch:
                latest_item_by_name_batch[fallback_key] = item

    context = {}
    for med in medicine_rows:
        fallback_key = (
            normalize_medicine_name(getattr(med, "name", "")).casefold(),
            (getattr(med, "batch", "") or "").strip().casefold(),
        )
        latest_item = latest_item_by_medicine_id.get(getattr(med, "id", None)) or latest_item_by_name_batch.get(fallback_key)
        purchase_rate = to_float_safe(getattr(latest_item, "purchase_rate", None), rate_lookup.get(getattr(med, "id", None), 0.0))
        if purchase_rate <= 0:
            purchase_rate = to_float_safe(rate_lookup.get(getattr(med, "id", None), 0.0), 0.0)
        source = "latest_purchase" if latest_item and purchase_rate > 0 else ("historical_rate" if purchase_rate > 0 else "missing_rate")
        context[getattr(med, "id", None)] = {
            "purchase_rate": purchase_rate,
            "gst_percent": to_float_safe(getattr(latest_item, "gst_percent", 0), 0),
            "discount_percent": to_float_safe(getattr(latest_item, "discount_percent", 0), 0),
            "distributor_name": (getattr(latest_item, "distributor_name", "") or "").strip(),
            "source": source,
            "latest_item": latest_item,
        }
    return context


def resolve_stock_sale_medicine_for_purchase_item(purchase_item, medicine_by_id, medicine_by_name_batch):
    item_medicine_id = getattr(purchase_item, "medicine_id", None)
    if item_medicine_id:
        med = medicine_by_id.get(item_medicine_id)
        if med:
            return med, "purchase_layer"

    fallback_key = (
        normalize_medicine_name(getattr(purchase_item, "medicine_name", "")).casefold(),
        (getattr(purchase_item, "batch", "") or "").strip().casefold(),
    )
    med = medicine_by_name_batch.get(fallback_key)
    if med:
        return med, "name_batch_match"
    return None, "missing_medicine"


def consume_purchase_item_layer(purchase_item_id, qty):
    purchase_item = VendorPurchaseItem.query.get(purchase_item_id)
    if not purchase_item:
        raise ValueError(f"Purchase layer not found for stock sale row {purchase_item_id}.")

    available = max(to_int_safe(getattr(purchase_item, "remaining_qty", 0), 0), 0)
    requested = max(to_int_safe(qty, 0), 0)
    if requested <= 0:
        return []
    if available < requested:
        raise ValueError(
            f"Purchase layer stock changed before sale for {getattr(purchase_item, 'medicine_name', '')} ({getattr(purchase_item, 'batch', '')}). Please refresh and retry."
        )

    purchase_item.remaining_qty = available - requested
    return [{
        "purchase_item": purchase_item,
        "qty": requested,
        "cost_rate": to_float(getattr(purchase_item, "purchase_rate", 0)),
    }]


def sync_medicine_qty_to_stock_sale_layers(rows, actor_username, operation_ref):
    expected_qty_by_medicine_id = {}
    for row in rows:
        if row.get("is_unresolved"):
            continue
        medicine_id = row.get("medicine_id")
        if not medicine_id:
            continue
        expected_qty_by_medicine_id[medicine_id] = expected_qty_by_medicine_id.get(medicine_id, 0) + max(
            to_int_safe(row.get("qty"), 0),
            0,
        )

    touched_names = []
    for medicine_id, expected_qty in expected_qty_by_medicine_id.items():
        med = Medicine.query.get(medicine_id)
        if not med:
            raise ValueError(f"Medicine missing before stock sale sync: {medicine_id}")
        current_qty = max(to_int_safe(getattr(med, "qty", 0), 0), 0)
        if current_qty == expected_qty:
            continue

        med.qty = expected_qty
        touched_names.append(med.name)
        db.session.add(StockHistory(
            medicine_id=med.id,
            medicine_name=med.name,
            batch=med.batch,
            action="ADJUSTMENT",
            stock_before=current_qty,
            qty_change=expected_qty - current_qty,
            stock_after=expected_qty,
            user=actor_username,
            remark=f"Stock sale sync {operation_ref} to purchase layers",
            ref_table="stock_sale",
            ref_id=None,
        ))
    return touched_names


def reset_stock_sale_purchase_layers(rows):
    medicine_ids = {row.get("medicine_id") for row in rows if row.get("medicine_id")}
    fallback_keys = {
        (
            normalize_medicine_name(row.get("name", "")).casefold(),
            (row.get("batch", "") or "").strip().casefold(),
        )
        for row in rows
        if normalize_medicine_name(row.get("name", "")) and (row.get("batch", "") or "").strip()
    }
    if not medicine_ids and not fallback_keys:
        return []

    purchase_items = VendorPurchaseItem.query.filter(
        db.func.coalesce(VendorPurchaseItem.remaining_qty, 0) > 0
    ).order_by(
        VendorPurchaseItem.created_at.asc(),
        VendorPurchaseItem.id.asc(),
    ).all()

    cleared_items = []
    for item in purchase_items:
        item_medicine_id = getattr(item, "medicine_id", None)
        item_key = (
            normalize_medicine_name(getattr(item, "medicine_name", "")).casefold(),
            (getattr(item, "batch", "") or "").strip().casefold(),
        )
        if item_medicine_id not in medicine_ids and item_key not in fallback_keys:
            continue
        if max(to_int_safe(getattr(item, "remaining_qty", 0), 0), 0) <= 0:
            continue
        item.remaining_qty = 0
        cleared_items.append(item)
    return cleared_items


def build_stock_sale_preview(lines_per_invoice=STOCK_SALE_DEFAULT_LINES_PER_INVOICE):
    chunk_size = normalize_stock_sale_lines_per_invoice(lines_per_invoice)
    purchase_items = VendorPurchaseItem.query.filter(
        db.func.coalesce(VendorPurchaseItem.remaining_qty, 0) > 0
    ).order_by(
        db.func.lower(db.func.coalesce(VendorPurchaseItem.medicine_name, "")).asc(),
        VendorPurchaseItem.batch.asc(),
        VendorPurchaseItem.created_at.asc(),
        VendorPurchaseItem.id.asc(),
    ).all()
    today = clinic_now().date()

    positive_medicines = Medicine.query.filter(Medicine.qty > 0).all()
    medicines_for_lookup = {
        med.id: med
        for med in Medicine.query.all()
        if getattr(med, "id", None)
    }

    medicine_by_name_batch = {}
    for med in medicines_for_lookup.values():
        key = (
            normalize_medicine_name(getattr(med, "name", "")).casefold(),
            (getattr(med, "batch", "") or "").strip().casefold(),
        )
        if key not in medicine_by_name_batch:
            medicine_by_name_batch[key] = med

    rows = []
    sale_rows = []
    unresolved_rows = []
    total_qty = 0
    estimated_sale_value = 0.0
    estimated_reentry_total = 0.0
    expired_count = 0
    allocated_qty_by_medicine_id = {}
    ignored_layer_count = 0
    ignored_layer_qty = 0

    for purchase_item in purchase_items:
        med, source = resolve_stock_sale_medicine_for_purchase_item(
            purchase_item,
            medicines_for_lookup,
            medicine_by_name_batch,
        )
        available_qty = max(to_int_safe(getattr(purchase_item, "remaining_qty", 0), 0), 0)
        if available_qty <= 0:
            continue
        if not med:
            ignored_layer_count += 1
            ignored_layer_qty += available_qty
            continue

        current_medicine_qty = max(to_int_safe(getattr(med, "qty", 0), 0), 0)
        if current_medicine_qty <= 0:
            ignored_layer_count += 1
            ignored_layer_qty += available_qty
            continue

        already_allocated = allocated_qty_by_medicine_id.get(med.id, 0)
        remaining_to_cycle = current_medicine_qty - already_allocated
        if remaining_to_cycle <= 0:
            ignored_layer_count += 1
            ignored_layer_qty += available_qty
            continue

        qty = min(available_qty, remaining_to_cycle)
        if qty <= 0:
            continue
        if qty < available_qty:
            ignored_layer_count += 1
            ignored_layer_qty += available_qty - qty

        raw_purchase_rate = to_float_safe(getattr(purchase_item, "purchase_rate", 0), 0)
        discount_percent = to_float_safe(getattr(purchase_item, "discount_percent", 0), 0)
        gst_percent = to_float_safe(getattr(purchase_item, "gst_percent", 0), 0)
        base_amount = qty * raw_purchase_rate
        discount_amount = base_amount * discount_percent / 100
        taxable_amount = base_amount - discount_amount
        gst_amount = taxable_amount * gst_percent / 100
        reentry_total = taxable_amount + gst_amount
        expiry_value = (getattr(med, "expiry", None) or getattr(purchase_item, "expiry", "") or "").strip()
        expiry_date = parse_expiry_date(expiry_value)
        is_expired = bool(expiry_date and expiry_date < today)
        if is_expired:
            expired_count += 1

        row = {
            "purchase_item_id": purchase_item.id,
            "medicine_id": getattr(med, "id", None),
            "medicine_code": normalize_medicine_code(
                getattr(med, "medicine_code", "") or getattr(purchase_item, "medicine_code", "")
            ),
            "name": normalize_medicine_name(getattr(med, "name", "") or getattr(purchase_item, "medicine_name", "")),
            "batch": ((getattr(med, "batch", None) or getattr(purchase_item, "batch", "") or "")).strip(),
            "expiry": expiry_value,
            "qty": qty,
            "purchase_rate": round_currency(raw_purchase_rate),
            "purchase_rate_raw": raw_purchase_rate,
            "sale_value": round_currency(base_amount),
            "reentry_total": round_currency(reentry_total),
            "mrp": to_float_safe(getattr(med, "mrp", None), to_float_safe(getattr(purchase_item, "mrp", 0), 0)),
            "barcode": (getattr(med, "barcode", "") or getattr(purchase_item, "barcode", "") or "").strip(),
            "composition": (getattr(med, "composition", "") or getattr(purchase_item, "composition", "") or "").strip(),
            "company": (getattr(med, "company", "") or getattr(purchase_item, "company", "") or "").strip(),
            "pack_type": (getattr(med, "pack_type", "") or getattr(purchase_item, "pack_type", "") or "").strip(),
            "pack_qty": getattr(med, "pack_qty", None) if med and getattr(med, "pack_qty", None) not in (None, "") else getattr(purchase_item, "pack_qty", None),
            "gst_percent": gst_percent,
            "discount_percent": discount_percent,
            "source": source,
            "source_label": {
                "purchase_layer": "Purchase layer",
                "name_batch_match": "Name/batch match",
                "missing_medicine": "Medicine missing",
                "missing_purchase_layer": "No purchase layer",
            }.get(source, "Purchase layer"),
            "is_expired": is_expired,
            "is_unresolved": False,
        }
        rows.append(row)
        total_qty += qty
        estimated_sale_value += base_amount
        estimated_reentry_total += reentry_total
        allocated_qty_by_medicine_id[med.id] = allocated_qty_by_medicine_id.get(med.id, 0) + qty
        if raw_purchase_rate <= 0:
            row["is_unresolved"] = True
            unresolved_rows.append(row)
        else:
            sale_rows.append(row)

    orphan_count = 0
    for med in positive_medicines:
        current_qty = max(to_int_safe(getattr(med, "qty", 0), 0), 0)
        allocated_qty = allocated_qty_by_medicine_id.get(med.id, 0)
        if allocated_qty >= current_qty:
            continue

        missing_qty = current_qty - allocated_qty
        source = "missing_purchase_layer" if allocated_qty == 0 else "partial_purchase_layer"
        source_label = "No purchase layer" if allocated_qty == 0 else "Layer shortfall"
        unresolved_row = {
            "purchase_item_id": None,
            "medicine_id": med.id,
            "medicine_code": normalize_medicine_code(getattr(med, "medicine_code", "")),
            "name": normalize_medicine_name(getattr(med, "name", "")),
            "batch": (getattr(med, "batch", "") or "").strip(),
            "expiry": (getattr(med, "expiry", "") or "").strip(),
            "qty": missing_qty,
            "purchase_rate": 0.0,
            "purchase_rate_raw": 0.0,
            "sale_value": 0.0,
            "reentry_total": 0.0,
            "mrp": to_float_safe(getattr(med, "mrp", 0), 0),
            "barcode": (getattr(med, "barcode", "") or "").strip(),
            "composition": (getattr(med, "composition", "") or "").strip(),
            "company": (getattr(med, "company", "") or "").strip(),
            "pack_type": (getattr(med, "pack_type", "") or "").strip(),
            "pack_qty": getattr(med, "pack_qty", None),
            "gst_percent": 0.0,
            "discount_percent": 0.0,
            "source": source,
            "source_label": source_label,
            "is_expired": False,
            "is_unresolved": True,
        }
        rows.append(unresolved_row)
        unresolved_rows.append(unresolved_row)
        if allocated_qty == 0:
            orphan_count += 1

    rows.sort(key=lambda row: (
        row.get("is_unresolved", False),
        (row.get("name") or "").lower(),
        row.get("batch") or "",
        row.get("purchase_item_id") or 0,
    ))

    return {
        "rows": rows,
        "sale_rows": sale_rows,
        "line_count": len(sale_rows),
        "total_qty": total_qty,
        "estimated_sale_value": round_currency(estimated_sale_value),
        "estimated_reentry_total": round_currency(estimated_reentry_total),
        "expired_count": expired_count,
        "unresolved_count": len(unresolved_rows),
        "unresolved_rows": unresolved_rows,
        "orphan_count": orphan_count,
        "sync_mismatch_count": 0,
        "sync_total_delta": 0,
        "sync_total_delta_display": "+0",
        "ignored_layer_count": ignored_layer_count,
        "ignored_layer_qty": ignored_layer_qty,
        "lines_per_invoice": chunk_size,
        "invoice_chunk_count": math.ceil(len(sale_rows) / chunk_size) if sale_rows else 0,
        "reentry_vendor_name": STOCK_SALE_REENTRY_VENDOR_NAME,
    }


def get_or_create_stock_sale_vendor():
    vendor = Vendor.query.filter(
        db.func.lower(db.func.trim(db.func.coalesce(Vendor.name, ""))) == STOCK_SALE_REENTRY_VENDOR_NAME.lower()
    ).order_by(Vendor.id.asc()).first()
    if vendor:
        if vendor.deleted_at is not None:
            vendor.deleted_at = None
            vendor.deleted_by = None
        if getattr(vendor, "is_active", True) in (False, 0, "0", "false", "False", None):
            vendor.is_active = True
        if not getattr(vendor, "vendor_type", ""):
            vendor.vendor_type = "Distributor"
        if not getattr(vendor, "default_payment_mode", ""):
            vendor.default_payment_mode = "CASH"
        if not getattr(vendor, "payment_status", ""):
            vendor.payment_status = "Paid"
        db.session.add(vendor)
        return vendor

    vendor = Vendor(
        name=STOCK_SALE_REENTRY_VENDOR_NAME,
        vendor_type="Distributor",
        default_payment_mode="CASH",
        payment_status="Paid",
        is_active=True,
    )
    db.session.add(vendor)
    db.session.flush()
    return vendor


def build_stock_sale_internal_note(operation_ref, custom_note=""):
    base_note = f"Bulk stock sale operation {operation_ref}. Auto re-entry vendor: {STOCK_SALE_REENTRY_VENDOR_NAME}."
    custom_text = (custom_note or "").strip()
    if custom_text:
        return f"{base_note} {custom_text}"
    return base_note


def execute_stock_sale_operation(*, customer, customer_gst_no, mobile, doctor, payment_mode, internal_note, lines_per_invoice, actor_username):
    preview = build_stock_sale_preview(lines_per_invoice)
    if not preview["sale_rows"]:
        return None, "No stock available for stock sale."
    if preview["unresolved_count"] > 0:
        return None, "Some stock rows are not linked to active purchase layers or medicine records. Fix inventory sync first, then retry."

    customer_name = (customer or "").strip() or STOCK_SALE_DEFAULT_CUSTOMER
    customer_gst_no = (customer_gst_no or "").strip().upper()
    mobile_number = (mobile or "").strip()
    doctor_name = (doctor or "").strip()
    normalized_payment_mode = normalize_payment_mode(payment_mode, default=STOCK_SALE_DEFAULT_PAYMENT_MODE)
    operation_ref = clinic_now().strftime("STOCKSALE-%Y%m%d-%H%M%S")
    invoice_print_date = clinic_now().date()
    chunk_size = preview["lines_per_invoice"]

    patient, normalized_mobile = upsert_patient_from_invoice(customer_name, mobile_number, "")
    if patient and not patient.id:
        db.session.flush()

    vendor = get_or_create_stock_sale_vendor()
    created_invoices = []
    touched_names = []
    stock_sale_note = build_stock_sale_internal_note(operation_ref, internal_note)

    try:
        for chunk_rows in chunk_sequence(preview["sale_rows"], chunk_size):
            created_at = datetime.utcnow()
            invoice = Invoice(
                invoice_no=None,
                patient_id=patient.id if patient else None,
                customer=customer_name,
                mobile=normalized_mobile or mobile_number,
                customer_gst_no=customer_gst_no,
                doctor=doctor_name,
                gender="",
                subtotal=0,
                discount=0,
                cgst=0,
                sgst=0,
                total=0,
                payment_mode=normalized_payment_mode,
                cash_amount=0,
                online_amount=0,
                is_split_payment=False,
                internal_note=stock_sale_note,
                created_by=actor_username,
                created_at=created_at,
            )
            db.session.add(invoice)
            db.session.flush()

            subtotal = 0.0
            total_discount = 0.0
            stock_sale_cgst = 0.0
            stock_sale_sgst = 0.0
            for row in chunk_rows:
                med = lock_medicine_for_update(Medicine.query.get(row["medicine_id"]))
                if not med:
                    raise ValueError(f"Medicine not found: {row['name']} ({row['batch']})")
                sell_qty = to_int_safe(row["qty"], 0)
                if sell_qty <= 0:
                    continue
                if med.qty < sell_qty:
                    raise ValueError(f"Stock changed before sale for {med.name} ({med.batch}). Please retry.")

                amount = round_currency(sell_qty * to_float_safe(row.get("purchase_rate_raw", row["purchase_rate"]), 0))
                subtotal += amount
                stock_line_gst = split_inclusive_gst(amount, medicine_gst_percent(med))
                stock_sale_cgst += stock_line_gst["cgst"]
                stock_sale_sgst += stock_line_gst["sgst"]
                old_stock = med.qty
                med.qty -= sell_qty
                touched_names.append(med.name)

                db.session.add(StockHistory(
                    medicine_id=med.id,
                    medicine_name=med.name,
                    batch=med.batch,
                    action="SALE",
                    stock_before=old_stock,
                    qty_change=-sell_qty,
                    stock_after=med.qty,
                    user=actor_username,
                    remark=f"Bulk stock sale {operation_ref}",
                    ref_table="invoice",
                    ref_id=invoice.id,
                ))

                fifo_alloc = consume_purchase_item_layer(row.get("purchase_item_id"), sell_qty)
                cost_amount = sum(a["qty"] * a["cost_rate"] for a in fifo_alloc)
                cost_price = round(cost_amount / sell_qty, 4) if sell_qty else 0

                invoice_item = InvoiceItem(
                    invoice_id=invoice.id,
                    name=row["name"],
                    qty=sell_qty,
                    price=to_float_safe(row.get("purchase_rate_raw", row["purchase_rate"]), 0),
                    amount=amount,
                    batch=row["batch"],
                    expiry=row["expiry"],
                    discount_percent=0,
                    discount_amount=0,
                    net_amount=amount,
                    cost_price=cost_price,
                    cost_amount=cost_amount,
                    gst_percent=stock_line_gst["gst_percent"],
                    taxable_amount=stock_line_gst["taxable_amount"],
                    gst_amount=stock_line_gst["gst_amount"],
                )
                db.session.add(invoice_item)
                db.session.flush()
                for alloc in fifo_alloc:
                    db.session.add(SalesAllocation(
                        invoice_item_id=invoice_item.id,
                        purchase_item_id=alloc["purchase_item"].id if alloc["purchase_item"] else None,
                        qty=alloc["qty"],
                        cost_rate=alloc["cost_rate"],
                        returned_qty=0,
                    ))

            invoice.subtotal = round_currency(subtotal)
            invoice.discount = round_currency(total_discount)
            invoice.cgst = round_currency(stock_sale_cgst)
            invoice.sgst = round_currency(stock_sale_sgst)
            invoice.total = round_currency(invoice.subtotal)
            payment_breakdown, payment_error = calculate_invoice_payment_breakdown(
                payment_mode=normalized_payment_mode,
                rounded_amount=compute_invoice_rounded_total(invoice.total),
                split_cash_amount_raw=None,
            )
            if payment_error:
                raise ValueError(payment_error)
            invoice.payment_mode = payment_breakdown["payment_mode"]
            invoice.cash_amount = payment_breakdown["cash_amount"]
            invoice.online_amount = payment_breakdown["online_amount"]
            invoice.is_split_payment = payment_breakdown["is_split_payment"]
            apply_invoice_print_profile(invoice, invoice_print_date)
            created_invoices.append(invoice)
            assign_invoice_number(invoice, invoice_print_date)

        reset_stock_sale_purchase_layers(preview["sale_rows"])

        purchase_created_at = datetime.utcnow()
        purchase = VendorPurchase(
            vendor_id=vendor.id,
            purchase_date=purchase_created_at,
            invoice_no=f"{operation_ref}-REENTRY",
            payment_mode="CASH",
            payment_status="Paid",
            paid_amount=0,
            notes=f"Auto re-entry after bulk stock sale {operation_ref}",
            subtotal=0,
            gst_total=0,
            discount_total=0,
            total_amount=0,
            created_by=actor_username,
            created_at=purchase_created_at,
        )
        db.session.add(purchase)
        db.session.flush()
        assign_purchase_number(purchase, purchase_created_at)

        purchase_subtotal = 0.0
        purchase_gst_total = 0.0
        purchase_discount_total = 0.0
        purchase_total_amount = 0.0

        for row in preview["sale_rows"]:
            med = Medicine.query.get(row["medicine_id"])
            if not med:
                raise ValueError(f"Medicine missing before re-entry: {row['name']} ({row['batch']})")
            qty = to_int_safe(row["qty"], 0)
            if qty <= 0:
                continue

            discount_percent = to_float_safe(row.get("discount_percent"), 0)
            gst_percent = to_float_safe(row.get("gst_percent"), 0)
            purchase_rate = to_float_safe(row.get("purchase_rate_raw", row.get("purchase_rate")), 0)
            base_amount = qty * purchase_rate
            discount_amount = base_amount * discount_percent / 100
            taxable_amount = base_amount - discount_amount
            gst_amount = taxable_amount * gst_percent / 100
            total_value = taxable_amount + gst_amount

            med.name = row["name"]
            med.batch = row["batch"]
            med.expiry = row["expiry"]
            med.mrp = to_float_safe(row["mrp"], med.mrp)
            med.barcode = row["barcode"] or med.barcode
            med.composition = row["composition"] or med.composition
            med.company = row["company"] or med.company
            med.pack_type = row["pack_type"] or med.pack_type
            if row["pack_qty"] not in (None, "", " "):
                med.pack_qty = row["pack_qty"]

            old_stock = med.qty
            med.qty += qty
            touched_names.append(med.name)

            db.session.add(StockHistory(
                medicine_id=med.id,
                medicine_name=med.name,
                batch=med.batch,
                action="PURCHASE",
                stock_before=old_stock,
                qty_change=qty,
                stock_after=med.qty,
                user=actor_username,
                remark=f"Auto re-entry {purchase.purchase_no} after {operation_ref}",
                ref_table="vendor_purchase",
                ref_id=purchase.id,
            ))

            db.session.add(VendorPurchaseItem(
                purchase_id=purchase.id,
                vendor_id=vendor.id,
                medicine_id=med.id,
                medicine_name=med.name,
                medicine_code=row["medicine_code"],
                barcode=row["barcode"],
                composition=row["composition"],
                company=row["company"],
                distributor_name=vendor.name,
                pack_type=row["pack_type"],
                pack_qty=row["pack_qty"],
                batch=row["batch"],
                expiry=row["expiry"],
                qty=qty,
                free_qty=0,
                remaining_qty=qty,
                purchase_rate=purchase_rate,
                mrp=to_float_safe(row["mrp"], 0),
                gst_percent=gst_percent,
                discount_percent=discount_percent,
                notes=f"Auto re-entry from bulk stock sale {operation_ref}",
                total_value=total_value,
            ))

            purchase_subtotal += taxable_amount
            purchase_gst_total += gst_amount
            purchase_discount_total += discount_amount
            purchase_total_amount += total_value

        purchase.subtotal = round_currency(purchase_subtotal)
        purchase.gst_total = round_currency(purchase_gst_total)
        purchase.discount_total = round_currency(purchase_discount_total)
        purchase.total_amount = round_currency(purchase_total_amount)
        purchase.paid_amount = purchase.total_amount

        vendor.last_purchase_date = purchase_created_at.date()
        vendor.total_purchases = round_currency((vendor.total_purchases or 0) + purchase.total_amount)
        vendor.payment_status = "Paid"
        if not getattr(vendor, "default_payment_mode", ""):
            vendor.default_payment_mode = "CASH"

        build_scoped_medicine_code_sync(touched_names)
        db.session.commit()
    except Exception as exc:
        db.session.rollback()
        app.logger.exception("Bulk stock sale failed")
        return None, summarize_exception_message(exc)

    invoice_nos = [invoice.invoice_no for invoice in created_invoices]
    for invoice in created_invoices:
        record_audit_event(
            action="Created stock sale invoice",
            entity_type="INVOICE",
            entity_id=invoice.id,
            ref_code=invoice.invoice_no,
            before=None,
            after=build_invoice_audit_snapshot(invoice),
            extra={
                "operation_ref": operation_ref,
                "payment_mode": invoice.payment_mode,
                "customer": invoice.customer,
            }
        )
    record_audit_event(
        action="Executed bulk stock sale",
        entity_type="INVENTORY",
        entity_id=vendor.id,
        ref_code=operation_ref,
        before=None,
        after=None,
        extra={
            "invoice_count": len(invoice_nos),
            "invoice_nos": invoice_nos,
            "purchase_no": purchase.purchase_no,
            "purchase_invoice_no": purchase.invoice_no,
            "reentry_vendor": vendor.name,
            "line_count": preview["line_count"],
            "total_qty": preview["total_qty"],
            "estimated_sale_value": preview["estimated_sale_value"],
        }
    )

    return {
        "operation_ref": operation_ref,
        "invoice_nos": invoice_nos,
        "purchase_no": purchase.purchase_no,
        "purchase_invoice_no": purchase.invoice_no,
        "vendor_name": vendor.name,
        "invoice_count": len(invoice_nos),
    }, None


def summarize_invoice_collection(invoices, returns=None):
    summary = {
        "invoice_count": 0,
        "sale_total": 0.0,
        "refund_total": 0.0,
        "net_sale_total": 0.0,
        "cash_collection": 0.0,
        "online_collection": 0.0,
        "cash_refund_total": 0.0,
        "online_refund_total": 0.0,
        "adjusted_payment_total": 0.0,
        "refund_due_total": 0.0,
        "split_payment_count": 0,
        "cash_invoice_count": 0,
        "online_invoice_count": 0,
        "return_count": 0,
    }

    for invoice in invoices or []:
        breakdown = build_invoice_payment_breakdown(invoice)
        summary["invoice_count"] += 1
        summary["sale_total"] += round_currency(getattr(invoice, "total", 0))
        summary["cash_collection"] += breakdown["cash_amount"]
        summary["online_collection"] += breakdown["online_amount"]
        if breakdown["cash_amount"] > 0:
            summary["cash_invoice_count"] += 1
        if breakdown["online_amount"] > 0:
            summary["online_invoice_count"] += 1
        if breakdown["is_split_payment"]:
            summary["split_payment_count"] += 1

    for return_bill in returns or []:
        if bool(getattr(return_bill, "is_cancelled", False)):
            continue
        breakdown = build_return_payment_breakdown(return_bill)
        summary["return_count"] += 1
        summary["refund_total"] += breakdown["refund_amount"]
        summary["cash_refund_total"] += breakdown["cash_refund_amount"]
        summary["online_refund_total"] += breakdown["online_refund_amount"]
        summary["adjusted_payment_total"] += round_currency(getattr(return_bill, "adjusted_amount", 0))
        summary["refund_due_total"] += round_currency(getattr(return_bill, "refund_amount", 0))
        summary["cash_collection"] -= breakdown["cash_refund_amount"]
        summary["online_collection"] -= breakdown["online_refund_amount"]

    summary["sale_total"] = round_currency(summary["sale_total"])
    summary["refund_total"] = round_currency(summary["refund_total"])
    summary["net_sale_total"] = round_currency(summary["sale_total"] - summary["refund_total"])
    summary["cash_collection"] = round_currency(summary["cash_collection"])
    summary["online_collection"] = round_currency(summary["online_collection"])
    summary["cash_refund_total"] = round_currency(summary["cash_refund_total"])
    summary["online_refund_total"] = round_currency(summary["online_refund_total"])
    summary["adjusted_payment_total"] = round_currency(summary["adjusted_payment_total"])
    summary["refund_due_total"] = round_currency(summary["refund_due_total"])
    return summary


def sanitize_json_payload(payload):
    if isinstance(payload, float):
        return payload if math.isfinite(payload) else 0.0
    if isinstance(payload, Decimal):
        as_float = float(payload)
        return as_float if math.isfinite(as_float) else 0.0
    if isinstance(payload, dict):
        return {
            str(key): sanitize_json_payload(value)
            for key, value in payload.items()
        }
    if isinstance(payload, (list, tuple, set)):
        return [sanitize_json_payload(item) for item in payload]
    return payload

def serialize_json_text(payload):
    if payload in (None, "", [], {}):
        return ""
    cleaned_payload = sanitize_json_payload(payload)
    try:
        return json.dumps(cleaned_payload, ensure_ascii=False, sort_keys=True, default=str, allow_nan=False)
    except Exception:
        return json.dumps({"value": str(cleaned_payload)}, ensure_ascii=False, sort_keys=True, allow_nan=False)

def parse_json_text(payload):
    raw = (payload or "").strip()
    if not raw:
        return None
    try:
        return json.loads(raw)
    except Exception:
        return {"raw": raw}


def get_existing_table_columns(table_name):
    try:
        inspector = inspect(db.engine)
        if not inspector.has_table(table_name):
            return {}
        return {column["name"]: column for column in inspector.get_columns(table_name)}
    except Exception:
        try:
            pragma_rows = db.session.execute(text(f'PRAGMA table_info("{table_name}")')).fetchall()
        except Exception:
            return {}
        return {
            row[1]: {"name": row[1], "type": row[2]}
            for row in pragma_rows
        }


def ensure_table_column_compat(table_name, column_name, column_def):
    existing_columns = get_existing_table_columns(table_name)
    if not existing_columns or column_name in existing_columns:
        return False
    db.session.execute(text(f'ALTER TABLE "{table_name}" ADD COLUMN "{column_name}" {column_def}'))
    db.session.commit()
    return True


def get_column_type_name(column_meta):
    if not isinstance(column_meta, dict):
        return ""
    column_type = column_meta.get("type")
    if column_type is None:
        return ""
    return f"{column_type} {column_type.__class__.__name__}".strip().lower()


def load_hold_bill_payload(raw_payload):
    if isinstance(raw_payload, (dict, list)):
        return raw_payload
    if isinstance(raw_payload, str):
        parsed = parse_json_text(raw_payload)
        if isinstance(parsed, (dict, list)):
            return parsed
    return {}


def hold_bill_payload_sql_expression(dialect_name, column_type_name):
    if dialect_name == "postgresql":
        if "jsonb" in column_type_name:
            return 'CAST(:payload_text AS JSONB)'
        if "json" in column_type_name:
            return 'CAST(:payload_text AS JSON)'
    return ':payload_text'


def create_hold_bill_table_compat():
    dialect_name = (db.session.bind.dialect.name if db.session.bind else "").lower()
    if dialect_name == "postgresql":
        db.session.execute(text(
            'CREATE TABLE IF NOT EXISTS "hold_bill" ('
            'id SERIAL PRIMARY KEY, '
            'customer TEXT, '
            'mobile TEXT, '
            'doctor TEXT, '
            'gender TEXT, '
            'data JSONB, '
            'created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, '
            'is_deleted BOOLEAN DEFAULT FALSE, '
            'deleted_at TIMESTAMP, '
            'deleted_by TEXT'
            ')'
        ))
    else:
        db.session.execute(text(
            'CREATE TABLE IF NOT EXISTS "hold_bill" ('
            'id INTEGER PRIMARY KEY AUTOINCREMENT, '
            'customer TEXT, '
            'mobile TEXT, '
            'doctor TEXT, '
            'gender TEXT, '
            'data TEXT, '
            'created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, '
            'is_deleted BOOLEAN DEFAULT FALSE, '
            'deleted_at TIMESTAMP, '
            'deleted_by TEXT'
            ')'
        ))
    db.session.commit()


def create_pending_bill_store_table_compat():
    dialect_name = (db.session.bind.dialect.name if db.session.bind else "").lower()
    if dialect_name == "postgresql":
        db.session.execute(text(
            'CREATE TABLE IF NOT EXISTS "pending_bill_store" ('
            'id SERIAL PRIMARY KEY, '
            'legacy_hold_bill_id INTEGER UNIQUE, '
            'customer TEXT, '
            'mobile TEXT, '
            'doctor TEXT, '
            'gender TEXT, '
            'data_text TEXT, '
            'created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, '
            'is_deleted BOOLEAN DEFAULT FALSE, '
            'deleted_at TIMESTAMP, '
            'deleted_by TEXT'
            ')'
        ))
    else:
        db.session.execute(text(
            'CREATE TABLE IF NOT EXISTS "pending_bill_store" ('
            'id INTEGER PRIMARY KEY AUTOINCREMENT, '
            'legacy_hold_bill_id INTEGER UNIQUE, '
            'customer TEXT, '
            'mobile TEXT, '
            'doctor TEXT, '
            'gender TEXT, '
            'data_text TEXT, '
            'created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, '
            'is_deleted BOOLEAN DEFAULT FALSE, '
            'deleted_at TIMESTAMP, '
            'deleted_by TEXT'
            ')'
        ))
    db.session.commit()


def sync_table_identity_compat(table_name, column_name="id"):
    dialect_name = (db.session.bind.dialect.name if db.session.bind else "").lower()
    if dialect_name != "postgresql":
        return
    try:
        db.session.execute(text(
            "SELECT setval("
            f"pg_get_serial_sequence('{table_name}', '{column_name}'), "
            f'COALESCE((SELECT MAX("{column_name}") FROM "{table_name}"), 1), '
            "TRUE)"
        ))
        db.session.commit()
    except Exception:
        db.session.rollback()
        app.logger.exception("Unable to sync %s.%s identity sequence.", table_name, column_name)


def repair_pending_bill_store_compat():
    existing_columns = get_existing_table_columns("pending_bill_store")
    if not existing_columns:
        try:
            create_pending_bill_store_table_compat()
            existing_columns = get_existing_table_columns("pending_bill_store")
        except Exception:
            db.session.rollback()
            app.logger.exception("Unable to create pending_bill_store table.")
            return False
    if not existing_columns:
        return False

    changed = False
    for column_name, column_def in (
        ("legacy_hold_bill_id", "INTEGER"),
        ("customer", "TEXT"),
        ("mobile", "TEXT"),
        ("doctor", "TEXT"),
        ("gender", "TEXT"),
        ("data_text", "TEXT"),
        ("created_at", "TIMESTAMP"),
        ("is_deleted", "BOOLEAN DEFAULT FALSE"),
        ("deleted_at", "TIMESTAMP"),
        ("deleted_by", "TEXT"),
    ):
        try:
            changed = ensure_table_column_compat("pending_bill_store", column_name, column_def) or changed
        except Exception:
            db.session.rollback()
            app.logger.exception("Unable to add pending_bill_store.%s compatibility column", column_name)

    try:
        db.session.execute(text(
            'CREATE UNIQUE INDEX IF NOT EXISTS "ix_pending_bill_store_legacy_hold_bill_id" '
            'ON "pending_bill_store" ("legacy_hold_bill_id")'
        ))
        db.session.execute(text(
            'UPDATE "pending_bill_store" SET "created_at" = CURRENT_TIMESTAMP WHERE "created_at" IS NULL'
        ))
        db.session.execute(text(
            'UPDATE "pending_bill_store" SET "is_deleted" = FALSE WHERE "is_deleted" IS NULL'
        ))
        db.session.commit()
    except Exception:
        db.session.rollback()
        app.logger.exception("Unable to backfill pending_bill_store defaults.")
    return changed


def repair_hold_bill_schema_compat():
    existing_columns = get_existing_table_columns("hold_bill")
    if not existing_columns:
        try:
            create_hold_bill_table_compat()
            existing_columns = get_existing_table_columns("hold_bill")
        except Exception:
            db.session.rollback()
            app.logger.exception("Unable to create missing hold_bill table.")
            return False
    if not existing_columns:
        return False

    changed = False
    for column_name, column_def in (
        ("customer", "TEXT"),
        ("mobile", "TEXT"),
        ("doctor", "TEXT"),
        ("gender", "TEXT"),
        ("data", "TEXT"),
        ("created_at", "TIMESTAMP"),
        ("is_deleted", "BOOLEAN DEFAULT FALSE"),
        ("deleted_at", "TIMESTAMP"),
        ("deleted_by", "TEXT"),
    ):
        try:
            changed = ensure_table_column_compat("hold_bill", column_name, column_def) or changed
        except Exception:
            db.session.rollback()
            app.logger.exception("Unable to add hold_bill.%s compatibility column", column_name)

    existing_columns = get_existing_table_columns("hold_bill")
    dialect_name = (db.session.bind.dialect.name if db.session.bind else "").lower()
    data_column_type = get_column_type_name(existing_columns.get("data"))

    if dialect_name == "postgresql" and data_column_type and "json" not in data_column_type:
        try:
            db.session.execute(text(
                'ALTER TABLE "hold_bill" ALTER COLUMN "data" TYPE JSONB USING '
                'CASE '
                'WHEN "data" IS NULL OR BTRIM(CAST("data" AS TEXT)) = \'\' THEN NULL '
                'ELSE CAST("data" AS JSONB) '
                'END'
            ))
            db.session.commit()
            changed = True
            existing_columns = get_existing_table_columns("hold_bill")
        except Exception:
            db.session.rollback()
            app.logger.exception("Unable to convert hold_bill.data to JSONB; legacy fallback will be used.")

    try:
        if "created_at" in existing_columns:
            db.session.execute(text(
                'UPDATE "hold_bill" SET "created_at" = CURRENT_TIMESTAMP WHERE "created_at" IS NULL'
            ))
        if "is_deleted" in existing_columns:
            db.session.execute(text(
                'UPDATE "hold_bill" SET "is_deleted" = FALSE WHERE "is_deleted" IS NULL'
            ))
        db.session.commit()
    except Exception:
        db.session.rollback()
        app.logger.exception("Unable to backfill hold_bill compatibility defaults.")

    return changed


def upsert_hold_bill_compat(*, hold_bill_id=0, customer="", mobile="", doctor="", gender="", payload=None):
    repair_hold_bill_schema_compat()
    existing_columns = get_existing_table_columns("hold_bill")
    if not existing_columns:
        return False

    dialect_name = (db.session.bind.dialect.name if db.session.bind else "").lower()
    data_column_type = get_column_type_name(existing_columns.get("data"))
    payload_expression = hold_bill_payload_sql_expression(dialect_name, data_column_type)
    params = {
        "hold_bill_id": hold_bill_id,
        "customer": (customer or "").strip() or None,
        "mobile": (mobile or "").strip() or None,
        "doctor": (doctor or "").strip() or None,
        "gender": (gender or "").strip() or None,
        "payload_text": serialize_json_text(payload) or None,
    }

    try:
        if hold_bill_id > 0:
            assignments = []
            for column_name in ("customer", "mobile", "doctor", "gender"):
                if column_name in existing_columns:
                    assignments.append(f'"{column_name}" = :{column_name}')
            if "data" in existing_columns:
                assignments.append(f'"data" = {payload_expression}')
            if "is_deleted" in existing_columns:
                assignments.append('"is_deleted" = FALSE')
            if "deleted_at" in existing_columns:
                assignments.append('"deleted_at" = NULL')
            if "deleted_by" in existing_columns:
                assignments.append('"deleted_by" = NULL')

            if assignments:
                result = db.session.execute(
                    text(f'UPDATE "hold_bill" SET {", ".join(assignments)} WHERE "id" = :hold_bill_id'),
                    params,
                )
                db.session.commit()
                if (result.rowcount or 0) > 0:
                    return True

        insert_columns = []
        insert_values = []
        explicit_id = hold_bill_id if hold_bill_id > 0 else None
        if explicit_id is None and "id" in existing_columns:
            explicit_id = to_int_safe(
                db.session.execute(text('SELECT COALESCE(MAX("id"), 0) + 1 FROM "hold_bill"')).scalar(),
                1,
            )
        if explicit_id is not None and "id" in existing_columns:
            params["insert_id"] = explicit_id
            insert_columns.append('"id"')
            insert_values.append(":insert_id")
        for column_name in ("customer", "mobile", "doctor", "gender"):
            if column_name in existing_columns:
                insert_columns.append(f'"{column_name}"')
                insert_values.append(f':{column_name}')
        if "data" in existing_columns:
            insert_columns.append('"data"')
            insert_values.append(payload_expression)
        if "created_at" in existing_columns:
            insert_columns.append('"created_at"')
            insert_values.append("CURRENT_TIMESTAMP")
        if "is_deleted" in existing_columns:
            insert_columns.append('"is_deleted"')
            insert_values.append("FALSE")

        if not insert_columns:
            return False

        db.session.execute(
            text(
                f'INSERT INTO "hold_bill" ({", ".join(insert_columns)}) '
                f'VALUES ({", ".join(insert_values)})'
            ),
            params,
        )
        db.session.commit()
        return True
    except Exception:
        db.session.rollback()
        app.logger.exception("Fallback hold bill persistence failed.")
        return False


def upsert_pending_bill_store_compat(*, pending_bill_id=0, customer="", mobile="", doctor="", gender="", payload=None):
    repair_pending_bill_store_compat()
    existing_columns = get_existing_table_columns("pending_bill_store")
    if not existing_columns:
        return False

    sync_table_identity_compat("pending_bill_store")
    params = {
        "pending_bill_id": pending_bill_id,
        "customer": (customer or "").strip() or None,
        "mobile": (mobile or "").strip() or None,
        "doctor": (doctor or "").strip() or None,
        "gender": (gender or "").strip() or None,
        "payload_text": serialize_json_text(payload) or None,
    }

    try:
        if pending_bill_id > 0:
            assignments = []
            for column_name in ("customer", "mobile", "doctor", "gender"):
                if column_name in existing_columns:
                    assignments.append(f'"{column_name}" = :{column_name}')
            if "data_text" in existing_columns:
                assignments.append('"data_text" = :payload_text')
            if "is_deleted" in existing_columns:
                assignments.append('"is_deleted" = FALSE')
            if "deleted_at" in existing_columns:
                assignments.append('"deleted_at" = NULL')
            if "deleted_by" in existing_columns:
                assignments.append('"deleted_by" = NULL')

            if assignments:
                result = db.session.execute(
                    text(f'UPDATE "pending_bill_store" SET {", ".join(assignments)} WHERE "id" = :pending_bill_id'),
                    params,
                )
                db.session.commit()
                if (result.rowcount or 0) > 0:
                    sync_table_identity_compat("pending_bill_store")
                    return True

        insert_columns = []
        insert_values = []
        if pending_bill_id > 0 and "id" in existing_columns:
            params["insert_id"] = pending_bill_id
            insert_columns.append('"id"')
            insert_values.append(":insert_id")
        for column_name in ("customer", "mobile", "doctor", "gender"):
            if column_name in existing_columns:
                insert_columns.append(f'"{column_name}"')
                insert_values.append(f':{column_name}')
        if "data_text" in existing_columns:
            insert_columns.append('"data_text"')
            insert_values.append(":payload_text")
        if "created_at" in existing_columns:
            insert_columns.append('"created_at"')
            insert_values.append("CURRENT_TIMESTAMP")
        if "is_deleted" in existing_columns:
            insert_columns.append('"is_deleted"')
            insert_values.append("FALSE")

        if not insert_columns:
            return False

        db.session.execute(
            text(
                f'INSERT INTO "pending_bill_store" ({", ".join(insert_columns)}) '
                f'VALUES ({", ".join(insert_values)})'
            ),
            params,
        )
        db.session.commit()
        sync_table_identity_compat("pending_bill_store")
        return True
    except Exception:
        db.session.rollback()
        app.logger.exception("Pending bill store compatibility persistence failed.")
        return False


def load_file_hold_bill_records():
    try:
        if not os.path.exists(HOLD_BILL_FALLBACK_FILE):
            return {}
        with open(HOLD_BILL_FALLBACK_FILE, "r", encoding="utf-8") as handle:
            payload = json.load(handle)
        if isinstance(payload, dict):
            return payload
    except Exception:
        app.logger.exception("Unable to read hold bill fallback file.")
    return {}


def save_file_hold_bill_records(records):
    os.makedirs(os.path.dirname(HOLD_BILL_FALLBACK_FILE), exist_ok=True)
    with open(HOLD_BILL_FALLBACK_FILE, "w", encoding="utf-8") as handle:
        json.dump(records, handle, ensure_ascii=False, sort_keys=True, indent=2)


def next_file_hold_bill_id(records):
    max_id = 900000
    for key in records.keys():
        max_id = max(max_id, to_int_safe(key, max_id))
    return max_id + 1


def save_file_hold_bill(*, hold_bill_id=0, customer="", mobile="", doctor="", gender="", payload=None):
    records = load_file_hold_bill_records()
    if hold_bill_id > 0 and str(hold_bill_id) in records:
        record_id = hold_bill_id
        created_at = records[str(record_id)].get("created_at") or datetime.utcnow().isoformat()
    else:
        record_id = next_file_hold_bill_id(records)
        created_at = datetime.utcnow().isoformat()

    records[str(record_id)] = {
        "id": record_id,
        "customer": (customer or "").strip(),
        "mobile": (mobile or "").strip(),
        "doctor": (doctor or "").strip(),
        "gender": (gender or "").strip(),
        "data": sanitize_json_payload(payload or {}),
        "created_at": created_at,
        "is_deleted": False,
        "deleted_at": None,
        "deleted_by": None,
        "source": "file_fallback",
    }
    save_file_hold_bill_records(records)
    return record_id


def get_file_hold_bill(hold_bill_id):
    records = load_file_hold_bill_records()
    record = records.get(str(hold_bill_id))
    if not isinstance(record, dict):
        return None
    return record


def delete_file_hold_bill(hold_bill_id):
    records = load_file_hold_bill_records()
    if str(hold_bill_id) not in records:
        return False
    records.pop(str(hold_bill_id), None)
    save_file_hold_bill_records(records)
    return True


def list_file_hold_bills():
    rows = []
    for record in load_file_hold_bill_records().values():
        if not isinstance(record, dict):
            continue
        created_at_raw = (record.get("created_at") or "").strip()
        try:
            created_at = datetime.fromisoformat(created_at_raw) if created_at_raw else datetime.utcnow()
        except Exception:
            created_at = datetime.utcnow()
        rows.append({
            "id": to_int_safe(record.get("id"), 0),
            "customer": (record.get("customer") or "").strip(),
            "mobile": (record.get("mobile") or "").strip(),
            "doctor": (record.get("doctor") or "").strip(),
            "gender": (record.get("gender") or "").strip(),
            "data": record.get("data") or {},
            "created_at": created_at,
            "is_deleted": False,
            "source": "file_fallback",
        })
    rows.sort(key=lambda row: (row.get("created_at") or datetime.utcnow(), row.get("id") or 0), reverse=True)
    return rows


def extract_hold_bill_payload_source(hold_bill):
    if hold_bill is None:
        return {}
    if hasattr(hold_bill, "data_text"):
        return getattr(hold_bill, "data_text", "")
    return getattr(hold_bill, "data", {})


def create_pending_bill_store_record(
    *,
    record_id=None,
    legacy_hold_bill_id=None,
    customer="",
    mobile="",
    doctor="",
    gender="",
    payload=None,
    created_at=None,
    is_deleted=False,
    deleted_at=None,
    deleted_by=None,
):
    record = PendingBillStore(
        legacy_hold_bill_id=legacy_hold_bill_id,
        customer=(customer or "").strip(),
        mobile=(mobile or "").strip(),
        doctor=(doctor or "").strip(),
        gender=(gender or "").strip(),
        data_text=serialize_json_text(payload),
        created_at=created_at or datetime.utcnow(),
        is_deleted=bool(is_deleted),
        deleted_at=deleted_at,
        deleted_by=deleted_by,
    )
    if record_id is not None:
        record.id = record_id
    return record


def sync_pending_bill_store():
    repair_pending_bill_store_compat()
    if not get_existing_table_columns("pending_bill_store"):
        return False

    migrated = False

    try:
        db.session.flush()
    except Exception:
        db.session.rollback()

    existing_by_legacy = {
        row.legacy_hold_bill_id: row
        for row in PendingBillStore.query.filter(PendingBillStore.legacy_hold_bill_id.isnot(None)).all()
    }
    existing_ids = {row[0] for row in db.session.query(PendingBillStore.id).all()}

    try:
        legacy_rows = active_legacy_hold_bill_query().order_by(HoldBill.id.asc()).all()
    except Exception:
        db.session.rollback()
        legacy_rows = []

    for legacy in legacy_rows:
        if legacy.id in existing_by_legacy:
            continue
        payload = load_hold_bill_payload(extract_hold_bill_payload_source(legacy))
        record_id = legacy.id if legacy.id not in existing_ids else None
        db.session.add(
            create_pending_bill_store_record(
                record_id=record_id,
                legacy_hold_bill_id=legacy.id,
                customer=getattr(legacy, "customer", ""),
                mobile=getattr(legacy, "mobile", ""),
                doctor=getattr(legacy, "doctor", ""),
                gender=getattr(legacy, "gender", ""),
                payload=payload,
                created_at=getattr(legacy, "created_at", None),
                is_deleted=getattr(legacy, "is_deleted", False),
                deleted_at=getattr(legacy, "deleted_at", None),
                deleted_by=getattr(legacy, "deleted_by", None),
            )
        )
        migrated = True
        if record_id:
            existing_ids.add(record_id)

    file_rows = list_file_hold_bills()
    if file_rows:
        existing_store_ids = {row[0] for row in db.session.query(PendingBillStore.id).all()}
        for row in file_rows:
            record_id = row["id"] if row["id"] not in existing_store_ids else None
            db.session.add(
                create_pending_bill_store_record(
                    record_id=record_id,
                    legacy_hold_bill_id=None,
                    customer=row.get("customer"),
                    mobile=row.get("mobile"),
                    doctor=row.get("doctor"),
                    gender=row.get("gender"),
                    payload=row.get("data"),
                    created_at=row.get("created_at"),
                    is_deleted=row.get("is_deleted", False),
                    deleted_at=row.get("deleted_at"),
                    deleted_by=row.get("deleted_by"),
                )
            )
            migrated = True
            if record_id is not None:
                existing_store_ids.add(record_id)
        if migrated:
            try:
                save_file_hold_bill_records({})
            except Exception:
                app.logger.exception("Unable to clear file fallback hold bill records after migration.")

    if migrated:
        try:
            db.session.commit()
            sync_table_identity_compat("pending_bill_store")
        except Exception:
            db.session.rollback()
            app.logger.exception("Unable to migrate pending bill records into stable store.")
            return False
    return True


def find_pending_bill_record(pending_bill_id, *, include_deleted=False, sync_if_missing=False):
    pending_bill_id = to_int_safe(pending_bill_id, 0)
    if pending_bill_id <= 0:
        return None

    def query_record():
        base_query = PendingBillStore.query if include_deleted else active_hold_bill_query()
        return base_query.filter(
            or_(
                PendingBillStore.id == pending_bill_id,
                PendingBillStore.legacy_hold_bill_id == pending_bill_id,
            )
        ).order_by(PendingBillStore.id.desc()).first()

    try:
        record = query_record()
    except Exception:
        db.session.rollback()
        app.logger.exception("Unable to read pending bill record %s.", pending_bill_id)
        record = None

    if record is None and sync_if_missing:
        repair_pending_bill_store_compat()
        sync_pending_bill_store()
        try:
            record = query_record()
        except Exception:
            db.session.rollback()
            app.logger.exception("Unable to re-read pending bill record %s after sync.", pending_bill_id)
            record = None
    return record


def get_release_identifier():
    return (
        os.environ.get("RAILWAY_GIT_COMMIT_SHA")
        or os.environ.get("RENDER_GIT_COMMIT")
        or os.environ.get("VERCEL_GIT_COMMIT_SHA")
        or os.environ.get("SOURCE_VERSION")
        or "local"
    )


def mask_database_target(engine_url):
    try:
        backend = engine_url.get_backend_name()
    except Exception:
        return "unknown"

    if backend == "sqlite":
        database_name = os.path.basename(engine_url.database or "") or "pharmacy.db"
        return database_name

    host = (getattr(engine_url, "host", "") or "").strip()
    port = getattr(engine_url, "port", None)
    database_name = (getattr(engine_url, "database", "") or "").strip()
    host_part = host or backend
    if port:
        host_part = f"{host_part}:{port}"
    if database_name:
        return f"{host_part}/{database_name}"
    return host_part


def format_bytes(size_value):
    size = float(size_value or 0)
    units = ("B", "KB", "MB", "GB", "TB")
    unit_index = 0
    while size >= 1024 and unit_index < len(units) - 1:
        size /= 1024.0
        unit_index += 1
    if unit_index == 0:
        return f"{int(size)} {units[unit_index]}"
    return f"{size:.2f} {units[unit_index]}"


def summarize_directory(path_value):
    summary = {
        "path": path_value,
        "available": os.path.isdir(path_value),
        "file_count": 0,
        "total_bytes": 0,
        "total_size": "0 B",
        "latest_file_at": None
    }
    if not summary["available"]:
        return summary

    latest_mtime = None
    for root, _dirs, files in os.walk(path_value):
        for name in files:
            file_path = os.path.join(root, name)
            try:
                stat_result = os.stat(file_path)
            except OSError:
                continue
            summary["file_count"] += 1
            summary["total_bytes"] += int(stat_result.st_size or 0)
            if latest_mtime is None or stat_result.st_mtime > latest_mtime:
                latest_mtime = stat_result.st_mtime
    summary["total_size"] = format_bytes(summary["total_bytes"])
    if latest_mtime is not None:
        summary["latest_file_at"] = datetime.fromtimestamp(latest_mtime).strftime("%d-%m-%Y %I:%M %p")
    return summary


def current_client_ip():
    forwarded = (request.headers.get("X-Forwarded-For") or "").strip()
    if forwarded:
        return forwarded.split(",")[0].strip()
    return (request.headers.get("X-Real-IP") or request.remote_addr or "").strip() or "unknown"


def current_user_agent():
    return (request.headers.get("User-Agent") or "").strip()[:255]


TENANT_LOGIN_ALLOWED_STATUSES = {"trial", "active", "expired"}
TENANT_TERMINAL_STATUSES = {"expired", "suspended", "cancelled"}
TENANT_STATUS_OPTIONS = ("Trial", "Active", "Expired", "Suspended", "Cancelled")
PLATFORM_SUPER_ADMIN_ROLE = "super_admin"
SUBSCRIPTION_PLAN_DEFINITIONS = {
    "trial": {
        "name": "Free Trial",
        "cycle": "trial",
        "days": 14,
        "amount": 0,
        "user_limit": 3,
        "features": {"pos": True, "inventory": True, "reports": True, "exports": True},
    },
    "monthly": {
        "name": "Monthly Plan",
        "cycle": "monthly",
        "days": 30,
        "amount": 1999,
        "user_limit": 6,
        "features": {"pos": True, "inventory": True, "reports": True, "exports": True},
    },
    "quarterly": {
        "name": "Quarterly Plan",
        "cycle": "quarterly",
        "days": 90,
        "amount": 5499,
        "user_limit": 10,
        "features": {"pos": True, "inventory": True, "reports": True, "exports": True},
    },
    "yearly": {
        "name": "Yearly Plan",
        "cycle": "yearly",
        "days": 365,
        "amount": 19999,
        "user_limit": 20,
        "features": {"pos": True, "inventory": True, "reports": True, "exports": True},
    },
    "custom": {
        "name": "Custom Plan",
        "cycle": "custom",
        "days": 30,
        "amount": 0,
        "user_limit": None,
        "features": {"pos": True, "inventory": True, "reports": True, "exports": True},
    },
}
SUBSCRIPTION_READONLY_ALLOWED_ENDPOINT_PREFIXES = (
    "export_",
    "print_",
    "shared_",
)
SUBSCRIPTION_MUTATION_ALLOWLIST = {
    "logout",
    "logout_everywhere",
    "change_password",
}


def normalize_tenant_code(value):
    normalized = re.sub(r"[^a-z0-9]+", "-", str(value or "").strip().lower()).strip("-")
    return normalized[:80] or "default"


def generate_tenant_uid():
    return "TEN-" + secrets.token_urlsafe(18).replace("-", "").replace("_", "")[:24].upper()


def tenant_login_allowed(tenant):
    return bool(tenant and (tenant.status or "").strip().lower() in TENANT_LOGIN_ALLOWED_STATUSES)


def is_super_admin_user(user=None):
    role = getattr(user, "role", None) if user is not None else session.get("role")
    return (role or "").strip().lower() == PLATFORM_SUPER_ADMIN_ROLE


def subscription_serializer():
    return URLSafeSerializer(app.secret_key, salt="tenant-admin-activation-v1")


def build_admin_activation_token(user):
    expires_at = datetime.utcnow() + timedelta(days=7)
    return subscription_serializer().dumps({
        "user_id": int(user.id),
        "tenant_id": int(user.tenant_id),
        "session_version": int(user.session_version or 0),
        "expires_at": expires_at.isoformat(),
    })


def read_admin_activation_token(token):
    try:
        payload = subscription_serializer().loads(token or "")
    except BadSignature:
        return None
    try:
        expires_at = datetime.fromisoformat(payload.get("expires_at") or "")
    except (TypeError, ValueError):
        return None
    if datetime.utcnow() > expires_at:
        return None
    return payload


def normalize_plan_ref(value):
    cleaned = re.sub(r"[^a-z0-9_-]+", "-", str(value or "").strip().lower()).strip("-")
    return cleaned or "trial"


def parse_subscription_amount(value, default=0):
    try:
        return round(float(str(value if value not in (None, "") else default).strip() or 0), 2)
    except (TypeError, ValueError):
        return round(float(default or 0), 2)


def plan_definition(plan_ref):
    key = normalize_plan_ref(plan_ref)
    return SUBSCRIPTION_PLAN_DEFINITIONS.get(key, SUBSCRIPTION_PLAN_DEFINITIONS["custom"])


def tenant_subscription_settings(tenant):
    settings = tenant_settings_dict(tenant)
    subscription = settings.get("subscription") if isinstance(settings.get("subscription"), dict) else {}
    return subscription


def tenant_subscription_is_expired(tenant, today_value=None):
    expiry = getattr(tenant, "subscription_expiry", None)
    if not expiry:
        return False
    today_value = today_value or clinic_now().date()
    return expiry < today_value


def refresh_tenant_subscription_status(tenant, *, commit=False):
    if not tenant:
        return tenant
    status = (tenant.status or "").strip().title()
    if status in {"Active", "Trial"} and tenant_subscription_is_expired(tenant):
        tenant.status = "Expired"
        if commit:
            db.session.commit()
    return tenant


def apply_subscription_to_tenant(
    tenant,
    *,
    plan_ref="trial",
    start_date=None,
    expiry_date=None,
    amount=None,
    payment_mode="Manual",
    payment_reference="",
    user_limit=None,
    features=None,
    notes="",
    status="Active",
    created_by=None,
):
    plan_ref = normalize_plan_ref(plan_ref)
    plan = plan_definition(plan_ref)
    start_date = start_date or clinic_now().date()
    if not expiry_date:
        expiry_date = start_date + timedelta(days=int(plan.get("days") or 30))
    if amount is None:
        amount = plan.get("amount", 0)
    if user_limit in (None, "", " "):
        user_limit = plan.get("user_limit")
    try:
        normalized_user_limit = int(user_limit) if user_limit not in (None, "", " ") else None
    except (TypeError, ValueError):
        normalized_user_limit = plan.get("user_limit")
    entitlements = features if isinstance(features, dict) else dict(plan.get("features") or {})
    tenant.subscription_plan_ref = plan_ref
    tenant.subscription_start = start_date
    tenant.subscription_expiry = expiry_date
    tenant.status = status if status in TENANT_STATUS_OPTIONS else "Active"
    if tenant.status in {"Active", "Trial"} and not tenant.activated_at:
        tenant.activated_at = datetime.utcnow()
    settings = tenant_settings_dict(tenant)
    settings["subscription"] = {
        "plan_ref": plan_ref,
        "plan_name": plan.get("name", plan_ref.title()),
        "billing_cycle": plan.get("cycle", plan_ref),
        "user_limit": normalized_user_limit,
        "features": entitlements,
        "readonly_after_expiry": True,
        "last_payment_amount": parse_subscription_amount(amount),
        "last_payment_mode": (payment_mode or "Manual").strip(),
        "last_payment_reference": (payment_reference or "").strip(),
    }
    update_tenant_settings(tenant, settings)
    history = SubscriptionHistory(
        tenant_id=tenant.id,
        plan_ref=plan_ref,
        plan_name=plan.get("name", plan_ref.title()),
        billing_cycle=plan.get("cycle", plan_ref),
        start_date=start_date,
        expiry_date=expiry_date,
        status=tenant.status,
        user_limit=normalized_user_limit,
        feature_entitlements_json=json.dumps(entitlements, sort_keys=True),
        amount=parse_subscription_amount(amount),
        payment_mode=(payment_mode or "Manual").strip()[:40],
        payment_reference=(payment_reference or "").strip()[:120],
        notes=(notes or "").strip(),
        created_by=(created_by or session.get("username") or "system")[:50],
    )
    db.session.add(history)
    return history


def tenant_feature_enabled(feature_name, tenant=None):
    if tenant is None:
        tenant = current_tenant()
    if not tenant:
        return False
    refresh_tenant_subscription_status(tenant)
    if (tenant.status or "").strip().lower() in {"suspended", "cancelled"}:
        return False
    subscription = tenant_subscription_settings(tenant)
    features = subscription.get("features") if isinstance(subscription.get("features"), dict) else {}
    return bool(features.get(feature_name, True))


def tenant_user_limit_reached(tenant):
    subscription = tenant_subscription_settings(tenant)
    user_limit = subscription.get("user_limit")
    if user_limit in (None, "", 0):
        return False
    try:
        user_limit = int(user_limit)
    except (TypeError, ValueError):
        return False
    if user_limit <= 0:
        return False
    with tenant_context(tenant.id):
        active_count = active_user_query().filter(User.tenant_id == tenant.id).count()
    return active_count >= user_limit


def tenant_from_identifier(identifier):
    cleaned = (identifier or "").strip()
    if not cleaned:
        return None
    return Tenant.query.filter(
        or_(
            db.func.lower(Tenant.tenant_code) == cleaned.lower(),
            db.func.lower(Tenant.tenant_uid) == cleaned.lower(),
            db.func.lower(Tenant.email) == cleaned.lower(),
        )
    ).first()


def create_default_tenant(*, commit=True):
    settings = TenantSettings(settings_json="{}")
    tenant = Tenant(
        tenant_uid=generate_tenant_uid(),
        tenant_code=normalize_tenant_code(os.environ.get("DEFAULT_TENANT_CODE") or "default"),
        pharmacy_name=(os.environ.get("DEFAULT_PHARMACY_NAME") or "The Endo Pharmacy").strip(),
        owner_name=(os.environ.get("DEFAULT_TENANT_OWNER") or "").strip(),
        contact_number=(os.environ.get("DEFAULT_TENANT_CONTACT") or "").strip(),
        email=(os.environ.get("DEFAULT_TENANT_EMAIL") or "").strip(),
        business_address=(os.environ.get("DEFAULT_TENANT_ADDRESS") or "").strip(),
        gstin=(os.environ.get("DEFAULT_TENANT_GSTIN") or "").strip(),
        drug_license=(os.environ.get("DEFAULT_TENANT_DRUG_LICENSE") or "").strip(),
        subscription_plan_ref=(os.environ.get("DEFAULT_SUBSCRIPTION_PLAN") or "legacy").strip(),
        subscription_start=date.today(),
        status="Active",
        activated_at=datetime.utcnow(),
        settings=settings,
    )
    db.session.add(settings)
    db.session.add(tenant)
    if commit:
        db.session.commit()
    return tenant


def ensure_default_tenant_for_legacy_users():
    """Create/link one default tenant only for a legacy single-tenant install."""
    tenant_count = Tenant.query.count()
    if tenant_count == 0:
        tenant = create_default_tenant(commit=False)
        db.session.flush()
        backfill_unassigned_rows_to_tenant(tenant.id)
        db.session.commit()
        return tenant
    if tenant_count == 1:
        tenant = Tenant.query.order_by(Tenant.id.asc()).first()
        if tenant:
            backfill_unassigned_rows_to_tenant(tenant.id)
            db.session.commit()
        return tenant
    return None


def backfill_unassigned_rows_to_tenant(tenant_id):
    try:
        inspector = inspect(db.engine)
        table_names = set(inspector.get_table_names())
    except Exception:
        table_names = set(TENANT_OWNED_TABLE_NAMES)
        inspector = None
    for table_name in TENANT_OWNED_TABLE_NAMES:
        if table_name not in table_names:
            continue
        try:
            columns = {col["name"] for col in inspector.get_columns(table_name)} if inspector else {"tenant_id"}
        except Exception:
            columns = {"tenant_id"}
        if "tenant_id" not in columns:
            continue
        extra_where = ' AND COALESCE("role", \'\') != :super_admin_role' if table_name == "user" else ""
        params = {"tenant_id": int(tenant_id)}
        if table_name == "user":
            params["super_admin_role"] = PLATFORM_SUPER_ADMIN_ROLE
        db.session.execute(
            text(f'UPDATE "{table_name}" SET "tenant_id" = :tenant_id WHERE "tenant_id" IS NULL{extra_where}'),
            params,
        )


def current_tenant():
    tenant_id = session.get("tenant_id")
    if tenant_id:
        return Tenant.query.filter(Tenant.id == tenant_id).first()
    return None


_tenant_context = contextvars.ContextVar("tenant_context", default=None)
_tenant_scope_disabled = contextvars.ContextVar("tenant_scope_disabled", default=False)


def current_tenant_id():
    value = _tenant_context.get()
    if value not in (None, "", 0):
        try:
            return int(value)
        except (TypeError, ValueError):
            return None
    try:
        value = session.get("tenant_id")
    except RuntimeError:
        value = None
    try:
        return int(value) if value not in (None, "", 0) else None
    except (TypeError, ValueError):
        return None


def set_tenant_context(tenant_id):
    normalized = None
    if tenant_id not in (None, "", 0):
        normalized = int(tenant_id)
    return _tenant_context.set(normalized)


def reset_tenant_context(token):
    _tenant_context.reset(token)


@contextmanager
def tenant_context(tenant_id):
    token = set_tenant_context(tenant_id)
    try:
        if has_app_context() and db.session().in_transaction():
            set_postgres_tenant_context(db.session().connection(), current_tenant_id())
        yield
    finally:
        reset_tenant_context(token)
        if has_app_context() and db.session().in_transaction():
            set_postgres_tenant_context(db.session().connection(), current_tenant_id())


@contextmanager
def tenant_scope_disabled():
    token = _tenant_scope_disabled.set(True)
    try:
        yield
    finally:
        _tenant_scope_disabled.reset(token)


TENANT_OWNED_MODELS = (
    User,
    Medicine,
    Invoice,
    InvoiceItem,
    Return,
    ReturnItem,
    ReturnLotAllocation,
    QuarantineStock,
    HoldBill,
    PendingBillStore,
    Patient,
    Appointment,
    LabTest,
    LabOrder,
    LabOrderItem,
    LabReport,
    PortalOtpChallenge,
    AppointmentBookingSettings,
    PublicAppointmentBooking,
    PublicAppointmentDayLock,
    Vendor,
    VendorPurchase,
    VendorPurchaseItem,
    SalesAllocation,
    VendorNote,
    VendorNoteItem,
    VendorNoteAllocation,
    VendorLedgerEntry,
    AuditLog,
    LoginSecurityEvent,
)


TENANT_REFERENCE_CHECKS = (
    (InvoiceItem, "invoice_id", Invoice),
    (Return, "invoice_id", Invoice),
    (ReturnItem, "return_id", Return),
    (ReturnItem, "invoice_item_id", InvoiceItem),
    (ReturnLotAllocation, "return_item_id", ReturnItem),
    (ReturnLotAllocation, "purchase_item_id", VendorPurchaseItem),
    (QuarantineStock, "return_id", Return),
    (QuarantineStock, "return_item_id", ReturnItem),
    (QuarantineStock, "invoice_item_id", InvoiceItem),
    (PendingBillStore, "legacy_hold_bill_id", HoldBill),
    (Appointment, "patient_id", Patient),
    (LabOrder, "patient_id", Patient),
    (LabOrderItem, "lab_order_id", LabOrder),
    (LabOrderItem, "lab_test_id", LabTest),
    (LabReport, "lab_order_id", LabOrder),
    (LabReport, "lab_order_item_id", LabOrderItem),
    (LabReport, "patient_id", Patient),
    (PublicAppointmentBooking, "appointment_id", Appointment),
    (PublicAppointmentBooking, "patient_id", Patient),
    (ClinicLocation, "id", ClinicLocation) if "ClinicLocation" in globals() else None,
    (VendorPurchase, "vendor_id", Vendor),
    (VendorPurchaseItem, "purchase_id", VendorPurchase),
    (VendorPurchaseItem, "vendor_id", Vendor),
    (VendorPurchaseItem, "medicine_id", Medicine),
    (VendorNote, "vendor_id", Vendor),
    (VendorNote, "reference_purchase_id", VendorPurchase),
    (VendorNoteItem, "note_id", VendorNote),
    (VendorNoteItem, "medicine_id", Medicine),
    (VendorNoteAllocation, "note_id", VendorNote),
    (VendorNoteAllocation, "note_item_id", VendorNoteItem),
    (VendorNoteAllocation, "purchase_item_id", VendorPurchaseItem),
    (VendorLedgerEntry, "vendor_id", Vendor),
    (SalesAllocation, "invoice_item_id", InvoiceItem),
    (SalesAllocation, "purchase_item_id", VendorPurchaseItem),
)
TENANT_REFERENCE_CHECKS = tuple(item for item in TENANT_REFERENCE_CHECKS if item is not None)


TENANT_OWNED_TABLE_NAMES = (
    "user", "medicine", "invoice", "invoice_item", "return_bill", "return_item",
    "return_lot_allocation", "quarantine_stock", "hold_bill", "pending_bill_store",
    "patient", "appointment", "lab_test", "lab_order", "lab_order_item", "lab_report",
    "portal_otp_challenge", "appointment_booking_settings", "public_appointment_booking",
    "public_appointment_day_lock", "clinic_location", "clinician", "clinic_schedule_rule",
    "clinic_schedule_exception", "stock_history", "vendor", "vendor_purchase",
    "vendor_purchase_item", "vendor_notes", "vendor_note_items", "vendor_note_allocations",
    "vendor_ledger", "sales_allocation", "audit_log", "login_security_event", "voice_call",
    "voice_call_event", "ai_api_client", "ai_access_token", "ai_api_request_audit",
    "ai_idempotency_record", "omnidim_gateway_action", "clinic_profile",
    "appointment_slot_lock", "appointment_slot_block", "appointment_waitlist",
    "patient_verification_session", "patient_verification_intent", "secure_document_token",
    "clinic_knowledge_entry", "reception_schedule", "reception_schedule_override",
    "callback_request", "complaint", "notification_template", "notification_delivery",
)


def is_tenant_model(model_or_instance):
    model = model_or_instance if isinstance(model_or_instance, type) else model_or_instance.__class__
    return hasattr(model, "tenant_id")


def tenant_owned_models():
    models = []
    try:
        mappers = list(db.Model.registry.mappers)
    except Exception:
        return list(TENANT_OWNED_MODELS)
    for mapper in mappers:
        model = mapper.class_
        if hasattr(model, "tenant_id"):
            models.append(model)
    return models


def authorize_tenant_object(obj, *, tenant_id=None, action="access"):
    if obj is None or not is_tenant_model(obj):
        return obj
    expected_tenant_id = tenant_id or current_tenant_id()
    object_tenant_id = getattr(obj, "tenant_id", None)
    if expected_tenant_id is None:
        raise PermissionError(f"Tenant context is required to {action} {obj.__class__.__name__}.")
    if object_tenant_id is None:
        setattr(obj, "tenant_id", expected_tenant_id)
        return obj
    if int(object_tenant_id) != int(expected_tenant_id):
        raise PermissionError(f"Cross-tenant {action} blocked for {obj.__class__.__name__}.")
    return obj


def tenant_filter(query, model, tenant_id=None):
    expected_tenant_id = tenant_id or current_tenant_id()
    if expected_tenant_id is None or not is_tenant_model(model):
        return query
    return query.filter(model.tenant_id == expected_tenant_id)


def tenant_get(model, object_id, *, tenant_id=None):
    query = tenant_filter(model.query, model, tenant_id=tenant_id)
    return query.filter(model.id == object_id).first()


def set_postgres_tenant_context(connection, tenant_id):
    if (connection.dialect.name or "").lower() != "postgresql":
        return
    if tenant_id is None:
        connection.exec_driver_sql("SELECT set_config('app.current_tenant_id', '', true)")
    else:
        connection.exec_driver_sql(
            "SELECT set_config('app.current_tenant_id', %s, true)",
            (str(int(tenant_id)),),
        )
    try:
        is_platform_admin = (
            tenant_id is None
            and (session.get("role") or "").strip().lower() == PLATFORM_SUPER_ADMIN_ROLE
        )
    except RuntimeError:
        is_platform_admin = False
    connection.exec_driver_sql(
        "SELECT set_config('app.is_platform_admin', %s, true)",
        ("true" if is_platform_admin else "",),
    )


def _normalized_boolish_column(column):
    return db.func.lower(db.func.trim(cast(column, String)))


def truthy_column_expr(column):
    return _normalized_boolish_column(column).in_(("1", "true", "t", "yes", "on"))


def falsey_or_null_column_expr(column):
    normalized = _normalized_boolish_column(column)
    return or_(column.is_(None), normalized.in_(("0", "false", "f", "no", "off", "")))


def active_invoice_expr():
    """SQL condition for invoices that count as sales (not cancelled)."""
    return falsey_or_null_column_expr(Invoice.is_cancelled)


def active_invoice_query():
    return Invoice.query.filter(active_invoice_expr())


def active_user_query():
    return User.query.filter(User.deleted_at.is_(None), truthy_column_expr(User.is_active))


def active_vendor_query():
    return Vendor.query.filter(Vendor.deleted_at.is_(None))


def active_legacy_hold_bill_query():
    return HoldBill.query.filter(falsey_or_null_column_expr(HoldBill.is_deleted))


def active_hold_bill_query():
    return PendingBillStore.query.filter(falsey_or_null_column_expr(PendingBillStore.is_deleted))


def active_pending_bill_query():
    return active_hold_bill_query()


def active_appointment_query():
    return Appointment.query.filter(falsey_or_null_column_expr(Appointment.is_deleted))


def active_user_by_id(user_id):
    if not user_id:
        return None
    return active_user_query().filter(User.id == user_id).first()


def log_login_security_event(*, username="", user=None, outcome="", reason="", is_suspicious=False):
    try:
        event_tenant_id = getattr(user, "tenant_id", None) if user else session.get("tenant_id")
        scope = tenant_scope_disabled() if not event_tenant_id else tenant_context(event_tenant_id)
        with scope:
            db.session.add(
                LoginSecurityEvent(
                    tenant_id=event_tenant_id,
                    username=(username or (user.username if user else "") or "").strip()[:50],
                    user_id=(user.id if user else None),
                    ip_address=current_client_ip(),
                    user_agent=current_user_agent(),
                    outcome=(outcome or "").strip().upper()[:30],
                    reason=(reason or "").strip()[:255],
                    is_suspicious=bool(is_suspicious),
                )
            )
            db.session.commit()
    except Exception:
        db.session.rollback()
        app.logger.exception("Failed to log login security event")


def failed_login_attempts_recent(username="", ip_address=""):
    username = (username or "").strip()
    ip_address = (ip_address or "").strip()
    window_started = datetime.utcnow() - timedelta(
        minutes=max(5, int(str(os.environ.get("SUSPICIOUS_LOGIN_WINDOW_MINUTES", "15")).strip() or 15))
    )
    query = LoginSecurityEvent.query.filter(
        LoginSecurityEvent.outcome == "FAILED",
        LoginSecurityEvent.created_at >= window_started,
    )
    filters = []
    if username:
        filters.append(LoginSecurityEvent.username == username)
    if ip_address:
        filters.append(LoginSecurityEvent.ip_address == ip_address)
    if filters:
        query = query.filter(or_(*filters))
    return query.count()


def run_system_health_checks(include_counts=False):
    release_id = get_release_identifier()
    backup_summary = get_backup_summary(app)
    suspicious_since = datetime.utcnow() - timedelta(hours=24)
    payload = {
        "status": "ok",
        "checked_at": clinic_now().isoformat(),
        "release": release_id,
        "environment": APP_ENV,
        "timezone": APP_TIMEZONE,
        "database": {
            "ok": True,
            "backend": "unknown",
            "target": "unknown",
            "latency_ms": None,
            "error": ""
        },
        "storage": {
            "vendor_uploads": summarize_directory(UPLOAD_FOLDER),
            "vendor_bill_uploads": summarize_directory(VENDOR_BILL_UPLOAD_FOLDER),
            "root_path": UPLOAD_STORAGE_ROOT
        },
        "backups": backup_summary,
        "security": {
            "suspicious_logins_24h": LoginSecurityEvent.query.filter(
                truthy_column_expr(LoginSecurityEvent.is_suspicious),
                LoginSecurityEvent.created_at >= suspicious_since,
            ).count(),
            "failed_logins_24h": LoginSecurityEvent.query.filter(
                LoginSecurityEvent.outcome == "FAILED",
                LoginSecurityEvent.created_at >= suspicious_since,
            ).count(),
        },
    }

    try:
        engine_url = db.engine.url
        payload["database"]["backend"] = engine_url.get_backend_name()
        payload["database"]["target"] = mask_database_target(engine_url)
        probe_started = datetime.utcnow()
        db.session.execute(text("SELECT 1"))
        probe_elapsed = datetime.utcnow() - probe_started
        payload["database"]["latency_ms"] = round(probe_elapsed.total_seconds() * 1000, 2)
    except Exception as exc:
        payload["status"] = "degraded"
        payload["database"]["ok"] = False
        payload["database"]["error"] = str(exc)

    if not payload["storage"]["vendor_uploads"]["available"] or not payload["storage"]["vendor_bill_uploads"]["available"]:
        payload["status"] = "degraded"

    if include_counts:
        today_local = clinic_now().date()
        payload["counts"] = {
            "users": active_user_query().count(),
            "patients": Patient.query.count(),
            "appointments": active_appointment_query().count(),
            "invoices": active_invoice_query().count(),
            "returns": Return.query.count(),
            "medicines": Medicine.query.count(),
            "active_medicines": Medicine.query.filter(truthy_column_expr(Medicine.is_active)).count(),
            "low_stock_medicines": Medicine.query.filter(Medicine.qty <= Medicine.reorder_level).count(),
            "vendors": active_vendor_query().count(),
            "audit_events": AuditLog.query.count(),
            "today_invoices": active_invoice_query().filter(db.func.date(Invoice.created_at) == today_local).count(),
            "today_appointments": active_appointment_query().filter(Appointment.appointment_date == today_local).count()
        }

    return payload


def build_upgrade_tracker():
    return [
        {
            "title": "Already Live In App",
            "items": [
                "Patient profile, customer directory, and linked visit history",
                "Live queue board with token flow for appointments",
                "Global search across patient, medicine, invoice, and appointment",
                "Audit logs with before/after change snapshots",
                "Medicine, profit, and appointment reporting exports",
                "Role-based access controls for medicines, reports, invoices, and users"
            ]
        },
        {
            "title": "Upgraded In This Pass",
            "items": [
                "Health and readiness endpoints for deployment monitoring",
                "Admin System Center with storage, database, and release diagnostics",
                "Automated smoke-test base for future safe changes",
                "Operational roadmap documented inside the repository"
            ]
        },
        {
            "title": "Next Pro Phases",
            "items": [
                "Patient credit ledger and due collection workflow",
                "Scheduled backups, restore drill, and release checklist",
                "WhatsApp reminder automation and refill nudges",
                "Chart-based analytics dashboard and deeper stock forecasting",
                "Modular route/service split plus formal database migrations"
            ]
        }
    ]


def storage_datetime_to_local(value):
    if not value:
        return None
    tzinfo = get_clinic_tzinfo()
    if not tzinfo:
        return value
    try:
        return value.replace(tzinfo=timezone.utc).astimezone(tzinfo)
    except Exception:
        return value


def storage_datetime_to_local_date(value):
    local_dt = storage_datetime_to_local(value)
    return local_dt.date() if local_dt else None


def build_dashboard_sales_trend(days=7):
    days = max(3, min(to_int_safe(days, 7), 31))
    end_date = clinic_now().date()
    start_date = end_date - timedelta(days=days - 1)
    start_date = floor_start_date_to_operations_fresh_start(start_date, end_date)
    start_bound, end_bound = local_date_range_to_storage_bounds(start_date, end_date)
    observed_days = (end_date - start_date).days + 1

    ordered_days = [start_date + timedelta(days=offset) for offset in range(observed_days)]
    bucket_map = {
        day_key: {
            "date": day_key.isoformat(),
            "label": day_key.strftime("%d %b"),
            "sales": 0.0,
            "returns": 0.0,
            "net": 0.0,
            "height_pct": 0
        }
        for day_key in ordered_days
    }

    invoices = active_invoice_query().filter(
        Invoice.created_at >= start_bound,
        Invoice.created_at < end_bound
    ).all()
    for invoice in invoices:
        local_day = storage_datetime_to_local_date(invoice.created_at)
        if local_day in bucket_map:
            bucket_map[local_day]["sales"] += to_float(invoice.total)

    returns = Return.query.filter(
        Return.created_at >= start_bound,
        Return.created_at < end_bound,
        falsey_or_null_column_expr(Return.is_cancelled)
    ).all()
    for return_bill in returns:
        local_day = storage_datetime_to_local_date(return_bill.created_at)
        if local_day in bucket_map:
            bucket_map[local_day]["returns"] += to_float(return_bill.total_refund)

    max_value = 0.0
    points = []
    for day_key in ordered_days:
        bucket = bucket_map[day_key]
        bucket["sales"] = round(bucket["sales"], 2)
        bucket["returns"] = round(bucket["returns"], 2)
        bucket["net"] = round(bucket["sales"] - bucket["returns"], 2)
        max_value = max(max_value, bucket["net"])
        points.append(bucket)

    for bucket in points:
        if bucket["net"] <= 0 or max_value <= 0:
            bucket["height_pct"] = 8 if bucket["net"] > 0 else 0
        else:
            bucket["height_pct"] = max(12, int(round((bucket["net"] / max_value) * 100)))
    return points


def build_dashboard_appointment_trend(days=7):
    days = max(3, min(to_int_safe(days, 7), 31))
    end_date = clinic_now().date()
    start_date = end_date - timedelta(days=days - 1)
    start_date = floor_start_date_to_operations_fresh_start(start_date, end_date)
    observed_days = (end_date - start_date).days + 1
    ordered_days = [start_date + timedelta(days=offset) for offset in range(observed_days)]
    bucket_map = {
        day_key: {
            "date": day_key.isoformat(),
            "label": day_key.strftime("%d %b"),
            "booked": 0,
            "completed": 0,
            "cancelled": 0,
            "booked_height_pct": 0,
            "completed_height_pct": 0
        }
        for day_key in ordered_days
    }

    appointments = active_appointment_query().filter(
        Appointment.appointment_date >= start_date,
        Appointment.appointment_date <= end_date
    ).all()
    for appointment in appointments:
        day_key = appointment.appointment_date
        if day_key not in bucket_map:
            continue
        bucket_map[day_key]["booked"] += 1
        normalized_status = (appointment.status or "BOOKED").strip().upper()
        if normalized_status == "COMPLETED":
            bucket_map[day_key]["completed"] += 1
        elif normalized_status == "CANCELLED":
            bucket_map[day_key]["cancelled"] += 1

    max_count = 0
    points = []
    for day_key in ordered_days:
        bucket = bucket_map[day_key]
        max_count = max(max_count, bucket["booked"], bucket["completed"])
        points.append(bucket)

    for bucket in points:
        if max_count <= 0:
            bucket["booked_height_pct"] = 0
            bucket["completed_height_pct"] = 0
            continue
        bucket["booked_height_pct"] = max(10, int(round((bucket["booked"] / max_count) * 100))) if bucket["booked"] else 0
        bucket["completed_height_pct"] = max(10, int(round((bucket["completed"] / max_count) * 100))) if bucket["completed"] else 0
    return points


def build_dashboard_dead_stock(limit=5, dormant_days=60):
    limit = max(1, min(to_int_safe(limit, 5), 12))
    dormant_days = max(30, min(to_int_safe(dormant_days, 60), 365))
    end_date = clinic_now().date()
    start_date = end_date - timedelta(days=dormant_days - 1)
    start_date = floor_start_date_to_operations_fresh_start(start_date, end_date)
    observed_days = (end_date - start_date).days + 1
    if observed_days < dormant_days:
        return []

    medicine_data, _errors = build_medicine_report_data(
        start_date.isoformat(),
        end_date.isoformat(),
        top_n=max(limit, 10)
    )
    dormant_rows = {}
    for row in medicine_data.get("medicine_summary") or []:
        if to_int_safe(row.get("current_stock"), 0) <= 0:
            continue
        if to_float_safe(row.get("net_sold_qty"), 0) > 0:
            continue
        dormant_rows[(row.get("medicine") or "").strip().upper()] = {
            "name": (row.get("medicine") or "").strip(),
            "qty": to_int_safe(row.get("current_stock"), 0),
            "blocked_value": 0.0,
            "days_without_sale": observed_days
        }

    if not dormant_rows:
        return []

    med_name_by_id = {
        med.id: (med.name or "").strip()
        for med in Medicine.query.with_entities(Medicine.id, Medicine.name).all()
    }
    purchase_items = VendorPurchaseItem.query.filter(
        db.func.coalesce(VendorPurchaseItem.remaining_qty, 0) > 0
    ).all()
    for item in purchase_items:
        med_name = (item.medicine_name or med_name_by_id.get(item.medicine_id) or "").strip().upper()
        if med_name in dormant_rows:
            dormant_rows[med_name]["blocked_value"] += (
                to_int_safe(item.remaining_qty, 0) * to_float_safe(item.purchase_rate, 0)
            )

    rows = list(dormant_rows.values())
    for row in rows:
        row["blocked_value"] = round(row["blocked_value"], 2)
    rows.sort(key=lambda row: (row["blocked_value"], row["qty"], row["name"].lower()), reverse=True)
    return rows[:limit]


def build_dashboard_top_medicines(limit=5, period_days=30):
    limit = max(1, min(to_int_safe(limit, 5), 12))
    period_days = max(7, min(to_int_safe(period_days, 30), 120))
    end_date = clinic_now().date()
    start_date = end_date - timedelta(days=period_days - 1)
    start_date = floor_start_date_to_operations_fresh_start(start_date, end_date)
    medicine_data, _errors = build_medicine_report_data(
        start_date.isoformat(),
        end_date.isoformat(),
        top_n=max(limit, 10)
    )
    rows = [row for row in (medicine_data.get("fast_movers") or []) if to_float_safe(row.get("sales_value"), 0) > 0]
    rows = rows[:limit]
    max_sales = max((to_float_safe(row.get("sales_value"), 0) for row in rows), default=0.0)
    result = []
    for row in rows:
        sales_value = to_float_safe(row.get("sales_value"), 0)
        result.append({
            "name": (row.get("medicine") or "").strip(),
            "qty": to_int_safe(row.get("net_sold_qty"), 0),
            "sales_value": round(sales_value, 2),
            "net_profit": round(to_float_safe(row.get("net_profit"), 0), 2),
            "bar_pct": max(12, int(round((sales_value / max_sales) * 100))) if max_sales > 0 else 0
        })
    return result

def is_truthy(value):
    return str(value or "").strip().lower() in {"1", "true", "yes", "on"}

def compact_display_value(value, limit=56):
    if value in (None, "", [], {}):
        return "-"
    if isinstance(value, bool):
        text = "Yes" if value else "No"
    elif isinstance(value, float):
        text = f"{value:.2f}".rstrip("0").rstrip(".")
    elif isinstance(value, Decimal):
        text = f"{float(value):.2f}".rstrip("0").rstrip(".")
    elif isinstance(value, (int,)):
        text = str(value)
    elif isinstance(value, datetime):
        text = value.strftime("%d-%m-%Y %I:%M %p")
    elif isinstance(value, date):
        text = value.strftime("%d-%m-%Y")
    elif isinstance(value, time):
        text = value.strftime("%I:%M %p")
    elif isinstance(value, dict):
        keys = [str(key).replace("_", " ").title() for key in list(value.keys())[:3]]
        text = ", ".join(keys)
        if len(value) > 3:
            text = f"{text} +{len(value) - 3} more"
    elif isinstance(value, (list, tuple, set)):
        items = [compact_display_value(item, limit=18) for item in list(value)[:3]]
        text = ", ".join(item for item in items if item and item != "-")
        if len(value) > 3:
            text = f"{text} +{len(value) - 3} more"
    else:
        text = str(value).strip()
    if not text:
        return "-"
    if len(text) > limit:
        return text[:limit - 3] + "..."
    return text

def classify_audit_action(action):
    normalized = (action or "").strip().lower()
    if not normalized:
        return "OTHER"
    if "delete" in normalized or "remove" in normalized:
        return "DELETE"
    if (
        "status" in normalized
        or "paid" in normalized
        or "cancel" in normalized
        or "posted" in normalized
        or "restored" in normalized
    ):
        return "STATUS"
    if (
        "create" in normalized
        or "added" in normalized
        or "booked" in normalized
        or normalized.startswith("new ")
    ):
        return "CREATE"
    if "update" in normalized or "edit" in normalized or "change" in normalized:
        return "UPDATE"
    return "OTHER"

def build_audit_change_rows(before_data, after_data, limit=8):
    if isinstance(before_data, dict) and isinstance(after_data, dict):
        changes = []
        ordered_keys = []
        for key in list(before_data.keys()) + list(after_data.keys()):
            if key not in ordered_keys:
                ordered_keys.append(key)
        for key in ordered_keys:
            before_value = before_data.get(key)
            after_value = after_data.get(key)
            if serialize_json_text(before_value) == serialize_json_text(after_value):
                continue
            changes.append({
                "field": str(key).replace("_", " ").title(),
                "before": compact_display_value(before_value),
                "after": compact_display_value(after_value)
            })
        return changes[:limit], len(changes)

    if before_data and not after_data:
        return [{
            "field": "Deleted Record",
            "before": compact_display_value(before_data),
            "after": "-"
        }], 1

    if after_data and not before_data:
        return [{
            "field": "Created Record",
            "before": "-",
            "after": compact_display_value(after_data)
        }], 1

    if before_data or after_data:
        return [{
            "field": "Snapshot",
            "before": compact_display_value(before_data),
            "after": compact_display_value(after_data)
        }], 1

    return [], 0

def resolve_patient_directory_match(patient_lookup, mobile_lookup, name_lookup, patient_id=None, mobile="", patient_name=""):
    if patient_id in patient_lookup:
        return patient_lookup[patient_id]
    mobile_digits = normalize_patient_mobile(mobile)
    if mobile_digits and mobile_digits in mobile_lookup:
        return patient_lookup.get(mobile_lookup[mobile_digits])
    normalized_name = (patient_name or "").strip().lower()
    if normalized_name and normalized_name in name_lookup:
        return patient_lookup.get(name_lookup[normalized_name])
    return None

def build_customer_directory_rows(patients):
    rows = []
    if not patients:
        return rows

    patient_lookup = {}
    mobile_lookup = {}
    name_lookup = {}
    patient_ids = []
    mobile_values = []
    name_values = []

    for patient in patients:
        row = {
            "patient": patient,
            "appointment_count": 0,
            "invoice_count": 0,
            "total_billed": 0.0,
            "last_appointment_at": None,
            "last_invoice_at": None,
            "last_activity_at": patient.updated_at,
        }
        rows.append(row)
        patient_lookup[patient.id] = row
        patient_ids.append(patient.id)

        mobile_digits = normalize_patient_mobile(patient.mobile)
        if mobile_digits and mobile_digits not in mobile_lookup:
            mobile_lookup[mobile_digits] = patient.id
            mobile_values.append(mobile_digits)

        normalized_name = (patient.name or "").strip().lower()
        if normalized_name and normalized_name not in name_lookup:
            name_lookup[normalized_name] = patient.id
            name_values.append(normalized_name)

    appointment_conditions = []
    if patient_ids:
        appointment_conditions.append(Appointment.patient_id.in_(patient_ids))
    if mobile_values:
        appointment_conditions.append(Appointment.mobile.in_(mobile_values))
    if name_values:
        appointment_conditions.append(
            db.func.lower(db.func.coalesce(Appointment.patient_name, "")).in_(name_values)
        )

    if appointment_conditions:
        appointment_rows = active_appointment_query().filter(or_(*appointment_conditions)).with_entities(
            Appointment.patient_id,
            Appointment.patient_name,
            Appointment.mobile,
            Appointment.appointment_date,
            Appointment.appointment_time
        ).all()
        for appt in appointment_rows:
            row = resolve_patient_directory_match(
                patient_lookup,
                mobile_lookup,
                name_lookup,
                patient_id=appt.patient_id,
                mobile=appt.mobile,
                patient_name=appt.patient_name
            )
            if not row:
                continue
            row["appointment_count"] += 1
            if appt.appointment_date:
                occurred_at = datetime.combine(appt.appointment_date, appt.appointment_time or time.min)
                if not row["last_appointment_at"] or occurred_at > row["last_appointment_at"]:
                    row["last_appointment_at"] = occurred_at
                if not row["last_activity_at"] or occurred_at > row["last_activity_at"]:
                    row["last_activity_at"] = occurred_at

    invoice_conditions = []
    if patient_ids:
        invoice_conditions.append(Invoice.patient_id.in_(patient_ids))
    if mobile_values:
        invoice_conditions.append(Invoice.mobile.in_(mobile_values))
    if name_values:
        invoice_conditions.append(
            db.func.lower(db.func.coalesce(Invoice.customer, "")).in_(name_values)
        )

    if invoice_conditions:
        invoice_rows = active_invoice_query().filter(or_(*invoice_conditions)).with_entities(
            Invoice.patient_id,
            Invoice.customer,
            Invoice.mobile,
            Invoice.total,
            Invoice.created_at
        ).all()
        for invoice in invoice_rows:
            row = resolve_patient_directory_match(
                patient_lookup,
                mobile_lookup,
                name_lookup,
                patient_id=invoice.patient_id,
                mobile=invoice.mobile,
                patient_name=invoice.customer
            )
            if not row:
                continue
            row["invoice_count"] += 1
            row["total_billed"] += round(to_float_safe(invoice.total, 0), 2)
            if invoice.created_at and (not row["last_invoice_at"] or invoice.created_at > row["last_invoice_at"]):
                row["last_invoice_at"] = invoice.created_at
            if invoice.created_at and (not row["last_activity_at"] or invoice.created_at > row["last_activity_at"]):
                row["last_activity_at"] = invoice.created_at

    for row in rows:
        row["total_billed"] = round(row["total_billed"], 2)
        row["has_mobile"] = bool((row["patient"].mobile or "").strip())
        row["has_notes"] = bool((row["patient"].notes or "").strip())

    return rows

def build_medicine_audit_snapshot(med):
    if not med:
        return None
    return {
        "id": med.id,
        "name": (med.name or "").strip(),
        "medicine_code": normalize_medicine_code(getattr(med, "medicine_code", "")),
        "batch": (med.batch or "").strip(),
        "expiry": med.expiry,
        "mrp": round(to_float_safe(med.mrp, 0), 3),
        "qty": to_int_safe(med.qty, 0),
        "discount_percent": to_int_safe(med.discount_percent, 0),
        "pack_type": (med.pack_type or "").strip(),
        "pack_qty": med.pack_qty,
        "barcode": (getattr(med, "barcode", "") or "").strip(),
        "reorder_level": to_int_safe(getattr(med, "reorder_level", 10), 10),
        "is_active": bool(getattr(med, "is_active", True))
    }

def build_invoice_audit_snapshot(inv):
    if not inv:
        return None
    payment_breakdown = build_invoice_payment_breakdown(inv)
    return {
        "id": inv.id,
        "invoice_no": (inv.invoice_no or "").strip(),
        "patient_id": getattr(inv, "patient_id", None),
        "customer": (inv.customer or "").strip(),
        "mobile": (inv.mobile or "").strip(),
        "payment_mode": (inv.payment_mode or "").strip().upper(),
        "subtotal": round(to_float_safe(inv.subtotal, 0), 2),
        "discount": round(to_float_safe(inv.discount, 0), 2),
        "total": round(to_float_safe(inv.total, 0), 2),
        "cash_amount": payment_breakdown["cash_amount"],
        "online_amount": payment_breakdown["online_amount"],
        "is_split_payment": payment_breakdown["is_split_payment"],
        "return_credit_used": round(to_float_safe(getattr(inv, "return_credit_used", 0), 0), 2),
        "final_payable": round(to_float_safe(getattr(inv, "final_payable", inv.total), 0), 2),
        "refund_amount": round(to_float_safe(getattr(inv, "refund_amount", 0), 0), 2),
        "internal_note": (getattr(inv, "internal_note", "") or "").strip(),
        "is_cancelled": bool(getattr(inv, "is_cancelled", False)),
        "cancel_reason": (getattr(inv, "cancel_reason", "") or "").strip(),
        "created_by": (inv.created_by or "").strip()
    }


def build_return_audit_snapshot(return_bill):
    if not return_bill:
        return None
    return {
        "id": return_bill.id,
        "return_no": (return_bill.return_no or "").strip(),
        "invoice_id": return_bill.invoice_id,
        "invoice_no": (return_bill.invoice_no or "").strip(),
        "customer": (return_bill.customer or "").strip(),
        "payment_mode": normalize_payment_mode(return_bill.payment_mode or "CASH"),
        "total_refund": round(to_float_safe(return_bill.total_refund, 0), 2),
        "adjusted_invoice_id": getattr(return_bill, "adjusted_invoice_id", None),
        "adjusted_amount": round(to_float_safe(getattr(return_bill, "adjusted_amount", 0), 0), 2),
        "refund_amount": round(to_float_safe(getattr(return_bill, "refund_amount", 0), 0), 2),
        "created_at": return_bill.created_at.isoformat() if return_bill.created_at else None,
        "is_cancelled": bool(return_bill.is_cancelled),
    }


def build_lab_test_audit_snapshot(lab_test):
    if not lab_test:
        return None
    return {
        "id": lab_test.id,
        "test_code": (lab_test.test_code or "").strip().upper(),
        "name": (lab_test.name or "").strip(),
        "category": (lab_test.category or "").strip(),
        "specimen_type": (lab_test.specimen_type or "").strip(),
        "preparation": (lab_test.preparation or "").strip(),
        "default_price": round(to_float_safe(lab_test.default_price, 0), 2),
        "fasting_required": bool(getattr(lab_test, "fasting_required", False)),
        "turnaround_text": (getattr(lab_test, "turnaround_text", None) or "").strip(),
        "aliases_json": getattr(lab_test, "aliases_json", None) or "[]",
        "is_active": bool(lab_test.is_active),
    }


def build_lab_order_audit_snapshot(order):
    if not order:
        return None
    payment_breakdown = build_invoice_payment_breakdown(order)
    return {
        "id": order.id,
        "order_no": (order.order_no or "").strip(),
        "patient_id": order.patient_id,
        "patient_name": (order.patient_name or "").strip(),
        "mobile": (order.mobile or "").strip(),
        "doctor": (order.doctor or "").strip(),
        "status": (order.status or "").strip().upper(),
        "subtotal": round(to_float_safe(order.subtotal, 0), 2),
        "discount": round(to_float_safe(order.discount, 0), 2),
        "total": round(to_float_safe(order.total, 0), 2),
        "payment_mode": payment_breakdown["payment_mode"],
        "cash_amount": payment_breakdown["cash_amount"],
        "online_amount": payment_breakdown["online_amount"],
        "is_split_payment": payment_breakdown["is_split_payment"],
        "created_by": (order.created_by or "").strip(),
    }


def normalize_lab_test_code(value):
    normalized = re.sub(r"[^A-Z0-9_-]+", "-", (value or "").strip().upper())
    return normalized.strip("-_")[:40]


def generate_internal_lab_test_code():
    """Allocate an opaque catalog code when staff do not need to enter one.

    Codes remain required internally for audit trails, search and immutable order
    snapshots, but they are not part of the simplified Lab Test Master form.
    """
    for _attempt in range(12):
        candidate = f"LAB-{secrets.token_hex(8).upper()}"
        if not LabTest.query.filter_by(test_code=candidate).first():
            return candidate
    # A collision is exceptionally unlikely, but do not silently save a
    # duplicate if the catalog is being edited concurrently.
    return ""


def assign_lab_order_number(order):
    if not order:
        return ""
    if not order.id:
        db.session.flush()
    if not order.order_no:
        order.order_no = f"LAB-{order.id:06d}"
    return order.order_no


def build_lab_order_line_items(form_data):
    raw_ids = form_data.getlist("lab_test_id[]") or form_data.getlist("lab_test_id")
    raw_qtys = form_data.getlist("qty[]") or form_data.getlist("qty")
    if not raw_ids:
        return [], "Please add at least one lab test."
    if len(raw_qtys) < len(raw_ids):
        return [], "Lab test quantity is incomplete. Please review the selected tests."

    requested_qty = {}
    for idx, raw_id in enumerate(raw_ids):
        test_id = to_int_safe(raw_id, 0)
        qty = to_int_safe(raw_qtys[idx] if idx < len(raw_qtys) else 0, 0)
        if test_id <= 0 or qty <= 0:
            return [], "Please select valid lab tests with a quantity greater than zero."
        if qty > 25:
            return [], "A lab test quantity cannot be more than 25 in one order."
        requested_qty[test_id] = requested_qty.get(test_id, 0) + qty

    if not requested_qty:
        return [], "Please add at least one lab test."
    if any(qty > 25 for qty in requested_qty.values()):
        return [], "A lab test quantity cannot be more than 25 in one order."

    selected_tests = LabTest.query.filter(LabTest.id.in_(list(requested_qty))).all()
    tests_by_id = {test.id: test for test in selected_tests}
    line_items = []
    for test_id, qty in requested_qty.items():
        lab_test = tests_by_id.get(test_id)
        if not lab_test or not lab_test.is_active:
            return [], "One or more selected lab tests are unavailable. Please refresh and try again."
        unit_price = round(max(to_float_safe(lab_test.default_price, 0), 0), 2)
        amount = round(unit_price * qty, 2)
        line_items.append({
            "lab_test": lab_test,
            "qty": qty,
            "unit_price": unit_price,
            "amount": amount,
        })
    return line_items, None

def build_appointment_audit_snapshot(appt):
    if not appt:
        return None
    return {
        "id": appt.id,
        "appointment_no": (appt.appointment_no or "").strip(),
        "patient_id": appt.patient_id,
        "patient_name": (appt.patient_name or "").strip(),
        "mobile": (appt.mobile or "").strip(),
        "appointment_date": appt.appointment_date.isoformat() if appt.appointment_date else "",
        "appointment_time": appt.appointment_time.strftime("%H:%M:%S") if appt.appointment_time else "",
        "status": (appt.status or "").strip().upper(),
        "payment_mode": (appt.payment_mode or "").strip().upper(),
        "payment_status": (appt.payment_status or "").strip().upper(),
        "consultation_fee": round(to_float_safe(appt.consultation_fee, 0), 2),
        "doctor_discount": round(to_float_safe(appt.doctor_discount, 0), 2)
    }

def build_patient_audit_snapshot(patient):
    if not patient:
        return None
    return {
        "id": patient.id,
        "name": (patient.name or "").strip(),
        "mobile": (patient.mobile or "").strip(),
        "age": patient.age,
        "gender": (patient.gender or "").strip().upper(),
        "notes": (patient.notes or "").strip()
    }

def can_manage_patient_records(user=None):
    actor = user
    if actor is None:
        actor = active_user_by_id(session.get("user_id"))
    if not actor:
        return False
    return bool(actor.role == "admin" or actor.can_invoice_action)

def normalize_patient_name(value):
    return " ".join(str(value or "").strip().lower().split())

def patient_name_expression(column):
    return db.func.lower(db.func.trim(db.func.coalesce(column, "")))

def invoice_name_expression():
    return patient_name_expression(Invoice.customer)

def appointment_name_expression():
    return patient_name_expression(Appointment.patient_name)

def patient_master_name_expression():
    return patient_name_expression(Patient.name)

def build_patient_duplicate_name_counts():
    rows = db.session.query(
        patient_master_name_expression().label("normalized_name"),
        db.func.count(Patient.id)
    ).filter(
        db.func.length(db.func.trim(db.func.coalesce(Patient.name, ""))) > 0
    ).group_by(
        patient_master_name_expression()
    ).having(
        db.func.count(Patient.id) > 1
    ).all()
    return {
        (normalized_name or "").strip(): int(count or 0)
        for normalized_name, count in rows
        if (normalized_name or "").strip()
    }

def build_patient_duplicate_candidates(patient, limit=8):
    normalized_name = normalize_patient_name(getattr(patient, "name", ""))
    if not normalized_name:
        return []
    rows = Patient.query.filter(
        Patient.id != patient.id,
        patient_master_name_expression() == normalized_name
    ).order_by(
        Patient.updated_at.desc(),
        Patient.id.desc()
    ).limit(max(1, min(to_int_safe(limit, 8), 15))).all()
    return rows

def build_patient_link_summary(patient):
    patient_name = normalize_patient_name(patient.name)
    patient_mobile = normalize_patient_mobile(patient.mobile)

    direct_appointments = active_appointment_query().filter(Appointment.patient_id == patient.id).count()
    direct_invoices = Invoice.query.filter(getattr(Invoice, "patient_id") == patient.id).count()

    orphan_appointment_conditions = [Appointment.patient_id.is_(None)]
    appointment_match_conditions = []
    if patient_mobile:
        appointment_match_conditions.append(Appointment.mobile == patient_mobile)
    if patient_name:
        appointment_match_conditions.append(appointment_name_expression() == patient_name)
    if appointment_match_conditions:
        orphan_appointment_conditions.append(or_(*appointment_match_conditions))
        orphan_appointments = active_appointment_query().filter(and_(*orphan_appointment_conditions)).count()
    else:
        orphan_appointments = 0

    orphan_invoice_conditions = [Invoice.patient_id.is_(None)]
    invoice_match_conditions = []
    if patient_mobile:
        invoice_match_conditions.append(Invoice.mobile == patient_mobile)
    if patient_name:
        invoice_match_conditions.append(invoice_name_expression() == patient_name)
    if invoice_match_conditions:
        orphan_invoice_conditions.append(or_(*invoice_match_conditions))
        orphan_invoices = Invoice.query.filter(and_(*orphan_invoice_conditions)).count()
    else:
        orphan_invoices = 0

    return {
        "linked_appointments": direct_appointments,
        "linked_invoices": direct_invoices,
        "orphan_appointments": orphan_appointments,
        "orphan_invoices": orphan_invoices
    }

def relink_patient_records(patient, matching_names=None, matching_mobiles=None, source_patient_ids=None, sync_display_fields=False):
    normalized_names = {
        normalize_patient_name(name)
        for name in (matching_names or [])
        if normalize_patient_name(name)
    }
    patient_name = (patient.name or "").strip()
    if normalize_patient_name(patient_name):
        normalized_names.add(normalize_patient_name(patient_name))

    normalized_mobiles = {
        normalize_patient_mobile(mobile)
        for mobile in (matching_mobiles or [])
        if normalize_patient_mobile(mobile)
    }
    patient_mobile = normalize_patient_mobile(patient.mobile)
    if patient_mobile:
        normalized_mobiles.add(patient_mobile)

    source_ids = {to_int_safe(source_id, 0) for source_id in (source_patient_ids or []) if to_int_safe(source_id, 0)}
    source_ids.discard(patient.id)

    appointment_conditions = [Appointment.patient_id == patient.id]
    if source_ids:
        appointment_conditions.append(Appointment.patient_id.in_(source_ids))
    if normalized_mobiles:
        appointment_conditions.append(Appointment.mobile.in_(sorted(normalized_mobiles)))
    if normalized_names:
        appointment_conditions.append(appointment_name_expression().in_(sorted(normalized_names)))
    appointment_rows = active_appointment_query().filter(or_(*appointment_conditions)).all() if appointment_conditions else []

    invoice_conditions = [Invoice.patient_id == patient.id]
    if source_ids:
        invoice_conditions.append(Invoice.patient_id.in_(source_ids))
    if normalized_mobiles:
        invoice_conditions.append(Invoice.mobile.in_(sorted(normalized_mobiles)))
    if normalized_names:
        invoice_conditions.append(invoice_name_expression().in_(sorted(normalized_names)))
    invoice_rows = Invoice.query.filter(or_(*invoice_conditions)).all() if invoice_conditions else []

    appointment_relinked = 0
    appointment_synced = 0
    invoice_relinked = 0
    invoice_synced = 0

    for appt in appointment_rows:
        if appt.patient_id != patient.id:
            appt.patient_id = patient.id
            appointment_relinked += 1
        if sync_display_fields:
            row_changed = False
            appt_name_token = normalize_patient_name(appt.patient_name)
            appt_mobile_token = normalize_patient_mobile(appt.mobile)
            if patient_name and (appt_name_token in normalized_names or not appt_name_token):
                if appt.patient_name != patient_name:
                    appt.patient_name = patient_name
                    row_changed = True
            if patient_mobile and (appt_mobile_token in normalized_mobiles or not appt_mobile_token):
                if appt.mobile != patient_mobile:
                    appt.mobile = patient_mobile
                    row_changed = True
            if patient.age not in (None, "") and appt.age != patient.age:
                appt.age = patient.age
                row_changed = True
            if (patient.gender or "").strip() and (appt.gender != patient.gender):
                appt.gender = patient.gender
                row_changed = True
            if row_changed:
                appointment_synced += 1

    for invoice in invoice_rows:
        if getattr(invoice, "patient_id", None) != patient.id:
            invoice.patient_id = patient.id
            invoice_relinked += 1
        if sync_display_fields:
            row_changed = False
            invoice_name_token = normalize_patient_name(invoice.customer)
            invoice_mobile_token = normalize_patient_mobile(invoice.mobile)
            if patient_name and (invoice_name_token in normalized_names or not invoice_name_token):
                if invoice.customer != patient_name:
                    invoice.customer = patient_name
                    row_changed = True
            if patient_mobile and (invoice_mobile_token in normalized_mobiles or not invoice_mobile_token):
                if invoice.mobile != patient_mobile:
                    invoice.mobile = patient_mobile
                    row_changed = True
            if (patient.gender or "").strip() and (not (invoice.gender or "").strip() or (invoice_name_token in normalized_names)):
                if invoice.gender != patient.gender:
                    invoice.gender = patient.gender
                    row_changed = True
            if row_changed:
                invoice_synced += 1

    return {
        "appointment_relinked": appointment_relinked,
        "appointment_synced": appointment_synced,
        "invoice_relinked": invoice_relinked,
        "invoice_synced": invoice_synced
    }

def record_audit_event(action, entity_type="", entity_id=None, ref_code="", before=None, after=None, extra=None):
    details = {}
    if isinstance(extra, dict):
        details.update(extra)
    elif extra not in (None, ""):
        details["info"] = extra
    try:
        details.setdefault("path", request.path)
        details.setdefault("method", request.method)
    except RuntimeError:
        pass

    try:
        db.session.add(AuditLog(
            user=session.get("username"),
            action=(action or "").strip(),
            entity_type=((entity_type or "").strip().upper() or None),
            entity_id=entity_id,
            ref_code=(ref_code or "").strip() or None,
            before_json=serialize_json_text(before),
            after_json=serialize_json_text(after),
            extra_json=serialize_json_text(details)
        ))
        db.session.commit()
    except Exception:
        db.session.rollback()
        app.logger.exception("Audit log write failed for action=%s entity=%s", action, entity_type)

def upsert_patient_from_invoice(customer_name, mobile, gender=""):
    patient_name = (customer_name or "").strip()
    mobile_digits = normalize_patient_mobile(mobile)
    gender = (gender or "").strip().upper()

    if not patient_name and not mobile_digits:
        return None, mobile_digits

    patient = None
    if mobile_digits:
        patient = Patient.query.filter_by(mobile=mobile_digits).first()
        if not patient:
            patient = Patient(name=patient_name or mobile_digits, mobile=mobile_digits)
            db.session.add(patient)
    elif patient_name:
        patient = Patient.query.filter(
            db.func.lower(Patient.name) == patient_name.lower()
        ).order_by(Patient.id.desc()).first()
        if not patient:
            patient = Patient(name=patient_name, mobile=None)
            db.session.add(patient)

    if patient_name:
        patient.name = patient_name
    if mobile_digits:
        patient.mobile = mobile_digits
    if gender and (not patient.gender or patient.gender == "OTHER"):
        patient.gender = gender
    return patient, mobile_digits

def find_medicine_for_hold(name, batch=""):
    if not name:
        return None
    if batch:
        med = Medicine.query.filter_by(name=name, batch=batch).first()
        if med:
            return med
    return Medicine.query.filter_by(name=name).first()

def build_hold_rows_from_form(form, include_partial=False):
    rows = []
    meds_list = form.getlist("medicine_name")
    qty_list = form.getlist("qty[]")
    if not qty_list:
        qty_list = form.getlist("qty")

    batch_overrides = form.getlist("batch_override[]")
    if not batch_overrides:
        batch_overrides = form.getlist("batch_override")

    expiry_list = form.getlist("line_expiry[]")
    qoh_list = form.getlist("line_qoh[]")
    mrp_list = form.getlist("line_mrp[]")
    discount_list = form.getlist("line_discount_percent[]")
    net_list = form.getlist("line_net[]")

    row_count = max(
        len(meds_list),
        len(qty_list),
        len(batch_overrides),
        len(expiry_list),
        len(mrp_list),
        len(discount_list),
        len(net_list)
    )

    for idx in range(row_count):
        name = (meds_list[idx] if idx < len(meds_list) else "").strip().upper()
        qty_val = to_int_safe(qty_list[idx] if idx < len(qty_list) else 0, 0)
        batch = (batch_overrides[idx] if idx < len(batch_overrides) else "").strip()
        batch_mode = "MANUAL" if batch else "AUTO"
        expiry = (expiry_list[idx] if idx < len(expiry_list) else "").strip()
        qoh_raw = qoh_list[idx] if idx < len(qoh_list) else ""
        mrp_raw = mrp_list[idx] if idx < len(mrp_list) else ""
        discount_raw = discount_list[idx] if idx < len(discount_list) else ""
        net_raw = net_list[idx] if idx < len(net_list) else ""

        if not name:
            continue
        if qty_val <= 0 and not include_partial:
            continue

        qoh = to_float_safe(qoh_raw, 0)
        mrp = to_float_safe(mrp_raw, 0)
        discount_percent = to_float_safe(discount_raw, 0)
        net_amount = to_float_safe(net_raw, 0)

        med = find_medicine_for_hold(name, batch)
        if med:
            if not batch and not include_partial:
                batch = med.batch or ""
            if not expiry:
                expiry = med.expiry or ""
            if qoh_raw in (None, "", " "):
                qoh = to_float_safe(med.qty, 0)
            if mrp_raw in (None, "", " "):
                mrp = to_float_safe(med.mrp, 0)
            if discount_raw in (None, "", " "):
                discount_percent = to_float_safe(med.discount_percent, 0)

        line_amount = qty_val * mrp
        if net_amount <= 0:
            net_amount = line_amount - (line_amount * discount_percent / 100)
        discount_amount = line_amount - net_amount
        if discount_amount < 0:
            discount_amount = 0

        rows.append({
            "name": name,
            "batch_mode": batch_mode,
            "batch": batch,
            "expiry": expiry,
            "qoh": round(qoh, 2),
            "qty": qty_val,
            "mrp": round(mrp, 2),
            "discount_percent": round(discount_percent, 2),
            "discount_amount": round(discount_amount, 2),
            "net_amount": round(net_amount, 2),
            "amount": round(line_amount, 2)
        })

    return rows


def build_hold_items_from_form(form):
    return build_hold_rows_from_form(form, include_partial=False)


def build_basic_hold_rows_from_form(form, include_partial=False):
    rows = []
    meds_list = form.getlist("medicine_name")
    qty_list = form.getlist("qty[]") or form.getlist("qty")
    batch_overrides = form.getlist("batch_override[]") or form.getlist("batch_override")
    expiry_list = form.getlist("line_expiry[]")
    qoh_list = form.getlist("line_qoh[]")
    mrp_list = form.getlist("line_mrp[]")
    discount_list = form.getlist("line_discount_percent[]")
    net_list = form.getlist("line_net[]")

    row_count = max(
        len(meds_list),
        len(qty_list),
        len(batch_overrides),
        len(expiry_list),
        len(qoh_list),
        len(mrp_list),
        len(discount_list),
        len(net_list),
    )

    for idx in range(row_count):
        name = (meds_list[idx] if idx < len(meds_list) else "").strip().upper()
        if not name:
            continue
        qty_val = to_int_safe(qty_list[idx] if idx < len(qty_list) else 0, 0)
        if qty_val <= 0 and not include_partial:
            continue
        batch = (batch_overrides[idx] if idx < len(batch_overrides) else "").strip()
        expiry = (expiry_list[idx] if idx < len(expiry_list) else "").strip()
        qoh = to_float_safe(qoh_list[idx] if idx < len(qoh_list) else 0, 0)
        mrp = to_float_safe(mrp_list[idx] if idx < len(mrp_list) else 0, 0)
        discount_percent = to_float_safe(discount_list[idx] if idx < len(discount_list) else 0, 0)
        net_amount = to_float_safe(net_list[idx] if idx < len(net_list) else 0, 0)
        amount = qty_val * mrp
        if net_amount <= 0:
            net_amount = amount - (amount * discount_percent / 100)
        discount_amount = amount - net_amount
        if discount_amount < 0:
            discount_amount = 0

        rows.append({
            "name": name,
            "batch_mode": "MANUAL" if batch else "AUTO",
            "batch": batch,
            "expiry": expiry,
            "qoh": round(qoh, 2),
            "qty": qty_val,
            "mrp": round(mrp, 2),
            "discount_percent": round(discount_percent, 2),
            "discount_amount": round(discount_amount, 2),
            "net_amount": round(net_amount, 2),
            "amount": round(amount, 2),
        })
    return rows

def build_hold_totals_from_form(form, items):
    subtotal_raw = form.get("subtotal")
    discount_raw = form.get("discount")
    cgst_raw = form.get("cgst")
    sgst_raw = form.get("sgst")
    net_total_raw = form.get("net_total")
    rounded_raw = form.get("rounded_amount")
    split_cash_raw = form.get("split_cash_amount")
    online_amount_raw = form.get("online_amount")

    subtotal = to_float_safe(subtotal_raw, 0.0) if subtotal_raw not in (None, "") else round(sum(i["net_amount"] for i in items), 2)
    discount = to_float_safe(discount_raw, 0.0) if discount_raw not in (None, "") else round(sum(i["discount_amount"] for i in items), 2)
    fallback_gst = split_inclusive_gst(subtotal, default_gst_percent())
    cgst = to_float_safe(cgst_raw, fallback_gst["cgst"]) if cgst_raw not in (None, "") else fallback_gst["cgst"]
    sgst = to_float_safe(sgst_raw, fallback_gst["sgst"]) if sgst_raw not in (None, "") else fallback_gst["sgst"]
    net_total = to_float_safe(net_total_raw, subtotal) if net_total_raw not in (None, "") else subtotal
    rounded_amount = to_float_safe(rounded_raw, round(net_total, 2)) if rounded_raw not in (None, "") else round(net_total, 2)
    split_cash_amount = max(to_float_safe(split_cash_raw, 0.0), 0.0) if split_cash_raw not in (None, "") else 0.0
    online_amount = max(
        to_float_safe(online_amount_raw, round(rounded_amount - split_cash_amount, 2)),
        0.0,
    ) if online_amount_raw not in (None, "") else max(round(rounded_amount - split_cash_amount, 2), 0.0)

    return {
        "subtotal": round(subtotal, 2),
        "discount": round(discount, 2),
        "cgst": round(cgst, 2),
        "sgst": round(sgst, 2),
        "net_total": round(net_total, 2),
        "rounded_amount": round(rounded_amount, 2),
        "cash_amount": round(split_cash_amount, 2),
        "online_amount": round(online_amount, 2),
        "is_split_payment": bool(split_cash_amount > 0 and online_amount > 0),
    }

def normalize_hold_bill_data(hold_bill):
    payload = load_hold_bill_payload(extract_hold_bill_payload_source(hold_bill))
    created_at = getattr(hold_bill, "created_at", None)
    hold_bill_id = getattr(hold_bill, "id", None)
    customer = getattr(hold_bill, "customer", "")
    mobile = getattr(hold_bill, "mobile", "")
    doctor = getattr(hold_bill, "doctor", "")
    gender = getattr(hold_bill, "gender", "")
    return normalize_hold_bill_payload(
        hold_bill_id=hold_bill_id,
        customer=customer,
        mobile=mobile,
        doctor=doctor,
        gender=gender,
        payload=payload,
        created_at=created_at,
    )


def normalize_hold_bill_payload(*, hold_bill_id=None, customer="", mobile="", doctor="", gender="", payload=None, created_at=None):
    payload = load_hold_bill_payload(payload)
    raw_items = []
    raw_draft_items = []
    totals = {}
    header = {}

    if isinstance(payload, dict):
        header = payload.get("header") if isinstance(payload.get("header"), dict) else {}
        raw_items = payload.get("items") if isinstance(payload.get("items"), list) else []
        raw_draft_items = payload.get("draft_items") if isinstance(payload.get("draft_items"), list) else []
        if not raw_items and isinstance(payload.get("cart"), list):
            raw_items = payload.get("cart")
        totals = payload.get("totals") if isinstance(payload.get("totals"), dict) else {}
    elif isinstance(payload, list):
        raw_items = payload

    def normalize_rows(raw_list, allow_zero_qty=False):
        normalized = []
        for raw in raw_list:
            if not isinstance(raw, dict):
                continue
            name = (raw.get("name") or raw.get("medicine_name") or "").strip().upper()
            if not name:
                continue
            batch_mode = (raw.get("batch_mode") or "").strip().upper()
            qty_val = to_int_safe(raw.get("qty"), 0)
            if qty_val < 0:
                qty_val = 0
            if qty_val <= 0 and not allow_zero_qty:
                continue
            batch = (raw.get("batch") or "").strip()
            expiry = (raw.get("expiry") or "").strip()
            qoh_source = raw.get("qoh", raw.get("stock", ""))
            mrp_source = raw.get("mrp", raw.get("price", ""))
            qoh = to_float_safe(qoh_source, 0)
            mrp = to_float_safe(mrp_source, 0)
            discount_percent = to_float_safe(raw.get("discount_percent", raw.get("discount", 0)), 0)
            net_amount = to_float_safe(raw.get("net_amount", raw.get("net", raw.get("amount", 0))), 0)

            med = find_medicine_for_hold(name, batch)
            if med:
                if not batch and batch_mode != "AUTO":
                    batch = med.batch or ""
                if not expiry:
                    expiry = med.expiry or ""
                if qoh_source in (None, "", " "):
                    qoh = to_float_safe(med.qty, 0)
                if mrp_source in (None, "", " "):
                    mrp = to_float_safe(med.mrp, 0)

            line_amount = qty_val * mrp
            if net_amount <= 0:
                net_amount = line_amount - (line_amount * discount_percent / 100)
            discount_amount = line_amount - net_amount
            if discount_amount < 0:
                discount_amount = 0

            normalized.append({
                "name": name,
                "batch_mode": batch_mode,
                "batch": batch,
                "expiry": expiry,
                "qoh": round(qoh, 2),
                "qty": qty_val,
                "mrp": round(mrp, 2),
                "discount_percent": round(discount_percent, 2),
                "discount_amount": round(discount_amount, 2),
                "net_amount": round(net_amount, 2),
                "amount": round(line_amount, 2)
            })
        return normalized

    items = normalize_rows(raw_draft_items or raw_items, allow_zero_qty=bool(raw_draft_items))
    finalized_items = normalize_rows(raw_items, allow_zero_qty=False)
    subtotal = to_float_safe(totals.get("subtotal"), round(sum(i["net_amount"] for i in finalized_items), 2))
    discount = to_float_safe(totals.get("discount"), round(sum(i["discount_amount"] for i in finalized_items), 2))
    fallback_gst = split_inclusive_gst(subtotal, default_gst_percent())
    cgst = to_float_safe(totals.get("cgst"), fallback_gst["cgst"])
    sgst = to_float_safe(totals.get("sgst"), fallback_gst["sgst"])
    net_total = to_float_safe(totals.get("net_total"), subtotal)
    rounded_amount = to_float_safe(totals.get("rounded_amount"), round(net_total, 2))
    cash_amount = to_float_safe(totals.get("cash_amount"), 0)
    online_amount = to_float_safe(totals.get("online_amount"), max(round(rounded_amount - cash_amount, 2), 0))
    is_split_payment = bool(totals.get("is_split_payment")) if isinstance(totals.get("is_split_payment"), bool) else bool(cash_amount > 0 and online_amount > 0)

    return {
        "hold_bill_id": hold_bill_id,
        "header": {
            "customer": (header.get("customer") or customer or "").strip(),
            "mobile": (header.get("mobile") or mobile or "").strip(),
            "doctor": (header.get("doctor") or doctor or "").strip(),
            "gender": (header.get("gender") or gender or "").strip(),
            "sale_type": (header.get("sale_type") or "sale").strip().lower() or "sale",
            "payment_mode": normalize_payment_mode(header.get("payment_mode") or "CASH"),
            "split_cash_amount": round(to_float_safe(header.get("split_cash_amount"), cash_amount), 2),
            "internal_note": (header.get("internal_note") or "").strip(),
        },
        "items": items,
        "totals": {
            "subtotal": round(subtotal, 2),
            "discount": round(discount, 2),
            "cgst": round(cgst, 2),
            "sgst": round(sgst, 2),
            "net_total": round(net_total, 2),
            "rounded_amount": round(rounded_amount, 2),
            "cash_amount": round(cash_amount, 2),
            "online_amount": round(online_amount, 2),
            "is_split_payment": is_split_payment,
        },
        "created_at": created_at,
    }

LOW_STOCK_LIMIT = 5
LOW_STOCK_TARGET = 10
LOW_STOCK_MIN_ORDER = 5

def get_low_stock_items(limit=LOW_STOCK_LIMIT, target_stock=LOW_STOCK_TARGET, min_order_qty=LOW_STOCK_MIN_ORDER):
    # Aggregate stock by medicine name across all batches.
    medicines = Medicine.query.order_by(
        db.func.lower(Medicine.name).asc(),
        Medicine.expiry.asc(),
        Medicine.batch.asc(),
        Medicine.id.asc()
    ).all()

    grouped = {}
    for med in medicines:
        name = (med.name or "").strip()
        if not name:
            continue
        key = name.lower()
        entry = grouped.get(key)
        if not entry:
            entry = {
                "name": name,
                "batch": (med.batch or "").strip() or "-",
                "expiry": (med.expiry or "").strip(),
                "stock": 0,
                "qty": 0,
                "batch_count": 0,
                "mrp": to_float(med.mrp)
            }
            grouped[key] = entry

        qty = to_int(med.qty)
        entry["stock"] += qty
        entry["qty"] = entry["stock"]
        entry["batch_count"] += 1

        expiry = (med.expiry or "").strip()
        if expiry and (not entry["expiry"] or expiry < entry["expiry"]):
            entry["expiry"] = expiry

        current_mrp = to_float(med.mrp)
        if entry["mrp"] is not None and entry["mrp"] != current_mrp:
            entry["mrp"] = None

    low_items = []
    for entry in grouped.values():
        if entry["stock"] > limit:
            continue
        if entry["batch_count"] > 1:
            entry["batch"] = f"{entry['batch_count']} batches"
        entry["suggested"] = max(target_stock - entry["stock"], min_order_qty)
        low_items.append(entry)

    low_items.sort(key=lambda item: item["name"].lower())
    return low_items


def medicine_pack_display(med):
    if med.pack_type and med.pack_qty:
        return f"{med.pack_type} of {med.pack_qty}"
    if med.pack_type:
        return med.pack_type
    if med.pack_qty:
        return str(med.pack_qty)
    return "-"


def medicine_expiry_display(expiry):
    raw = (expiry or "").strip()
    exp_dt = parse_expiry_date(raw)
    if exp_dt:
        return exp_dt.strftime("%m/%Y"), exp_dt
    return raw or "-", None


def build_medicine_purchase_rate_lookup(medicines):
    medicine_rows = list(medicines or [])
    if not medicine_rows:
        return {}

    medicine_ids = {med.id for med in medicine_rows if getattr(med, "id", None)}
    medicine_name_keys = {
        (
            normalize_medicine_name(getattr(med, "name", "")).casefold(),
            (getattr(med, "batch", "") or "").strip().casefold(),
        )
        for med in medicine_rows
        if normalize_medicine_name(getattr(med, "name", "")) and (getattr(med, "batch", "") or "").strip()
    }

    filters = []
    if medicine_ids:
        filters.append(VendorPurchaseItem.medicine_id.in_(medicine_ids))
    if medicine_name_keys:
        medicine_name_values = sorted({name for name, _batch in medicine_name_keys})
        batch_values = sorted({batch for _name, batch in medicine_name_keys})
        filters.append(
            and_(
                db.func.lower(db.func.trim(db.func.coalesce(VendorPurchaseItem.medicine_name, ""))).in_(medicine_name_values),
                db.func.lower(db.func.trim(db.func.coalesce(VendorPurchaseItem.batch, ""))).in_(batch_values),
            )
        )

    if not filters:
        return {}

    purchase_items = VendorPurchaseItem.query.filter(
        or_(*filters)
    ).order_by(
        VendorPurchaseItem.created_at.desc(),
        VendorPurchaseItem.id.desc()
    ).all()

    latest_rate_by_medicine_id = {}
    latest_rate_by_name_batch = {}
    for item in purchase_items:
        purchase_rate = to_float_safe(getattr(item, "purchase_rate", 0), 0)
        medicine_id = getattr(item, "medicine_id", None)
        if medicine_id and medicine_id in medicine_ids and medicine_id not in latest_rate_by_medicine_id:
            latest_rate_by_medicine_id[medicine_id] = purchase_rate

        fallback_key = (
            normalize_medicine_name(getattr(item, "medicine_name", "")).casefold(),
            (getattr(item, "batch", "") or "").strip().casefold(),
        )
        if fallback_key in medicine_name_keys and fallback_key not in latest_rate_by_name_batch:
            latest_rate_by_name_batch[fallback_key] = purchase_rate

    purchase_rate_lookup = {}
    for med in medicine_rows:
        med_id = getattr(med, "id", None)
        fallback_key = (
            normalize_medicine_name(getattr(med, "name", "")).casefold(),
            (getattr(med, "batch", "") or "").strip().casefold(),
        )
        purchase_rate_lookup[med_id] = latest_rate_by_medicine_id.get(
            med_id,
            latest_rate_by_name_batch.get(fallback_key, 0.0)
        )
    return purchase_rate_lookup


def build_medicine_master_groups(show_archived=False):
    today = date.today()
    medicines = Medicine.query.order_by(
        db.func.lower(Medicine.name).asc(),
        Medicine.batch.asc(),
        Medicine.id.asc()
    ).all()

    grouped = {}
    stats = {
        "visible_medicine_count": 0,
        "visible_batch_count": 0,
        "archived_batch_count": 0,
        "hidden_archived_batch_count": 0,
        "total_stock": 0
    }

    for med in medicines:
        name = (med.name or "").strip()
        if not name:
            continue

        key = name.lower()
        group = grouped.get(key)
        if not group:
            group = {
                "name": name,
                "medicine_codes": set(),
                "medicine_code_display": "",
                "total_stock": 0,
                "total_batches": 0,
                "active_batches": 0,
                "archived_batches": 0,
                "has_barcode": False,
                "visible_stock": 0,
                "next_expiry": "-",
                "next_expiry_sort": date.max,
                "batches": [],
                "search_text": name.lower()
            }
            grouped[key] = group

        qty = to_int(med.qty)
        is_archived = qty <= 0
        expiry_display, expiry_sort = medicine_expiry_display(med.expiry)
        is_expired = bool(expiry_sort and expiry_sort < today)
        status = "Archived" if is_archived else ("Expired" if is_expired else "Active")
        code_value = normalize_medicine_code(getattr(med, "medicine_code", ""))
        if (getattr(med, "barcode", "") or "").strip():
            group["has_barcode"] = True
        if code_value:
            group["medicine_codes"].add(code_value)

        group["total_batches"] += 1
        group["total_stock"] += qty
        stats["total_stock"] += qty

        if is_archived:
            group["archived_batches"] += 1
            stats["archived_batch_count"] += 1
            if not show_archived:
                stats["hidden_archived_batch_count"] += 1
        else:
            group["active_batches"] += 1
            if expiry_sort and expiry_sort < group["next_expiry_sort"]:
                group["next_expiry_sort"] = expiry_sort
                group["next_expiry"] = expiry_display

        group["search_text"] += " " + " ".join(
            part.lower()
            for part in (
                code_value,
                med.batch or "",
                getattr(med, "barcode", "") or "",
                medicine_pack_display(med),
                expiry_display,
                status
            )
            if part
        )

        if is_archived and not show_archived:
            continue

        batch_row = {
            "id": med.id,
            "medicine_code": code_value,
            "batch": (med.batch or "").strip() or "-",
            "pack": medicine_pack_display(med),
            "expiry": expiry_display,
            "expiry_sort": expiry_sort or date.max,
            "mrp": to_float(med.mrp),
            "qty": qty,
            "status": status,
            "status_class": "archived" if is_archived else ("expired" if is_expired else "active")
        }
        group["batches"].append(batch_row)
        group["visible_stock"] += qty
        stats["visible_batch_count"] += 1

    groups = []
    for group in grouped.values():
        if not group["batches"]:
            continue
        if len(group["medicine_codes"]) == 1:
            group["medicine_code_display"] = next(iter(group["medicine_codes"]))
        group["batches"].sort(
            key=lambda item: (
                item["status"] != "Active",
                item["expiry_sort"],
                item["batch"].lower(),
                item["id"]
            )
        )
        if group["next_expiry"] == "-" and group["batches"]:
            group["next_expiry"] = group["batches"][0]["expiry"]
        groups.append(group)

    groups.sort(key=lambda item: item["name"].lower())
    stats["visible_medicine_count"] = len(groups)
    return groups, stats

def generate_vendor_note_no(note_type):
    prefix = "VN-DN-" if note_type == "DEBIT" else "VN-CN-"
    last = VendorNote.query.filter_by(note_type=note_type).order_by(VendorNote.id.desc()).first()
    next_num = 1
    if last and last.note_no and last.note_no.startswith(prefix):
        try:
            next_num = int(last.note_no.replace(prefix, "")) + 1
        except Exception:
            next_num = last.id + 1
    return f"{prefix}{next_num:06d}"

def compute_vendor_note_totals(items):
    subtotal = Decimal("0")
    gst_total = Decimal("0")
    prepared = []
    for raw in items:
        qty = int(raw.get("qty") or 0)
        free_qty = int(raw.get("free_qty") or 0)
        rate = quantize_decimal(raw.get("purchase_rate") or 0, "0.0001")
        gst_percent = quantize_decimal(raw.get("gst_percent") or 0, "0.01")
        disc_percent = quantize_decimal(raw.get("disc_percent") or 0, "0.01")
        base = Decimal(qty) * rate
        disc_amt = base * disc_percent / Decimal("100")
        taxable = base - disc_amt
        gst_amt = taxable * gst_percent / Decimal("100")
        line_total = quantize_decimal(taxable + gst_amt, "0.0001")
        subtotal += taxable
        gst_total += gst_amt
        prepared.append({
            "qty": qty,
            "free_qty": free_qty,
            "purchase_rate": rate,
            "gst_percent": gst_percent,
            "disc_percent": disc_percent,
            "line_total": line_total
        })
    subtotal = quantize_decimal(subtotal, "0.0001")
    gst_total = quantize_decimal(gst_total, "0.0001")
    return subtotal, gst_total, prepared

def vendor_note_to_dict(note, include_items=False, include_ledger=False):
    data = {
        "id": note.id,
        "note_no": note.note_no,
        "note_type": note.note_type,
        "vendor_id": note.vendor_id,
        "reference_purchase_id": note.reference_purchase_id,
        "supplier_bill_no": note.supplier_bill_no,
        "note_date": note.note_date.isoformat() if note.note_date else None,
        "status": note.status,
        "reason_code": note.reason_code,
        "reason_text": note.reason_text,
        "subtotal": decimal_str(note.subtotal),
        "gst_total": decimal_str(note.gst_total),
        "round_off": decimal_str(note.round_off),
        "grand_total": decimal_str(note.grand_total),
        "outstanding_impact": decimal_str(note.outstanding_impact),
        "remarks": note.remarks,
        "created_by": note.created_by,
        "created_at": note.created_at.isoformat() if note.created_at else None,
        "posted_at": note.posted_at.isoformat() if note.posted_at else None,
        "cancelled_at": note.cancelled_at.isoformat() if note.cancelled_at else None,
        "cancel_reason": note.cancel_reason
    }
    if include_items:
        data["items"] = [
            {
                "id": it.id,
                "medicine_id": it.medicine_id,
                "batch_no": it.batch_no,
                "expiry": it.expiry,
                "qty": it.qty,
                "free_qty": it.free_qty,
                "purchase_rate": decimal_str(it.purchase_rate),
                "mrp": decimal_str(it.mrp),
                "gst_percent": decimal_str(it.gst_percent),
                "disc_percent": decimal_str(it.disc_percent),
                "line_total": decimal_str(it.line_total),
                "hsn": it.hsn
            }
            for it in VendorNoteItem.query.filter_by(note_id=note.id).order_by(VendorNoteItem.id.asc()).all()
        ]
    if include_ledger:
        data["ledger"] = [
            {
                "id": l.id,
                "txn_date": l.txn_date.isoformat() if l.txn_date else None,
                "txn_type": l.txn_type,
                "debit": decimal_str(l.debit),
                "credit": decimal_str(l.credit),
                "notes": l.notes
            }
            for l in VendorLedgerEntry.query.filter_by(ref_table="vendor_notes", ref_id=note.id).order_by(VendorLedgerEntry.id.asc()).all()
        ]
    return data

def get_purchase_items_for_return(med, batch_no=None, reference_purchase_id=None):
    query = VendorPurchaseItem.query
    if reference_purchase_id:
        query = query.filter(VendorPurchaseItem.purchase_id == reference_purchase_id)
    query = query.filter(
        or_(
            VendorPurchaseItem.medicine_id == med.id,
            (VendorPurchaseItem.medicine_id.is_(None) &
             (VendorPurchaseItem.medicine_name == med.name) &
             (VendorPurchaseItem.batch == med.batch))
        )
    )
    if batch_no:
        query = query.filter(VendorPurchaseItem.batch == batch_no)
    return query.order_by(VendorPurchaseItem.created_at.asc(), VendorPurchaseItem.id.asc()).all()

def adjust_vendor_outstanding(vendor_id, delta, return_applied=False):
    vendor = Vendor.query.get(vendor_id) if vendor_id else None
    if not vendor:
        return Decimal("0")
    before = to_decimal(vendor.outstanding_balance or 0)
    balance = before + to_decimal(delta or 0)
    if balance < Decimal("0"):
        balance = Decimal("0")
    after = quantize_decimal(balance, "0.01")
    vendor.outstanding_balance = float(after)
    if vendor.outstanding_balance <= 0:
        vendor.payment_status = "Paid"
    elif (vendor.payment_status or "").strip().lower() == "paid":
        vendor.payment_status = "Unpaid"
    db.session.add(vendor)
    applied = quantize_decimal(after - before, "0.0001")
    if return_applied:
        return applied
    return Decimal("0")


def get_note_outstanding_impact(note):
    if note is None:
        return Decimal("0")
    impact = getattr(note, "outstanding_impact", None)
    if impact not in (None, "", " "):
        return to_decimal(impact)
    grand_total = to_decimal(getattr(note, "grand_total", 0) or 0)
    if (getattr(note, "note_type", "") or "").upper() == "DEBIT":
        return -grand_total
    return grand_total

def parse_date(val):
    if not val:
        return None
    try:
        return datetime.strptime(val, "%Y-%m-%d").date()
    except ValueError:
        return None

def get_clinic_tzinfo():
    if ZoneInfo is not None:
        try:
            return ZoneInfo(APP_TIMEZONE)
        except Exception:
            return None
    return None

def local_date_range_to_storage_bounds(start_date, end_date=None):
    if not start_date:
        return None, None
    end_date = end_date or start_date
    start_local = datetime.combine(start_date, time.min)
    end_local_exclusive = datetime.combine(end_date + timedelta(days=1), time.min)
    tzinfo = get_clinic_tzinfo()
    if not tzinfo:
        return start_local, end_local_exclusive
    start_utc = start_local.replace(tzinfo=tzinfo).astimezone(timezone.utc).replace(tzinfo=None)
    end_utc = end_local_exclusive.replace(tzinfo=tzinfo).astimezone(timezone.utc).replace(tzinfo=None)
    return start_utc, end_utc

def local_month_to_storage_bounds(year, month):
    month_start = date(year, month, 1)
    next_month = (month_start.replace(day=28) + timedelta(days=4)).replace(day=1)
    return local_date_range_to_storage_bounds(month_start, next_month - timedelta(days=1))

def parse_time_value(val):
    if not val:
        return None
    raw = str(val).strip()
    normalized = raw.upper().replace(".", "")
    for fmt in ("%H:%M", "%H:%M:%S", "%I:%M %p", "%I:%M%p", "%I:%M:%S %p", "%I:%M:%S%p"):
        try:
            time_source = normalized if "%p" in fmt else raw
            return datetime.strptime(time_source, fmt).time()
        except ValueError:
            continue
    return None

def generate_appointment_no():
    prefix = "APT-"
    last = Appointment.query.order_by(Appointment.id.desc()).first()
    next_num = 1
    if last and last.appointment_no and last.appointment_no.startswith(prefix):
        try:
            next_num = int(last.appointment_no.replace(prefix, "")) + 1
        except Exception:
            next_num = last.id + 1
    return f"{prefix}{next_num:06d}"

def get_doctor_suggestions():
    names = set()
    invoice_names = db.session.query(Invoice.doctor).filter(
        Invoice.doctor.isnot(None),
        Invoice.doctor != ""
    ).all()
    appt_names = db.session.query(Appointment.doctor_name).filter(
        Appointment.doctor_name.isnot(None),
        Appointment.doctor_name != ""
    ).all()
    for (name,) in invoice_names + appt_names:
        nm = (name or "").strip()
        if nm:
            names.add(nm)
    return sorted(names, key=lambda x: x.lower())

APPOINTMENT_STATUSES = ("BOOKED", "WAITING", "CHECKED_IN", "IN_CONSULTATION", "COMPLETED", "CANCELLED")
APPOINTMENT_PAYMENT_MODES = ("CASH", "ONLINE", "UPI", "CARD")
APPOINTMENT_PAYMENT_STATUSES = ("PAID", "UNPAID")
APPOINTMENT_CONSULTATION_FEES = ("600", "1000")
APPOINTMENT_DEFAULT_DOCTOR = "GENERAL"
APPOINTMENT_GENDERS = ("MALE", "FEMALE", "OTHER")

APPOINTMENT_STATUS_FLOW = {
    "BOOKED": {"WAITING", "CHECKED_IN", "IN_CONSULTATION", "COMPLETED", "CANCELLED"},
    "WAITING": {"BOOKED", "CHECKED_IN", "IN_CONSULTATION", "COMPLETED", "CANCELLED"},
    "CHECKED_IN": {"WAITING", "IN_CONSULTATION", "COMPLETED", "CANCELLED"},
    "IN_CONSULTATION": {"CHECKED_IN", "COMPLETED", "CANCELLED"},
    "COMPLETED": set(),
    "CANCELLED": set()
}

def find_medicine_by_name_batch(name, batch):
    n = (name or "").strip()
    b = (batch or "").strip()
    if not n or not b:
        return None
    return Medicine.query.filter(
        db.func.lower(Medicine.name) == n.lower(),
        db.func.lower(Medicine.batch) == b.lower()
    ).first()


def resolve_medicine_code_mapping(medicine_code, exclude_medicine_id=None):
    normalized_code = normalize_medicine_code(medicine_code)
    if not normalized_code:
        return "", "", None

    query = Medicine.query.filter(Medicine.medicine_code == normalized_code)
    if exclude_medicine_id:
        query = query.filter(Medicine.id != exclude_medicine_id)

    matches = query.order_by(db.func.lower(Medicine.name).asc(), Medicine.id.asc()).all()
    names = {}
    for med in matches:
        cleaned_name = normalize_medicine_name(getattr(med, "name", ""))
        if not cleaned_name:
            continue
        names[cleaned_name.casefold()] = cleaned_name

    if len(names) > 1:
        return normalized_code, "", (
            f"Medicine code {normalized_code} is linked to multiple medicine names. "
            "Please clean the mapping in Medicine Master first."
        )

    canonical_name = next(iter(names.values())) if names else ""
    return normalized_code, canonical_name, None


def find_medicine_code_template(name, pack_type="", pack_qty=None, exclude_medicine_id=None):
    normalized_name = normalize_medicine_name(name)
    if not normalized_name:
        return ""

    query = Medicine.query.filter(
        db.func.lower(db.func.trim(db.func.coalesce(Medicine.name, ""))) == normalized_name.lower()
    )
    if exclude_medicine_id:
        query = query.filter(Medicine.id != exclude_medicine_id)

    template = query.order_by(Medicine.id.asc()).first()
    if template:
        existing_code = normalize_medicine_code(getattr(template, "medicine_code", ""))
        if existing_code:
            return existing_code
    return f"{build_medicine_code_prefix(normalized_name)}001"


def propagate_medicine_code_to_matching_batches(
    name,
    pack_type="",
    pack_qty=None,
    medicine_code="",
    exclude_medicine_id=None,
    previous_code="",
):
    if not normalize_medicine_name(name):
        return 0
    sync_result = sync_medicine_codes_to_current_names()
    return to_int_safe(sync_result.get("medicine_updates"), 0)


def find_medicine_discount_template(name, pack_type="", pack_qty=None, exclude_medicine_id=None):
    normalized_name = normalize_medicine_name(name)
    if not normalized_name:
        return None

    base_query = Medicine.query.filter(
        db.func.lower(db.func.trim(Medicine.name)) == normalized_name.lower()
    )
    if exclude_medicine_id:
        base_query = base_query.filter(Medicine.id != exclude_medicine_id)

    exact_query = base_query
    normalized_pack_type = (pack_type or "").strip().lower()
    if normalized_pack_type:
        exact_query = exact_query.filter(
            db.func.lower(db.func.coalesce(Medicine.pack_type, "")) == normalized_pack_type
        )
    if pack_qty is not None:
        exact_query = exact_query.filter(Medicine.pack_qty == pack_qty)

    template = exact_query.order_by(Medicine.created_at.desc(), Medicine.id.desc()).first()
    if template:
        return template
    return base_query.order_by(Medicine.created_at.desc(), Medicine.id.desc()).first()

def normalize_expiry(val):
    if not val:
        return ""
    v = str(val).strip()
    # MM/YYYY
    if len(v) == 7 and v[2] == "/":
        mm = v[:2]
        yy = v[3:]
        return f"{yy}-{mm}-01"
    # YYYY-MM
    if len(v) == 7 and v[4] == "-":
        return f"{v}-01"
    # YYYY-MM-DD
    if len(v) == 10 and v[4] == "-" and v[7] == "-":
        return v
    return v

def parse_expiry_date(val):
    v = normalize_expiry(val)
    if not v:
        return None
    try:
        return datetime.strptime(v, "%Y-%m-%d").date()
    except ValueError:
        return None

def get_batch_candidates(name):
    today = date.today()
    meds = Medicine.query.filter(
        Medicine.name == name,
        Medicine.qty > 0
    ).all()
    candidates = []
    for med in meds:
        exp_dt = parse_expiry_date(med.expiry)
        if exp_dt and exp_dt < today:
            continue
        purchase_dt = db.session.query(db.func.min(VendorPurchaseItem.created_at)).filter(
            or_(
                VendorPurchaseItem.medicine_id == med.id,
                (VendorPurchaseItem.medicine_id.is_(None) &
                 (VendorPurchaseItem.medicine_name == med.name) &
                 (VendorPurchaseItem.batch == med.batch))
            )
        ).scalar()
        if not purchase_dt:
            purchase_dt = med.created_at
        candidates.append((med, exp_dt or date.max, purchase_dt or datetime.max))
    candidates.sort(key=lambda x: (x[1], x[2], x[0].id))
    return [c[0] for c in candidates]

def get_purchase_items_for_med(med):
    return VendorPurchaseItem.query.filter(
        or_(
            VendorPurchaseItem.medicine_id == med.id,
            (VendorPurchaseItem.medicine_id.is_(None) &
             (VendorPurchaseItem.medicine_name == med.name) &
             (VendorPurchaseItem.batch == med.batch))
        )
    ).order_by(VendorPurchaseItem.created_at.asc(), VendorPurchaseItem.id.asc()).all()

def fifo_consume(med, qty):
    remaining = qty
    allocations = []
    purchase_items = get_purchase_items_for_med(med)
    for pi in purchase_items:
        available = to_int(pi.remaining_qty)
        if available <= 0:
            continue
        take = min(available, remaining)
        if take <= 0:
            continue
        pi.remaining_qty = available - take
        allocations.append({
            "purchase_item": pi,
            "qty": take,
            "cost_rate": to_float(pi.purchase_rate)
        })
        remaining -= take
        if remaining == 0:
            break
    if remaining > 0:
        allocations.append({
            "purchase_item": None,
            "qty": remaining,
            "cost_rate": to_float(med.mrp)
        })
    return allocations

def lock_medicine_for_update(med):
    """Reload a medicine row with a row-level lock (PostgreSQL ``FOR UPDATE``).

    SQLite ignores the lock clause but serialises writers anyway, so the
    re-read still gives the latest committed quantity.
    """
    if med is None or not getattr(med, "id", None):
        return med
    try:
        return (
            Medicine.query.filter(Medicine.id == med.id)
            .with_for_update()
            .populate_existing()
            .first()
        )
    except SQLAlchemyError:
        app.logger.exception("Could not lock medicine row id=%s; using current row", med.id)
        return med


def fifo_return(invoice_item_id, qty, fallback_rate):
    remaining = qty
    cost_total = 0.0
    allocations = SalesAllocation.query.filter_by(invoice_item_id=invoice_item_id).order_by(SalesAllocation.id.asc()).all()
    for alloc in allocations:
        available = to_int(alloc.qty) - to_int(alloc.returned_qty)
        if available <= 0:
            continue
        take = min(available, remaining)
        if take <= 0:
            continue
        if alloc.purchase_item_id:
            pi = VendorPurchaseItem.query.get(alloc.purchase_item_id)
            if pi:
                pi.remaining_qty = to_int(pi.remaining_qty) + take
        alloc.returned_qty = to_int(alloc.returned_qty) + take
        cost_total += take * to_float(alloc.cost_rate)
        remaining -= take
        if remaining == 0:
            break
    if remaining > 0:
        cost_total += remaining * to_float(fallback_rate)
    return cost_total

RETURN_DISPOSITIONS = ("RESTOCK", "DAMAGED", "EXPIRED")


def normalize_return_disposition(value):
    cleaned = str(value or "").strip().upper()
    return cleaned if cleaned in RETURN_DISPOSITIONS else "RESTOCK"


def fifo_return_cost_preview(invoice_item_id, qty, fallback_rate):
    """Cost of returned units (same order as ``fifo_return``) without changing lots."""
    remaining = to_int(qty)
    cost_total = 0.0
    allocations = SalesAllocation.query.filter_by(invoice_item_id=invoice_item_id).order_by(SalesAllocation.id.asc()).all()
    for alloc in allocations:
        available = to_int(alloc.qty) - to_int(alloc.returned_qty)
        if available <= 0:
            continue
        take = min(available, remaining)
        cost_total += take * to_float(alloc.cost_rate)
        remaining -= take
        if remaining <= 0:
            break
    if remaining > 0:
        cost_total += remaining * to_float(fallback_rate)
    return cost_total


def restock_lots_for_manual_return(med, qty, fallback_rate):
    """Put manually returned units back into the newest purchase lots of a batch.

    Without this, ``Medicine.qty`` went up but no vendor lot did, so stock and
    lots drifted apart and FIFO costing / vendor debit notes became wrong.
    Returns (allocations, cost_total) where allocations are (lot, qty, rate).
    """
    remaining = to_int(qty)
    allocations = []
    cost_total = 0.0
    lots = list(reversed(get_purchase_items_for_med(med)))
    for lot in lots:
        if remaining <= 0:
            break
        capacity = to_int(lot.qty) + to_int(lot.free_qty) - to_int(lot.remaining_qty)
        if capacity <= 0:
            continue
        take = min(capacity, remaining)
        lot.remaining_qty = to_int(lot.remaining_qty) + take
        rate = to_float(lot.purchase_rate)
        allocations.append((lot, take, rate))
        cost_total += take * rate
        remaining -= take
    if remaining > 0:
        cost_total += remaining * to_float(fallback_rate)
    return allocations, cost_total


def reverse_manual_return_lots(return_item_id):
    for alloc in ReturnLotAllocation.query.filter_by(return_item_id=return_item_id).all():
        lot = VendorPurchaseItem.query.get(alloc.purchase_item_id)
        if lot:
            lot.remaining_qty = max(to_int(lot.remaining_qty) - to_int(alloc.qty), 0)
        db.session.delete(alloc)


def apply_return_line_stock(*, ret, med, qty, disposition, invoice_item_id, fallback_rate, actor, remark):
    """Move returned units to sellable stock or to quarantine.

    RESTOCK  -> Medicine.qty and the vendor purchase lot both go up.
    DAMAGED / EXPIRED -> nothing is added to sellable stock; a quarantine
    record is created later (needs the ReturnItem id) for an admin decision.
    Returns (cost_total, lot_allocations).
    """
    disposition = normalize_return_disposition(disposition)
    lot_allocations = []
    if disposition == "RESTOCK":
        med = lock_medicine_for_update(med)
        old_stock = to_int_safe(med.qty, 0)
        med.qty = old_stock + qty
        db.session.add(StockHistory(
            medicine_id=med.id,
            medicine_name=med.name,
            batch=med.batch,
            action="RETURN",
            stock_before=old_stock,
            qty_change=qty,
            stock_after=med.qty,
            user=actor,
            remark=remark,
            ref_table="return_bill",
            ref_id=ret.id,
        ))
        if invoice_item_id:
            cost_total = fifo_return(invoice_item_id, qty, fallback_rate)
        else:
            lot_allocations, cost_total = restock_lots_for_manual_return(med, qty, fallback_rate)
    else:
        current = to_int_safe(med.qty, 0)
        db.session.add(StockHistory(
            medicine_id=med.id,
            medicine_name=med.name,
            batch=med.batch,
            action="RETURN_QUARANTINE",
            stock_before=current,
            qty_change=0,
            stock_after=current,
            user=actor,
            remark=f"{remark} | {qty} unit(s) kept aside as {disposition} (not sellable)",
            ref_table="return_bill",
            ref_id=ret.id,
        ))
        if invoice_item_id:
            cost_total = fifo_return_cost_preview(invoice_item_id, qty, fallback_rate)
        else:
            cost_total = qty * to_float(fallback_rate)
    return cost_total, lot_allocations


def record_return_line_followups(*, ret, return_item, med, disposition, lot_allocations, cost_price, actor, note=""):
    for lot, take, rate in lot_allocations:
        db.session.add(ReturnLotAllocation(
            return_item_id=return_item.id,
            purchase_item_id=lot.id,
            qty=take,
            cost_rate=rate,
        ))
    disposition = normalize_return_disposition(disposition)
    if disposition != "RESTOCK":
        db.session.add(QuarantineStock(
            medicine_id=med.id if med else None,
            medicine_name=return_item.medicine_name,
            batch=return_item.batch,
            expiry=return_item.expiry,
            qty=to_int(return_item.qty),
            reason=disposition,
            note=(note or return_item.reason or "")[:255],
            status="PENDING",
            return_id=ret.id,
            return_item_id=return_item.id,
            invoice_item_id=return_item.invoice_item_id or None,
            cost_rate=cost_price,
            created_by=actor,
        ))


def return_success_message(lines):
    kept_aside = sum(to_int(row.get("qty")) for row in lines if normalize_return_disposition(row.get("disposition")) != "RESTOCK")
    message = "Medicine returned successfully. Stock updated & Return Bill generated."
    if kept_aside:
        message += f" {kept_aside} damaged/expired unit(s) kept aside in Quarantine Stock (not sellable)."
    return message


def find_medicine_for_invoice_item(item):
    """Exact batch row for a sold item (name + batch + expiry, then name + batch)."""
    return (
        Medicine.query.filter_by(name=item.name, batch=item.batch, expiry=item.expiry).first()
        or Medicine.query.filter_by(name=item.name, batch=item.batch).first()
    )


def fifo_cancel_return(invoice_item_id, qty, fallback_rate):
    remaining = qty
    cost_total = 0.0
    allocations = SalesAllocation.query.filter_by(invoice_item_id=invoice_item_id).order_by(SalesAllocation.id.desc()).all()
    for alloc in allocations:
        available = to_int(alloc.returned_qty)
        if available <= 0:
            continue
        take = min(available, remaining)
        if take <= 0:
            continue
        if alloc.purchase_item_id:
            pi = VendorPurchaseItem.query.get(alloc.purchase_item_id)
            if pi:
                new_remaining = to_int(pi.remaining_qty) - take
                if new_remaining < 0:
                    new_remaining = 0
                pi.remaining_qty = new_remaining
        alloc.returned_qty = to_int(alloc.returned_qty) - take
        cost_total += take * to_float(alloc.cost_rate)
        remaining -= take
        if remaining == 0:
            break
    if remaining > 0:
        cost_total += remaining * to_float(fallback_rate)
    return cost_total

# ---------------- DATABASE ----------------
instance_dir = ensure_writable_dir(
    app.instance_path,
    os.path.join(TMP_BASE_DIR, "instance")
)
default_db = "sqlite:///" + os.path.join(APP_BASE_DIR, "instance", "pharmacy.db")
db_url = resolve_database_url(default_db)
app.config["SQLALCHEMY_DATABASE_URI"] = db_url
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
db.init_app(app)
migrate = Migrate(app, db, compare_type=True, render_as_batch=db_url.startswith("sqlite")) if Migrate else None
AUTO_DATA_BACKFILL_ON_BOOT = env_flag("AUTO_DATA_BACKFILL_ON_BOOT", not IS_SERVERLESS)
app.register_blueprint(ai_api_bp)
app.register_blueprint(ai_admin_bp)
app.register_blueprint(omnidim_gateway_bp)


@event.listens_for(SASession, "do_orm_execute")
def enforce_tenant_select_criteria(execute_state):
    if _tenant_scope_disabled.get():
        return
    if not execute_state.is_select:
        return
    tenant_id = current_tenant_id()
    if tenant_id is None:
        return
    options = [
        with_loader_criteria(
            model,
            lambda cls: cls.tenant_id == tenant_id,
            include_aliases=True,
        )
        for model in tenant_owned_models()
    ]
    execute_state.statement = execute_state.statement.options(*options)


@event.listens_for(SASession, "before_flush")
def enforce_tenant_writes(session_obj, _flush_context, _instances):
    if _tenant_scope_disabled.get():
        return
    tenant_id = current_tenant_id()
    tenant_objects = [
        obj for obj in set(session_obj.new).union(session_obj.dirty).union(session_obj.deleted)
        if is_tenant_model(obj)
    ]
    tenant_objects = [
        obj for obj in tenant_objects
        if not (
            isinstance(obj, User)
            and obj.tenant_id is None
            and (obj.role or "").strip().lower() == PLATFORM_SUPER_ADMIN_ROLE
        )
    ]
    if not tenant_objects:
        return
    if tenant_id is None:
        with tenant_scope_disabled():
            only_tenant = Tenant.query.order_by(Tenant.id.asc()).first() if Tenant.query.count() == 1 else None
        if only_tenant:
            tenant_id = only_tenant.id
        elif app.config.get("TESTING") and Tenant.query.count() == 0:
            return
        else:
            raise PermissionError("Tenant context is required for tenant-owned writes.")

    for obj in tenant_objects:
        authorize_tenant_object(obj, tenant_id=tenant_id, action="write")

    for obj in session_obj.new.union(session_obj.dirty):
        obj_type = obj.__class__
        for source_model, fk_field, target_model in TENANT_REFERENCE_CHECKS:
            if obj_type is not source_model:
                continue
            ref_id = getattr(obj, fk_field, None)
            if not ref_id:
                continue
            bypass_token = _tenant_scope_disabled.set(True)
            try:
                target = session_obj.get(target_model, ref_id)
            finally:
                _tenant_scope_disabled.reset(bypass_token)
            if target is None:
                continue
            target_tenant_id = getattr(target, "tenant_id", None)
            if target_tenant_id is not None and int(target_tenant_id) != int(tenant_id):
                raise PermissionError(
                    f"Cross-tenant reference blocked: {source_model.__name__}.{fk_field}"
                )


@event.listens_for(SASession, "after_begin")
def set_transaction_tenant_context(session_obj, _transaction, connection):
    set_postgres_tenant_context(connection, current_tenant_id())


@app.before_request
def bind_request_tenant_context():
    g._tenant_context_token = None
    tenant_id = session.get("tenant_id")
    if tenant_id:
        try:
            g._tenant_context_token = set_tenant_context(tenant_id)
        except (TypeError, ValueError):
            session.clear()
            return redirect("/login")
    return None


@app.before_request
def enforce_subscription_access():
    if request.method in ("GET", "HEAD", "OPTIONS"):
        return None
    if request.endpoint in SUBSCRIPTION_MUTATION_ALLOWLIST:
        return None
    if not session.get("user_id") or is_super_admin_user():
        return None
    tenant_id = session.get("tenant_id")
    if not tenant_id:
        return None
    tenant = Tenant.query.filter(Tenant.id == tenant_id).first()
    if not tenant:
        return None
    refresh_tenant_subscription_status(tenant, commit=True)
    status = (tenant.status or "").strip().lower()
    if status in {"suspended", "cancelled"}:
        flash("This pharmacy account is suspended. Data is preserved; changes are blocked.", "danger")
        return redirect(request.referrer or "/")
    if status == "expired":
        endpoint = request.endpoint or ""
        if any(endpoint.startswith(prefix) for prefix in SUBSCRIPTION_READONLY_ALLOWED_ENDPOINT_PREFIXES):
            return None
        flash("Subscription expired. Read-only access is available; renew to make changes.", "warning")
        return redirect(request.referrer or "/")
    path = request.path or ""
    feature_checks = (
        ("/billing", "pos"),
        ("/stock-sale", "inventory"),
        ("/vendor", "inventory"),
        ("/medicines", "inventory"),
        ("/reports", "reports"),
        ("/lab", "lab"),
        ("/appointments", "appointments"),
    )
    for path_prefix, feature_name in feature_checks:
        if path.startswith(path_prefix) and not tenant_feature_enabled(feature_name, tenant):
            flash("This feature is not enabled for the current subscription.", "danger")
            return redirect(request.referrer or "/")
    return None


@app.teardown_request
def clear_request_tenant_context(_exc):
    token = getattr(g, "_tenant_context_token", None)
    if token is not None:
        reset_tenant_context(token)

# ---------------- INIT ----------------
with app.app_context():
    db.create_all()
    def ensure_column(table, column, col_def):
        try:
            insp = inspect(db.engine)
            existing = {c["name"] for c in insp.get_columns(table)}
        except Exception:
            # Fallback for SQLite/older engines
            cols = db.session.execute(text(f'PRAGMA table_info("{table}")')).fetchall()
            existing = {c[1] for c in cols}
        if column not in existing:
            db.session.execute(text(f'ALTER TABLE "{table}" ADD COLUMN "{column}" {col_def}'))
            db.session.commit()

    # Safe schema upgrades for return system (no data loss)
    try:
        # User permissions
        ensure_column("user", "tenant_id", "INTEGER")
        ensure_column("user", "can_view_medicine", "BOOLEAN DEFAULT FALSE")
        ensure_column("user", "can_add_medicine", "BOOLEAN DEFAULT FALSE")
        ensure_column("user", "can_edit_medicine", "BOOLEAN DEFAULT FALSE")
        ensure_column("user", "can_delete_medicine", "BOOLEAN DEFAULT FALSE")
        ensure_column("user", "can_edit_invoice", "BOOLEAN DEFAULT FALSE")
        ensure_column("user", "can_delete_invoice", "BOOLEAN DEFAULT FALSE")
        ensure_column("user", "can_invoice_action", "BOOLEAN DEFAULT FALSE")
        ensure_column("user", "can_view_stock_history", "BOOLEAN DEFAULT FALSE")
        ensure_column("user", "can_view_reports", "BOOLEAN DEFAULT FALSE")
        ensure_column("user", "can_manage_users", "BOOLEAN DEFAULT FALSE")
        ensure_column("user", "can_manage_purchases", "BOOLEAN DEFAULT FALSE")
        ensure_column("user", "can_view_audit_logs", "BOOLEAN DEFAULT FALSE")
        ensure_column("user", "can_view_profit_dashboard", "BOOLEAN DEFAULT FALSE")
        ensure_column("user", "access_profile", "TEXT")
        ensure_column("user", "session_version", "INTEGER DEFAULT 0")
        ensure_column("user", "is_active", "BOOLEAN DEFAULT TRUE")
        ensure_column("user", "deleted_at", "TIMESTAMP")
        ensure_column("user", "deleted_by", "TEXT")
        ensure_column("user", "last_login_at", "TIMESTAMP")
        ensure_column("user", "last_login_ip", "TEXT")
        ensure_column("user", "last_login_user_agent", "TEXT")
        db.session.execute(text(
            'UPDATE "user" '
            'SET "session_version" = 0 '
            'WHERE "session_version" IS NULL'
        ))
        db.session.execute(text(
            'UPDATE "user" '
            'SET "is_active" = :active '
            'WHERE "is_active" IS NULL'
        ), {"active": True})
        db.session.commit()

        # Medicine extra fields
        tenant_owned_tables = (
            "medicine", "invoice", "invoice_item", "return_bill", "return_item",
            "return_lot_allocation", "quarantine_stock", "hold_bill", "pending_bill_store",
            "patient", "appointment", "lab_test", "lab_order", "lab_order_item",
            "lab_report", "portal_otp_challenge", "appointment_booking_settings",
            "public_appointment_booking", "public_appointment_day_lock",
            "clinic_location", "clinician", "clinic_schedule_rule",
            "clinic_schedule_exception", "stock_history", "vendor", "vendor_purchase",
            "vendor_purchase_item", "vendor_notes", "vendor_note_items",
            "vendor_note_allocations", "vendor_ledger", "sales_allocation", "audit_log",
            "login_security_event", "voice_call", "voice_call_event", "ai_api_client",
            "ai_access_token", "ai_api_request_audit", "ai_idempotency_record",
            "omnidim_gateway_action", "clinic_profile", "appointment_slot_lock",
            "appointment_slot_block", "appointment_waitlist", "patient_verification_session",
            "patient_verification_intent", "secure_document_token", "clinic_knowledge_entry",
            "reception_schedule", "reception_schedule_override", "callback_request",
            "complaint", "notification_template", "notification_delivery",
        )
        for tenant_table in tenant_owned_tables:
            ensure_column(tenant_table, "tenant_id", "INTEGER")

        # Medicine extra fields
        ensure_column("medicine", "medicine_code", "TEXT")
        ensure_column("medicine", "composition", "TEXT")
        ensure_column("medicine", "company", "TEXT")
        ensure_column("medicine", "pack_type", "TEXT")
        ensure_column("medicine", "pack_qty", "INTEGER")
        ensure_column("medicine", "barcode", "TEXT")
        ensure_column("medicine", "reorder_level", "INTEGER DEFAULT 10")
        ensure_column("medicine", "is_active", "BOOLEAN DEFAULT TRUE")

        # Vendor extra fields
        ensure_column("vendor", "shop_name", "TEXT")
        ensure_column("vendor", "area", "TEXT")
        ensure_column("vendor", "city", "TEXT")
        ensure_column("vendor", "state", "TEXT")
        ensure_column("vendor", "pincode", "TEXT")
        ensure_column("vendor", "account_holder_name", "TEXT")
        ensure_column("vendor_purchase", "invoice_no", "TEXT")
        ensure_column("vendor_purchase", "bill_attachment_ref", "TEXT")
        ensure_column("vendor_purchase", "paid_amount", "REAL")
        ensure_column("vendor_purchase", "notes", "TEXT")

        # AI clinic/lab profile upgrade (additive; see migration 20260905_07)
        ensure_column("clinician", "sub_specialties_json", "TEXT DEFAULT '[]'")
        ensure_column("clinician", "languages_json", "TEXT DEFAULT '[]'")
        ensure_column("clinician", "conditions_treated_json", "TEXT DEFAULT '[]'")
        ensure_column("clinician", "services_offered_json", "TEXT DEFAULT '[]'")
        ensure_column("lab_test", "aliases_json", "TEXT DEFAULT '[]'")
        ensure_column("lab_test", "fasting_required", "BOOLEAN DEFAULT FALSE")
        ensure_column("lab_test", "turnaround_text", "TEXT")
        try:
            _rule_insp = inspect(db.engine)
            _had_slot_mode_column = "individual_time_slots" in {
                c["name"] for c in _rule_insp.get_columns("clinic_schedule_rule")
            }
        except Exception:
            _had_slot_mode_column = True
        ensure_column("clinic_schedule_rule", "individual_time_slots", "BOOLEAN DEFAULT TRUE")
        if not _had_slot_mode_column:
            # One-time backfill only: a clinic-wide gate rule (no clinician)
            # is an FCFS capacity pool, not an individual doctor calendar.
            # Never re-run this, so an admin's later choice for that rule is
            # never silently reverted on a future restart.
            db.session.execute(text(
                "UPDATE clinic_schedule_rule SET individual_time_slots = 0 "
                "WHERE clinician_id IS NULL"
            ))
            db.session.commit()

        ensure_column("return_bill", "return_no", "TEXT")
        ensure_column("return_bill", "payment_mode", "TEXT")
        ensure_column("return_bill", "cgst", "REAL")
        ensure_column("return_bill", "sgst", "REAL")
        ensure_column("return_bill", "adjusted_invoice_id", "INTEGER")
        ensure_column("return_bill", "adjusted_amount", "REAL DEFAULT 0")
        ensure_column("return_bill", "refund_amount", "REAL DEFAULT 0")
        ensure_column("return_bill", "cash_refund_amount", "NUMERIC(10,2) DEFAULT 0")
        ensure_column("return_bill", "online_refund_amount", "NUMERIC(10,2) DEFAULT 0")
        ensure_column("return_bill", "is_split_refund", "BOOLEAN DEFAULT FALSE")
        ensure_column("return_bill", "is_cancelled", "BOOLEAN DEFAULT FALSE")
        ensure_column("return_bill", "cancelled_by", "TEXT")
        ensure_column("return_bill", "cancelled_at", "TEXT")
        ensure_column("return_item", "medicine_id", "INTEGER")
        ensure_column("return_item", "purchase_rate", "REAL")
        ensure_column("return_item", "selling_rate", "REAL")
        ensure_column("return_item", "gst_percent", "REAL")
        ensure_column("return_item", "reason", "TEXT")
        ensure_column("invoice", "patient_id", "INTEGER")
        ensure_column("invoice", "cash_amount", "NUMERIC(10,2) DEFAULT 0")
        ensure_column("invoice", "online_amount", "NUMERIC(10,2) DEFAULT 0")
        ensure_column("invoice", "is_split_payment", "BOOLEAN DEFAULT FALSE")
        ensure_column("invoice", "return_credit_used", "REAL DEFAULT 0")
        ensure_column("invoice", "final_payable", "REAL DEFAULT 0")
        ensure_column("invoice", "refund_amount", "REAL DEFAULT 0")
        ensure_column("invoice", "internal_note", "TEXT")
        ensure_column("invoice", "print_profile_code", "TEXT")
        ensure_column("invoice", "print_address_line_1", "TEXT")
        ensure_column("invoice", "print_address_line_2", "TEXT")
        ensure_column("invoice", "print_mobile", "TEXT")
        ensure_column("invoice", "print_gst_no", "TEXT")
        ensure_column("invoice", "print_licence_no", "TEXT")
        ensure_column("invoice", "print_logo_path", "TEXT")
        ensure_column("invoice", "print_pharmacy_name", "TEXT")
        ensure_column("invoice", "print_legal_business_name", "TEXT")
        ensure_column("invoice", "print_alternate_mobile", "TEXT")
        ensure_column("invoice", "print_invoice_header", "TEXT")
        ensure_column("invoice", "print_invoice_footer", "TEXT")
        ensure_column("invoice", "print_invoice_terms", "TEXT")
        ensure_column("invoice", "print_authorized_signatory", "TEXT")
        ensure_column("invoice", "customer_gst_no", "TEXT")
        ensure_column("invoice", "is_cancelled", "BOOLEAN DEFAULT FALSE")
        ensure_column("invoice", "cancelled_at", "TIMESTAMP")
        ensure_column("invoice", "cancelled_by", "TEXT")
        ensure_column("invoice", "cancel_reason", "TEXT")
        ensure_column("invoice_item", "gst_percent", "REAL")
        ensure_column("invoice_item", "taxable_amount", "REAL")
        ensure_column("invoice_item", "gst_amount", "REAL")
        ensure_column("medicine", "gst_percent", "REAL DEFAULT 5")
        ensure_column("medicine", "schedule_type", "TEXT DEFAULT ''")
        ensure_column("return_item", "disposition", "TEXT DEFAULT 'RESTOCK'")
        ensure_column("invoice_item", "cost_price", "REAL")
        ensure_column("invoice_item", "cost_amount", "REAL")
        ensure_column("return_item", "cost_price", "REAL")
        ensure_column("return_item", "cost_amount", "REAL")
        ensure_column("vendor_purchase_item", "remaining_qty", "INTEGER")
        ensure_column("vendor_purchase_item", "medicine_code", "TEXT")
        ensure_column("vendor_purchase_item", "pack_type", "TEXT")
        ensure_column("vendor_purchase_item", "pack_qty", "INTEGER")
        ensure_column("vendor_purchase_item", "barcode", "TEXT")
        ensure_column("vendor_purchase_item", "notes", "TEXT")
        ensure_column("vendor_notes", "outstanding_impact", "NUMERIC(12,4)")
        ensure_column("stock_history", "ref_table", "TEXT")
        ensure_column("stock_history", "ref_id", "INTEGER")
        ensure_column("audit_log", "user", "TEXT")
        ensure_column("audit_log", "action", "TEXT")
        ensure_column("audit_log", "entity_type", "TEXT")
        ensure_column("audit_log", "entity_id", "INTEGER")
        ensure_column("audit_log", "ref_code", "TEXT")
        ensure_column("audit_log", "before_json", "TEXT")
        ensure_column("audit_log", "after_json", "TEXT")
        ensure_column("audit_log", "extra_json", "TEXT")
        ensure_column("audit_log", "created_at", "TIMESTAMP")
        ensure_column("appointment", "payment_mode", "TEXT")
        ensure_column("appointment", "payment_status", "TEXT")
        ensure_column("appointment", "doctor_discount", "REAL")
        ensure_column("appointment", "consultation_fee", "REAL")
        ensure_column("appointment", "token_no", "INTEGER")
        ensure_column("appointment", "patient_id", "INTEGER")
        ensure_column("appointment", "age", "INTEGER")
        ensure_column("appointment", "gender", "TEXT")
        ensure_column("appointment", "symptoms", "TEXT")
        ensure_column("appointment", "previous_visit_notes", "TEXT")
        ensure_column("appointment", "is_deleted", "BOOLEAN DEFAULT FALSE")
        ensure_column("appointment", "deleted_at", "TIMESTAMP")
        ensure_column("appointment", "deleted_by", "TEXT")
        # Public QR appointments are first-come, first-served.  These fields
        # are intentionally independent from the legacy per-slot settings so
        # existing staff-created appointments continue to keep their own time.
        ensure_column("appointment_booking_settings", "arrival_window_start", "TEXT DEFAULT '17:30'")
        ensure_column("appointment_booking_settings", "arrival_window_end", "TEXT DEFAULT '19:45'")
        ensure_column("hold_bill", "customer", "TEXT")
        ensure_column("hold_bill", "mobile", "TEXT")
        ensure_column("hold_bill", "doctor", "TEXT")
        ensure_column("hold_bill", "gender", "TEXT")
        ensure_column("hold_bill", "data", "TEXT")
        ensure_column("hold_bill", "created_at", "TIMESTAMP")
        ensure_column("hold_bill", "is_deleted", "BOOLEAN DEFAULT FALSE")
        ensure_column("hold_bill", "deleted_at", "TIMESTAMP")
        ensure_column("hold_bill", "deleted_by", "TEXT")
        ensure_column("pending_bill_store", "legacy_hold_bill_id", "INTEGER")
        ensure_column("pending_bill_store", "customer", "TEXT")
        ensure_column("pending_bill_store", "mobile", "TEXT")
        ensure_column("pending_bill_store", "doctor", "TEXT")
        ensure_column("pending_bill_store", "gender", "TEXT")
        ensure_column("pending_bill_store", "data_text", "TEXT")
        ensure_column("pending_bill_store", "created_at", "TIMESTAMP")
        ensure_column("pending_bill_store", "is_deleted", "BOOLEAN DEFAULT FALSE")
        ensure_column("pending_bill_store", "deleted_at", "TIMESTAMP")
        ensure_column("pending_bill_store", "deleted_by", "TEXT")
        ensure_column("vendor", "is_active", "BOOLEAN DEFAULT TRUE")
        ensure_column("vendor", "deleted_at", "TIMESTAMP")
        ensure_column("vendor", "deleted_by", "TEXT")
        db.session.execute(text(
            'UPDATE "invoice" '
            'SET "cash_amount" = 0 '
            'WHERE "cash_amount" IS NULL'
        ))
        db.session.execute(text(
            'UPDATE "invoice" '
            'SET "online_amount" = 0 '
            'WHERE "online_amount" IS NULL'
        ))
        db.session.execute(text(
            'UPDATE "invoice" '
            'SET "is_split_payment" = FALSE '
            'WHERE "is_split_payment" IS NULL'
        ))
        db.session.commit()
        backfill_invoice_print_profiles()
        sync_invoice_print_profiles_to_cutover()
        if (db.session.bind.dialect.name if db.session.bind else "").lower() == "postgresql":
            legacy_boolean_columns = {
                "user": {
                    "is_active": True,
                    "can_view_medicine": False,
                    "can_add_medicine": False,
                    "can_edit_medicine": False,
                    "can_delete_medicine": False,
                    "can_edit_invoice": False,
                    "can_delete_invoice": False,
                    "can_invoice_action": False,
                    "can_view_stock_history": False,
                    "can_view_reports": False,
                    "can_manage_users": False,
                    "can_manage_purchases": False,
                    "can_view_audit_logs": False,
                    "can_view_profit_dashboard": False,
                },
                "medicine": {"is_active": True},
                "vendor": {"is_active": True},
                "return_bill": {"is_cancelled": False},
                "appointment": {"is_deleted": False},
                "hold_bill": {"is_deleted": False},
                "pending_bill_store": {"is_deleted": False},
                "login_security_event": {"is_suspicious": False},
            }
            pg_inspector = inspect(db.engine)
            for table_name, columns in legacy_boolean_columns.items():
                if not pg_inspector.has_table(table_name):
                    continue
                existing_columns = {col["name"]: col for col in pg_inspector.get_columns(table_name)}
                for column_name, default_value in columns.items():
                    column_meta = existing_columns.get(column_name)
                    if not column_meta:
                        continue
                    type_name = column_meta["type"].__class__.__name__.lower()
                    if "bool" in type_name:
                        continue
                    default_sql = "TRUE" if default_value else "FALSE"
                    db.session.execute(text(
                        f'ALTER TABLE "{table_name}" ALTER COLUMN "{column_name}" '
                        'TYPE BOOLEAN USING ('
                        f'CASE WHEN "{column_name}" IS NULL THEN NULL '
                        f'WHEN LOWER(TRIM(CAST("{column_name}" AS TEXT))) IN '
                        "('1', 'true', 't', 'yes', 'on') THEN TRUE ELSE FALSE END)"
                    ))
                    db.session.execute(text(
                        f'ALTER TABLE "{table_name}" ALTER COLUMN "{column_name}" SET DEFAULT {default_sql}'
                    ))
            db.session.commit()
        if AUTO_DATA_BACKFILL_ON_BOOT:
            db.session.execute(text(
                'UPDATE "appointment" '
                'SET "payment_status" = CASE '
                'WHEN "payment_status" IS NULL OR "payment_status" = \'\' THEN '
                'CASE WHEN UPPER(COALESCE("payment_mode", \'\')) IN (\'PAID\', \'UNPAID\') '
                'THEN UPPER("payment_mode") ELSE \'UNPAID\' END '
                'ELSE UPPER("payment_status") END'
            ))
            db.session.execute(text(
                'UPDATE "appointment" '
                'SET "payment_mode" = CASE '
                'WHEN UPPER(COALESCE("payment_mode", \'\')) IN (\'CASH\', \'ONLINE\', \'UPI\', \'CARD\') '
                'THEN UPPER("payment_mode") ELSE \'CASH\' END'
            ))
            db.session.execute(text(
                'UPDATE "appointment" '
                'SET "doctor_discount" = 0 '
                'WHERE "doctor_discount" IS NULL'
            ))
            db.session.execute(text(
                'UPDATE "appointment" '
                'SET "consultation_fee" = 0 '
                'WHERE "consultation_fee" IS NULL'
            ))
            db.session.execute(text(
                'UPDATE "medicine" '
                'SET "reorder_level" = 10 '
                'WHERE "reorder_level" IS NULL'
            ))
            db.session.execute(text(
                'UPDATE "medicine" '
                'SET "is_active" = :active '
                'WHERE "is_active" IS NULL'
            ), {"active": True})
            db.session.execute(text(
                'UPDATE "appointment" '
                'SET "is_deleted" = :deleted '
                'WHERE "is_deleted" IS NULL'
            ), {"deleted": False})
            db.session.execute(text(
                'UPDATE "hold_bill" '
                'SET "is_deleted" = :deleted '
                'WHERE "is_deleted" IS NULL'
            ), {"deleted": False})
            db.session.execute(text(
                'UPDATE "pending_bill_store" '
                'SET "is_deleted" = :deleted '
                'WHERE "is_deleted" IS NULL'
            ), {"deleted": False})
            db.session.commit()

            appointments_without_token = Appointment.query.filter(
                Appointment.token_no.is_(None),
                Appointment.deleted_at.is_(None),
                # Public QR confirmations deliberately do not receive a
                # token until the patient reaches reception.  Do not turn a
                # server restart into an implicit token-issuance event.
                or_(Appointment.created_by.is_(None), Appointment.created_by != "PUBLIC_QR"),
            ).order_by(
                Appointment.appointment_date.asc(),
                Appointment.appointment_time.asc(),
                Appointment.id.asc()
            ).all()
            if appointments_without_token:
                token_tracker = {}
                for appt in appointments_without_token:
                    if not appt.appointment_date:
                        continue
                    day_key = appt.appointment_date.isoformat()
                    if day_key not in token_tracker:
                        day_max = db.session.query(db.func.max(Appointment.token_no)).filter(
                            Appointment.appointment_date == appt.appointment_date
                        ).scalar() or 0
                        token_tracker[day_key] = int(day_max)
                    token_tracker[day_key] += 1
                    appt.token_no = token_tracker[day_key]
                db.session.commit()
        else:
            app.logger.info("Skipping boot-time data backfill (AUTO_DATA_BACKFILL_ON_BOOT=0)")

        db.session.execute(text(
            'CREATE TABLE IF NOT EXISTS "sales_allocation" ('
            'id INTEGER PRIMARY KEY, '
            'invoice_item_id INTEGER NOT NULL, '
            'purchase_item_id INTEGER, '
            'qty INTEGER, '
            'cost_rate REAL, '
            'returned_qty INTEGER DEFAULT 0, '
            'created_at TEXT'
            ')'
        ))
        db.session.commit()
        ensure_column("sales_allocation", "returned_qty", "INTEGER")
        if AUTO_DATA_BACKFILL_ON_BOOT:
            missing_remaining = db.session.execute(text(
                'SELECT COUNT(*) FROM "vendor_purchase_item" WHERE "remaining_qty" IS NULL'
            )).scalar()
            if missing_remaining:
                db.session.execute(text('UPDATE "vendor_purchase_item" SET "remaining_qty" = 0'))
                db.session.commit()
                medicines = Medicine.query.all()
                for med in medicines:
                    stock_left = to_int(med.qty)
                    purchase_items = VendorPurchaseItem.query.filter(
                        or_(
                            VendorPurchaseItem.medicine_id == med.id,
                            (VendorPurchaseItem.medicine_id.is_(None) &
                             (VendorPurchaseItem.medicine_name == med.name) &
                             (VendorPurchaseItem.batch == med.batch))
                        )
                    ).order_by(VendorPurchaseItem.created_at.desc(), VendorPurchaseItem.id.desc()).all()
                    for pi in purchase_items:
                        lot_qty = to_int(pi.qty) + to_int(pi.free_qty)
                        if stock_left <= 0:
                            pi.remaining_qty = 0
                            continue
                        take = lot_qty if stock_left >= lot_qty else stock_left
                        pi.remaining_qty = take
                        stock_left -= take
                db.session.commit()
            db.session.execute(text(
                'UPDATE "sales_allocation" '
                'SET "returned_qty" = 0 '
                'WHERE "returned_qty" IS NULL'
            ))
            db.session.commit()
        ensure_runtime_indexes()
        persist_medicine_code_sync()
        repair_hold_bill_schema_compat()
        repair_pending_bill_store_compat()
        sync_pending_bill_store()
    except Exception:
        # If schema upgrade fails, app should still run, but the failure must be
        # visible in logs: a missing column breaks billing later in confusing ways.
        db.session.rollback()
        app.logger.exception("Boot-time schema upgrade failed; run 'flask db upgrade' to add missing columns")
    try:
        backfill_medicine_gst_from_purchases()
    except Exception:
        db.session.rollback()
        app.logger.exception("Medicine GST backfill failed; medicines without a rate use DEFAULT_GST_PERCENT")
    try:
        ensure_default_tenant_for_legacy_users()
    except Exception:
        db.session.rollback()
        app.logger.exception("Default tenant bootstrap failed")
    with tenant_scope_disabled():
        bootstrap_tenant = Tenant.query.filter_by(tenant_code="default").first()
    if bootstrap_tenant:
        with tenant_context(bootstrap_tenant.id):
            if not active_user_query().filter_by(username="admin").first():
                bootstrap_admin_password = (
                    (os.environ.get("DEFAULT_ADMIN_PASSWORD") or "").strip()
                    or (os.environ.get("ADMIN_PASSWORD") or "").strip()
                )
                if not bootstrap_admin_password and not IS_PROD:
                    bootstrap_admin_password = secrets.token_urlsafe(12)
                    app.logger.warning(
                        "Generated a local bootstrap admin password because DEFAULT_ADMIN_PASSWORD is missing: %s",
                        bootstrap_admin_password
                    )
                if bootstrap_admin_password:
                    admin = User(
                        tenant_id=bootstrap_tenant.id,
                        username="admin",
                        role="admin",
                        access_profile="admin",
                        can_view_medicine=True,
                        can_add_medicine=True,
                        can_edit_medicine=True,
                        can_delete_medicine=True,
                        can_edit_invoice=True,
                        can_delete_invoice=True,
                        can_invoice_action=True,
                        can_view_stock_history=True,
                        can_view_reports=True,
                        can_manage_users=True,
                        can_manage_purchases=True,
                        can_view_audit_logs=True,
                        can_view_profit_dashboard=True
                    )
                    admin.set_password(bootstrap_admin_password)
                    db.session.add(admin)
                    db.session.commit()
                else:
                    app.logger.warning(
                        "Admin bootstrap skipped because DEFAULT_ADMIN_PASSWORD/ADMIN_PASSWORD is not set."
                    )
    else:
        if (os.environ.get("DEFAULT_ADMIN_PASSWORD") or os.environ.get("ADMIN_PASSWORD")):
            app.logger.warning(
                "Admin bootstrap skipped because the default pharmacy tenant is not available."
            )
    super_admin_username = (os.environ.get("SUPER_ADMIN_USERNAME") or "").strip()
    super_admin_password = (os.environ.get("SUPER_ADMIN_PASSWORD") or "").strip()
    if super_admin_username and super_admin_password:
        with tenant_context(None):
            existing_super_admin = active_user_query().filter(
                User.tenant_id.is_(None),
                db.func.lower(User.username) == super_admin_username.lower(),
            ).first()
            if not existing_super_admin:
                platform_owner = User(
                    tenant_id=None,
                    username=super_admin_username,
                    role=PLATFORM_SUPER_ADMIN_ROLE,
                    access_profile="platform_owner",
                    can_manage_users=True,
                    can_view_reports=True,
                    can_view_audit_logs=True,
                )
                platform_owner.set_password(super_admin_password)
                db.session.add(platform_owner)
                db.session.commit()

configure_monitoring(app, db, env_flag=env_flag)
app.extensions["tenant_context"] = tenant_context
app.extensions["tenant_scope_disabled"] = tenant_scope_disabled
background_jobs = init_background_jobs(
    app,
    enabled=env_flag("ENABLE_BACKGROUND_JOBS", IS_PROD and not IS_SERVERLESS)
)

# ---------------- AUTH DECORATOR ----------------
def set_login_session(user, tenant=None):
    session.clear()
    session.permanent = True
    now_iso = datetime.utcnow().isoformat()
    resolved_tenant = tenant or getattr(user, "tenant", None)
    session["user_id"] = user.id
    session["tenant_id"] = None if is_super_admin_user(user) else (getattr(resolved_tenant, "id", None) or getattr(user, "tenant_id", None))
    session["tenant_uid"] = getattr(resolved_tenant, "tenant_uid", "") or ""
    session["tenant_code"] = getattr(resolved_tenant, "tenant_code", "") or ""
    session["tenant_name"] = getattr(resolved_tenant, "pharmacy_name", "") or ""
    session["tenant_logo_path"] = tenant_business_identity(resolved_tenant).get("logo_path", "")
    session["session_version"] = int(user.session_version or 0)
    session["username"] = user.username
    session["role"] = user.role
    session["login_at"] = now_iso
    session["last_seen_at"] = now_iso
    session["access_profile"] = getattr(user, "access_profile", "custom") or "custom"
    session["can_view_medicine"] = user.can_view_medicine
    session["can_edit_invoice"] = user.can_edit_invoice
    session["can_delete_invoice"] = user.can_delete_invoice
    session["can_view_stock_history"] = user.can_view_stock_history
    session["can_view_reports"] = user.can_view_reports
    session["can_manage_users"] = user.can_manage_users
    session["can_manage_purchases"] = getattr(user, "can_manage_purchases", False)
    session["can_view_audit_logs"] = getattr(user, "can_view_audit_logs", False)
    session["can_view_profit_dashboard"] = getattr(user, "can_view_profit_dashboard", False)
    session["can_invoice_action"] = user.can_invoice_action
    session["can_add_medicine"] = user.can_add_medicine
    session["can_edit_medicine"] = user.can_edit_medicine
    session["can_delete_medicine"] = user.can_delete_medicine


def login_required(f):
    @wraps(f)
    def w(*args, **kwargs):
        user_id = session.get("user_id")
        if not user_id:
            return redirect("/login")
        user = active_user_by_id(user_id)
        if not user:
            session.clear()
            return redirect("/login")
        if is_super_admin_user(user):
            now_utc = datetime.utcnow()
            last_seen_raw = (session.get("last_seen_at") or "").strip()
            if last_seen_raw:
                try:
                    last_seen_at = datetime.fromisoformat(last_seen_raw)
                except ValueError:
                    last_seen_at = None
                if last_seen_at and (now_utc - last_seen_at) > timedelta(minutes=session_idle_minutes):
                    session.clear()
                    flash("Your session expired due to inactivity. Please login again.", "warning")
                    return redirect("/login")
            if int(session.get("session_version", 0)) != int(user.session_version or 0):
                session.clear()
                flash("You have been logged out from all devices. Please login again.", "warning")
                return redirect("/login")
            g.user = user
            g.tenant = None
            session["last_seen_at"] = now_utc.isoformat()
            return f(*args, **kwargs)
        tenant = Tenant.query.filter(Tenant.id == user.tenant_id).first() if getattr(user, "tenant_id", None) else None
        if not tenant:
            tenant = ensure_default_tenant_for_legacy_users()
            if tenant and not getattr(user, "tenant_id", None):
                user.tenant_id = tenant.id
                db.session.commit()
        if not tenant or session.get("tenant_id") != tenant.id:
            log_login_security_event(
                username=user.username,
                user=user,
                outcome="SESSION_REVOKED",
                reason="Tenant membership changed",
                is_suspicious=True,
            )
            session.clear()
            flash("Your tenant access changed. Please login again.", "warning")
            return redirect("/login")
        refresh_tenant_subscription_status(tenant, commit=True)
        if not tenant_login_allowed(tenant):
            log_login_security_event(
                username=user.username,
                user=user,
                outcome="SESSION_REVOKED",
                reason=f"Tenant status is {tenant.status}",
                is_suspicious=False,
            )
            session.clear()
            flash("This pharmacy account is not active. Please contact support.", "danger")
            return redirect("/login")
        now_utc = datetime.utcnow()
        last_seen_raw = (session.get("last_seen_at") or "").strip()
        if last_seen_raw:
            try:
                last_seen_at = datetime.fromisoformat(last_seen_raw)
            except ValueError:
                last_seen_at = None
            if last_seen_at and (now_utc - last_seen_at) > timedelta(minutes=session_idle_minutes):
                log_login_security_event(
                    username=user.username,
                    user=user,
                    outcome="SESSION_EXPIRED",
                    reason="Idle session timeout",
                    is_suspicious=False,
                )
                session.clear()
                flash("Your session expired due to inactivity. Please login again.", "warning")
                return redirect("/login")
        login_at_raw = (session.get("login_at") or "").strip()
        if login_at_raw:
            try:
                login_at = datetime.fromisoformat(login_at_raw)
            except ValueError:
                login_at = None
            if login_at and (now_utc - login_at) > timedelta(hours=session_absolute_hours):
                log_login_security_event(
                    username=user.username,
                    user=user,
                    outcome="SESSION_EXPIRED",
                    reason="Absolute session lifetime exceeded",
                    is_suspicious=False,
                )
                session.clear()
                flash("Your session has expired. Please login again.", "warning")
                return redirect("/login")
        session_version = int(session.get("session_version", 0))
        if session_version != int(user.session_version or 0):
            log_login_security_event(
                username=user.username,
                user=user,
                outcome="SESSION_REVOKED",
                reason="Session version mismatch",
                is_suspicious=False,
            )
            session.clear()
            flash("You have been logged out from all devices. Please login again.", "warning")
            return redirect("/login")
        g.user = user
        g.tenant = tenant
        session["last_seen_at"] = now_utc.isoformat()
        return f(*args, **kwargs)
    return w


@app.route("/healthz")
def healthz():
    payload = run_system_health_checks(include_counts=False)
    status_code = 200 if payload["status"] == "ok" else 503
    return jsonify(payload), status_code


@app.route("/readyz")
def readyz():
    payload = run_system_health_checks(include_counts=False)
    database_ok = bool(payload["database"]["ok"])
    storage_ok = all(
        details.get("available")
        for details in payload.get("storage", {}).values()
        if isinstance(details, dict) and "available" in details
    )
    payload["ready"] = bool(database_ok and storage_ok)
    status_code = 200 if payload["ready"] else 503
    return jsonify(payload), status_code


@app.route("/telephony/<provider>/inbound", methods=["POST"])
def generic_telephony_inbound(provider):
    """Receive one signed, provider-neutral staging telephony event.

    This intentionally supports only the internal generic staging envelope.
    It is disabled until an explicit provider name and webhook secret are
    configured. A real Exotel/Twilio/etc. adapter must validate that
    provider's signing scheme and translate its payload before using this
    boundary.
    """
    raw_body = request.get_data(cache=True, as_text=False)
    request_target = (request.full_path or request.path or "").rstrip("?")
    response = handle_generic_telephony_webhook(
        provider=provider,
        method=request.method,
        request_target=request_target,
        raw_body=raw_body,
        headers=request.headers,
        db_session=db.session,
        environment={**os.environ, "APP_ENV": app.config.get("APP_ENV", "")},
    )
    return jsonify(dict(response.payload)), response.status_code

# ---------------- LOGIN ----------------
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = (request.form.get("username") or "").strip()
        password = request.form.get("password") or ""
        tenant_identifier = (request.form.get("tenant") or request.form.get("tenant_code") or "").strip()
        if not username or not password:
            flash("Username and password are required", "danger")
            return render_template("login.html")
        normalized_username = username.lower()
        platform_user = None
        if not tenant_identifier:
            with tenant_scope_disabled():
                platform_user = active_user_query().filter(
                    User.tenant_id.is_(None),
                    db.func.lower(User.username) == normalized_username,
                    db.func.lower(User.role) == PLATFORM_SUPER_ADMIN_ROLE,
                ).first()
            if platform_user and platform_user.check_password(password):
                platform_user.last_login_at = datetime.utcnow()
                platform_user.last_login_ip = current_client_ip()
                platform_user.last_login_user_agent = current_user_agent()
                db.session.commit()
                set_login_session(platform_user, None)
                log_login_security_event(
                    username=platform_user.username,
                    user=platform_user,
                    outcome="SUCCESS",
                    reason="Platform owner login successful",
                    is_suspicious=False,
                )
                return redirect("/super-admin")
        try:
            ensure_default_tenant_for_legacy_users()
        except Exception:
            db.session.rollback()
            app.logger.exception("Unable to prepare tenant context during login")
        login_tenant = tenant_from_identifier(tenant_identifier) if tenant_identifier else None
        if tenant_identifier and not login_tenant:
            log_login_security_event(
                username=username,
                outcome="FAILED",
                reason="Unknown tenant identifier",
                is_suspicious=True,
            )
            flash("Invalid credentials", "danger")
            return render_template("login.html")
        if not login_tenant:
            tenant_count = Tenant.query.count()
            if tenant_count > 1:
                log_login_security_event(
                    username=username,
                    outcome="FAILED",
                    reason="Tenant identifier required",
                    is_suspicious=True,
                )
                flash("Please enter your pharmacy tenant code.", "danger")
                return render_template("login.html")
            if tenant_count == 1:
                login_tenant = Tenant.query.order_by(Tenant.id.asc()).first()
        if login_tenant:
            with tenant_context(login_tenant.id):
                user = active_user_query().filter(db.func.lower(User.username) == normalized_username).first()
        else:
            user = active_user_query().filter(db.func.lower(User.username) == normalized_username).first()
        if user and user.check_password(password):
            tenant = Tenant.query.filter(Tenant.id == user.tenant_id).first() if getattr(user, "tenant_id", None) else None
            if login_tenant:
                if not tenant or login_tenant.id != tenant.id:
                    log_login_security_event(
                        username=user.username,
                        user=user,
                        outcome="FAILED",
                        reason="Tenant membership verification failed",
                        is_suspicious=True,
                    )
                    flash("Invalid credentials", "danger")
                    return render_template("login.html")
            elif not tenant:
                tenant = ensure_default_tenant_for_legacy_users()
                user = active_user_query().filter(User.id == user.id).first()
            if not tenant:
                log_login_security_event(
                    username=user.username,
                    user=user,
                    outcome="FAILED",
                    reason="User is not linked to a tenant",
                    is_suspicious=True,
                )
                flash("Your user is not linked to a pharmacy account. Please contact an administrator.", "danger")
                return render_template("login.html")
            if not tenant_login_allowed(tenant):
                log_login_security_event(
                    username=user.username,
                    user=user,
                    outcome="FAILED",
                    reason=f"Tenant status is {tenant.status}",
                    is_suspicious=False,
                )
                flash("This pharmacy account is not active. Please contact support.", "danger")
                return render_template("login.html")
            suspicious_reason = "Login successful"
            suspicious = False
            request_ip = current_client_ip()
            request_agent = current_user_agent()
            if user.last_login_ip and user.last_login_ip != request_ip:
                suspicious = True
                suspicious_reason = "Successful login from a new IP address"
            elif user.last_login_user_agent and user.last_login_user_agent != request_agent:
                suspicious = True
                suspicious_reason = "Successful login from a new device signature"
            with tenant_context(tenant.id):
                user.last_login_at = datetime.utcnow()
                user.last_login_ip = request_ip
                user.last_login_user_agent = request_agent
                db.session.commit()
                set_login_session(user, tenant)
                log_login_security_event(
                    username=user.username,
                    user=user,
                    outcome="SUCCESS",
                    reason=suspicious_reason,
                    is_suspicious=suspicious,
                )
            return redirect("/")
        suspicious_threshold = max(3, int(str(os.environ.get("SUSPICIOUS_LOGIN_THRESHOLD", "5")).strip() or 5))
        failed_attempts = failed_login_attempts_recent(username, current_client_ip())
        if login_tenant:
            with tenant_context(login_tenant.id):
                known_user = User.query.filter(db.func.lower(User.username) == normalized_username).first()
        else:
            known_user = User.query.filter(db.func.lower(User.username) == normalized_username).first()
        disabled_attempt = bool(known_user and (known_user.deleted_at is not None or not getattr(known_user, "is_active", True)))
        suspicious = disabled_attempt or (failed_attempts + 1 >= suspicious_threshold)
        failure_reason = "Attempted login to disabled user" if disabled_attempt else "Invalid credentials"
        log_login_security_event(
            username=username,
            user=(known_user if known_user else None),
            outcome="FAILED",
            reason=failure_reason,
            is_suspicious=suspicious,
        )
        flash("Invalid credentials", "danger")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect("/login")


@app.route("/logout-all", methods=["POST"])
@login_required
def logout_everywhere():
    if session.get("role") != "admin":
        flash("Access denied", "danger")
        return redirect("/")
    user = active_user_by_id(session.get("user_id"))
    if user:
        user.session_version = int(user.session_version or 0) + 1
        db.session.commit()
    session.clear()
    flash("Logged out from all devices.", "success")
    return redirect("/login")


@app.route("/change-password", methods=["GET", "POST"])
@login_required
def change_password():
    user = active_user_by_id(session.get("user_id"))
    if not user:
        session.clear()
        return redirect("/login")

    if request.method == "POST":
        current_password = (request.form.get("current_password") or "").strip()
        new_password = (request.form.get("new_password") or "").strip()
        confirm_password = (request.form.get("confirm_password") or "").strip()

        if not current_password:
            flash("Current password is required", "danger")
            return redirect(request.url)
        if not user.check_password(current_password):
            flash("Current password is incorrect", "danger")
            return redirect(request.url)
        if not new_password:
            flash("New password is required", "danger")
            return redirect(request.url)
        if new_password != confirm_password:
            flash("New password and confirm password do not match", "danger")
            return redirect(request.url)

        user.set_password(new_password)
        db.session.commit()
        flash("Password updated successfully", "success")
        return redirect("/")

    return render_template(
        "change_password.html",
        user=user,
        require_current_password=True,
        page_title="Change Password"
    )
# ---------------- ADD USER (ADMIN ONLY) ----------------
def admin_required(f):
    @wraps(f)
    def w(*args, **kwargs):
        if session.get("role") != "admin" and not session.get("can_manage_users"):
            flash("Access denied", "danger")
            return redirect("/")
        return f(*args, **kwargs)
    return w


def super_admin_required(f):
    @wraps(f)
    def w(*args, **kwargs):
        user = active_user_by_id(session.get("user_id"))
        if not user or not is_super_admin_user(user):
            flash("Super admin access required", "danger")
            return redirect("/login")
        g.user = user
        g.tenant = None
        return f(*args, **kwargs)
    return w

def invoice_access_required(f):
    @wraps(f)
    def w(*args, **kwargs):
        user = active_user_by_id(session.get("user_id"))
        if not user:
            flash("Access denied", "danger")
            return redirect("/")
        if user.role != "admin" and not user.can_invoice_action:
            flash("Access denied", "danger")
            return redirect("/")
        return f(*args, **kwargs)
    return w


def lab_catalog_access_required(f):
    """Phase 1 keeps price-master ownership with administrators only."""
    @wraps(f)
    def w(*args, **kwargs):
        user = active_user_by_id(session.get("user_id"))
        if not user or user.role != "admin":
            flash("Only an administrator can manage the Lab Test Master.", "danger")
            return redirect("/lab-billing")
        return f(*args, **kwargs)
    return w


def public_appointment_admin_required(f):
    """Keep public-booking policy and payment approval with a true admin."""
    @wraps(f)
    def w(*args, **kwargs):
        user = active_user_by_id(session.get("user_id"))
        if not user or user.role != "admin":
            flash("Only an administrator can manage public appointment booking.", "danger")
            return redirect("/appointments")
        return f(*args, **kwargs)
    return w

def inventory_access_required(f):
    @wraps(f)
    def w(*args, **kwargs):
        user = active_user_by_id(session.get("user_id"))
        if not user:
            flash("Access denied", "danger")
            return redirect("/")
        if user.role != "admin" and not (
            user.can_view_medicine
            or user.can_add_medicine
            or user.can_edit_medicine
            or user.can_delete_medicine
            or getattr(user, "can_manage_purchases", False)
        ):
            flash("Access denied", "danger")
            return redirect("/")
        return f(*args, **kwargs)
    return w

def vendor_note_access_required(api=False):
    def decorator(f):
        @wraps(f)
        def w(*args, **kwargs):
            user = active_user_by_id(session.get("user_id"))
            allowed = bool(
                user and (
                    user.role == "admin"
                    or user.can_invoice_action
                    or getattr(user, "can_manage_purchases", False)
                )
            )
            if allowed:
                return f(*args, **kwargs)
            if api:
                return jsonify({"error": "Access denied"}), 403
            flash("Access denied", "danger")
            return redirect("/")
        return w
    return decorator


@app.route("/system-center")
@login_required
@admin_required
def system_center():
    health = run_system_health_checks(include_counts=True)
    return render_template(
        "system_center.html",
        system_health=health,
        upgrade_tracker=build_upgrade_tracker(),
        release_identifier=get_release_identifier(),
        max_upload_mb=max_upload_mb,
        background_job_status=(background_jobs.snapshot() if background_jobs else {}),
        backup_snapshots=list_backup_snapshots(app, limit=8),
        restore_commands=build_restore_commands(app, "latest"),
        recent_suspicious_logins=LoginSecurityEvent.query.filter(
            truthy_column_expr(LoginSecurityEvent.is_suspicious)
        ).order_by(LoginSecurityEvent.created_at.desc()).limit(8).all(),
        migrate_enabled=bool(migrate),
        sentry_configured=bool((os.environ.get("SENTRY_DSN") or "").strip())
    )


@app.route("/system-center/backups/run", methods=["POST"])
@login_required
@admin_required
def run_backup_snapshot_now():
    snapshot = build_backup_snapshot(
        app,
        upload_dirs=app.config.get("INFRA_UPLOAD_DIRECTORIES", {}),
        keep_count=int(os.environ.get("BACKUP_KEEP_COUNT", "14") or 14),
        include_uploads=True,
    )
    flash(f"Backup snapshot created: {snapshot['snapshot_name']}", "success")
    return redirect("/system-center")


@app.route("/system-center/backups/restore-drill", methods=["POST"])
@login_required
@admin_required
def run_restore_drill():
    snapshot_name = (request.form.get("snapshot_name") or "latest").strip() or "latest"
    try:
        result = restore_backup_snapshot(
            app,
            snapshot_name=snapshot_name,
            include_uploads=True,
            dry_run=True,
            allow_production=False,
        )
        flash(
            f"Restore drill passed for {result['snapshot_name']}. "
            f"Tables checked: {sum((result.get('table_counts') or {}).values())} rows in snapshot manifest.",
            "success",
        )
    except Exception as exc:
        flash(f"Restore drill failed: {exc}", "danger")
    return redirect("/system-center")

# ---------------- DASHBOARD (DAILY LIVE SALE) ----------------
@app.route("/")
@login_required
def index():
    show_profit_cards = bool(
        session.get("role") == "admin" or session.get("can_view_profit_dashboard")
    )
    business_identity = tenant_business_identity(current_tenant())
    # ---------- TODAY SALE ----------
    today = clinic_now().date()
    today_iso = today.isoformat()
    today_start, tomorrow_start = local_date_range_to_storage_bounds(today, today)
    today_invoices = active_invoice_query().filter(
        Invoice.created_at >= today_start,
        Invoice.created_at < tomorrow_start
    ).all()
    today_returns = Return.query.filter(
        Return.created_at >= today_start,
        Return.created_at < tomorrow_start,
        falsey_or_null_column_expr(Return.is_cancelled)
    ).all()

    today_collection_summary = summarize_invoice_collection(today_invoices, today_returns)
    cash_today_sale = 0
    online_today_sale = 0
    cash_bills_today = 0
    online_bills_today = 0

    cash_today_sale = today_collection_summary["cash_collection"]
    online_today_sale = today_collection_summary["online_collection"]
    cash_bills_today = today_collection_summary["cash_invoice_count"]
    online_bills_today = today_collection_summary["online_invoice_count"]

    today_sale = today_collection_summary["net_sale_total"]
    bills_today = len(today_invoices)

    # ---------- LOW STOCK ----------
    low_stock_count = len(get_low_stock_items(limit=LOW_STOCK_LIMIT))

    # ---------- EXPIRING SOON (30 days) ----------
    expiring_soon = build_expiring_medicines_query(today).count()

    # ---------- INVENTORY VALUE (AT PURCHASE RATE) ----------
    inventory_value = (
        db.session.query(
            db.func.coalesce(
                db.func.sum(
                    db.func.coalesce(VendorPurchaseItem.remaining_qty, 0) *
                    db.func.coalesce(VendorPurchaseItem.purchase_rate, 0)
                ),
                0
            )
        ).scalar()
        or 0
    )

    # ---------- GST COLLECTED (ONLY DISPLAY) ----------
    gst_collected = sum(
        (i.cgst + i.sgst) for i in today_invoices
    )

    # ---------- APPOINTMENTS (TODAY) ----------
    appointments_today = active_appointment_query().filter(
        Appointment.appointment_date == today
    )
    appointment_total_today = appointments_today.count()
    appointment_booked_today = appointments_today.filter(
        Appointment.status == "BOOKED"
    ).count()
    appointment_completed_today = appointments_today.filter(
        Appointment.status == "COMPLETED"
    ).count()

    sales_trend = build_dashboard_sales_trend(days=7)
    appointment_trend = build_dashboard_appointment_trend(days=7)
    top_medicines = build_dashboard_top_medicines(limit=5, period_days=30)
    dead_stock_items = build_dashboard_dead_stock(limit=5, dormant_days=60)

    today_profit = None
    month_profit = None
    if show_profit_cards:
        today_profit, _today_profit_error = build_profit_report_summary(today_iso, today_iso)
        month_start = today.replace(day=1)
        month_profit, _month_profit_error = build_profit_report_summary(month_start.isoformat(), today_iso)
        today_profit = today_profit or {
            "gross_profit": 0.0,
            "gross_profit_percentage": 0.0,
            "net_sales": 0.0
        }
        month_profit = month_profit or {
            "gross_profit": 0.0,
            "gross_profit_percentage": 0.0,
            "net_sales": 0.0
        }

    return render_template(
        "index.html",
        today_sale=today_sale,
        bills_today=bills_today,
        cash_today_sale=cash_today_sale,
        online_today_sale=online_today_sale,
        cash_bills_today=cash_bills_today,
        online_bills_today=online_bills_today,
        low_stock=low_stock_count,
        expiring_soon=expiring_soon,
        inventory_value=inventory_value,
        gst_collected=gst_collected,
        appointment_total_today=appointment_total_today,
        appointment_booked_today=appointment_booked_today,
        appointment_completed_today=appointment_completed_today,
        today_date=today_iso,
        sales_trend=sales_trend,
        appointment_trend=appointment_trend,
        top_medicines=top_medicines,
        dead_stock_items=dead_stock_items,
        today_profit=today_profit,
        month_profit=month_profit,
        show_profit_cards=show_profit_cards,
        business_identity=business_identity,
        business_profile_complete=bool(
            business_identity.get("pharmacy_name")
            and business_identity.get("address_line_1")
        ),
    )
@app.route("/low-stock")
@login_required
def low_stock():
    medicines = get_low_stock_items(limit=LOW_STOCK_LIMIT)
    return render_template("low_stock.html", medicines=medicines)
@app.route("/order-list")
@login_required
def order_list():
    medicines = get_low_stock_items(limit=LOW_STOCK_LIMIT)

    order_items = []
    for m in medicines:
        order_items.append({
            "name": m["name"],
            "batch": m["batch"],
            "stock": m["stock"],
            "suggested": m["suggested"]
        })

    return render_template("order_list.html", items=order_items)

def user_is_admin():
    return (session.get("role") or "").strip().lower() == "admin"


def reports_permission_required(f):
    @wraps(f)
    def w(*args, **kwargs):
        user = active_user_by_id(session.get("user_id"))
        if not user or (user.role != "admin" and not user.can_view_reports):
            flash("Access denied", "danger")
            return redirect("/")
        return f(*args, **kwargs)
    return w


def admin_only(f):
    @wraps(f)
    def w(*args, **kwargs):
        user = active_user_by_id(session.get("user_id"))
        if not user or user.role != "admin":
            flash("Only an administrator can do this.", "danger")
            return redirect(request.referrer or "/")
        return f(*args, **kwargs)
    return w


def parse_report_date_range(default_days=30):
    today = clinic_now().date()
    default_from = today.replace(day=1) if default_days == "month" else today - timedelta(days=default_days)
    try:
        start = datetime.strptime((request.args.get("from") or "").strip(), "%Y-%m-%d").date()
    except ValueError:
        start = default_from
    try:
        end = datetime.strptime((request.args.get("to") or "").strip(), "%Y-%m-%d").date()
    except ValueError:
        end = today
    if end < start:
        start, end = end, start
    return start, end


def excel_response(sheets, filename):
    """sheets: list of (title, headers, rows)."""
    from openpyxl import Workbook
    from openpyxl.styles import Font

    workbook = Workbook()
    workbook.remove(workbook.active)
    for title, headers, rows in sheets:
        sheet = workbook.create_sheet(title=title[:31])
        sheet.append(headers)
        for cell in sheet[1]:
            cell.font = Font(bold=True)
        for row in rows:
            sheet.append(row)
        for column in sheet.columns:
            width = max(len(str(cell.value or "")) for cell in column)
            sheet.column_dimensions[column[0].column_letter].width = min(max(10, width + 2), 45)
    output = BytesIO()
    workbook.save(output)
    output.seek(0)
    return send_file(
        output,
        as_attachment=True,
        download_name=filename,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        max_age=0,
    )


# ---------------- EXPIRY MANAGEMENT ----------------
def build_expiry_buckets(reference_date=None, window_days=90):
    today = reference_date or clinic_now().date()
    rows = []
    for med in Medicine.query.filter(Medicine.qty > 0).all():
        exp_dt = parse_expiry_date(med.expiry)
        if not exp_dt:
            continue
        days_left = (exp_dt - today).days
        if days_left > window_days:
            continue
        if days_left < 0:
            bucket = "expired"
        elif days_left <= 30:
            bucket = "30"
        elif days_left <= 60:
            bucket = "60"
        else:
            bucket = "90"
        last_lot = (
            VendorPurchaseItem.query.filter(
                or_(
                    VendorPurchaseItem.medicine_id == med.id,
                    and_(
                        VendorPurchaseItem.medicine_id.is_(None),
                        VendorPurchaseItem.medicine_name == med.name,
                        VendorPurchaseItem.batch == med.batch,
                    ),
                )
            )
            .order_by(VendorPurchaseItem.created_at.desc(), VendorPurchaseItem.id.desc())
            .first()
        )
        vendor = Vendor.query.get(last_lot.vendor_id) if last_lot and last_lot.vendor_id else None
        cost_rate = to_float(last_lot.purchase_rate) if last_lot else 0.0
        rows.append({
            "medicine": med,
            "days_left": days_left,
            "bucket": bucket,
            "expiry_date": exp_dt,
            "stock_value_mrp": round_currency(to_int(med.qty) * to_float(med.mrp)),
            "stock_value_cost": round_currency(to_int(med.qty) * cost_rate),
            "vendor": vendor,
        })
    rows.sort(key=lambda row: (row["days_left"], row["medicine"].name or ""))
    return rows


@app.route("/expiring-soon")
@login_required
def expiring_soon():
    window_days = to_int_safe(request.args.get("days"), 90)
    if window_days not in (30, 60, 90, 180):
        window_days = 90
    rows = build_expiry_buckets(clinic_now().date(), window_days)
    summary = {}
    for key in ("expired", "30", "60", "90"):
        bucket_rows = [row for row in rows if row["bucket"] == key]
        summary[key] = {
            "count": len(bucket_rows),
            "units": sum(to_int(row["medicine"].qty) for row in bucket_rows),
            "value": round_currency(sum(row["stock_value_mrp"] for row in bucket_rows)),
        }
    if (request.args.get("format") or "").lower() == "xlsx":
        return excel_response(
            [(
                "Expiry",
                ["Medicine", "Batch", "Expiry", "Days Left", "Stock", "MRP Value", "Cost Value", "Last Vendor"],
                [
                    [
                        row["medicine"].name, row["medicine"].batch, row["medicine"].expiry, row["days_left"],
                        row["medicine"].qty, row["stock_value_mrp"], row["stock_value_cost"],
                        row["vendor"].name if row["vendor"] else "",
                    ]
                    for row in rows
                ],
            )],
            f"Expiry_Report_{clinic_now().strftime('%Y%m%d')}.xlsx",
        )
    return render_template(
        "expiring.html",
        rows=rows,
        summary=summary,
        window_days=window_days,
        is_admin=user_is_admin(),
    )


@app.route("/expired-stock/<int:medicine_id>/write-off", methods=["POST"])
@login_required
@admin_only
def write_off_expired_stock(medicine_id):
    med = lock_medicine_for_update(Medicine.query.get_or_404(medicine_id))
    exp_dt = parse_expiry_date(med.expiry)
    if not exp_dt or exp_dt >= clinic_now().date():
        flash("Only expired batches can be written off from this screen.", "danger")
        return redirect("/expiring-soon")
    qty = to_int(med.qty)
    if qty <= 0:
        flash("No stock left in this batch.", "info")
        return redirect("/expiring-soon")
    # Remove the units from the oldest purchase lots so lots stay in sync.
    remaining = qty
    cost_total = 0.0
    for lot in get_purchase_items_for_med(med):
        if remaining <= 0:
            break
        available = to_int(lot.remaining_qty)
        if available <= 0:
            continue
        take = min(available, remaining)
        lot.remaining_qty = available - take
        cost_total += take * to_float(lot.purchase_rate)
        remaining -= take
    med.qty = 0
    db.session.add(StockHistory(
        medicine_id=med.id,
        medicine_name=med.name,
        batch=med.batch,
        action="EXPIRY_WRITE_OFF",
        stock_before=qty,
        qty_change=-qty,
        stock_after=0,
        user=session.get("username"),
        remark=f"Expired stock written off (cost value Rs {round_currency(cost_total):.2f})",
    ))
    db.session.commit()
    record_audit_event(
        action="Wrote off expired stock",
        entity_type="MEDICINE",
        entity_id=med.id,
        ref_code=f"{med.name} / {med.batch}",
        before={"qty": qty},
        after={"qty": 0},
        extra={"cost_value": round_currency(cost_total)},
    )
    flash(f"{qty} expired unit(s) of {med.name} ({med.batch}) written off.", "warning")
    return redirect("/expiring-soon")


# ---------------- QUARANTINE (DAMAGED / EXPIRED RETURNS) ----------------
@app.route("/quarantine-stock")
@login_required
def quarantine_stock():
    status = (request.args.get("status") or "PENDING").strip().upper()
    query = QuarantineStock.query
    if status != "ALL":
        query = query.filter(QuarantineStock.status == status)
    rows = query.order_by(QuarantineStock.created_at.desc(), QuarantineStock.id.desc()).all()
    return_numbers = {
        r.id: (r.return_no or f"RB-{r.id:06d}")
        for r in Return.query.filter(Return.id.in_([row.return_id for row in rows if row.return_id] or [0])).all()
    }
    pending_value = round_currency(sum(
        to_int(row.qty) * to_float(row.cost_rate)
        for row in QuarantineStock.query.filter_by(status="PENDING").all()
    ))
    return render_template(
        "quarantine_stock.html",
        rows=rows,
        status=status,
        return_numbers=return_numbers,
        pending_value=pending_value,
        is_admin=user_is_admin(),
    )


@app.route("/quarantine-stock/<int:qid>/restock", methods=["POST"])
@login_required
@admin_only
def quarantine_restock(qid):
    row = QuarantineStock.query.get_or_404(qid)
    if (row.status or "").upper() != "PENDING":
        flash("This item is already resolved.", "info")
        return redirect("/quarantine-stock")
    med = Medicine.query.get(row.medicine_id) if row.medicine_id else None
    if not med:
        med = Medicine.query.filter_by(name=row.medicine_name, batch=row.batch).first()
    if not med:
        flash("Medicine batch not found in master.", "danger")
        return redirect("/quarantine-stock")
    med = lock_medicine_for_update(med)
    qty = to_int(row.qty)
    old_stock = to_int(med.qty)
    med.qty = old_stock + qty
    if row.invoice_item_id:
        fifo_return(row.invoice_item_id, qty, row.cost_rate)
    else:
        allocations, _cost = restock_lots_for_manual_return(med, qty, row.cost_rate)
        for lot, take, rate in allocations:
            db.session.add(ReturnLotAllocation(
                return_item_id=row.return_item_id or 0,
                purchase_item_id=lot.id,
                qty=take,
                cost_rate=rate,
            ))
    db.session.add(StockHistory(
        medicine_id=med.id,
        medicine_name=med.name,
        batch=med.batch,
        action="QUARANTINE_RESTOCK",
        stock_before=old_stock,
        qty_change=qty,
        stock_after=med.qty,
        user=session.get("username"),
        remark=f"Quarantine #{row.id} checked OK and moved back to sellable stock",
    ))
    row.status = "RESTOCKED"
    row.resolved_by = session.get("username")
    row.resolved_at = datetime.utcnow()
    db.session.commit()
    flash(f"{qty} unit(s) of {row.medicine_name} moved back to sellable stock.", "success")
    return redirect("/quarantine-stock")


@app.route("/quarantine-stock/<int:qid>/write-off", methods=["POST"])
@login_required
@admin_only
def quarantine_write_off(qid):
    row = QuarantineStock.query.get_or_404(qid)
    if (row.status or "").upper() != "PENDING":
        flash("This item is already resolved.", "info")
        return redirect("/quarantine-stock")
    note = (request.form.get("note") or "").strip()
    row.status = "WRITTEN_OFF"
    if note:
        row.note = note[:255]
    row.resolved_by = session.get("username")
    row.resolved_at = datetime.utcnow()
    db.session.add(StockHistory(
        medicine_id=row.medicine_id,
        medicine_name=row.medicine_name,
        batch=row.batch,
        action="QUARANTINE_WRITE_OFF",
        stock_before=None,
        qty_change=0,
        stock_after=None,
        user=session.get("username"),
        remark=f"Quarantine #{row.id}: {row.qty} {row.reason} unit(s) written off (loss Rs {to_int(row.qty) * to_float(row.cost_rate):.2f})",
    ))
    db.session.commit()
    flash(f"{row.qty} unit(s) of {row.medicine_name} written off.", "warning")
    return redirect("/quarantine-stock")


# ---------------- GST SUMMARY REPORT ----------------
def build_gst_summary(start_date, end_date):
    start_bound, end_bound = local_date_range_to_storage_bounds(start_date, end_date)

    def blank():
        return {"taxable": 0.0, "cgst": 0.0, "sgst": 0.0, "total": 0.0, "qty": 0}

    sales_by_rate = {}
    invoices = active_invoice_query().filter(
        Invoice.created_at >= start_bound, Invoice.created_at < end_bound
    ).all()
    invoice_map = {inv.id: inv for inv in invoices}
    items = InvoiceItem.query.filter(InvoiceItem.invoice_id.in_(list(invoice_map) or [0])).all()
    for item in items:
        invoice = invoice_map.get(item.invoice_id)
        net = to_float(item.net_amount if item.net_amount is not None else item.amount)
        if item.gst_amount is not None and item.taxable_amount is not None:
            rate = snap_gst_slab(item.gst_percent)
            half = round_currency(to_float(item.gst_amount) / 2)
            gst = {"taxable_amount": to_float(item.taxable_amount), "cgst": half, "sgst": half}
        else:
            rate = invoice_item_gst_percent(invoice, item)
            gst = split_inclusive_gst(net, rate)
        row = sales_by_rate.setdefault(rate, blank())
        row["taxable"] += gst["taxable_amount"]
        row["cgst"] += gst["cgst"]
        row["sgst"] += gst["sgst"]
        row["total"] += net
        row["qty"] += to_int(item.qty)

    returns_by_rate = {}
    return_rows = (
        db.session.query(ReturnItem)
        .join(Return, ReturnItem.return_id == Return.id)
        .filter(
            Return.created_at >= start_bound,
            Return.created_at < end_bound,
            falsey_or_null_column_expr(Return.is_cancelled),
        )
        .all()
    )
    for item in return_rows:
        rate = snap_gst_slab(item.gst_percent)
        net = to_float(item.net_amount if item.net_amount is not None else item.amount)
        gst = split_inclusive_gst(net, rate)
        row = returns_by_rate.setdefault(rate, blank())
        row["taxable"] += gst["taxable_amount"]
        row["cgst"] += gst["cgst"]
        row["sgst"] += gst["sgst"]
        row["total"] += net
        row["qty"] += to_int(item.qty)

    purchases_by_rate = {}
    purchase_rows = (
        db.session.query(VendorPurchaseItem)
        .join(VendorPurchase, VendorPurchaseItem.purchase_id == VendorPurchase.id)
        .filter(VendorPurchase.purchase_date >= start_bound, VendorPurchase.purchase_date < end_bound)
        .all()
    )
    for item in purchase_rows:
        rate = snap_gst_slab(item.gst_percent)
        base = to_int(item.qty) * to_float(item.purchase_rate)
        taxable = base - base * to_float(item.discount_percent) / 100
        tax = taxable * rate / 100
        row = purchases_by_rate.setdefault(rate, blank())
        row["taxable"] += taxable
        row["cgst"] += tax / 2
        row["sgst"] += tax / 2
        row["total"] += taxable + tax
        row["qty"] += to_int(item.qty) + to_int(item.free_qty)

    def finish(bucket):
        out = []
        for key, row in sorted(bucket.items(), key=lambda kv: (str(kv[0]))):
            out.append({
                "key": key,
                **{name: (round_currency(value) if name != "qty" else value) for name, value in row.items()},
            })
        return out

    def total(rows):
        agg = blank()
        for row in rows:
            for name in agg:
                agg[name] += row[name]
        return {name: (round_currency(value) if name != "qty" else value) for name, value in agg.items()}

    sales = finish(sales_by_rate)
    returns = finish(returns_by_rate)
    purchases = finish(purchases_by_rate)
    sales_total, returns_total, purchase_total = total(sales), total(returns), total(purchases)
    output_tax = round_currency(sales_total["cgst"] + sales_total["sgst"] - returns_total["cgst"] - returns_total["sgst"])
    input_tax = round_currency(purchase_total["cgst"] + purchase_total["sgst"])
    return {
        "sales": sales,
        "returns": returns,
        "purchases": purchases,
        "sales_total": sales_total,
        "returns_total": returns_total,
        "purchase_total": purchase_total,
        "output_tax": output_tax,
        "input_tax": input_tax,
        "net_tax": round_currency(output_tax - input_tax),
        "invoice_count": len(invoices),
    }


@app.route("/reports/gst")
@login_required
@reports_permission_required
def gst_report():
    start_date, end_date = parse_report_date_range("month")
    data = build_gst_summary(start_date, end_date)
    if (request.args.get("format") or "").lower() == "xlsx":
        def rate_rows(rows):
            return [[f'{row["key"]}%', row["qty"], row["taxable"], row["cgst"], row["sgst"], row["total"]] for row in rows]
        headers = ["GST Rate", "Qty", "Taxable Value", "CGST", "SGST", "Total"]
        identity = tenant_business_identity(current_tenant())
        return excel_response(
            [
                ("Sales (Outward)", headers, rate_rows(data["sales"])),
                ("Returns (Credit Notes)", headers, rate_rows(data["returns"])),
                ("Purchases (Input)", headers, rate_rows(data["purchases"])),
                ("Summary", ["Item", "Amount"], [
                    ["Output GST (sales - returns)", data["output_tax"]],
                    ["Input GST (purchases)", data["input_tax"]],
                    ["Net GST payable (estimate)", data["net_tax"]],
                ]),
                ("Business Profile", ["Field", "Value"], [
                    ["Pharmacy Name", identity["pharmacy_name"]],
                    ["Legal Business Name", identity["legal_business_name"]],
                    ["Address", ", ".join(value for value in (identity["address_line_1"], identity["address_line_2"]) if value)],
                    ["GSTIN", identity["gst_no"]],
                    ["Drug License", identity["licence_no"]],
                    ["Contact", identity["mobile"]],
                    ["Email", identity["email"]],
                ]),
            ],
            f"GST_Summary_{start_date.isoformat()}_{end_date.isoformat()}.xlsx",
        )
    return render_template(
        "gst_report.html",
        data=data,
        start_date=start_date,
        end_date=end_date,
        business_identity=tenant_business_identity(current_tenant()),
    )


# ---------------- SCHEDULE H1 / X REGISTER ----------------
def build_schedule_register(start_date, end_date, schedules=("H1", "X")):
    start_bound, end_bound = local_date_range_to_storage_bounds(start_date, end_date)
    scheduled = {
        ((m.name or "").strip().lower(), (m.batch or "").strip().lower()): normalize_schedule_type(m.schedule_type)
        for m in Medicine.query.filter(Medicine.schedule_type.in_(list(schedules))).all()
    }
    scheduled_names = {}
    for (name, _batch), code in scheduled.items():
        scheduled_names[name] = code
    if not scheduled_names:
        return []
    rows = []
    invoices = active_invoice_query().filter(
        Invoice.created_at >= start_bound, Invoice.created_at < end_bound
    ).order_by(Invoice.created_at.asc(), Invoice.id.asc()).all()
    invoice_map = {inv.id: inv for inv in invoices}
    for item in InvoiceItem.query.filter(InvoiceItem.invoice_id.in_(list(invoice_map) or [0])).order_by(InvoiceItem.id.asc()).all():
        key = ((item.name or "").strip().lower(), (item.batch or "").strip().lower())
        code = scheduled.get(key) or scheduled_names.get(key[0])
        if not code:
            continue
        inv = invoice_map[item.invoice_id]
        local_dt = storage_datetime_to_local(inv.created_at) or inv.created_at
        rows.append({
            "date": local_dt.strftime("%d-%m-%Y") if local_dt else "",
            "invoice_no": inv.invoice_no,
            "patient": inv.customer or "",
            "mobile": inv.mobile or "",
            "doctor": inv.doctor or "",
            "medicine": item.name,
            "batch": item.batch,
            "qty": item.qty,
            "schedule": code,
        })
    return rows


@app.route("/reports/schedule-h1")
@login_required
@reports_permission_required
def schedule_h1_register():
    start_date, end_date = parse_report_date_range("month")
    rows = build_schedule_register(start_date, end_date)
    if (request.args.get("format") or "").lower() == "xlsx":
        return excel_response(
            [(
                "Schedule H1 Register",
                ["Date", "Invoice No", "Patient", "Mobile", "Prescriber (Doctor)", "Medicine", "Batch", "Qty", "Schedule"],
                [[r["date"], r["invoice_no"], r["patient"], r["mobile"], r["doctor"], r["medicine"], r["batch"], r["qty"], r["schedule"]] for r in rows],
            )],
            f"Schedule_H1_Register_{start_date.isoformat()}_{end_date.isoformat()}.xlsx",
        )
    return render_template("schedule_register.html", rows=rows, start_date=start_date, end_date=end_date)


# ---------------- DATA HEALTH ----------------
def build_data_health_report():
    meds = Medicine.query.all()
    groups = {}
    for med in meds:
        key = ((med.name or "").strip().lower(), (med.batch or "").strip().lower())
        groups.setdefault(key, []).append(med)
    duplicates = [sorted(rows, key=lambda m: m.id) for rows in groups.values() if len(rows) > 1]

    today = clinic_now().date()
    expired = []
    for med in meds:
        exp_dt = parse_expiry_date(med.expiry)
        if exp_dt and exp_dt < today and to_int(med.qty) > 0:
            expired.append(med)

    lot_totals = dict(
        db.session.query(VendorPurchaseItem.medicine_id, db.func.coalesce(db.func.sum(VendorPurchaseItem.remaining_qty), 0))
        .filter(VendorPurchaseItem.medicine_id.isnot(None))
        .group_by(VendorPurchaseItem.medicine_id)
        .all()
    )
    mismatches = []
    for med in meds:
        if med.id in lot_totals and to_int(med.qty) != to_int(lot_totals[med.id]):
            mismatches.append({"medicine": med, "lot_qty": to_int(lot_totals[med.id])})

    costly_lots = []
    for lot in VendorPurchaseItem.query.filter(VendorPurchaseItem.mrp > 0).all():
        landed = to_float(lot.purchase_rate) * (1 + to_float(lot.gst_percent) / 100)
        if landed > to_float(lot.mrp):
            costly_lots.append({"lot": lot, "landed": round_currency(landed)})

    negative = [med for med in meds if to_int(med.qty) < 0]
    return {
        "duplicates": duplicates,
        "expired": expired,
        "mismatches": mismatches,
        "costly_lots": costly_lots,
        "negative": negative,
    }


@app.route("/data-health")
@login_required
@admin_only
def data_health():
    return render_template("data_health.html", report=build_data_health_report())


@app.route("/data-health/merge-duplicate", methods=["POST"])
@login_required
@admin_only
def merge_duplicate_medicine():
    keep = Medicine.query.get_or_404(to_int_safe(request.form.get("keep_id"), 0))
    drop = Medicine.query.get_or_404(to_int_safe(request.form.get("merge_id"), 0))
    same_key = (
        (keep.name or "").strip().lower() == (drop.name or "").strip().lower()
        and (keep.batch or "").strip().lower() == (drop.batch or "").strip().lower()
    )
    if keep.id == drop.id or not same_key:
        flash("Only two rows of the same medicine and batch can be merged.", "danger")
        return redirect("/data-health")
    keep = lock_medicine_for_update(keep)
    drop = lock_medicine_for_update(drop)
    moved_qty = to_int(drop.qty)
    old_keep = to_int(keep.qty)
    keep.qty = old_keep + moved_qty
    drop.qty = 0
    drop.is_active = False
    VendorPurchaseItem.query.filter_by(medicine_id=drop.id).update({"medicine_id": keep.id})
    ReturnItem.query.filter_by(medicine_id=drop.id).update({"medicine_id": keep.id})
    VendorNoteItem.query.filter_by(medicine_id=drop.id).update({"medicine_id": keep.id})
    QuarantineStock.query.filter_by(medicine_id=drop.id).update({"medicine_id": keep.id})
    for field in ("barcode", "composition", "company"):
        if not getattr(keep, field, None) and getattr(drop, field, None):
            setattr(keep, field, getattr(drop, field))
    db.session.add(StockHistory(
        medicine_id=keep.id,
        medicine_name=keep.name,
        batch=keep.batch,
        action="MERGE",
        stock_before=old_keep,
        qty_change=moved_qty,
        stock_after=keep.qty,
        user=session.get("username"),
        remark=f"Merged duplicate row #{drop.id} into #{keep.id}",
    ))
    db.session.commit()
    record_audit_event(
        action="Merged duplicate medicine rows",
        entity_type="MEDICINE",
        entity_id=keep.id,
        ref_code=f"{keep.name} / {keep.batch}",
        before={"keep_qty": old_keep, "merged_row": drop.id, "merged_qty": moved_qty},
        after={"keep_qty": keep.qty},
    )
    flash(f"Merged duplicate row #{drop.id} into #{keep.id} ({moved_qty} unit(s) moved). The duplicate is archived.", "success")
    return redirect("/data-health")


# ---------------- MEDICINES ----------------
@app.route("/medicines")
@login_required
def medicines():
    user = active_user_by_id(session.get("user_id"))
    if not user:
        flash("Access denied", "danger")
        return redirect("/")
    if user.role != "admin" and not (
        user.can_view_medicine or user.can_add_medicine or user.can_edit_medicine or user.can_delete_medicine
    ):
        flash("Access denied", "danger")
        return redirect("/")
    persist_medicine_code_sync()
    show_archived = (request.args.get("show_archived") or "").strip().lower() in {"1", "true", "yes", "on"}
    initial_search = (request.args.get("search") or "").strip()
    medicine_groups, medicine_stats = build_medicine_master_groups(show_archived=show_archived)
    return render_template(
        "medicines.html",
        medicine_groups=medicine_groups,
        medicine_stats=medicine_stats,
        show_archived=show_archived,
        initial_search=initial_search
    )

def build_patient_medicine_usage_report(
    from_date_raw,
    to_date_raw,
    search_query=""
):
    from_date_raw = (from_date_raw or "").strip()
    to_date_raw = (to_date_raw or "").strip()
    search_filter = (search_query or "").strip()
    search_query = search_filter.lower()
    search_digits = normalize_patient_mobile(search_filter)

    if not from_date_raw or not to_date_raw:
        return [], [], None, "Please select both from date and to date."

    start_date = parse_date(from_date_raw)
    end_date = parse_date(to_date_raw)
    if not start_date or not end_date:
        return [], [], None, "Please enter valid from/to dates."

    if end_date < start_date:
        return [], [], None, "To date must be greater than or equal to from date."

    start_bound, end_bound = local_date_range_to_storage_bounds(start_date, end_date)
    invoices = active_invoice_query().filter(
        Invoice.created_at >= start_bound,
        Invoice.created_at < end_bound
    ).order_by(
        Invoice.created_at.asc(),
        Invoice.id.asc()
    ).all()

    invoice_map = {invoice.id: invoice for invoice in invoices}
    invoice_ids = list(invoice_map.keys())
    items = []
    if invoice_ids:
        items = InvoiceItem.query.filter(
            InvoiceItem.invoice_id.in_(invoice_ids)
        ).order_by(
            InvoiceItem.invoice_id.asc(),
            InvoiceItem.id.asc()
        ).all()

    grouped = {}
    for item in items:
        invoice = invoice_map.get(item.invoice_id)
        if not invoice:
            continue

        medicine_name = (item.name or "").strip()
        if not medicine_name:
            continue

        patient_name = (invoice.customer or "").strip() or "Walk-in"
        mobile = (invoice.mobile or "").strip()
        mobile_digits = normalize_patient_mobile(mobile)

        if search_query:
            search_haystack = " ".join([
                patient_name.lower(),
                mobile.lower(),
                medicine_name.lower()
            ])
            matches_search = search_query in search_haystack
            if not matches_search and search_digits and len(search_digits) >= 3:
                matches_search = search_digits in mobile_digits
            if not matches_search:
                continue

        mobile_key = normalize_patient_mobile(mobile) or mobile.lower()
        patient_key = f"{patient_name.lower()}||{mobile_key}"

        patient_entry = grouped.get(patient_key)
        if not patient_entry:
            patient_entry = {
                "patient_name": patient_name,
                "mobile": mobile or "-",
                "invoice_ids": set(),
                "invoice_nos": set(),
                "total_qty": 0,
                "medicines": {}
            }
            grouped[patient_key] = patient_entry

        patient_entry["invoice_ids"].add(invoice.id)
        patient_entry["invoice_nos"].add(invoice.invoice_no or f"INV-{invoice.id}")

        qty = to_int(item.qty)
        patient_entry["total_qty"] += qty

        medicine_key = medicine_name.upper()
        medicine_entry = patient_entry["medicines"].get(medicine_key)
        if not medicine_entry:
            medicine_entry = {
                "medicine": medicine_name,
                "invoice_ids": set(),
                "invoice_nos": set(),
                "total_qty": 0,
                "last_purchase_at": None
            }
            patient_entry["medicines"][medicine_key] = medicine_entry

        medicine_entry["invoice_ids"].add(invoice.id)
        medicine_entry["invoice_nos"].add(invoice.invoice_no or f"INV-{invoice.id}")
        medicine_entry["total_qty"] += qty
        if not medicine_entry["last_purchase_at"] or (
            invoice.created_at and invoice.created_at > medicine_entry["last_purchase_at"]
        ):
            medicine_entry["last_purchase_at"] = invoice.created_at

    patients = []
    detail_rows = []
    total_purchase_count = 0
    total_qty = 0

    for patient_entry in sorted(
        grouped.values(),
        key=lambda row: ((row["patient_name"] or "").lower(), (row["mobile"] or "").lower())
    ):
        medicine_rows = []
        patient_purchase_count = 0

        for medicine_entry in sorted(
            patient_entry["medicines"].values(),
            key=lambda row: (-row["total_qty"], (row["medicine"] or "").lower())
        ):
            purchase_count = len(medicine_entry["invoice_ids"])
            patient_purchase_count += purchase_count
            total_purchase_count += purchase_count

            row = {
                "patient_name": patient_entry["patient_name"],
                "mobile": patient_entry["mobile"],
                "medicine": medicine_entry["medicine"],
                "purchase_count": purchase_count,
                "total_qty": medicine_entry["total_qty"],
                "last_purchase_date": medicine_entry["last_purchase_at"].strftime("%d-%m-%Y") if medicine_entry["last_purchase_at"] else "-",
                "invoice_nos": ", ".join(sorted(medicine_entry["invoice_nos"]))
            }
            medicine_rows.append(row)
            detail_rows.append(row)

        patient_total_qty = patient_entry["total_qty"]
        total_qty += patient_total_qty
        patients.append({
            "patient_name": patient_entry["patient_name"],
            "mobile": patient_entry["mobile"],
            "invoice_count": len(patient_entry["invoice_ids"]),
            "purchase_count": patient_purchase_count,
            "distinct_medicines": len(medicine_rows),
            "total_qty": patient_total_qty,
            "invoice_nos": ", ".join(sorted(patient_entry["invoice_nos"])),
            "medicines": medicine_rows
        })

    summary = {
        "from_date": from_date_raw,
        "to_date": to_date_raw,
        "search_filter": search_filter,
        "patient_count": len(patients),
        "patient_medicine_count": len(detail_rows),
        "purchase_count": total_purchase_count,
        "total_qty": total_qty
    }
    return patients, detail_rows, summary, None

def build_profit_report_summary(from_date_raw, to_date_raw):
    start_date = parse_date(from_date_raw)
    end_date = parse_date(to_date_raw)

    if not from_date_raw or not to_date_raw:
        return None, "Please select from and to dates"
    if not start_date or not end_date:
        return None, "Please enter valid from and to dates."
    if end_date < start_date:
        return None, "To date must be greater than or equal to from date."

    start_bound, end_bound = local_date_range_to_storage_bounds(start_date, end_date)

    sales_total = db.session.query(db.func.coalesce(db.func.sum(Invoice.subtotal), 0)).filter(
        Invoice.created_at >= start_bound,
        Invoice.created_at < end_bound,
        active_invoice_expr(),
    ).scalar() or 0
    returns_total = db.session.query(db.func.coalesce(db.func.sum(ReturnItem.net_amount), 0)).join(
        Return, ReturnItem.return_id == Return.id
    ).filter(
        Return.created_at >= start_bound,
        Return.created_at < end_bound,
        falsey_or_null_column_expr(Return.is_cancelled)
    ).scalar() or 0
    cogs = db.session.query(db.func.coalesce(db.func.sum(InvoiceItem.cost_amount), 0)).join(
        Invoice, InvoiceItem.invoice_id == Invoice.id
    ).filter(
        Invoice.created_at >= start_bound,
        Invoice.created_at < end_bound,
        active_invoice_expr(),
    ).scalar() or 0
    return_cogs = db.session.query(db.func.coalesce(db.func.sum(ReturnItem.cost_amount), 0)).join(
        Return, ReturnItem.return_id == Return.id
    ).filter(
        Return.created_at >= start_bound,
        Return.created_at < end_bound,
        falsey_or_null_column_expr(Return.is_cancelled)
    ).scalar() or 0

    net_sales = sales_total - returns_total
    net_cogs = cogs - return_cogs
    gross_profit = net_sales - net_cogs
    gross_profit_percentage = (gross_profit / net_sales * 100) if net_sales else 0

    return {
        "from_date": start_date.isoformat(),
        "to_date": end_date.isoformat(),
        "sales_total": round(sales_total, 2),
        "returns_total": round(returns_total, 2),
        "net_sales": round(net_sales, 2),
        "cogs": round(cogs, 2),
        "return_cogs": round(return_cogs, 2),
        "net_cogs": round(net_cogs, 2),
        "gross_profit": round(gross_profit, 2),
        "gross_profit_percentage": round(gross_profit_percentage, 2)
    }, None

def build_medicine_report_data(from_date_raw="", to_date_raw="", medicine_query="", top_n=10):
    from_date_raw = (from_date_raw or "").strip()
    to_date_raw = (to_date_raw or "").strip()
    query_text = (medicine_query or "").strip().lower()
    top_n = to_int_safe(top_n, 10)
    if top_n < 1:
        top_n = 10
    if top_n > 100:
        top_n = 100

    errors = []
    start_date = parse_date(from_date_raw) if from_date_raw else None
    end_date = parse_date(to_date_raw) if to_date_raw else None
    if from_date_raw and not start_date:
        errors.append("Invalid from date")
    if to_date_raw and not end_date:
        errors.append("Invalid to date")

    result = {
        "medicine_summary": [],
        "fast_movers": [],
        "medicine_totals": None,
        "top_n": top_n
    }

    if start_date and end_date and end_date < start_date:
        errors.append("To date must be greater than or equal to from date")
        return result, errors

    start_bound = None
    end_bound = None
    if start_date:
        start_bound, _ = local_date_range_to_storage_bounds(start_date, start_date)
    if end_date:
        _, end_bound = local_date_range_to_storage_bounds(end_date, end_date)

    period_days = 0
    if start_date and end_date:
        period_days = (end_date - start_date).days + 1
    elif start_date and not end_date:
        period_days = (clinic_now().date() - start_date).days + 1
    elif end_date and not start_date:
        period_days = 1

    rows = {}
    med_name_by_id = {m.id: (m.name or "").strip() for m in Medicine.query.all()}

    def get_row(name):
        key = (name or "").strip().upper()
        if not key:
            return None
        if key not in rows:
            rows[key] = {
                "medicine": key,
                "purchase_qty": 0,
                "free_qty": 0,
                "inward_qty": 0,
                "sold_qty": 0,
                "return_qty": 0,
                "net_sold_qty": 0,
                "current_stock": 0,
                "inward_purchase_value": 0.0,
                "gross_sales_value": 0.0,
                "return_sales_value": 0.0,
                "sales_value": 0.0,
                "purchase_amount": 0.0,
                "return_purchase_amount": 0.0,
                "net_purchase_amount": 0.0,
                "net_profit": 0.0,
                "profit_percent": 0.0,
                "avg_daily_sale": 0.0
            }
        return rows[key]

    for med in Medicine.query.all():
        row = get_row(med.name)
        if not row:
            continue
        row["current_stock"] += to_int(med.qty)

    purchase_query = VendorPurchaseItem.query
    if start_bound:
        purchase_query = purchase_query.filter(VendorPurchaseItem.created_at >= start_bound)
    if end_bound:
        purchase_query = purchase_query.filter(VendorPurchaseItem.created_at < end_bound)
    for item in purchase_query.all():
        med_name = (item.medicine_name or med_name_by_id.get(item.medicine_id) or "").strip()
        row = get_row(med_name)
        if not row:
            continue
        qty = to_int(item.qty)
        free_qty = to_int(item.free_qty)
        row["purchase_qty"] += qty
        row["free_qty"] += free_qty
        row["inward_qty"] += qty + free_qty
        row["inward_purchase_value"] += to_float(item.total_value)

    sales_query = InvoiceItem.query.join(Invoice, InvoiceItem.invoice_id == Invoice.id).filter(active_invoice_expr())
    if start_bound:
        sales_query = sales_query.filter(Invoice.created_at >= start_bound)
    if end_bound:
        sales_query = sales_query.filter(Invoice.created_at < end_bound)
    for item in sales_query.all():
        row = get_row(item.name)
        if not row:
            continue
        row["sold_qty"] += to_int(item.qty)
        sales_value = item.net_amount if item.net_amount not in (None, 0) else item.amount
        row["gross_sales_value"] += to_float(sales_value)
        row["purchase_amount"] += to_float(item.cost_amount)

    return_query = ReturnItem.query.join(Return, ReturnItem.return_id == Return.id).filter(
        falsey_or_null_column_expr(Return.is_cancelled)
    )
    if start_bound:
        return_query = return_query.filter(Return.created_at >= start_bound)
    if end_bound:
        return_query = return_query.filter(Return.created_at < end_bound)
    for item in return_query.all():
        row = get_row(item.medicine_name)
        if not row:
            continue
        row["return_qty"] += to_int(item.qty)
        return_sales_value = item.net_amount if item.net_amount not in (None, 0) else item.amount
        row["return_sales_value"] += to_float(return_sales_value)
        row["return_purchase_amount"] += to_float(item.cost_amount)

    for row in rows.values():
        row["net_sold_qty"] = row["sold_qty"] - row["return_qty"]
        row["sales_value"] = row["gross_sales_value"] - row["return_sales_value"]
        row["net_purchase_amount"] = row["purchase_amount"] - row["return_purchase_amount"]
        row["net_profit"] = row["sales_value"] - row["net_purchase_amount"]
        row["profit_percent"] = round((row["net_profit"] / row["sales_value"] * 100), 2) if row["sales_value"] else 0.0
        if period_days > 0:
            row["avg_daily_sale"] = round(row["net_sold_qty"] / period_days, 2)
        else:
            row["avg_daily_sale"] = round(float(row["net_sold_qty"]), 2)
        row["inward_purchase_value"] = round(row["inward_purchase_value"], 2)
        row["gross_sales_value"] = round(row["gross_sales_value"], 2)
        row["return_sales_value"] = round(row["return_sales_value"], 2)
        row["purchase_amount"] = round(row["purchase_amount"], 2)
        row["return_purchase_amount"] = round(row["return_purchase_amount"], 2)
        row["net_purchase_amount"] = round(row["net_purchase_amount"], 2)
        row["sales_value"] = round(row["sales_value"], 2)
        row["net_profit"] = round(row["net_profit"], 2)

    medicine_summary = list(rows.values())
    if query_text:
        medicine_summary = [
            row for row in medicine_summary
            if query_text in (row["medicine"] or "").lower()
        ]
    medicine_summary.sort(key=lambda row: (row["medicine"] or "").lower())

    fast_movers = [row for row in medicine_summary if row["net_sold_qty"] > 0]
    fast_movers.sort(
        key=lambda row: (row["avg_daily_sale"], row["net_sold_qty"], row["sales_value"]),
        reverse=True
    )

    result["medicine_summary"] = medicine_summary
    result["fast_movers"] = fast_movers[:top_n]
    result["medicine_totals"] = {
        "count": len(medicine_summary),
        "purchase_qty": sum(row["purchase_qty"] for row in medicine_summary),
        "free_qty": sum(row["free_qty"] for row in medicine_summary),
        "inward_qty": sum(row["inward_qty"] for row in medicine_summary),
        "sold_qty": sum(row["sold_qty"] for row in medicine_summary),
        "return_qty": sum(row["return_qty"] for row in medicine_summary),
        "net_sold_qty": sum(row["net_sold_qty"] for row in medicine_summary),
        "current_stock": sum(row["current_stock"] for row in medicine_summary),
        "inward_purchase_value": round(sum(row["inward_purchase_value"] for row in medicine_summary), 2),
        "gross_sales_value": round(sum(row["gross_sales_value"] for row in medicine_summary), 2),
        "return_sales_value": round(sum(row["return_sales_value"] for row in medicine_summary), 2),
        "purchase_amount": round(sum(row["purchase_amount"] for row in medicine_summary), 2),
        "return_purchase_amount": round(sum(row["return_purchase_amount"] for row in medicine_summary), 2),
        "net_purchase_amount": round(sum(row["net_purchase_amount"] for row in medicine_summary), 2),
        "sales_value": round(sum(row["sales_value"] for row in medicine_summary), 2),
        "net_profit": round(sum(row["net_profit"] for row in medicine_summary), 2),
        "period_days": period_days
    }
    return result, errors

@app.route("/medicines/add", methods=["GET", "POST"])
@login_required
def add_medicine():
    user = active_user_by_id(session.get("user_id"))
    if not user:
        flash("Access denied", "danger")
        return redirect("/")
    if user.role != "admin" and not user.can_add_medicine:
        flash("Access denied", "danger")
        return redirect("/medicines")
    if request.method == "POST":
        schema_ok, schema_err = ensure_inventory_runtime_schema()
        if not schema_ok:
            flash("Unable to save medicine because inventory schema update failed.", "danger")
            if schema_err:
                app.logger.error("Inventory schema check failed before add medicine: %s", schema_err)
            return redirect("/medicines/add")
        name = (request.form.get("name") or "").strip()
        batch = (request.form.get("batch") or "").strip()
        expiry = (request.form.get("expiry") or "").strip()
        if not name or not batch or not expiry:
            flash("Name, batch and expiry are required", "danger")
            return redirect("/medicines/add")
        qty = to_int(request.form.get("qty"))
        pack_type = (request.form.get("pack_type") or "").strip()
        pack_qty_raw = (request.form.get("pack_qty") or "").strip()
        pack_qty = parse_pack_qty(pack_qty_raw)
        barcode = (request.form.get("barcode") or "").strip()
        reorder_level = to_int_safe(request.form.get("reorder_level"), 10)
        if reorder_level < 0:
            reorder_level = 0
        if pack_qty_raw and (pack_qty is None or pack_qty < 1):
            flash("Pack quantity must be at least 1", "danger")
            return redirect("/medicines/add")
        gst_percent = normalize_gst_percent(request.form.get("gst_percent"), default_gst_percent())
        existing_batch = find_medicine_by_name_batch(name, batch)
        if existing_batch:
            flash(
                f"{existing_batch.name} batch {existing_batch.batch} already exists. Edit that batch instead of adding a duplicate.",
                "danger",
            )
            return redirect("/medicines/add")

        med = Medicine(
            name=name,
            medicine_code="",
            batch=batch,
            mrp=to_float(request.form.get("mrp")),
            qty=qty,
            expiry=expiry,
            pack_type=pack_type,
            pack_qty=pack_qty,
            discount_percent=to_int_safe(request.form.get("discount_percent"), 0),
            barcode=barcode,
            reorder_level=reorder_level,
            is_active=True,
            gst_percent=gst_percent,
            schedule_type=normalize_schedule_type(request.form.get("schedule_type")),
        )

        med = persist_new_medicine_record(med)
        build_scoped_medicine_code_sync([name])

        history = StockHistory(
            medicine_id=med.id,
            medicine_name=med.name,
            batch=med.batch,
            action="ADD",
            stock_before=0,
            qty_change=qty,
            stock_after=qty,
            user=session.get("username"),
            remark="New medicine added"
        )

        db.session.add(history)
        db.session.commit()
        record_audit_event(
            action="Created medicine",
            entity_type="MEDICINE",
            entity_id=med.id,
            ref_code=f"{med.name} / {med.batch}",
            before=None,
            after=build_medicine_audit_snapshot(med)
        )

        flash("Medicine added successfully", "success")
        return redirect("/medicines")

    return render_template("add_medicine.html", **medicine_form_choices())

@app.route("/medicines/edit/<int:id>", methods=["GET", "POST"])
@login_required
def edit_medicine(id):
    user = active_user_by_id(session.get("user_id"))
    if not user:
        flash("Access denied", "danger")
        return redirect("/")
    if user.role != "admin" and not user.can_edit_medicine:
        flash("Access denied", "danger")
        return redirect("/medicines")
    med = Medicine.query.get_or_404(id)
    old_qty = med.qty

    if request.method == "POST":
        before_snapshot = build_medicine_audit_snapshot(med)
        name = (request.form.get("name") or "").strip()
        batch = (request.form.get("batch") or "").strip()
        expiry = (request.form.get("expiry") or "").strip()
        if not name or not batch or not expiry:
            flash("Name, batch and expiry are required", "danger")
            return redirect(request.url)
        clash = find_medicine_by_name_batch(name, batch)
        if clash and clash.id != med.id:
            flash(f"Another row already has {clash.name} batch {clash.batch}. Use Data Health > merge duplicates.", "danger")
            return redirect(request.url)
        med.gst_percent = normalize_gst_percent(request.form.get("gst_percent"), medicine_gst_percent(med))
        if "schedule_type" in request.form:
            med.schedule_type = normalize_schedule_type(request.form.get("schedule_type"))
        med.name = name
        med.batch = batch
        med.expiry = expiry
        med.mrp = to_float(request.form.get("mrp"))
        med.discount_percent = to_int(request.form.get("discount_percent"))
        med.qty = to_int(request.form.get("qty"))
        med.barcode = (request.form.get("barcode") or "").strip()
        med.reorder_level = max(0, to_int_safe(request.form.get("reorder_level"), 10))
        pack_type = (request.form.get("pack_type") or "").strip()
        pack_qty_raw = (request.form.get("pack_qty") or "").strip()
        pack_qty = parse_pack_qty(pack_qty_raw)
        if pack_qty_raw and (pack_qty is None or pack_qty < 1):
            flash("Pack quantity must be at least 1", "danger")
            return redirect(request.url)
        if pack_type:
            med.pack_type = pack_type
        if pack_qty_raw:
            med.pack_qty = pack_qty
        db.session.flush()
        build_scoped_medicine_code_sync([name])

        change = med.qty - old_qty

        if change != 0:
            history = StockHistory(
                medicine_id=med.id,
                medicine_name=med.name,
                batch=med.batch,
                action="EDIT",
                stock_before=old_qty,
                qty_change=change,
                stock_after=med.qty,
                user=session.get("username"),
                remark="Medicine edited"
            )
            db.session.add(history)

        db.session.commit()
        record_audit_event(
            action="Updated medicine",
            entity_type="MEDICINE",
            entity_id=med.id,
            ref_code=f"{med.name} / {med.batch}",
            before=before_snapshot,
            after=build_medicine_audit_snapshot(med)
        )
        flash("Medicine updated successfully", "success")
        return redirect("/medicines")

    return render_template("edit_medicine.html", med=med, **medicine_form_choices())

@app.route("/medicines/delete/<int:id>", methods=["POST"])
@login_required
def delete_medicine(id):
    user = active_user_by_id(session.get("user_id"))
    if not user:
        flash("Access denied", "danger")
        return redirect("/")
    if user.role != "admin" and not user.can_delete_medicine:
        flash("Access denied", "danger")
        return redirect("/medicines")
    med = Medicine.query.get_or_404(id)
    before_snapshot = build_medicine_audit_snapshot(med)

    # 🔴 STOCK HISTORY ENTRY (DELETE)
    history = StockHistory(
        medicine_name=med.name,
        batch=med.batch,
        action="DELETE",
        stock_before=med.qty,
        qty_change=-med.qty,
        stock_after=0,
        user=session.get("username"),
        remark="Medicine deleted from inventory"
    )
    db.session.add(history)

    # 🔴 DELETE MEDICINE
    db.session.delete(med)
    db.session.commit()
    record_audit_event(
        action="Deleted medicine",
        entity_type="MEDICINE",
        entity_id=before_snapshot.get("id") if before_snapshot else None,
        ref_code=f"{before_snapshot.get('name', '')} / {before_snapshot.get('batch', '')}" if before_snapshot else "",
        before=before_snapshot,
        after=None
    )

    flash("Medicine deleted successfully", "danger")
    return redirect("/medicines")


# ---------------- BILLING ----------------
@app.route("/billing/return-search")
@login_required
@invoice_access_required
def billing_return_search():
    query_text = (request.args.get("q") or "").strip()
    if len(query_text) < 2:
        return jsonify({"ok": True, "invoices": []})

    like = f"%{query_text}%"
    digits = normalize_patient_mobile(query_text)
    conditions = [
        Invoice.invoice_no.ilike(like),
        Invoice.customer.ilike(like),
    ]
    if digits:
        conditions.append(Invoice.mobile.ilike(f"%{digits}%"))
    else:
        conditions.append(Invoice.mobile.ilike(like))

    invoices = (
        active_invoice_query().filter(or_(*conditions))
        .order_by(Invoice.created_at.desc(), Invoice.id.desc())
        .limit(20)
        .all()
    )
    return jsonify({
        "ok": True,
        "invoices": [
            {
                "id": invoice.id,
                "invoice_no": invoice.invoice_no,
                "customer": invoice.customer,
                "mobile": invoice.mobile,
                "date": (storage_datetime_to_local(invoice.created_at) or invoice.created_at).strftime("%d-%m-%Y")
                if invoice.created_at else "",
                "total": round_currency(invoice.total),
            }
            for invoice in invoices
        ],
    })


@app.route("/billing/return-invoice/<int:invoice_id>")
@login_required
@invoice_access_required
def billing_return_invoice(invoice_id):
    invoice = Invoice.query.get_or_404(invoice_id)
    if bool(getattr(invoice, "is_cancelled", False)):
        return jsonify({"ok": False, "error": "This invoice is cancelled. Items cannot be returned."}), 400
    return jsonify({"ok": True, "invoice": build_returnable_invoice_payload(invoice)})


@app.route("/billing", methods=["GET", "POST"])
@login_required
@invoice_access_required
def billing():
    meds = Medicine.query.order_by(Medicine.name).all()
    payment_modes = POS_PAYMENT_MODES

    cart = []
    posted_hold_bill_id = to_int_safe(request.form.get("hold_bill_id"), 0) if request.method == "POST" else 0

    def redirect_to_billing_with_context():
        if posted_hold_bill_id > 0:
            return redirect(url_for("billing", hold_bill_id=posted_hold_bill_id))
        return redirect("/billing")

    if request.method == "POST":
        exchange_invoice, exchange_return_requests, exchange_error = build_exchange_return_requests(request.form)
        has_exchange_return = bool(exchange_return_requests)
        validation_error = validate_billing_submission(request.form)
        if validation_error and not has_exchange_return:
            flash(validation_error, "danger")
            return redirect_to_billing_with_context()
        if exchange_error:
            flash(exchange_error, "danger")
            return redirect_to_billing_with_context()
        requested_payment_mode = (request.form.get("payment_mode") or "CASH").strip().upper() or "CASH"
        if requested_payment_mode not in payment_modes:
            flash("Invalid payment mode selected.", "danger")
            return redirect_to_billing_with_context()
        subtotal = 0
        total_discount = 0
        total_gst_cgst = 0.0
        total_gst_sgst = 0.0
        scheduled_items = []

        meds_list = request.form.getlist("medicine_name")
        batch_overrides = request.form.getlist("batch_override[]")
        if not batch_overrides:
            batch_overrides = request.form.getlist("batch_override")
        qty_list = request.form.getlist("qty")
        if not qty_list:
            qty_list = request.form.getlist("qty[]")

        for idx, (name, qty) in enumerate(zip(meds_list, qty_list)):
            name = (name or "").strip().upper()
            if not name:
                continue
            qty = to_int_safe(qty, 0)
            if qty <= 0:
                continue
            batch_override = (batch_overrides[idx] or "").strip() if idx < len(batch_overrides) else ""
            allocations = []

            if batch_override:
                med = Medicine.query.filter_by(name=name, batch=batch_override).first()
                if not med:
                    db.session.rollback()
                    flash(f"Batch not found for {name}", "danger")
                    return redirect_to_billing_with_context()
                exp_dt = parse_expiry_date(med.expiry)
                if exp_dt and exp_dt < date.today():
                    db.session.rollback()
                    flash(f"Batch {med.batch} of {med.name} is expired", "danger")
                    return redirect_to_billing_with_context()
                if qty > med.qty:
                    db.session.rollback()
                    flash(f"Not enough stock for {med.name} ({med.batch})", "danger")
                    return redirect_to_billing_with_context()
                allocations.append((med, qty))
            else:
                candidates = get_batch_candidates(name)
                total_available = sum(m.qty for m in candidates)
                if total_available <= 0:
                    db.session.rollback()
                    flash(f"No stock available for {name}", "danger")
                    return redirect_to_billing_with_context()
                if qty > total_available:
                    db.session.rollback()
                    flash(f"Not enough stock for {name}. Available: {total_available}", "danger")
                    return redirect_to_billing_with_context()
                remaining = qty
                for med in candidates:
                    take = min(med.qty, remaining)
                    if take <= 0:
                        continue
                    allocations.append((med, take))
                    remaining -= take
                    if remaining == 0:
                        break

            for med, take_qty in allocations:
                # Lock the stock row and re-check: two counters billing the
                # last strips at the same time must not push stock below zero.
                med = lock_medicine_for_update(med)
                if med is None or to_int_safe(med.qty, 0) < take_qty:
                    db.session.rollback()
                    flash(
                        f"Stock for {name} changed while billing (another counter sold it). Please re-check the quantity.",
                        "danger",
                    )
                    return redirect_to_billing_with_context()
                if normalize_schedule_type(getattr(med, "schedule_type", "")) in ("H1", "X"):
                    scheduled_items.append(med.name)
                discp = med.discount_percent or 0
                amount = take_qty * med.mrp
                disc_amt = amount * discp / 100
                net_amt = amount - disc_amt
                subtotal += net_amt
                total_discount += disc_amt
                line_gst = split_inclusive_gst(net_amt, medicine_gst_percent(med))
                total_gst_cgst += line_gst["cgst"]
                total_gst_sgst += line_gst["sgst"]

                old_stock = med.qty
                med.qty -= take_qty

                history = StockHistory(
                    medicine_id=med.id,
                    medicine_name=med.name,
                    batch=med.batch,
                    action="SALE",
                    stock_before=old_stock,
                    qty_change=-take_qty,
                    stock_after=med.qty,
                    user=session.get("username"),
                    remark="Invoice sale"
                )
                db.session.add(history)

                fifo_alloc = fifo_consume(med, take_qty)
                cost_amount = sum(a["qty"] * a["cost_rate"] for a in fifo_alloc)
                cost_price = round(cost_amount / take_qty, 4) if take_qty else 0

                cart.append({
                    "name": med.name,
                    "qty": take_qty,
                    "price": med.mrp,
                    "amount": amount,
                    "batch": med.batch,
                    "expiry": med.expiry,
                    "discount_percent": discp,
                    "discount_amount": disc_amt,
                    "net_amount": net_amt,
                    "cost_price": cost_price,
                    "cost_amount": cost_amount,
                    "gst_percent": line_gst["gst_percent"],
                    "taxable_amount": line_gst["taxable_amount"],
                    "gst_amount": line_gst["gst_amount"],
                    "allocations": fifo_alloc
                })

        if not cart and not exchange_return_requests:
            flash("Please add at least one sale item or one return adjustment item.", "danger")
            db.session.rollback()
            return redirect_to_billing_with_context()

        if scheduled_items and not (request.form.get("doctor") or "").strip():
            db.session.rollback()
            names = ", ".join(sorted(set(scheduled_items)))
            flash(
                f"Doctor name is required for Schedule H1/X medicines ({names}). Please enter the prescribing doctor.",
                "danger",
            )
            return redirect_to_billing_with_context()

        cgst = round_currency(total_gst_cgst)
        sgst = round_currency(total_gst_sgst)
        total = round(subtotal, 2)
        rounded_total = compute_invoice_rounded_total(total)
        return_credit_total = round_currency(sum(row["amounts"]["net_amount"] for row in exchange_return_requests))
        final_payable = round_currency(rounded_total - return_credit_total)
        collectable_amount = max(final_payable, 0.0)
        return_credit_used = min(return_credit_total, rounded_total)
        exchange_refund_amount = max(round_currency(return_credit_total - rounded_total), 0.0)
        effective_payment_mode = (
            "ADJUSTMENT"
            if return_credit_total > 0 and collectable_amount <= 0
            else requested_payment_mode
        )
        payment_breakdown, payment_error = calculate_invoice_payment_breakdown(
            payment_mode=effective_payment_mode,
            rounded_amount=collectable_amount,
            split_cash_amount_raw=request.form.get("split_cash_amount"),
        )
        if payment_error:
            db.session.rollback()
            flash(payment_error, "danger")
            return redirect_to_billing_with_context()

        customer = (request.form.get("customer") or "").strip()
        mobile = (request.form.get("mobile") or "").strip()
        internal_note = (request.form.get("internal_note") or "").strip()
        invoice_created_at = datetime.utcnow()
        invoice_print_date = clinic_now().date()
        patient, normalized_mobile = upsert_patient_from_invoice(customer, mobile, request.form.get("gender", ""))
        if patient and not patient.id:
            db.session.flush()
        inv = None
        ret = None
        try:
            if cart:
                inv = Invoice(
                    invoice_no=None,
                    patient_id=patient.id if patient else None,
                    customer=customer,
                    mobile=normalized_mobile or mobile,
                    doctor=request.form.get("doctor", ""),
                    gender=request.form.get("gender", ""),
                    subtotal=subtotal,
                    discount=total_discount,
                    cgst=cgst,
                    sgst=sgst,
                    total=total,
                    payment_mode=payment_breakdown["payment_mode"],
                    cash_amount=payment_breakdown["cash_amount"],
                    online_amount=payment_breakdown["online_amount"],
                    is_split_payment=payment_breakdown["is_split_payment"],
                    return_credit_used=return_credit_used,
                    final_payable=collectable_amount,
                    refund_amount=exchange_refund_amount,
                    internal_note=internal_note,
                    created_by=session.get("username"),
                    created_at=invoice_created_at,
                )
                apply_invoice_print_profile(inv, invoice_print_date)

                db.session.add(inv)
                db.session.flush()
                assign_invoice_number(inv, invoice_print_date)

                for item in cart:
                    inv_item = InvoiceItem(
                        invoice_id=inv.id,
                        name=item["name"],
                        qty=item["qty"],
                        price=item["price"],
                        amount=item["amount"],
                        batch=item["batch"],
                        expiry=item["expiry"],
                        discount_percent=item["discount_percent"],
                        discount_amount=item["discount_amount"],
                        net_amount=item["net_amount"],
                        cost_price=item["cost_price"],
                        cost_amount=item["cost_amount"],
                        gst_percent=item["gst_percent"],
                        taxable_amount=item["taxable_amount"],
                        gst_amount=item["gst_amount"],
                    )
                    db.session.add(inv_item)
                    db.session.flush()
                    for alloc in item["allocations"]:
                        db.session.add(SalesAllocation(
                            invoice_item_id=inv_item.id,
                            purchase_item_id=alloc["purchase_item"].id if alloc["purchase_item"] else None,
                            qty=alloc["qty"],
                            cost_rate=alloc["cost_rate"],
                            returned_qty=0
                        ))

            if exchange_return_requests:
                ret = Return(
                    invoice_id=exchange_invoice.id,
                    invoice_no=exchange_invoice.invoice_no,
                    customer=exchange_invoice.customer or customer,
                    mobile=exchange_invoice.mobile or normalized_mobile or mobile,
                    total_refund=return_credit_total,
                    cgst=round_currency(sum(row["amounts"]["cgst"] for row in exchange_return_requests)),
                    sgst=round_currency(sum(row["amounts"]["sgst"] for row in exchange_return_requests)),
                    payment_mode="ADJUSTMENT",
                    adjusted_invoice_id=inv.id if inv else None,
                    adjusted_amount=return_credit_used,
                    refund_amount=exchange_refund_amount,
                    cash_refund_amount=0,
                    online_refund_amount=0,
                    is_split_refund=False,
                    created_by=session.get("username"),
                    created_at=invoice_created_at,
                )
                db.session.add(ret)
                db.session.flush()
                assign_return_number(ret)

                for row in exchange_return_requests:
                    item = row["item"]
                    qty = row["qty"]
                    med = row["medicine"]
                    disposition = normalize_return_disposition(row.get("disposition"))
                    if not med:
                        med = Medicine(
                            name=item.name,
                            batch=item.batch,
                            expiry=item.expiry,
                            mrp=item.price or 0,
                            qty=0,
                            discount_percent=int(item.discount_percent or 0),
                            gst_percent=normalize_gst_percent(row["amounts"].get("gst_percent"), default_gst_percent()),
                        )
                        med = persist_new_medicine_record(med)

                    amounts = row["amounts"]
                    fallback_rate = item.cost_price or item.price or 0
                    cost_total, lot_allocations = apply_return_line_stock(
                        ret=ret,
                        med=med,
                        qty=qty,
                        disposition=disposition,
                        invoice_item_id=item.id,
                        fallback_rate=fallback_rate,
                        actor=session.get("username"),
                        remark=f"Exchange Return {ret.return_no} (Inv {exchange_invoice.invoice_no})",
                    )
                    cost_price = round(cost_total / qty, 4) if qty else 0

                    exchange_return_item = ReturnItem(
                        return_id=ret.id,
                        invoice_item_id=item.id,
                        medicine_id=med.id,
                        medicine_name=item.name,
                        batch=item.batch,
                        expiry=item.expiry,
                        qty=qty,
                        price=item.price,
                        amount=amounts["amount"],
                        purchase_rate=0,
                        selling_rate=item.price or 0,
                        gst_percent=amounts["gst_percent"],
                        reason=row["reason"],
                        discount_percent=amounts["discount_percent"],
                        discount_amount=amounts["discount_amount"],
                        net_amount=amounts["net_amount"],
                        cost_price=cost_price,
                        cost_amount=cost_total,
                        disposition=disposition,
                    )
                    db.session.add(exchange_return_item)
                    db.session.flush()
                    record_return_line_followups(
                        ret=ret,
                        return_item=exchange_return_item,
                        med=med,
                        disposition=disposition,
                        lot_allocations=lot_allocations,
                        cost_price=cost_price,
                        actor=session.get("username"),
                    )

            if posted_hold_bill_id > 0:
                held_bill = find_pending_bill_record(posted_hold_bill_id)
                if held_bill:
                    held_bill.is_deleted = True
                    held_bill.deleted_at = datetime.utcnow()
                    held_bill.deleted_by = session.get("username")

            db.session.commit()
        except Exception:
            db.session.rollback()
            app.logger.exception("Exchange billing transaction failed")
            flash("Billing transaction failed. No stock or invoice changes were saved.", "danger")
            return redirect_to_billing_with_context()

        if inv:
            record_audit_event(
                action="Created invoice",
                entity_type="INVOICE",
                entity_id=inv.id,
                ref_code=inv.invoice_no,
                before=None,
                after=build_invoice_audit_snapshot(inv),
                extra={
                    "item_count": len(cart),
                    "payment_mode": inv.payment_mode,
                    "cash_amount": payment_breakdown["cash_amount"],
                    "online_amount": payment_breakdown["online_amount"],
                    "is_split_payment": payment_breakdown["is_split_payment"],
                    "return_credit_used": return_credit_used,
                    "exchange_return_id": ret.id if ret else None,
                }
            )
        if ret:
            record_audit_event(
                action="Created exchange return bill" if inv else "Created return bill",
                entity_type="RETURN_BILL",
                entity_id=ret.id,
                ref_code=ret.return_no,
                before=None,
                after=build_return_audit_snapshot(ret),
                extra={
                    "original_invoice_id": exchange_invoice.id,
                    "adjusted_invoice_id": inv.id if inv else None,
                    "adjusted_amount": return_credit_used,
                    "refund_amount": exchange_refund_amount,
                    "item_count": len(exchange_return_requests),
                },
            )

        if not inv and ret:
            flash("Return credit note generated. Stock updated.", "success")
            return redirect(f"/return-invoice/{ret.id}")

        return render_template(
            "invoice.html",
            inv=inv,
            auto_print=request.form.get("auto_print") == "1",
            print_profile=resolve_invoice_print_profile(inv),
            payment_breakdown=payment_breakdown,
            cart=cart,
            exchange_return_bill=ret,
            exchange_return_items=exchange_return_requests,
            return_credit_total=return_credit_total,
            return_credit_used=return_credit_used,
            exchange_refund_amount=exchange_refund_amount,
            final_payable=collectable_amount,
            customer=inv.customer,
            mobile=inv.mobile,
            doctor=inv.doctor,
            gender=inv.gender,
            invoice_no=inv.invoice_no,
            subtotal=subtotal,
            discount=total_discount,
            cgst=cgst,
            sgst=sgst,
            total=total,
            rounded_total=rounded_total,
            date=(storage_datetime_to_local(inv.created_at) or clinic_now()).strftime("%d-%m-%Y"),
            bill_time=(storage_datetime_to_local(inv.created_at) or clinic_now()).strftime("%I:%M %p")
        )

    restored_hold_bill = None
    restore_hold_bill_id = to_int_safe(request.args.get("hold_bill_id"), 0)
    if restore_hold_bill_id > 0:
        hold_bill = find_pending_bill_record(restore_hold_bill_id, sync_if_missing=True)
        if hold_bill:
            restored_hold_bill = normalize_hold_bill_data(hold_bill)
        else:
            flash("Held bill not found. It may have been deleted.", "warning")

    doctor_counts = db.session.query(Invoice.doctor, db.func.count(Invoice.id)).group_by(Invoice.doctor).all()
    return render_template(
        "billing.html",
        payment_modes=payment_modes,
        doctor_suggestions=doctor_name_suggestions(doctor_counts),
        **prepare_billing_context(meds, restored_hold_bill)
    )


# ---------------- LAB TEST MASTER & BILLING ----------------
@app.route("/lab-tests")
@login_required
@lab_catalog_access_required
def lab_tests():
    search_query = (request.args.get("q") or "").strip()
    query = LabTest.query
    if search_query:
        like = f"%{search_query}%"
        query = query.filter(or_(
            LabTest.test_code.ilike(like),
            LabTest.name.ilike(like),
            LabTest.category.ilike(like),
            LabTest.specimen_type.ilike(like),
        ))
    tests = query.order_by(LabTest.is_active.desc(), LabTest.name.asc(), LabTest.test_code.asc()).all()
    return render_template("lab_tests.html", tests=tests, search_query=search_query)


def validate_lab_test_master_form(form_data, *, existing_test=None):
    test_code = normalize_lab_test_code(form_data.get("test_code"))
    name = (form_data.get("name") or "").strip()
    category = (form_data.get("category") or "").strip()
    if "specimen_type" in form_data:
        specimen_type = (form_data.get("specimen_type") or "").strip()
    else:
        # Editing the simplified form must not erase specimen information
        # already stored for legacy catalog rows.
        specimen_type = ((existing_test.specimen_type if existing_test else "") or "").strip()
    preparation = (form_data.get("preparation") or "").strip()
    default_price, price_error = parse_optional_money(form_data.get("default_price"))
    aliases = [
        item.strip() for item in (form_data.get("aliases") or "").split(",") if item.strip()
    ][:20]
    fasting_required = "fasting_required" in form_data
    turnaround_text = (form_data.get("turnaround_text") or "").strip()[:120]

    if not test_code:
        test_code = normalize_lab_test_code(
            existing_test.test_code if existing_test else generate_internal_lab_test_code()
        )
    if not test_code:
        return None, "Unable to allocate an internal test code. Please try again."
    if not name:
        return None, "Test name is required."
    if default_price is None or price_error:
        return None, price_error or "A valid test price is required."
    if default_price > 1000000:
        return None, "Test price is too high. Please review it."
    return {
        "test_code": test_code,
        "name": name,
        "category": category,
        "specimen_type": specimen_type,
        "preparation": preparation,
        "default_price": default_price,
        "aliases_json": json.dumps(aliases, separators=(",", ":")),
        "fasting_required": fasting_required,
        "turnaround_text": turnaround_text or None,
    }, None


@app.route("/lab-tests/add", methods=["GET", "POST"])
@login_required
@lab_catalog_access_required
def add_lab_test():
    if request.method == "POST":
        payload, error = validate_lab_test_master_form(request.form)
        if error:
            flash(error, "danger")
            return render_template(
                "lab_test_form.html",
                test=None,
                form_title="Add Lab Test",
                submit_label="Save Lab Test",
            ), 400

        duplicate = LabTest.query.filter_by(test_code=payload["test_code"]).first()
        if duplicate:
            flash("This test code already exists. Use a unique code.", "danger")
            return render_template(
                "lab_test_form.html",
                test=None,
                form_title="Add Lab Test",
                submit_label="Save Lab Test",
            ), 400

        lab_test = LabTest(
            **payload,
            is_active=True,
            created_by=session.get("username"),
            updated_by=session.get("username"),
        )
        try:
            db.session.add(lab_test)
            db.session.commit()
        except IntegrityError:
            db.session.rollback()
            flash("This test code already exists. Use a unique code.", "danger")
            return render_template(
                "lab_test_form.html",
                test=None,
                form_title="Add Lab Test",
                submit_label="Save Lab Test",
            ), 400
        except Exception:
            db.session.rollback()
            app.logger.exception("Unable to create lab test")
            flash("Unable to save the lab test. Please try again.", "danger")
            return render_template(
                "lab_test_form.html",
                test=None,
                form_title="Add Lab Test",
                submit_label="Save Lab Test",
            ), 500

        record_audit_event(
            action="Created lab test",
            entity_type="LAB_TEST",
            entity_id=lab_test.id,
            ref_code=lab_test.test_code,
            before=None,
            after=build_lab_test_audit_snapshot(lab_test),
        )
        flash("Lab test added to the price master.", "success")
        return redirect("/lab-tests")

    return render_template(
        "lab_test_form.html",
        test=None,
        form_title="Add Lab Test",
        submit_label="Save Lab Test",
    )


@app.route("/lab-tests/<int:id>/edit", methods=["GET", "POST"])
@login_required
@lab_catalog_access_required
def edit_lab_test(id):
    lab_test = LabTest.query.get_or_404(id)

    def _aliases_display(existing_test):
        try:
            values = json.loads(existing_test.aliases_json or "[]")
        except (TypeError, ValueError):
            values = []
        return ", ".join(str(item).strip() for item in values if str(item).strip()) if isinstance(values, list) else ""

    if request.method == "POST":
        before_snapshot = build_lab_test_audit_snapshot(lab_test)
        payload, error = validate_lab_test_master_form(request.form, existing_test=lab_test)
        if error:
            flash(error, "danger")
            return render_template(
                "lab_test_form.html",
                test=lab_test,
                form_title="Edit Lab Test",
                submit_label="Save Changes",
                test_aliases_display=(request.form.get("aliases") or _aliases_display(lab_test)),
            ), 400

        duplicate = LabTest.query.filter(
            LabTest.test_code == payload["test_code"],
            LabTest.id != lab_test.id,
        ).first()
        if duplicate:
            flash("This test code already exists. Use a unique code.", "danger")
            return render_template(
                "lab_test_form.html",
                test=lab_test,
                form_title="Edit Lab Test",
                submit_label="Save Changes",
                test_aliases_display=(request.form.get("aliases") or _aliases_display(lab_test)),
            ), 400

        for field_name, field_value in payload.items():
            setattr(lab_test, field_name, field_value)
        lab_test.updated_by = session.get("username")
        if "is_active" in request.form:
            lab_test.is_active = bool(request.form.get("is_active"))
        try:
            db.session.commit()
        except IntegrityError:
            db.session.rollback()
            flash("This test code already exists. Use a unique code.", "danger")
            return render_template(
                "lab_test_form.html",
                test=lab_test,
                form_title="Edit Lab Test",
                submit_label="Save Changes",
                test_aliases_display=_aliases_display(lab_test),
            ), 400
        except Exception:
            db.session.rollback()
            app.logger.exception("Unable to update lab test %s", id)
            flash("Unable to update the lab test. Please try again.", "danger")
            return render_template(
                "lab_test_form.html",
                test=lab_test,
                form_title="Edit Lab Test",
                submit_label="Save Changes",
                test_aliases_display=_aliases_display(lab_test),
            ), 500

        record_audit_event(
            action="Updated lab test",
            entity_type="LAB_TEST",
            entity_id=lab_test.id,
            ref_code=lab_test.test_code,
            before=before_snapshot,
            after=build_lab_test_audit_snapshot(lab_test),
        )
        flash("Lab test updated. New price applies only to new lab orders.", "success")
        return redirect("/lab-tests")

    return render_template(
        "lab_test_form.html",
        test=lab_test,
        form_title="Edit Lab Test",
        submit_label="Save Changes",
        test_aliases_display=_aliases_display(lab_test),
    )


@app.route("/lab-tests/<int:id>/deactivate", methods=["POST"])
@login_required
@lab_catalog_access_required
def deactivate_lab_test(id):
    lab_test = LabTest.query.get_or_404(id)
    before_snapshot = build_lab_test_audit_snapshot(lab_test)
    lab_test.is_active = False
    lab_test.updated_by = session.get("username")
    try:
        db.session.commit()
    except Exception:
        db.session.rollback()
        app.logger.exception("Unable to deactivate lab test %s", id)
        flash("Unable to deactivate the lab test. Please try again.", "danger")
        return redirect("/lab-tests")

    record_audit_event(
        action="Deactivated lab test",
        entity_type="LAB_TEST",
        entity_id=lab_test.id,
        ref_code=lab_test.test_code,
        before=before_snapshot,
        after=build_lab_test_audit_snapshot(lab_test),
    )
    flash("Lab test deactivated. Historical lab orders are unchanged.", "info")
    return redirect("/lab-tests")


@app.route("/lab-billing", methods=["GET", "POST"])
@login_required
@invoice_access_required
def lab_billing():
    active_lab_tests = LabTest.query.filter(LabTest.is_active.is_(True)).order_by(
        LabTest.name.asc(), LabTest.test_code.asc()
    ).all()

    if request.method == "POST":
        patient_name = (request.form.get("customer") or "").strip()
        mobile = (request.form.get("mobile") or "").strip()
        gender = (request.form.get("gender") or "").strip().upper()
        doctor = (request.form.get("doctor") or "").strip()
        internal_note = (request.form.get("internal_note") or "").strip()
        payment_mode = normalize_payment_mode(request.form.get("payment_mode") or "CASH")

        if not patient_name:
            flash("Patient name is required for a lab order.", "danger")
            return redirect("/lab-billing")
        if payment_mode not in POS_PAYMENT_MODES:
            flash("Invalid payment mode selected.", "danger")
            return redirect("/lab-billing")

        line_items, line_error = build_lab_order_line_items(request.form)
        if line_error:
            flash(line_error, "danger")
            return redirect("/lab-billing")

        subtotal = round(sum(item["amount"] for item in line_items), 2)
        rounded_total = compute_invoice_rounded_total(subtotal)
        payment_breakdown, payment_error = calculate_invoice_payment_breakdown(
            payment_mode=payment_mode,
            rounded_amount=rounded_total,
            split_cash_amount_raw=request.form.get("split_cash_amount"),
        )
        if payment_error:
            flash(payment_error, "danger")
            return redirect("/lab-billing")

        patient, normalized_mobile = upsert_patient_from_invoice(patient_name, mobile, gender)
        try:
            if patient and not patient.id:
                db.session.flush()

            order = LabOrder(
                order_no=None,
                patient_id=patient.id if patient else None,
                patient_name=patient_name,
                mobile=normalized_mobile or mobile,
                gender=gender,
                doctor=doctor,
                subtotal=subtotal,
                discount=0,
                total=subtotal,
                payment_mode=payment_breakdown["payment_mode"],
                cash_amount=payment_breakdown["cash_amount"],
                online_amount=payment_breakdown["online_amount"],
                is_split_payment=payment_breakdown["is_split_payment"],
                internal_note=internal_note,
                status="ORDERED",
                created_by=session.get("username"),
                created_at=datetime.utcnow(),
            )
            db.session.add(order)
            db.session.flush()
            assign_lab_order_number(order)

            for line in line_items:
                lab_test = line["lab_test"]
                db.session.add(LabOrderItem(
                    lab_order_id=order.id,
                    lab_test_id=lab_test.id,
                    test_code=lab_test.test_code,
                    test_name=lab_test.name,
                    category=lab_test.category,
                    specimen_type=lab_test.specimen_type,
                    preparation=lab_test.preparation,
                    qty=line["qty"],
                    unit_price=line["unit_price"],
                    amount=line["amount"],
                    discount_percent=0,
                    discount_amount=0,
                    net_amount=line["amount"],
                ))
            db.session.commit()
        except Exception:
            db.session.rollback()
            app.logger.exception("Unable to create lab order")
            flash("Unable to create the lab order. No bill was saved.", "danger")
            return redirect("/lab-billing")

        record_audit_event(
            action="Created lab order",
            entity_type="LAB_ORDER",
            entity_id=order.id,
            ref_code=order.order_no,
            before=None,
            after=build_lab_order_audit_snapshot(order),
            extra={"test_count": len(line_items), "payment_mode": order.payment_mode},
        )
        flash("Lab order created successfully.", "success")
        return redirect(url_for("view_lab_order", id=order.id))

    return render_template(
        "lab_billing.html",
        lab_tests=active_lab_tests,
        payment_modes=POS_PAYMENT_MODES,
    )


@app.route("/lab-orders")
@login_required
@invoice_access_required
def lab_orders():
    search_query = (request.args.get("q") or request.args.get("search") or "").strip()
    status_filter = (request.args.get("status") or "").strip().upper()
    query = LabOrder.query
    if search_query:
        like = f"%{search_query}%"
        query = query.filter(or_(
            LabOrder.order_no.ilike(like),
            LabOrder.patient_name.ilike(like),
            LabOrder.mobile.ilike(like),
            LabOrder.doctor.ilike(like),
        ))
    if status_filter:
        query = query.filter(LabOrder.status == status_filter)
    orders = query.order_by(LabOrder.created_at.desc(), LabOrder.id.desc()).limit(300).all()
    if orders:
        order_ids = [order.id for order in orders]
        item_counts = dict(
            db.session.query(LabOrderItem.lab_order_id, db.func.count(LabOrderItem.id))
            .filter(LabOrderItem.lab_order_id.in_(order_ids))
            .group_by(LabOrderItem.lab_order_id)
            .all()
        )
        for order in orders:
            order.item_count = item_counts.get(order.id, 0)
    return render_template(
        "lab_orders.html",
        orders=orders,
        search_query=search_query,
        status_filter=status_filter,
    )


@app.route("/lab-order/<int:id>")
@login_required
@invoice_access_required
def view_lab_order(id):
    order = LabOrder.query.get_or_404(id)
    items = LabOrderItem.query.filter_by(lab_order_id=order.id).order_by(LabOrderItem.id.asc()).all()
    reports = LabReport.query.filter_by(lab_order_id=order.id).order_by(
        LabReport.uploaded_at.desc(), LabReport.id.desc()
    ).all()
    rounded_total = compute_invoice_rounded_total(order.total or order.subtotal)
    payment_breakdown = build_invoice_payment_breakdown(order, rounded_total)
    local_created_at = storage_datetime_to_local(order.created_at) or order.created_at or clinic_now()
    return render_template(
        "lab_order.html",
        order=order,
        items=items,
        reports=reports,
        payment_breakdown=payment_breakdown,
        rounded_total=rounded_total,
        date=local_created_at.strftime("%d-%m-%Y"),
        bill_time=local_created_at.strftime("%I:%M %p"),
    )


@app.route("/lab-order/<int:id>/reports/upload", methods=["GET", "POST"])
@login_required
@invoice_access_required
def lab_report_upload(id):
    """Staff-only upload for a finalized report; files never enter /static."""
    order = LabOrder.query.get_or_404(id)

    def render_upload_page(status_code=200):
        reports = LabReport.query.filter_by(lab_order_id=order.id).order_by(
            LabReport.uploaded_at.desc(), LabReport.id.desc()
        ).all()
        return render_template(
            "lab_report_upload.html",
            order=order,
            reports=reports,
        ), status_code

    if request.method == "GET":
        return render_upload_page()

    title = (request.form.get("report_title") or "").strip()
    raw_report_date = (request.form.get("report_date") or "").strip()
    patient_note = (request.form.get("patient_note") or "").strip()
    report_file = request.files.get("report_file")
    report_mobile = normalize_public_report_mobile(order.mobile)

    if not report_mobile:
        flash(
            "Add a valid 10-digit mobile number to this lab order before publishing a patient report.",
            "danger",
        )
        return render_upload_page(400)
    if not title:
        flash("Report title is required.", "danger")
        return render_upload_page(400)
    if len(title) > 180:
        flash("Report title must be 180 characters or fewer.", "danger")
        return render_upload_page(400)
    if len(patient_note) > 500:
        flash("Patient note must be 500 characters or fewer.", "danger")
        return render_upload_page(400)

    report_date = parse_date(raw_report_date) if raw_report_date else clinic_now().date()
    if raw_report_date and not report_date:
        flash("Please enter a valid report date.", "danger")
        return render_upload_page(400)

    saved_file = None
    try:
        saved_file = save_private_lab_report_file(report_file, order.id)
        now = datetime.utcnow()
        report = LabReport(
            lab_order_id=order.id,
            patient_id=order.patient_id,
            patient_name=(order.patient_name or "").strip() or "Patient",
            mobile=report_mobile,
            title=title,
            report_date=report_date,
            patient_note=patient_note or None,
            storage_key=saved_file["storage_key"],
            original_filename=saved_file["original_filename"],
            mime_type=saved_file["mime_type"],
            file_size=saved_file["file_size"],
            file_sha256=saved_file["file_sha256"],
            status="PUBLISHED",
            uploaded_by=session.get("username"),
            uploaded_at=now,
            published_by=session.get("username"),
            published_at=now,
        )
        db.session.add(report)
        db.session.commit()
    except ValueError as exc:
        db.session.rollback()
        flash(str(exc), "danger")
        return render_upload_page(400)
    except Exception:
        db.session.rollback()
        if saved_file:
            delete_private_lab_report_file(saved_file.get("storage_key"))
        app.logger.exception("Unable to upload lab report for order %s", order.id)
        flash("Unable to upload the report. Please try again.", "danger")
        return render_upload_page(500)

    record_audit_event(
        action="Published lab report",
        entity_type="LAB_REPORT",
        entity_id=report.id,
        ref_code=order.order_no,
        before=None,
        after=build_lab_report_audit_snapshot(report),
        extra={"lab_order_id": order.id},
    )
    flash("Lab report uploaded and published for secure patient access.", "success")
    return redirect(url_for("view_lab_order", id=order.id))


@app.route("/lab-reports/<int:report_id>/file")
@login_required
@invoice_access_required
def staff_download_lab_report(report_id):
    report = LabReport.query.get_or_404(report_id)
    storage_key, file_path = private_lab_report_path(report.storage_key)
    if not storage_key or not os.path.isfile(file_path):
        abort(404)
    report_dir = os.path.dirname(file_path)

    record_audit_event(
        action="Downloaded lab report (staff)",
        entity_type="LAB_REPORT",
        entity_id=report.id,
        ref_code=str(report.lab_order_id),
        after=build_lab_report_audit_snapshot(report),
    )
    response = send_from_directory(
        report_dir,
        storage_key,
        as_attachment=True,
        download_name=lab_report_download_name(report),
    )
    response.headers["Cache-Control"] = "private, no-store, max-age=0"
    return response


@app.route("/lab-reports/<int:report_id>/publish", methods=["POST"])
@login_required
@invoice_access_required
def publish_lab_report(report_id):
    report = LabReport.query.get_or_404(report_id)
    if (report.status or "").upper() == "PUBLISHED":
        flash("This lab report is already published.", "info")
        return redirect(url_for("lab_report_upload", id=report.lab_order_id))
    if (report.status or "").upper() == "REVOKED":
        flash("A revoked report cannot be republished. Upload the corrected final report instead.", "warning")
        return redirect(url_for("lab_report_upload", id=report.lab_order_id))

    storage_key, file_path = private_lab_report_path(report.storage_key)
    if not storage_key or not os.path.isfile(file_path):
        flash("The private PDF file is unavailable, so this report cannot be published.", "danger")
        return redirect(url_for("lab_report_upload", id=report.lab_order_id))

    before_snapshot = build_lab_report_audit_snapshot(report)
    report.status = "PUBLISHED"
    report.published_by = session.get("username")
    report.published_at = datetime.utcnow()
    report.revoked_by = None
    report.revoked_at = None
    report.revoke_reason = None
    try:
        db.session.commit()
    except Exception:
        db.session.rollback()
        app.logger.exception("Unable to publish lab report %s", report.id)
        flash("Unable to publish the lab report. Please try again.", "danger")
        return redirect(url_for("lab_report_upload", id=report.lab_order_id))

    record_audit_event(
        action="Published lab report",
        entity_type="LAB_REPORT",
        entity_id=report.id,
        ref_code=str(report.lab_order_id),
        before=before_snapshot,
        after=build_lab_report_audit_snapshot(report),
    )
    flash("Lab report published for secure patient access.", "success")
    return redirect(url_for("lab_report_upload", id=report.lab_order_id))


@app.route("/lab-reports/<int:report_id>/revoke", methods=["POST"])
@login_required
@invoice_access_required
def revoke_lab_report(report_id):
    report = LabReport.query.get_or_404(report_id)
    if (report.status or "").upper() == "REVOKED":
        flash("This lab report is already revoked.", "info")
        return redirect(url_for("lab_report_upload", id=report.lab_order_id))

    revoke_reason = (request.form.get("revoke_reason") or "").strip()
    if len(revoke_reason) > 500:
        flash("Revoke reason must be 500 characters or fewer.", "danger")
        return redirect(url_for("lab_report_upload", id=report.lab_order_id))

    before_snapshot = build_lab_report_audit_snapshot(report)
    report.status = "REVOKED"
    report.revoked_by = session.get("username")
    report.revoked_at = datetime.utcnow()
    report.revoke_reason = revoke_reason or "Revoked by laboratory staff"
    try:
        db.session.commit()
    except Exception:
        db.session.rollback()
        app.logger.exception("Unable to revoke lab report %s", report.id)
        flash("Unable to revoke the lab report. Please try again.", "danger")
        return redirect(url_for("lab_report_upload", id=report.lab_order_id))

    record_audit_event(
        action="Revoked lab report",
        entity_type="LAB_REPORT",
        entity_id=report.id,
        ref_code=str(report.lab_order_id),
        before=before_snapshot,
        after=build_lab_report_audit_snapshot(report),
    )
    flash("Lab report access has been revoked. The PDF remains in private storage for audit purposes.", "success")
    return redirect(url_for("lab_report_upload", id=report.lab_order_id))


@app.route("/my-lab-reports")
def patient_report_portal():
    """Entry point for the public, OTP-protected report portal."""
    resolve_public_portal_tenant_id()
    session.pop("pending_lab_report_mobile", None)
    session.pop("lab_report_portal", None)
    session.modified = True
    return render_template("patient_report_portal.html")


@app.route("/my-lab-reports/send-otp", methods=["POST"])
def send_patient_report_otp():
    portal_tenant_id = resolve_public_portal_tenant_id()
    if not portal_tenant_id:
        flash("Please open the report link for your pharmacy before requesting an OTP.", "warning")
        return redirect(url_for("patient_report_portal"))
    mobile = normalize_public_report_mobile(request.form.get("mobile"))
    session.pop("pending_lab_report_mobile", None)
    session.pop("lab_report_portal", None)
    session.modified = True
    if not mobile:
        flash("Please enter the registered 10-digit mobile number.", "danger")
        return redirect(url_for("patient_report_portal"))

    # Limit one IP from using this endpoint to send bulk OTP messages.  Per-mobile
    # resend and expiry limits are also enforced by create_portal_otp_challenge.
    recent_window = datetime.utcnow() - timedelta(minutes=PUBLIC_PORTAL_OTP_WINDOW_MINUTES)
    with tenant_context(portal_tenant_id):
        recent_ip_requests = PortalOtpChallenge.query.filter(
            PortalOtpChallenge.purpose == "LAB_REPORTS",
            PortalOtpChallenge.request_ip == portal_request_ip(),
            PortalOtpChallenge.sent_at >= recent_window,
        ).count()
    if recent_ip_requests >= 10:
        flash("Too many verification requests from this connection. Please try again later.", "danger")
        return redirect(url_for("patient_report_portal"))

    # Always issue a challenge for a valid mobile. This prevents the endpoint
    # from revealing whether a number has a report before its owner verifies it.
    with tenant_context(portal_tenant_id):
        _, _, delivery_error = create_portal_otp_challenge(
            mobile=mobile,
            purpose="LAB_REPORTS",
        )
    if delivery_error:
        flash(delivery_error, "danger")
        return redirect(url_for("patient_report_portal"))

    session["pending_lab_report_mobile"] = mobile
    session.modified = True
    return render_template(
        "patient_report_verify.html",
        mobile_masked=mask_mobile(mobile),
    )


@app.route("/my-lab-reports/verify-otp", methods=["GET", "POST"])
def verify_patient_report_otp():
    portal_tenant_id = resolve_public_portal_tenant_id()
    if not portal_tenant_id:
        flash("Please open the report link for your pharmacy before verifying an OTP.", "warning")
        return redirect(url_for("patient_report_portal"))
    mobile = normalize_public_report_mobile(session.get("pending_lab_report_mobile"))
    if not mobile:
        flash("Start with your registered mobile number to request a verification code.", "warning")
        return redirect(url_for("patient_report_portal"))

    if request.method == "GET":
        return render_template("patient_report_verify.html", mobile_masked=mask_mobile(mobile))

    with tenant_context(portal_tenant_id):
        challenge, verification_error = verify_portal_otp_challenge(
            mobile=mobile,
            purpose="LAB_REPORTS",
            otp_code=request.form.get("otp"),
        )
    if verification_error:
        flash(verification_error, "danger")
        return render_template("patient_report_verify.html", mobile_masked=mask_mobile(mobile)), 400

    # Mark this one-time code consumed. The verified session has its own short TTL.
    if challenge:
        with tenant_context(portal_tenant_id):
            challenge.used_at = datetime.utcnow()
            try:
                db.session.commit()
            except Exception:
                db.session.rollback()
                app.logger.warning("Unable to record OTP consumption for lab report portal")
    set_public_portal_session("lab_report_portal", mobile)
    session.pop("pending_lab_report_mobile", None)
    session.modified = True
    return redirect(url_for("patient_report_list"))


@app.route("/my-lab-reports/list")
def patient_report_list():
    portal_tenant_id = resolve_public_portal_tenant_id()
    if not portal_tenant_id:
        flash("Please open the report link for your pharmacy before viewing reports.", "warning")
        return redirect(url_for("patient_report_portal"))
    mobile = normalize_public_report_mobile(get_public_portal_session_mobile("lab_report_portal"))
    if not mobile:
        flash("Please verify your mobile number before viewing reports.", "warning")
        return redirect(url_for("patient_report_portal"))

    with tenant_context(portal_tenant_id):
        reports = LabReport.query.filter(
            LabReport.mobile == mobile,
            LabReport.status == "PUBLISHED",
        ).order_by(
            LabReport.report_date.desc(), LabReport.uploaded_at.desc(), LabReport.id.desc()
        ).all()
    if reports:
        with tenant_context(portal_tenant_id):
            order_numbers = dict(
                db.session.query(LabOrder.id, LabOrder.order_no)
                .filter(LabOrder.id.in_([report.lab_order_id for report in reports]))
                .all()
            )
        for report in reports:
            report.order_no = order_numbers.get(report.lab_order_id) or f"LAB-{report.lab_order_id:06d}"

    patient_name = reports[0].patient_name if reports else ""
    return render_template(
        "patient_report_list.html",
        reports=reports,
        patient_name=patient_name,
        mobile_masked=mask_mobile(mobile),
    )


@app.route("/my-lab-reports/<int:report_id>/download")
def download_patient_lab_report(report_id):
    portal_tenant_id = resolve_public_portal_tenant_id()
    if not portal_tenant_id:
        flash("Please open the report link for your pharmacy before downloading a report.", "warning")
        return redirect(url_for("patient_report_portal"))
    mobile = normalize_public_report_mobile(get_public_portal_session_mobile("lab_report_portal"))
    if not mobile:
        flash("Please verify your mobile number before downloading a report.", "warning")
        return redirect(url_for("patient_report_portal"))

    # Filter by both verified mobile and published status so a guessed report ID
    # cannot disclose whether any other patient's record exists.
    with tenant_context(portal_tenant_id):
        report = LabReport.query.filter(
            LabReport.id == report_id,
            LabReport.mobile == mobile,
            LabReport.status == "PUBLISHED",
        ).first()
    if not report:
        abort(404)
    with tenant_context(portal_tenant_id):
        storage_key, file_path = private_lab_report_path(report.storage_key)
        if not storage_key or not os.path.isfile(file_path):
            abort(404)
        report_dir = os.path.dirname(file_path)

        before_snapshot = build_lab_report_audit_snapshot(report)
        report.download_count = to_int_safe(report.download_count, 0) + 1
        report.last_downloaded_at = datetime.utcnow()
        try:
            db.session.commit()
        except Exception:
            db.session.rollback()
            app.logger.exception("Unable to record download for lab report %s", report.id)

        record_audit_event(
            action="Downloaded lab report (patient portal)",
            entity_type="LAB_REPORT",
            entity_id=report.id,
            ref_code=str(report.lab_order_id),
            before=before_snapshot,
            after=build_lab_report_audit_snapshot(report),
            extra={"verified_mobile": mask_mobile(mobile)},
        )
    response = send_from_directory(
        report_dir,
        storage_key,
        as_attachment=True,
        download_name=lab_report_download_name(report),
    )
    response.headers["Cache-Control"] = "private, no-store, max-age=0"
    return response


@app.route("/stock-sale", methods=["GET", "POST"])
@login_required
def stock_sale():
    user = active_user_by_id(session.get("user_id"))
    if not user:
        flash("Access denied", "danger")
        return redirect("/")
    if user.role != "admin":
        flash("Access denied", "danger")
        return redirect("/")

    schema_ok, schema_err = ensure_inventory_runtime_schema()
    if not schema_ok:
        flash("Unable to open Stock Sale because inventory schema update failed.", "danger")
        if schema_err:
            app.logger.error("Inventory schema check failed before stock sale: %s", schema_err)
        return redirect("/")

    form_state = {
        "customer": STOCK_SALE_DEFAULT_CUSTOMER,
        "customer_gst_no": "",
        "mobile": "",
        "doctor": "",
        "payment_mode": STOCK_SALE_DEFAULT_PAYMENT_MODE,
        "internal_note": "",
        "lines_per_invoice": STOCK_SALE_DEFAULT_LINES_PER_INVOICE,
    }

    if request.method == "POST":
        form_state.update({
            "customer": (request.form.get("customer") or "").strip() or STOCK_SALE_DEFAULT_CUSTOMER,
            "customer_gst_no": (request.form.get("customer_gst_no") or "").strip().upper(),
            "mobile": (request.form.get("mobile") or "").strip(),
            "doctor": (request.form.get("doctor") or "").strip(),
            "payment_mode": normalize_payment_mode(request.form.get("payment_mode"), default=STOCK_SALE_DEFAULT_PAYMENT_MODE),
            "internal_note": (request.form.get("internal_note") or "").strip(),
            "lines_per_invoice": normalize_stock_sale_lines_per_invoice(request.form.get("lines_per_invoice")),
        })
        preview = build_stock_sale_preview(form_state["lines_per_invoice"])
        if request.form.get("confirm_stock_sale") == "yes":
            result, error = execute_stock_sale_operation(
                customer=form_state["customer"],
                customer_gst_no=form_state["customer_gst_no"],
                mobile=form_state["mobile"],
                doctor=form_state["doctor"],
                payment_mode=form_state["payment_mode"],
                internal_note=form_state["internal_note"],
                lines_per_invoice=form_state["lines_per_invoice"],
                actor_username=session.get("username"),
            )
            if error:
                flash(error, "danger")
            else:
                invoice_preview = ", ".join(result["invoice_nos"][:5])
                if len(result["invoice_nos"]) > 5:
                    invoice_preview += f" +{len(result['invoice_nos']) - 5} more"
                flash(
                    f"Stock sale completed. Created {result['invoice_count']} invoice(s) [{invoice_preview}] and re-entry purchase {result['purchase_no']} for vendor {result['vendor_name']}.",
                    "success"
                )
                return redirect("/stock-sale")
        return render_template(
            "stock_sale.html",
            payment_modes=POS_PAYMENT_MODES,
            preview=preview,
            form_state=form_state,
            reentry_vendor_name=STOCK_SALE_REENTRY_VENDOR_NAME,
        )

    preview = build_stock_sale_preview(form_state["lines_per_invoice"])
    return render_template(
        "stock_sale.html",
        payment_modes=POS_PAYMENT_MODES,
        preview=preview,
        form_state=form_state,
        reentry_vendor_name=STOCK_SALE_REENTRY_VENDOR_NAME,
    )


# ---------------- RETURN MEDICINE ----------------
@app.route("/return-medicine", methods=["GET", "POST"])
@login_required
@invoice_access_required
def return_medicine():
    invoice = None
    items_payload = []
    medicines = Medicine.query.order_by(Medicine.name).all()

    invoice_no = request.args.get("invoice_no", "").strip()
    search_customer = request.args.get("customer", "").strip()
    search_from = request.args.get("from", "").strip()
    search_to = request.args.get("to", "").strip()
    search_results = []

    if request.method == "POST":
        mode = request.form.get("mode", "invoice")
        return_validation_error = validate_return_submission(request.form)
        if return_validation_error:
            flash(return_validation_error, "danger")
            return redirect("/return-medicine")
        actor = session.get("username")

        # ---------------- MANUAL RETURN ----------------
        if mode == "manual":
            customer = request.form.get("manual_customer", "").strip()
            mobile = request.form.get("manual_mobile", "").strip()
            payment_mode = request.form.get("manual_payment_mode", "CASH")
            original_invoice_no = request.form.get("original_invoice_no", "").strip()

            ids = request.form.getlist("manual_medicine_id")
            qtys = request.form.getlist("manual_qty")
            sold_qtys = request.form.getlist("manual_sold_qty")
            selling_rates = request.form.getlist("manual_selling_rate")
            purchase_rates = request.form.getlist("manual_purchase_rate")
            gst_percents = request.form.getlist("manual_gst")
            reasons = request.form.getlist("manual_reason")
            dispositions = request.form.getlist("manual_disposition")

            def pick(values, idx, default=""):
                return values[idx] if idx < len(values) else default

            total_refund = 0
            total_cgst = 0
            total_sgst = 0
            line_items = []

            for idx, mid in enumerate(ids):
                if not mid:
                    continue
                med = Medicine.query.get(to_int_safe(mid, 0))
                if not med:
                    continue
                qty = to_int_safe(pick(qtys, idx), 0)
                if qty <= 0:
                    continue

                sold_qty = to_int_safe(pick(sold_qtys, idx), 0)
                if sold_qty and qty > sold_qty:
                    flash(f"Return qty cannot exceed sold qty for {med.name} ({med.batch})", "danger")
                    return redirect("/return-medicine")

                selling_rate = to_float_safe(pick(selling_rates, idx), 0) or to_float_safe(med.mrp, 0)
                purchase_rate = to_float_safe(pick(purchase_rates, idx), 0)
                gst_percent = normalize_gst_percent(pick(gst_percents, idx), medicine_gst_percent(med))
                reason = (pick(reasons, idx) or "").strip()
                disposition = normalize_return_disposition(pick(dispositions, idx, "RESTOCK"))

                amount = round_currency(qty * selling_rate)
                gst = split_inclusive_gst(amount, gst_percent)

                total_refund += amount
                total_cgst += gst["cgst"]
                total_sgst += gst["sgst"]

                line_items.append({
                    "med": med,
                    "qty": qty,
                    "selling_rate": selling_rate,
                    "purchase_rate": purchase_rate,
                    "gst_percent": gst["gst_percent"],
                    "reason": reason,
                    "disposition": disposition,
                    "amount": amount,
                    "net_amount": amount,
                })

            if not line_items:
                flash("Please select at least one medicine to return", "danger")
                return redirect("/return-medicine")

            try:
                ret = Return(
                    invoice_id=0,
                    invoice_no=original_invoice_no,
                    customer=customer,
                    mobile=mobile,
                    total_refund=0,
                    cgst=round_currency(total_cgst),
                    sgst=round_currency(total_sgst),
                    payment_mode=payment_mode,
                    created_by=actor
                )
                db.session.add(ret)
                db.session.flush()
                assign_return_number(ret)

                for item in line_items:
                    med = item["med"]
                    fallback_rate = item["purchase_rate"] or item["selling_rate"]
                    cost_total, lot_allocations = apply_return_line_stock(
                        ret=ret,
                        med=med,
                        qty=item["qty"],
                        disposition=item["disposition"],
                        invoice_item_id=None,
                        fallback_rate=fallback_rate,
                        actor=actor,
                        remark=f"Return Bill {ret.return_no}",
                    )
                    cost_price = round(cost_total / item["qty"], 4) if item["qty"] else 0
                    return_item = ReturnItem(
                        return_id=ret.id,
                        invoice_item_id=0,
                        medicine_id=med.id,
                        medicine_name=med.name,
                        batch=med.batch,
                        expiry=med.expiry,
                        qty=item["qty"],
                        price=item["selling_rate"],
                        amount=item["amount"],
                        purchase_rate=item["purchase_rate"],
                        selling_rate=item["selling_rate"],
                        gst_percent=item["gst_percent"],
                        reason=item["reason"],
                        discount_percent=0,
                        discount_amount=0,
                        net_amount=item["net_amount"],
                        cost_price=cost_price,
                        cost_amount=cost_total,
                        disposition=item["disposition"],
                    )
                    db.session.add(return_item)
                    db.session.flush()
                    record_return_line_followups(
                        ret=ret,
                        return_item=return_item,
                        med=med,
                        disposition=item["disposition"],
                        lot_allocations=lot_allocations,
                        cost_price=cost_price,
                        actor=actor,
                    )

                ret.total_refund = round_currency(total_refund)
                db.session.commit()
            except SQLAlchemyError:
                db.session.rollback()
                app.logger.exception("Manual return failed")
                flash("Return could not be saved. No stock was changed.", "danger")
                return redirect("/return-medicine")
            record_audit_event(
                action="Created return bill",
                entity_type="RETURN_BILL",
                entity_id=ret.id,
                ref_code=ret.return_no,
                before=None,
                after=build_return_audit_snapshot(ret),
                extra={"mode": "manual", "item_count": len(line_items)},
            )
            flash(return_success_message(line_items), "success")
            return redirect(f"/return-invoice/{ret.id}")

        # ---------------- INVOICE RETURN ----------------
        invoice_no = request.form.get("invoice_no", "").strip()
        if not invoice_no:
            flash("Please enter invoice number", "danger")
            return redirect("/return-medicine")

        invoice = Invoice.query.filter_by(invoice_no=invoice_no).first()
        if not invoice:
            flash("Invoice not found", "danger")
            return redirect(f"/return-medicine?invoice_no={invoice_no}")
        if bool(getattr(invoice, "is_cancelled", False)):
            flash("This invoice is cancelled. Items cannot be returned.", "danger")
            return redirect("/return-medicine")

        is_admin = (session.get("role") or "").strip().lower() == "admin"
        override_window = is_admin and (request.form.get("override_window") or "").strip() == "1"
        if not override_window and not is_invoice_return_window_open(invoice):
            flash(
                f"Return is allowed only within {return_window_days()} days of the invoice date."
                + (" Tick 'Allow late return' to override." if is_admin else " Ask an admin to approve a late return."),
                "danger",
            )
            return redirect(f"/return-medicine?invoice_no={invoice_no}")

        items = InvoiceItem.query.filter_by(invoice_id=invoice.id).all()
        returned_map = returned_qty_map_for_invoice(invoice.id)

        return_requests = []
        for it in items:
            already_returned = int(returned_map.get(it.id) or 0)
            remaining = it.qty - already_returned
            req_qty = to_int_safe(request.form.get(f"return_qty_{it.id}", 0), 0)
            reason = request.form.get(f"reason_{it.id}", "").strip()
            disposition = normalize_return_disposition(request.form.get(f"disposition_{it.id}"))
            if req_qty < 0 or req_qty > remaining:
                flash(f"Invalid return qty for {it.name}", "danger")
                return redirect(f"/return-medicine?invoice_no={invoice_no}")
            if req_qty > 0:
                med = find_medicine_for_invoice_item(it)
                if is_cold_chain_medicine(med, it) and not override_window:
                    flash(f"Cold-chain/refrigerated item cannot be returned: {it.name}.", "danger")
                    return redirect(f"/return-medicine?invoice_no={invoice_no}")
                return_requests.append((it, req_qty, med, reason, disposition))

        if not return_requests:
            flash("Please enter return quantity", "danger")
            return redirect(f"/return-medicine?invoice_no={invoice_no}")

        refund_multiplier = 1.0
        if to_float(invoice.subtotal) > 0 and to_float(invoice.total) > 0:
            refund_multiplier = to_float(invoice.total) / to_float(invoice.subtotal)

        try:
            ret = Return(
                invoice_id=invoice.id,
                invoice_no=invoice.invoice_no,
                customer=invoice.customer,
                mobile=invoice.mobile,
                payment_mode=request.form.get("payment_mode", "CASH"),
                created_by=actor
            )
            db.session.add(ret)
            db.session.flush()
            assign_return_number(ret)

            subtotal_return = 0
            total_cgst = 0
            total_sgst = 0
            summary_lines = []

            for it, req_qty, med, reason, disposition in return_requests:
                if not med:
                    med = persist_new_medicine_record(Medicine(
                        name=it.name,
                        batch=it.batch,
                        expiry=it.expiry,
                        mrp=it.price or 0,
                        qty=0,
                        discount_percent=int(it.discount_percent or 0),
                        gst_percent=invoice_item_gst_percent(invoice, it),
                    ))

                amounts = return_item_amount_snapshot(invoice, it, req_qty)
                subtotal_return += amounts["net_amount"]
                total_cgst += amounts["cgst"]
                total_sgst += amounts["sgst"]

                fallback_rate = it.cost_price or it.price or 0
                cost_total, lot_allocations = apply_return_line_stock(
                    ret=ret,
                    med=med,
                    qty=req_qty,
                    disposition=disposition,
                    invoice_item_id=it.id,
                    fallback_rate=fallback_rate,
                    actor=actor,
                    remark=f"Return Bill {ret.return_no} (Inv {invoice.invoice_no})",
                )
                cost_price = round(cost_total / req_qty, 4) if req_qty else 0

                return_item = ReturnItem(
                    return_id=ret.id,
                    invoice_item_id=it.id,
                    medicine_id=med.id,
                    medicine_name=it.name,
                    batch=it.batch,
                    expiry=it.expiry,
                    qty=req_qty,
                    price=it.price,
                    amount=amounts["amount"],
                    purchase_rate=0,
                    selling_rate=it.price or 0,
                    gst_percent=amounts["gst_percent"],
                    reason=reason,
                    discount_percent=amounts["discount_percent"],
                    discount_amount=amounts["discount_amount"],
                    net_amount=amounts["net_amount"],
                    cost_price=cost_price,
                    cost_amount=cost_total,
                    disposition=disposition,
                )
                db.session.add(return_item)
                db.session.flush()
                record_return_line_followups(
                    ret=ret,
                    return_item=return_item,
                    med=med,
                    disposition=disposition,
                    lot_allocations=lot_allocations,
                    cost_price=cost_price,
                    actor=actor,
                )
                summary_lines.append({"disposition": disposition, "qty": req_qty})

            ret.cgst = round_currency(total_cgst)
            ret.sgst = round_currency(total_sgst)
            ret.total_refund = round_currency(subtotal_return * refund_multiplier)
            db.session.commit()
        except SQLAlchemyError:
            db.session.rollback()
            app.logger.exception("Invoice return failed for invoice %s", invoice_no)
            flash("Return could not be saved. No stock was changed.", "danger")
            return redirect(f"/return-medicine?invoice_no={invoice_no}")
        record_audit_event(
            action="Created return bill",
            entity_type="RETURN_BILL",
            entity_id=ret.id,
            ref_code=ret.return_no,
            before=None,
            after=build_return_audit_snapshot(ret),
            extra={
                "mode": "invoice",
                "original_invoice_id": invoice.id,
                "window_override": bool(override_window),
                "item_count": len(return_requests),
            },
        )
        flash(return_success_message(summary_lines), "success")
        return redirect(f"/return-invoice/{ret.id}")

    # ---------------- SEARCH (GET) ----------------
    if invoice_no:
        invoice = Invoice.query.filter_by(invoice_no=invoice_no).first()
        if invoice:
            items = InvoiceItem.query.filter_by(invoice_id=invoice.id).all()
            returned_map = dict(
                db.session.query(ReturnItem.invoice_item_id, db.func.sum(ReturnItem.qty))
                .join(Return, Return.id == ReturnItem.return_id)
                .filter(
                    Return.invoice_id == invoice.id,
                    falsey_or_null_column_expr(Return.is_cancelled)
                )
                .group_by(ReturnItem.invoice_item_id)
                .all()
            )
            for it in items:
                already_returned = int(returned_map.get(it.id) or 0)
                remaining = it.qty - already_returned
                items_payload.append({
                    "item": it,
                    "returned": already_returned,
                    "remaining": remaining,
                    "cold_chain": is_cold_chain_medicine(find_medicine_for_invoice_item(it), it),
                })
        else:
            flash("Invoice not found", "danger")

    if (search_customer or search_from or search_to) and not invoice_no:
        q = Invoice.query
        if search_customer:
            q = q.filter(Invoice.customer.ilike(f"%{search_customer}%"))
        if search_from:
            from_dt = datetime.strptime(search_from, "%Y-%m-%d")
            q = q.filter(Invoice.created_at >= from_dt)
        if search_to:
            to_dt = datetime.strptime(search_to, "%Y-%m-%d") + timedelta(days=1)
            q = q.filter(Invoice.created_at < to_dt)
        search_results = q.order_by(Invoice.id.desc()).limit(50).all()

    return render_template(
        "return_medicine.html",
        invoice=invoice,
        invoice_cancelled=bool(invoice and getattr(invoice, "is_cancelled", False)),
        return_window_open=is_invoice_return_window_open(invoice) if invoice else True,
        return_window_days=return_window_days(),
        is_admin=(session.get("role") or "").strip().lower() == "admin",
        items=items_payload,
        invoice_no=invoice_no,
        medicines=medicines,
        search_results=search_results,
        search_customer=search_customer,
        search_from=search_from,
        search_to=search_to
    )


# ---------------- RETURN INVOICE ----------------
@app.route("/return-invoice/<int:id>")
@login_required
@invoice_access_required
def return_invoice(id):
    ret = Return.query.get_or_404(id)
    return render_template("return_invoice.html", **build_return_invoice_context(ret))


@app.route("/return-bill/edit/<int:id>", methods=["GET", "POST"])
@login_required
@invoice_access_required
def edit_return_bill(id):
    user = active_user_by_id(session.get("user_id"))
    if not user or user.role != "admin":
        flash("Only an administrator can edit a return bill.", "danger")
        return redirect("/return-bills")

    return_bill = Return.query.get_or_404(id)
    if return_bill.is_cancelled:
        flash("A cancelled return bill cannot be edited.", "warning")
        return redirect("/return-bills")

    if request.method == "POST":
        customer = (request.form.get("customer") or "").strip()
        payment_mode = (request.form.get("payment_mode") or "").strip().upper()

        if not customer:
            flash("Patient name is required.", "danger")
            return redirect(url_for("edit_return_bill", id=return_bill.id))
        if len(customer) > 100:
            flash("Patient name cannot exceed 100 characters.", "danger")
            return redirect(url_for("edit_return_bill", id=return_bill.id))
        if payment_mode not in POS_PAYMENT_MODES:
            flash("Invalid payment mode selected.", "danger")
            return redirect(url_for("edit_return_bill", id=return_bill.id))

        before_snapshot = build_return_audit_snapshot(return_bill)
        return_bill.customer = customer
        return_bill.payment_mode = payment_mode

        try:
            db.session.commit()
        except Exception:
            db.session.rollback()
            app.logger.exception("Return bill edit failed for id=%s", return_bill.id)
            flash("Return bill could not be updated. Please try again.", "danger")
            return redirect(url_for("edit_return_bill", id=return_bill.id))

        record_audit_event(
            action="Updated return bill details",
            entity_type="RETURN_BILL",
            entity_id=return_bill.id,
            ref_code=return_bill.return_no or f"RB-{return_bill.id:06d}",
            before=before_snapshot,
            after=build_return_audit_snapshot(return_bill),
            extra={"editable_fields": ["customer", "payment_mode"]},
        )
        flash("Return bill name and payment mode updated successfully.", "success")
        return redirect(url_for("return_invoice", id=return_bill.id))

    return render_template(
        "edit_return_bill.html",
        return_bill=return_bill,
        payment_modes=POS_PAYMENT_MODES,
    )

# ---------------- HOLD BILL ----------------
@app.route("/billing/hold", methods=["POST"])
@login_required
@invoice_access_required
def hold_bill():
    hold_bill_id = to_int_safe(request.form.get("hold_bill_id"), 0)

    customer = (request.form.get("customer") or "").strip()
    mobile = (request.form.get("mobile") or "").strip()
    doctor = (request.form.get("doctor") or "").strip()
    gender = (request.form.get("gender") or "").strip()
    sale_type = (request.form.get("sale_type") or "sale").strip().lower() or "sale"
    payment_mode = normalize_payment_mode(request.form.get("payment_mode") or "CASH")
    split_cash_amount = round(max(to_float_safe(request.form.get("split_cash_amount"), 0), 0), 2)
    internal_note = (request.form.get("internal_note") or "").strip()

    if not customer:
        flash("Please enter patient name before holding bill", "danger")
        if hold_bill_id > 0:
            return redirect(url_for("billing", hold_bill_id=hold_bill_id))
        return redirect("/billing")

    try:
        items = build_hold_items_from_form(request.form)
        draft_items = build_hold_rows_from_form(request.form, include_partial=True)
    except Exception:
        app.logger.exception("Primary hold bill payload build failed; using basic fallback rows.")
        items = build_basic_hold_rows_from_form(request.form, include_partial=False)
        draft_items = build_basic_hold_rows_from_form(request.form, include_partial=True)

    payload = {
        "header": {
            "customer": customer,
            "mobile": mobile,
            "doctor": doctor,
            "gender": gender,
            "sale_type": sale_type,
            "payment_mode": payment_mode,
            "split_cash_amount": split_cash_amount,
            "internal_note": internal_note,
        },
        "draft_items": draft_items,
        "items": items,
        "totals": build_hold_totals_from_form(request.form, items)
    }

    flash_msg = "Pending bill updated" if hold_bill_id > 0 else "Bill saved to Pending Bills"
    repair_pending_bill_store_compat()
    try:
        pending_bill = find_pending_bill_record(hold_bill_id, sync_if_missing=True) if hold_bill_id > 0 else None
        if pending_bill:
            pending_bill.customer = customer
            pending_bill.mobile = mobile
            pending_bill.doctor = doctor
            pending_bill.gender = gender
            pending_bill.data_text = serialize_json_text(payload)
            pending_bill.is_deleted = False
            pending_bill.deleted_at = None
            pending_bill.deleted_by = None
        else:
            pending_bill = create_pending_bill_store_record(
                customer=customer,
                mobile=mobile,
                doctor=doctor,
                gender=gender,
                payload=payload,
            )
            db.session.add(pending_bill)
        db.session.commit()
    except Exception:
        db.session.rollback()
        app.logger.exception("Primary pending bill persistence failed; attempting compatibility fallback.")
        saved = upsert_pending_bill_store_compat(
            pending_bill_id=hold_bill_id,
            customer=customer,
            mobile=mobile,
            doctor=doctor,
            gender=gender,
            payload=payload,
        )
        if not saved:
            flash("Pending bill save failed. Please retry once.", "danger")
            if hold_bill_id > 0:
                return redirect(url_for("billing", hold_bill_id=hold_bill_id))
            return redirect("/billing")

    flash(flash_msg, "info")
    return redirect("/pending-bills")

# ---------------- PENDING BILLS ----------------
@app.route("/pending-bills")
@login_required
@invoice_access_required
def pending_bills():
    bills = []
    sync_pending_bill_store()
    try:
        bills = active_hold_bill_query().order_by(PendingBillStore.created_at.desc(), PendingBillStore.id.desc()).all()
    except Exception:
        db.session.rollback()
        app.logger.exception("Unable to read pending bills from database.")
    return render_template("pending_bills.html", bills=bills)

@app.route("/restore-bill/<int:id>")
@login_required
@invoice_access_required
def restore_bill(id):
    hb = find_pending_bill_record(id, sync_if_missing=True)
    if not hb:
        flash("Held bill not found.", "warning")
        return redirect("/pending-bills")
    return redirect(url_for("billing", hold_bill_id=hb.id))

@app.route("/delete-hold/<int:id>", methods=["POST"])
@login_required
@invoice_access_required
def delete_hold(id):
    hold_bill = find_pending_bill_record(id, sync_if_missing=True)
    if hold_bill:
        hold_bill.is_deleted = True
        hold_bill.deleted_at = datetime.utcnow()
        hold_bill.deleted_by = session.get("username")
        db.session.commit()
        flash("Pending bill removed from the active hold list.", "success")
        return redirect("/pending-bills")
    abort(404)

# ---------------- CANCEL RETURN BILL ----------------
@app.route("/return-bill/delete/<int:id>", methods=["POST"])
@login_required
@invoice_access_required
def delete_return_bill(id):
    ret = Return.query.get_or_404(id)
    if ret.is_cancelled:
        flash("Return bill already cancelled.", "info")
        return redirect("/return-bills")

    items = ReturnItem.query.filter_by(return_id=id).all()
    item_medicines = {}
    required_stock = {}
    quarantine_by_item = {
        q.return_item_id: q
        for q in QuarantineStock.query.filter_by(return_id=ret.id).all()
    }

    def stock_was_added(item):
        """True when this returned line is currently inside sellable stock."""
        disposition = normalize_return_disposition(getattr(item, "disposition", "RESTOCK"))
        if disposition == "RESTOCK":
            return True
        quarantine = quarantine_by_item.get(item.id)
        return bool(quarantine and (quarantine.status or "").upper() == "RESTOCKED")

    for it in items:
        if not stock_was_added(it):
            continue
        med = None
        if it.medicine_id:
            med = Medicine.query.get(it.medicine_id)
        if not med:
            med = Medicine.query.filter_by(name=it.medicine_name, batch=it.batch).first()
        if not med:
            flash(f"Medicine not found for {it.medicine_name} ({it.batch}).", "danger")
            return redirect("/return-bills")
        item_medicines[it.id] = med
        required_stock[med.id] = {
            "med": med,
            "qty": required_stock.get(med.id, {}).get("qty", 0) + to_int(it.qty)
        }

    for entry in required_stock.values():
        med = entry["med"]
        if to_int(med.qty) < entry["qty"]:
            flash(
                f"Cannot cancel: stock for {med.name} ({med.batch}) is less than total return qty.",
                "danger"
            )
            return redirect("/return-bills")

    for it in items:
        quarantine = quarantine_by_item.get(it.id)
        if not stock_was_added(it):
            # Units never entered sellable stock: just close the quarantine record.
            if quarantine and (quarantine.status or "").upper() == "PENDING":
                quarantine.status = "CANCELLED"
                quarantine.resolved_by = session.get("username")
                quarantine.resolved_at = datetime.utcnow()
            continue
        med = item_medicines.get(it.id)
        if not med:
            continue
        if it.invoice_item_id:
            fallback_rate = it.cost_price or it.selling_rate or it.price or 0
            fifo_cancel_return(it.invoice_item_id, it.qty, fallback_rate)
        else:
            reverse_manual_return_lots(it.id)
        old_stock = med.qty
        med.qty -= it.qty
        history = StockHistory(
            medicine_id=med.id,
            medicine_name=med.name,
            batch=med.batch,
            action="RETURN_CANCEL",
            stock_before=old_stock,
            qty_change=-it.qty,
            stock_after=med.qty,
            user=session.get("username"),
            remark=f"Return Bill cancelled {ret.return_no or f'RB-{ret.id:06d}'}"
        )
        db.session.add(history)
        if quarantine:
            quarantine.status = "CANCELLED"
            quarantine.resolved_by = session.get("username")
            quarantine.resolved_at = datetime.utcnow()

    ret.is_cancelled = True
    ret.cancelled_by = session.get("username")
    ret.cancelled_at = datetime.now()
    db.session.commit()
    flash("Return bill cancelled. Stock reversed and record kept for audit.", "warning")
    return redirect("/return-bills")

# ---------------- RETURN BILLS LIST ----------------
@app.route("/return-bills")
@login_required
@invoice_access_required
def return_bills():
    returns = Return.query.order_by(Return.id.desc()).all()
    return render_template("return_bills.html", returns=returns)

# ---------------- INVOICES LIST ----------------
@app.route("/invoices")
@login_required
@invoice_access_required
def invoices():
    from_str = request.args.get("from", "").strip()
    to_str = request.args.get("to", "").strip()
    search_query = (request.args.get("search") or "").strip()
    query = Invoice.query
    active_from = from_str
    active_to = to_str
    fresh_start_date = get_operations_fresh_start_date()
    default_cutover_window = False

    if (
        not from_str
        and not to_str
        and not search_query
        and is_post_operations_fresh_start()
    ):
        default_cutover_window = True
        active_from = fresh_start_date.isoformat()
        from_dt, _unused = local_date_range_to_storage_bounds(fresh_start_date, fresh_start_date)
        query = query.filter(Invoice.created_at >= from_dt)

    if from_str:
        try:
            from_dt = datetime.strptime(from_str, "%Y-%m-%d")
            query = query.filter(Invoice.created_at >= from_dt)
        except ValueError:
            pass
    if to_str:
        try:
            to_dt = datetime.strptime(to_str, "%Y-%m-%d") + timedelta(days=1)
            query = query.filter(Invoice.created_at < to_dt)
        except ValueError:
            pass
    if search_query:
        like = f"%{search_query}%"
        digits = normalize_patient_mobile(search_query)
        conditions = [
            Invoice.invoice_no.ilike(like),
            Invoice.customer.ilike(like)
        ]
        if digits:
            conditions.append(Invoice.mobile.ilike(f"%{digits}%"))
        query = query.filter(or_(*conditions))
    return render_template(
        "invoices.html",
        invoices=query.order_by(Invoice.id.desc()).all(),
        search_query=search_query,
        active_from=active_from,
        active_to=active_to,
        default_cutover_window=default_cutover_window,
        fresh_start_date=fresh_start_date.isoformat(),
    )

def render_invoice_page(inv, *, share_url="", is_public_invoice=False):
    items = InvoiceItem.query.filter_by(invoice_id=inv.id).all()
    rounded_total = compute_invoice_rounded_total(inv.total if inv.total not in (None, "") else inv.subtotal)
    payment_breakdown = build_invoice_payment_breakdown(inv, rounded_total)
    exchange_return_bill = Return.query.filter_by(adjusted_invoice_id=inv.id).first()
    exchange_return_items = []
    return_credit_total = round_currency(getattr(inv, "return_credit_used", 0))
    exchange_refund_amount = round_currency(getattr(inv, "refund_amount", 0))
    final_payable = round_currency(getattr(inv, "final_payable", rounded_total))
    if exchange_return_bill and not bool(getattr(exchange_return_bill, "is_cancelled", False)):
        exchange_return_items = [
            {"item": item, "qty": item.qty, "amounts": {"net_amount": item.net_amount}}
            for item in ReturnItem.query.filter_by(return_id=exchange_return_bill.id).all()
        ]
        return_credit_total = round_currency(getattr(exchange_return_bill, "total_refund", return_credit_total))
        exchange_refund_amount = round_currency(getattr(exchange_return_bill, "refund_amount", exchange_refund_amount))
        final_payable = round_currency(max(rounded_total - return_credit_total, 0))

    print_profile = resolve_invoice_print_profile(inv)
    if is_public_invoice and print_profile.get("logo_path", "").startswith("/tenant-business-logo/"):
        filename = print_profile["logo_path"].rsplit("/", 1)[-1]
        logo_share = URLSafeSerializer(
            app.secret_key, salt="tenant-business-logo-v1"
        ).dumps({
            "tenant_id": getattr(inv, "tenant_id", None),
            "filename": filename,
        })
        print_profile["logo_path"] = url_for(
            "tenant_business_logo", filename=filename, share=logo_share
        )

    return render_template(
        "invoice.html",
        inv=inv,
        is_public_invoice=is_public_invoice,
        share_url=share_url,
        print_profile=print_profile,
        payment_breakdown=payment_breakdown,
        cart=items,
        exchange_return_bill=exchange_return_bill,
        exchange_return_items=exchange_return_items,
        return_credit_total=return_credit_total,
        return_credit_used=round_currency(getattr(inv, "return_credit_used", 0)),
        exchange_refund_amount=exchange_refund_amount,
        final_payable=final_payable,
        customer=inv.customer,
        customer_gst_no=(inv.customer_gst_no or "").strip(),
        mobile=inv.mobile,
        doctor=inv.doctor,
        gender=inv.gender,
        invoice_no=inv.invoice_no,
        subtotal=inv.subtotal,
        discount=inv.discount,
        cgst=inv.cgst,
        sgst=inv.sgst,
        total=inv.total,
        rounded_total=rounded_total,
        date=(storage_datetime_to_local(inv.created_at) or inv.created_at).strftime("%d-%m-%Y"),
        bill_time=(storage_datetime_to_local(inv.created_at) or inv.created_at).strftime("%I:%M %p")
    )


def excel_item_gst_split(inv, item, net_amount):
    if getattr(item, "gst_amount", None) is not None:
        half = round_currency(to_float_safe(item.gst_amount, 0) / 2)
        return half, half
    gst = split_inclusive_gst(net_amount, invoice_item_gst_percent(inv, item))
    return gst["cgst"], gst["sgst"]


def build_single_invoice_excel(inv):
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter

    items = InvoiceItem.query.filter_by(invoice_id=inv.id).order_by(InvoiceItem.id.asc()).all()
    created_at = storage_datetime_to_local(inv.created_at) or inv.created_at
    rounded_total = compute_invoice_rounded_total(inv.total if inv.total not in (None, "") else inv.subtotal)
    payment_breakdown = build_invoice_payment_breakdown(inv, rounded_total)
    print_profile = resolve_invoice_print_profile(inv)

    def money(value):
        try:
            return float(value or 0)
        except (TypeError, ValueError):
            return 0.0

    def auto_size_columns(sheet):
        for column_cells in sheet.columns:
            column_letter = get_column_letter(column_cells[0].column)
            max_length = 0
            for cell in column_cells:
                value = "" if cell.value is None else str(cell.value)
                max_length = max(max_length, len(value))
            sheet.column_dimensions[column_letter].width = min(max(max_length + 2, 12), 42)

    wb = Workbook()
    summary = wb.active
    summary.title = "Invoice Summary"
    detail = wb.create_sheet("Invoice Items")

    title_fill = PatternFill("solid", fgColor="173F91")
    title_font = Font(color="FFFFFF", bold=True, size=13)
    header_fill = PatternFill("solid", fgColor="D9EAF7")
    header_font = Font(bold=True)

    summary.merge_cells("A1:B1")
    summary["A1"] = " - ".join(
        part for part in (print_profile.get("pharmacy_name"), "Invoice Report") if part
    )
    summary["A1"].fill = title_fill
    summary["A1"].font = title_font
    summary["A1"].alignment = Alignment(horizontal="center")

    summary_rows = [
        ("Invoice No", inv.invoice_no or ""),
        ("Invoice Date", created_at.strftime("%d-%m-%Y") if created_at else ""),
        ("Invoice Time", created_at.strftime("%I:%M %p") if created_at else ""),
        ("Patient / Party Name", inv.customer or ""),
        ("Mobile", inv.mobile or ""),
        ("Gender", inv.gender or ""),
        ("Doctor", inv.doctor or ""),
        ("Customer GST No", inv.customer_gst_no or ""),
        ("Payment Mode", payment_breakdown["display_mode"]),
        ("Payment Type", payment_breakdown["payment_type"]),
        ("Cash Collection", payment_breakdown["cash_amount"]),
        ("Online Collection", payment_breakdown["online_amount"]),
        ("Subtotal", money(inv.subtotal)),
        ("Discount", money(inv.discount)),
        ("CGST", money(inv.cgst)),
        ("SGST", money(inv.sgst)),
        ("Total", money(inv.total)),
        ("Rounded Amount", payment_breakdown["rounded_amount"]),
        ("Created By", inv.created_by or ""),
        ("Internal Note", inv.internal_note or ""),
        ("Pharmacy Address 1", print_profile.get("address_line_1", "")),
        ("Pharmacy Address 2", print_profile.get("address_line_2", "")),
        ("Pharmacy Mobile", print_profile.get("mobile", "")),
        ("Pharmacy Alternate Mobile", print_profile.get("alternate_mobile", "")),
        ("Pharmacy Name", print_profile.get("pharmacy_name", "")),
        ("Legal Business Name", print_profile.get("legal_business_name", "")),
        ("Pharmacy GST No", print_profile.get("gst_no", "")),
        ("Pharmacy Licence No", print_profile.get("licence_no", "")),
        ("Invoice Header", print_profile.get("invoice_header", "")),
        ("Invoice Footer", print_profile.get("invoice_footer", "")),
        ("Invoice Terms", print_profile.get("invoice_terms", "")),
        ("Authorized Signatory", print_profile.get("authorized_signatory", "")),
    ]

    for row_number, (label, value) in enumerate(summary_rows, start=3):
        summary.cell(row=row_number, column=1, value=label)
        summary.cell(row=row_number, column=2, value=value)
        summary.cell(row=row_number, column=1).font = header_font

    item_headers = [
        "S.No",
        "Product",
        "Qty",
        "Batch",
        "Expiry",
        "MRP",
        "Amount",
        "Discount %",
        "Discount Amount",
        "Net Amount",
        "CGST",
        "SGST",
    ]
    detail.append(item_headers)
    for cell in detail[1]:
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center")

    for index, item in enumerate(items, start=1):
        net_amount = money(item.net_amount if item.net_amount is not None else item.amount)
        detail.append([
            index,
            item.name or "",
            item.qty or 0,
            item.batch or "",
            item.expiry or "",
            money(item.price),
            money(item.amount),
            money(item.discount_percent),
            money(item.discount_amount),
            net_amount,
            *excel_item_gst_split(inv, item, net_amount),
        ])

    total_row = detail.max_row + 1
    detail.cell(row=total_row, column=1, value="TOTAL")
    detail.cell(row=total_row, column=1).font = header_font
    for column in (3, 7, 9, 10, 11, 12):
        letter = get_column_letter(column)
        detail.cell(row=total_row, column=column, value=f"=SUM({letter}2:{letter}{total_row - 1})")
        detail.cell(row=total_row, column=column).font = header_font

    detail.freeze_panes = "A2"
    for sheet in (summary, detail):
        auto_size_columns(sheet)

    output = BytesIO()
    wb.save(output)
    output.seek(0)
    return output


# ---------------- PART-3: VIEW / PRINT INVOICE ----------------
@app.route("/invoice/<int:id>")
@login_required
@invoice_access_required
def view_invoice(id):
    inv = Invoice.query.get_or_404(id)
    share_url = url_for(
        "shared_invoice",
        token=build_invoice_share_token(inv.id),
        _external=True,
    )
    return render_invoice_page(inv, share_url=share_url, is_public_invoice=False)


@app.route("/invoice/<int:id>/excel")
@login_required
@invoice_access_required
def export_invoice_excel(id):
    inv = Invoice.query.get_or_404(id)
    output = build_single_invoice_excel(inv)
    safe_invoice_no = secure_filename(inv.invoice_no or f"invoice_{inv.id}") or f"invoice_{inv.id}"
    return send_file(
        output,
        as_attachment=True,
        download_name=f"{safe_invoice_no}_Excel_Report.xlsx",
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        max_age=0,
    )


@app.route("/invoice/share/<token>")
def shared_invoice(token):
    invoice_id = read_invoice_share_token(token)
    if not invoice_id:
        abort(404)
    inv = Invoice.query.get_or_404(invoice_id)
    return render_invoice_page(inv, share_url=request.url, is_public_invoice=True)
@app.route("/invoice/edit/<int:id>", methods=["GET", "POST"])
@login_required
@invoice_access_required
def edit_invoice(id):
    user = active_user_by_id(session.get("user_id"))
    if not user:
        flash("Access denied", "danger")
        return redirect("/")
    if user.role != "admin":
        flash("Access denied", "danger")
        return redirect("/invoices")
    invoice = Invoice.query.get_or_404(id)
    if bool(getattr(invoice, "is_cancelled", False)):
        flash("A cancelled invoice cannot be edited.", "warning")
        return redirect("/invoices")
    items = InvoiceItem.query.filter_by(invoice_id=id).all()
    payment_modes = POS_PAYMENT_MODES

    if request.method == "POST":
        before_snapshot = build_invoice_audit_snapshot(invoice)
        customer = (request.form.get("customer") or "").strip()
        mobile = (request.form.get("mobile") or "").strip()
        payment_mode = (request.form.get("payment_mode") or "CASH").strip().upper() or "CASH"
        internal_note = (request.form.get("internal_note") or "").strip()

        if not customer:
            flash("Patient name is required.", "danger")
            return redirect(f"/invoice/edit/{invoice.id}")
        if payment_mode not in payment_modes:
            flash("Invalid payment mode selected.", "danger")
            return redirect(f"/invoice/edit/{invoice.id}")

        payment_update, payment_error = resolve_invoice_edit_payment_update(invoice, payment_mode)
        if payment_error:
            flash(payment_error, "danger")
            return redirect(f"/invoice/edit/{invoice.id}")

        invoice.customer = customer
        invoice.mobile = mobile
        invoice.payment_mode = payment_update["payment_mode"]
        invoice.cash_amount = payment_update["cash_amount"]
        invoice.online_amount = payment_update["online_amount"]
        invoice.is_split_payment = payment_update["is_split_payment"]
        invoice.internal_note = internal_note
        patient, normalized_mobile = upsert_patient_from_invoice(customer, mobile, invoice.gender)
        if patient and not patient.id:
            db.session.flush()
        invoice.patient_id = patient.id if patient else invoice.patient_id
        invoice.mobile = normalized_mobile or mobile

        db.session.commit()
        record_audit_event(
            action="Updated invoice details",
            entity_type="INVOICE",
            entity_id=invoice.id,
            ref_code=invoice.invoice_no,
            before=before_snapshot,
            after=build_invoice_audit_snapshot(invoice)
        )
        flash("Invoice details updated successfully.", "success")
        return redirect(f"/invoice/{invoice.id}")


    return render_template(
        "edit_invoice.html",
        invoice=invoice,
        items=items,
        payment_modes=payment_modes
    )
def cancel_invoice_record(inv, *, actor_username, reason):
    """Cancel an invoice: restore stock and FIFO lots, keep the record.

    GST rules require issued invoice numbers to stay in the books, so the
    invoice and its items are kept and marked cancelled instead of deleted.
    Returns an error message, or None on success (caller commits).
    """
    if bool(getattr(inv, "is_cancelled", False)):
        return "Invoice is already cancelled."
    has_returns = Return.query.filter(
        Return.invoice_id == inv.id,
        falsey_or_null_column_expr(Return.is_cancelled)
    ).first()
    if has_returns:
        return "Cannot cancel an invoice that has returns. Cancel the return bills first."
    if Return.query.filter(
        Return.adjusted_invoice_id == inv.id,
        falsey_or_null_column_expr(Return.is_cancelled)
    ).first():
        return "This invoice used an exchange return credit. Cancel that return bill first."

    items = InvoiceItem.query.filter_by(invoice_id=inv.id).all()
    for it in items:
        med = (
            Medicine.query.filter_by(name=it.name, batch=it.batch, expiry=it.expiry).first()
            or Medicine.query.filter_by(name=it.name, batch=it.batch).first()
        )
        if not med:
            med = persist_new_medicine_record(Medicine(
                name=it.name,
                batch=it.batch,
                expiry=it.expiry or "",
                mrp=it.price or 0,
                qty=0,
                discount_percent=int(it.discount_percent or 0),
                gst_percent=normalize_gst_percent(getattr(it, "gst_percent", None), default_gst_percent()),
            ))
        med = lock_medicine_for_update(med)
        old_stock = to_int_safe(med.qty, 0)
        med.qty = old_stock + to_int_safe(it.qty, 0)
        db.session.add(StockHistory(
            medicine_id=med.id,
            medicine_name=med.name,
            batch=med.batch,
            action="INVOICE_CANCEL",
            stock_before=old_stock,
            qty_change=to_int_safe(it.qty, 0),
            stock_after=med.qty,
            user=actor_username,
            remark=f"Invoice {inv.invoice_no} cancelled (stock returned)",
            ref_table="invoice",
            ref_id=inv.id,
        ))

        for alloc in SalesAllocation.query.filter_by(invoice_item_id=it.id).all():
            still_sold = to_int(alloc.qty) - to_int(alloc.returned_qty)
            if still_sold <= 0:
                continue
            if alloc.purchase_item_id:
                pi = VendorPurchaseItem.query.get(alloc.purchase_item_id)
                if pi:
                    pi.remaining_qty = to_int(pi.remaining_qty) + still_sold
            # Mark the allocation fully returned so nothing can restore it twice.
            alloc.returned_qty = to_int(alloc.qty)

    inv.is_cancelled = True
    inv.cancelled_at = datetime.utcnow()
    inv.cancelled_by = actor_username
    inv.cancel_reason = (reason or "").strip()[:255] or "Cancelled"
    return None


@app.route("/invoice/cancel/<int:id>", methods=["POST"])
@app.route("/delete-invoice/<int:id>", methods=["POST"])
@login_required
def cancel_invoice(id):
    user = active_user_by_id(session.get("user_id"))
    if not user:
        flash("Access denied", "danger")
        return redirect("/")
    if user.role != "admin" and not (user.can_delete_invoice or user.can_invoice_action):
        flash("Access denied", "danger")
        return redirect("/invoices")
    inv = Invoice.query.get_or_404(id)
    before_snapshot = build_invoice_audit_snapshot(inv)
    reason = (request.form.get("reason") or "").strip()
    try:
        error = cancel_invoice_record(inv, actor_username=session.get("username"), reason=reason)
        if error:
            db.session.rollback()
            flash(error, "danger")
            return redirect("/invoices")
        db.session.commit()
    except SQLAlchemyError:
        db.session.rollback()
        app.logger.exception("Invoice cancel failed for id=%s", id)
        flash("Invoice could not be cancelled. No stock was changed.", "danger")
        return redirect("/invoices")
    record_audit_event(
        action="Cancelled invoice",
        entity_type="INVOICE",
        entity_id=inv.id,
        ref_code=inv.invoice_no,
        before=before_snapshot,
        after=build_invoice_audit_snapshot(inv),
        extra={"reason": inv.cancel_reason},
    )
    flash(f"Invoice {inv.invoice_no} cancelled. Stock restored and record kept for GST.", "info")
    return redirect("/invoices")


@app.route("/company")
@login_required
def company():
    return "<h2>Company Master – Coming Soon</h2>"

@app.route("/category")
@login_required
def category():
    return "<h2>Category Master – Coming Soon</h2>"

@app.route("/salt")
@login_required
def salt():
    return "<h2>Salt Master – Coming Soon</h2>"

@app.route("/vendor")
@login_required
@inventory_access_required
def vendor():
    vendors = active_vendor_query().order_by(Vendor.name).all()
    return render_template("vendor.html", vendors=vendors)


@app.route("/vendor/attachment/<path:filename>")
@login_required
@inventory_access_required
def view_vendor_attachment(filename):
    cleaned_name, base_dir, file_path = resolve_tenant_upload_file(UPLOAD_FOLDER, filename)
    if not cleaned_name:
        return "Attachment not found.", 404
    if not active_vendor_query().filter(Vendor.attachment_ref == cleaned_name).first():
        return "Attachment not found.", 404
    if not os.path.exists(file_path):
        return "Attachment file not found on server.", 404
    return send_from_directory(base_dir, cleaned_name, as_attachment=False)

@app.route("/vendor-notes")
@login_required
@vendor_note_access_required()
def vendor_notes():
    vendors = active_vendor_query().order_by(Vendor.name.asc()).all()
    medicines = Medicine.query.order_by(
        db.func.lower(Medicine.name).asc(),
        Medicine.batch.asc(),
        Medicine.id.asc()
    ).all()
    purchases = VendorPurchase.query.order_by(
        VendorPurchase.purchase_date.desc(),
        VendorPurchase.id.desc()
    ).limit(300).all()
    notes = VendorNote.query.order_by(
        VendorNote.note_date.desc(),
        VendorNote.id.desc()
    ).limit(200).all()
    vendor_map = {v.id: v.name for v in vendors}
    return render_template(
        "vendor_notes.html",
        vendors=vendors,
        medicines=medicines,
        purchases=purchases,
        notes=notes,
        vendor_map=vendor_map,
        today=date.today().isoformat()
    )


@app.route("/vendor-note-invoice/<int:note_id>")
@login_required
@vendor_note_access_required()
def vendor_note_invoice(note_id):
    note = VendorNote.query.get_or_404(note_id)
    vendor = Vendor.query.get(note.vendor_id) if note.vendor_id else None
    ref_purchase = VendorPurchase.query.get(note.reference_purchase_id) if note.reference_purchase_id else None
    ref_bill_no = None
    if ref_purchase:
        ref_bill_no = ref_purchase.invoice_no if ref_purchase.invoice_no else (ref_purchase.purchase_no or f"PB-{ref_purchase.id:06d}")

    note_items = VendorNoteItem.query.filter_by(note_id=note.id).order_by(VendorNoteItem.id.asc()).all()
    med_ids = [it.medicine_id for it in note_items if it.medicine_id]
    med_map = {}
    if med_ids:
        meds = Medicine.query.filter(Medicine.id.in_(med_ids)).all()
        med_map = {m.id: m.name for m in meds}

    items = []
    for idx, it in enumerate(note_items, start=1):
        items.append({
            "sr_no": idx,
            "medicine_name": med_map.get(it.medicine_id) or "-",
            "batch_no": it.batch_no or "-",
            "expiry": it.expiry or "-",
            "qty": to_int(it.qty),
            "free_qty": to_int(it.free_qty),
            "purchase_rate": to_float(it.purchase_rate),
            "mrp": to_float(it.mrp),
            "gst_percent": to_float(it.gst_percent),
            "disc_percent": to_float(it.disc_percent),
            "line_total": to_float(it.line_total)
        })

    auto_print = (request.args.get("print") or "").strip() == "1"
    return render_template(
        "vendor_note_invoice.html",
        note=note,
        vendor=vendor,
        ref_bill_no=ref_bill_no,
        items=items,
        note_date=note.note_date.strftime("%d-%m-%Y") if note.note_date else "-",
        created_at=note.created_at.strftime("%d-%m-%Y %I:%M %p") if note.created_at else "-",
        printed_at=datetime.now().strftime("%d-%m-%Y %I:%M %p"),
        auto_print=auto_print
    )

@app.route("/vendor/reports")
@login_required
@inventory_access_required
def vendor_reports():
    vendors = active_vendor_query().order_by(Vendor.name).all()
    return render_vendor_reports_page(vendors)

@app.route("/vendor/medicine-history")
@login_required
@inventory_access_required
def vendor_medicine_history():
    query_name = (request.args.get("name") or "").strip()
    items_query = VendorPurchaseItem.query
    if query_name:
        items_query = items_query.filter(VendorPurchaseItem.medicine_name.ilike(f"%{query_name}%"))
    items = items_query.order_by(VendorPurchaseItem.created_at.desc()).limit(200).all()

    last_rates = []
    seen = set()
    for it in items:
        key = (it.vendor_id, it.medicine_name, it.batch)
        if key in seen:
            continue
        seen.add(key)
        vendor_obj = Vendor.query.get(it.vendor_id)
        last_rates.append({
            "vendor": vendor_obj.name if vendor_obj else "-",
            "medicine": it.medicine_name,
            "batch": it.batch,
            "expiry": it.expiry,
            "rate": it.purchase_rate,
            "date": it.created_at
        })

    return render_template("vendor_medicine_history.html", items=last_rates, query_name=query_name)

@app.route("/vendor/add", methods=["GET", "POST"])
@login_required
@inventory_access_required
def add_vendor():
    if request.method == "POST":
        schema_ok, schema_err = ensure_inventory_runtime_schema()
        if not schema_ok:
            flash("Unable to save vendor because inventory schema update failed.", "danger")
            if schema_err:
                app.logger.error("Inventory schema check failed before add vendor: %s", schema_err)
            return redirect("/vendor/add")
        name = (request.form.get("name") or "").strip()
        if not name:
            flash("Vendor name is required", "danger")
            return redirect("/vendor/add")
        existing = active_vendor_query().filter(db.func.lower(Vendor.name) == name.lower()).first()
        if existing:
            flash("Vendor name already exists", "danger")
            return redirect("/vendor/add")

        last_purchase_raw = request.form.get("last_purchase_date") if "last_purchase_date" in request.form else ""
        last_purchase_dt = parse_date(last_purchase_raw) if last_purchase_raw else None

        attachment_ref = request.form.get("attachment_ref", "")
        file = request.files.get("attachment_file")
        if file and file.filename and allowed_file(file.filename):
            attachment_ref = save_uploaded_file(file, UPLOAD_FOLDER, "vendor")

        v = Vendor(
            name=name,
            mobile=request.form.get("mobile", ""),
            email=request.form.get("email", ""),
            gst_no=request.form.get("gst_no", ""),
            shop_name=request.form.get("shop_name", ""),
            area=request.form.get("area", ""),
            city=request.form.get("city", ""),
            state=request.form.get("state", ""),
            pincode=request.form.get("pincode", ""),
            address=request.form.get("address", ""),
            vendor_type=(request.form.get("vendor_type") or "Distributor"),
            credit_days=to_int(request.form.get("credit_days")),
            credit_limit=to_float(request.form.get("credit_limit")),
            bank_name=request.form.get("bank_name", ""),
            account_holder_name=request.form.get("account_holder_name", ""),
            account_no=request.form.get("account_no", ""),
            ifsc=request.form.get("ifsc", ""),
            upi=request.form.get("upi", ""),
            categories=request.form.get("categories", ""),
            salts=request.form.get("salts", ""),
            last_purchase_date=last_purchase_dt,
            total_purchases=to_float(request.form.get("total_purchases")),
            outstanding_balance=to_float(request.form.get("outstanding_balance")),
            payment_status=(request.form.get("payment_status") or "Paid"),
            rate_history=request.form.get("rate_history", ""),
            default_payment_mode=(request.form.get("default_payment_mode") or "CASH"),
            notes=request.form.get("notes", ""),
            attachment_ref=attachment_ref,
            is_active=(True if "is_active" not in request.form else bool(request.form.get("is_active")))
        )

        db.session.add(v)
        db.session.commit()
        flash("Vendor added successfully", "success")
        return redirect("/vendor")

    return render_template(
        "vendor_form.html",
        vendor=None,
        medicine_names=[],
        medicine_code_lookup={}
    )

@app.route("/vendor/edit/<int:id>", methods=["GET", "POST"])
@login_required
@inventory_access_required
def edit_vendor(id):
    v = active_vendor_query().filter(Vendor.id == id).first_or_404()

    if request.method == "POST":
        schema_ok, schema_err = ensure_inventory_runtime_schema()
        if not schema_ok:
            flash("Unable to update vendor because inventory schema update failed.", "danger")
            if schema_err:
                app.logger.error("Inventory schema check failed before edit vendor: %s", schema_err)
            return redirect(f"/vendor/edit/{id}")
        name = (request.form.get("name") or "").strip()
        if not name:
            flash("Vendor name is required", "danger")
            return redirect(f"/vendor/edit/{id}")
        existing = active_vendor_query().filter(db.func.lower(Vendor.name) == name.lower(), Vendor.id != v.id).first()
        if existing:
            flash("Vendor name already exists", "danger")
            return redirect(f"/vendor/edit/{id}")

        last_purchase_raw = request.form.get("last_purchase_date") if "last_purchase_date" in request.form else None
        last_purchase_dt = parse_date(last_purchase_raw) if last_purchase_raw else v.last_purchase_date

        attachment_ref = request.form.get("attachment_ref", v.attachment_ref or "")
        file = request.files.get("attachment_file")
        if file and file.filename and allowed_file(file.filename):
            attachment_ref = save_uploaded_file(file, UPLOAD_FOLDER, f"vendor_{v.id}")
        elif not attachment_ref:
            attachment_ref = v.attachment_ref or ""

        v.name = name
        v.mobile = request.form.get("mobile", "")
        v.email = request.form.get("email", "")
        v.gst_no = request.form.get("gst_no", "")
        v.shop_name = request.form.get("shop_name", v.shop_name or "")
        v.area = request.form.get("area", v.area or "")
        v.city = request.form.get("city", v.city or "")
        v.state = request.form.get("state", v.state or "")
        v.pincode = request.form.get("pincode", v.pincode or "")
        v.address = request.form.get("address", v.address or "")
        v.vendor_type = request.form.get("vendor_type", v.vendor_type or "Distributor") or v.vendor_type or "Distributor"
        v.credit_days = to_int(request.form.get("credit_days"))
        v.credit_limit = to_float(request.form.get("credit_limit"))
        v.bank_name = request.form.get("bank_name", v.bank_name or "")
        v.account_holder_name = request.form.get("account_holder_name", v.account_holder_name or "")
        v.account_no = request.form.get("account_no", v.account_no or "")
        v.ifsc = request.form.get("ifsc", v.ifsc or "")
        v.upi = request.form.get("upi", v.upi or "")
        v.categories = request.form.get("categories", "")
        v.salts = request.form.get("salts", "")
        v.last_purchase_date = last_purchase_dt
        v.total_purchases = to_float(request.form.get("total_purchases"))
        v.outstanding_balance = to_float(request.form.get("outstanding_balance"))
        v.payment_status = request.form.get("payment_status", v.payment_status or "Paid") or v.payment_status or "Paid"
        v.rate_history = request.form.get("rate_history", "")
        v.default_payment_mode = request.form.get("default_payment_mode", v.default_payment_mode or "CASH") or v.default_payment_mode or "CASH"
        v.notes = request.form.get("notes", v.notes or "")
        v.attachment_ref = attachment_ref
        if "is_active" in request.form:
            v.is_active = True if request.form.get("is_active") else False

        db.session.commit()
        flash("Vendor updated successfully", "success")
        return redirect("/vendor")

    medicines = Medicine.query.order_by(Medicine.name).all()
    medicine_names = build_medicine_name_suggestions(medicines)
    medicine_code_lookup = build_medicine_code_lookup(medicines)
    medicine_purchase_catalog = build_medicine_purchase_catalog(medicines)
    purchase_items = VendorPurchaseItem.query.filter_by(vendor_id=v.id).order_by(VendorPurchaseItem.created_at.desc()).limit(50).all()
    today = date.today()
    for item in purchase_items:
        item.is_expired = False
        if item.expiry:
            try:
                exp_date = datetime.strptime(normalize_expiry(item.expiry), "%Y-%m-%d").date()
                if exp_date < today:
                    item.is_expired = True
            except ValueError:
                item.is_expired = False
    last_rates = []
    seen = set()
    for item in purchase_items:
        key = (item.medicine_name, item.batch)
        if key in seen:
            continue
        seen.add(key)
        last_rates.append(item)
    purchase_bills = VendorPurchase.query.filter_by(vendor_id=v.id).order_by(
        VendorPurchase.purchase_date.desc(),
        VendorPurchase.id.desc()
    ).all()
    recent_purchase_medicine_chips = build_recent_purchase_medicine_chips(purchase_items)

    return render_template(
        "vendor_form.html",
        vendor=v,
        medicines=medicines,
        medicine_names=medicine_names,
        medicine_code_lookup=medicine_code_lookup,
        medicine_purchase_catalog=medicine_purchase_catalog,
        purchase_items=purchase_items,
        last_rates=last_rates,
        purchase_bills=purchase_bills,
        recent_purchase_medicine_chips=recent_purchase_medicine_chips
    )

@app.route("/vendor/<int:id>/purchase", methods=["POST"])
@login_required
@inventory_access_required
def add_vendor_purchase(id):
    schema_ok, schema_err = ensure_inventory_runtime_schema()
    vendor = active_vendor_query().filter(Vendor.id == id).first_or_404()

    accepts_json = (
        request.headers.get("X-Requested-With") == "XMLHttpRequest"
        or "application/json" in (request.headers.get("Accept") or "")
    )

    def purchase_error(message, status_code=400):
        if accepts_json:
            return jsonify({"ok": False, "message": message}), status_code
        flash(message, "danger")
        return redirect(f"/vendor/edit/{vendor.id}")

    if not schema_ok:
        if schema_err:
            app.logger.error("Inventory schema check failed before vendor purchase save: %s", schema_err)
        return purchase_error("Unable to save purchase because inventory schema update failed.", 500)

    invoice_no = (request.form.get("invoice_no") or "").strip()
    if not invoice_no:
        return purchase_error("Bill/Invoice number is required")
    duplicate = VendorPurchase.query.filter(
        VendorPurchase.vendor_id == vendor.id,
        db.func.lower(VendorPurchase.invoice_no) == invoice_no.lower()
    ).first()
    if duplicate:
        return purchase_error("This bill number already exists for this vendor")

    purchase_date_val = (request.form.get("purchase_date") or "").strip()
    if purchase_date_val:
        parsed_purchase_date = parse_date(purchase_date_val)
        if not parsed_purchase_date:
            return purchase_error("Purchase date is invalid")
        purchase_date = datetime.combine(parsed_purchase_date, datetime.min.time())
    else:
        purchase_date = datetime.now()
    payment_mode = request.form.get("payment_mode") or vendor.default_payment_mode or "CASH"
    payment_status = request.form.get("payment_status") or vendor.payment_status or "Unpaid"
    paid_amount = to_float(request.form.get("paid_amount"))
    purchase_notes = (request.form.get("purchase_notes") or "").strip()
    bill_attachment_file = request.files.get("bill_attachment_file")
    if bill_attachment_file and (bill_attachment_file.filename or "").strip() and not allowed_file(bill_attachment_file.filename):
        return purchase_error("Bill photo must be PDF, JPG or PNG")

    raw_items_json = (request.form.get("purchase_items_json") or "").strip()
    raw_items = []
    if raw_items_json:
        try:
            parsed_items = json.loads(raw_items_json)
        except ValueError:
            return purchase_error("Purchase items payload is invalid JSON")
        if not isinstance(parsed_items, list):
            return purchase_error("Purchase items payload must be a list")
        raw_items = parsed_items
    else:
        names = request.form.getlist("medicine_name")
        compositions = request.form.getlist("composition")
        companies = request.form.getlist("company")
        distributors = request.form.getlist("distributor_name")
        medicine_codes = request.form.getlist("medicine_code")
        pack_types = request.form.getlist("pack_type")
        pack_qtys = request.form.getlist("pack_qty")
        batches = request.form.getlist("batch")
        barcodes = request.form.getlist("barcode")
        expiries = request.form.getlist("expiry")
        qtys = request.form.getlist("qty")
        free_qtys = request.form.getlist("free_qty")
        purchase_rates = request.form.getlist("purchase_rate")
        mrps = request.form.getlist("mrp")
        gst_percents = request.form.getlist("gst_percent")
        discount_percents = request.form.getlist("discount_percent")
        item_notes = request.form.getlist("item_notes")

        for idx, raw_name in enumerate(names):
            raw_items.append({
                "medicine_name": raw_name,
                "medicine_code": medicine_codes[idx] if idx < len(medicine_codes) else "",
                "barcode": barcodes[idx] if idx < len(barcodes) else "",
                "composition": compositions[idx] if idx < len(compositions) else "",
                "company": companies[idx] if idx < len(companies) else "",
                "distributor_name": distributors[idx] if idx < len(distributors) else "",
                "pack_type": pack_types[idx] if idx < len(pack_types) else "",
                "pack_qty": pack_qtys[idx] if idx < len(pack_qtys) else "",
                "batch": batches[idx] if idx < len(batches) else "",
                "expiry": expiries[idx] if idx < len(expiries) else "",
                "qty": qtys[idx] if idx < len(qtys) else 0,
                "free_qty": free_qtys[idx] if idx < len(free_qtys) else 0,
                "purchase_rate": purchase_rates[idx] if idx < len(purchase_rates) else 0,
                "mrp": mrps[idx] if idx < len(mrps) else 0,
                "gst_percent": gst_percents[idx] if idx < len(gst_percents) else 0,
                "discount_percent": discount_percents[idx] if idx < len(discount_percents) else 0,
                "notes": item_notes[idx] if idx < len(item_notes) else "",
            })

    line_items = []
    subtotal = 0
    gst_total = 0
    discount_total = 0
    total_amount = 0

    for raw_item in raw_items:
        if not isinstance(raw_item, dict):
            continue

        entered_name = normalize_medicine_name(raw_item.get("medicine_name"))
        medicine_code = normalize_medicine_code(raw_item.get("medicine_code"))
        batch = (raw_item.get("batch") or "").strip()
        barcode = (raw_item.get("barcode") or "").strip()
        expiry_raw = (raw_item.get("expiry") or "").strip()
        expiry = normalize_expiry(expiry_raw)
        qty = to_int(raw_item.get("qty"))
        free_qty = to_int(raw_item.get("free_qty"))
        purchase_rate = to_float(raw_item.get("purchase_rate", raw_item.get("rate")))
        mrp = to_float(raw_item.get("mrp"))
        gst_percent = to_float(raw_item.get("gst_percent", raw_item.get("gst")))
        discount_percent = to_float(raw_item.get("discount_percent", raw_item.get("discount")))
        composition = (raw_item.get("composition") or "").strip()
        company = (raw_item.get("company") or "").strip()
        distributor_name = (raw_item.get("distributor_name") or "").strip()
        pack_type = (raw_item.get("pack_type") or "").strip()
        pack_qty_raw = str(raw_item.get("pack_qty") or "").strip()
        pack_qty = parse_pack_qty(pack_qty_raw)
        item_notes = (raw_item.get("notes") or "").strip()

        row_has_data = any(
            [
                entered_name,
                medicine_code,
                batch,
                barcode,
                expiry_raw,
                composition,
                company,
                qty > 0,
                free_qty > 0,
                purchase_rate > 0,
                mrp > 0,
                gst_percent > 0,
                discount_percent > 0,
                bool(pack_qty_raw),
            ]
        )
        if not row_has_data:
            continue
        resolved_code = medicine_code
        canonical_code_name = ""
        if medicine_code and not entered_name:
            resolved_code, canonical_code_name, code_error = resolve_medicine_code_mapping(medicine_code)
            if code_error:
                return purchase_error(code_error)
        name = entered_name or canonical_code_name
        if not name:
            return purchase_error("Medicine name is required for each purchase row")
        if not batch or not expiry:
            return purchase_error(f"Batch and expiry required for {name}")
        if qty <= 0:
            continue
        if not pack_type:
            return purchase_error(f"Pack type is required for {name}")
        if not pack_qty_raw or pack_qty is None or pack_qty < 1:
            return purchase_error(f"Pack quantity must be at least 1 for {name}")

        base_amount = qty * purchase_rate
        discount_amt = base_amount * discount_percent / 100
        taxable = base_amount - discount_amt
        gst_amt = taxable * gst_percent / 100
        total_value = taxable + gst_amt

        subtotal += taxable
        gst_total += gst_amt
        discount_total += discount_amt
        total_amount += total_value

        line_items.append({
            "name": name,
            "medicine_code": resolved_code,
            "composition": composition,
            "company": company,
            "distributor_name": distributor_name,
            "pack_type": pack_type,
            "pack_qty": pack_qty,
            "batch": batch,
            "barcode": barcode,
            "expiry": expiry,
            "qty": qty,
            "free_qty": free_qty,
            "purchase_rate": purchase_rate,
            "mrp": mrp,
            "gst_percent": gst_percent,
            "discount_percent": discount_percent,
            "notes": item_notes,
            "total_value": total_value
        })

    if not line_items:
        return purchase_error("Please add at least one medicine to purchase")

    # Warn (not block) when the landed cost per unit is above MRP: this is
    # almost always a typing mistake and would mean selling at a loss.
    costly_lines = [
        f'{row["name"]} ({row["batch"]})'
        for row in line_items
        if to_float_safe(row.get("mrp"), 0) > 0
        and to_float_safe(row.get("purchase_rate"), 0) * (1 + to_float_safe(row.get("gst_percent"), 0) / 100)
        > to_float_safe(row.get("mrp"), 0)
    ]

    saved_bill_attachment_ref = ""
    try:
        purchase = VendorPurchase(
            vendor_id=vendor.id,
            purchase_date=purchase_date,
            invoice_no=invoice_no,
            payment_mode=payment_mode,
            payment_status=payment_status,
            paid_amount=paid_amount,
            notes=purchase_notes,
            subtotal=subtotal,
            gst_total=gst_total,
            discount_total=discount_total,
            total_amount=total_amount,
            created_by=session.get("username")
        )
        db.session.add(purchase)
        db.session.flush()
        assign_purchase_number(purchase, purchase_date)
        if bill_attachment_file and (bill_attachment_file.filename or "").strip():
            saved_bill_attachment_ref = save_uploaded_file(
                bill_attachment_file,
                VENDOR_BILL_UPLOAD_FOLDER,
                f"vendorbill_{vendor.id}_{purchase.id}"
            )
            purchase.bill_attachment_ref = saved_bill_attachment_ref

        target_codes_by_name = {}
        for item in line_items:
            item_name = normalize_medicine_name(item["name"])
            if item_name and item_name not in target_codes_by_name:
                target_codes_by_name[item_name] = resolve_target_medicine_code_for_name(item_name)

        for item in line_items:
            target_code = target_codes_by_name.get(normalize_medicine_name(item["name"]), "")
            med = find_medicine_by_name_batch(item["name"], item["batch"])
            if not med:
                discount_template = find_medicine_discount_template(
                    item["name"],
                    item["pack_type"],
                    item.get("pack_qty")
                )
                med = Medicine(
                    name=item["name"],
                    medicine_code="",
                    composition=item["composition"],
                    company=item["company"],
                    pack_type=item["pack_type"],
                    pack_qty=item["pack_qty"],
                    batch=item["batch"],
                    barcode=item["barcode"] or "",
                    expiry=item["expiry"],
                    mrp=item["mrp"] or 0,
                    qty=0,
                    gst_percent=normalize_gst_percent(item.get("gst_percent"), default_gst_percent()),
                    # Keep selling discount in sync across new batches of the same medicine.
                    discount_percent=int(
                        to_float_safe(
                            getattr(discount_template, "discount_percent", item["discount_percent"]),
                            item["discount_percent"]
                        ) or 0
                    )
                )
                med = persist_new_medicine_record(med)
                tenant_id = current_tenant_id()
                if (
                    not tenant_id
                    or not med.id
                    or med.id <= 0
                    or med.tenant_id != tenant_id
                ):
                    raise RuntimeError(
                        "New purchase medicine was not persisted for the active tenant."
                    )
                med = Medicine.query.filter(
                    Medicine.id == med.id,
                    Medicine.tenant_id == tenant_id,
                ).first()
                if med is None:
                    raise RuntimeError(
                        "New purchase medicine could not be retrieved for the active tenant."
                    )
            else:
                if item["expiry"]:
                    med.expiry = item["expiry"]
                if item["mrp"]:
                    med.mrp = item["mrp"]
                if item["composition"]:
                    med.composition = item["composition"]
                if item["company"]:
                    med.company = item["company"]
                if item["pack_type"]:
                    med.pack_type = item["pack_type"]
                if item.get("pack_qty") is not None:
                    med.pack_qty = item["pack_qty"]
                if to_float_safe(item.get("gst_percent"), 0) > 0:
                    med.gst_percent = normalize_gst_percent(item.get("gst_percent"), medicine_gst_percent(med))
            if target_code:
                med.medicine_code = target_code
            if item["barcode"]:
                med.barcode = item["barcode"]

            effective_barcode = item["barcode"] or ((getattr(med, "barcode", "") or "").strip())

            old_stock = med.qty
            med.qty += item["qty"] + item["free_qty"]

            history = StockHistory(
                tenant_id=current_tenant_id(),
                medicine_id=med.id,
                medicine_name=med.name,
                batch=med.batch,
                action="PURCHASE",
                stock_before=old_stock,
                qty_change=item["qty"] + item["free_qty"],
                stock_after=med.qty,
                user=session.get("username"),
                remark=f"Purchase {purchase.purchase_no} from {vendor.name}"
            )
            db.session.add(history)

            db.session.add(VendorPurchaseItem(
                tenant_id=current_tenant_id(),
                purchase_id=purchase.id,
                vendor_id=vendor.id,
                medicine_id=med.id,
                medicine_name=item["name"],
                medicine_code=target_code,
                barcode=effective_barcode,
                composition=item["composition"],
                company=item["company"],
                distributor_name=item["distributor_name"],
                pack_type=item["pack_type"],
                pack_qty=item["pack_qty"],
                batch=item["batch"],
                expiry=item["expiry"],
                qty=item["qty"],
                free_qty=item["free_qty"],
                remaining_qty=item["qty"] + item["free_qty"],
                purchase_rate=item["purchase_rate"],
                mrp=item["mrp"],
                gst_percent=item["gst_percent"],
                discount_percent=item["discount_percent"],
                notes=item["notes"],
                total_value=item["total_value"]
            ))

        vendor.last_purchase_date = purchase_date.date() if purchase_date else vendor.last_purchase_date
        vendor.total_purchases = (vendor.total_purchases or 0) + total_amount
        vendor.payment_status = payment_status
        if payment_status.lower() in ("unpaid", "partial"):
            balance_add = total_amount - paid_amount if payment_status.lower() == "partial" else total_amount
            if balance_add < 0:
                balance_add = 0
            vendor.outstanding_balance = (vendor.outstanding_balance or 0) + balance_add

        touched_names = [item["name"] for item in line_items]
        build_scoped_medicine_code_sync(touched_names)
        db.session.commit()
    except IntegrityError as exc:
        db.session.rollback()
        if saved_bill_attachment_ref:
            delete_uploaded_file(VENDOR_BILL_UPLOAD_FOLDER, saved_bill_attachment_ref)
        app.logger.exception(
            "Vendor purchase save failed with integrity error for vendor_id=%s invoice_no=%s",
            vendor.id,
            invoice_no,
        )
        error_text = str(getattr(exc, "orig", exc)).lower()
        if "invoice" in error_text and ("duplicate" in error_text or "unique" in error_text):
            return purchase_error("This bill number already exists. Please use a different bill number.")
        if "purchase_no" in error_text and ("duplicate" in error_text or "unique" in error_text):
            return purchase_error("Purchase number collision detected. Please retry once.", 500)
        return purchase_error(
            f"Unable to save purchase right now. {summarize_exception_message(exc)}",
            500,
        )
    except SQLAlchemyError as exc:
        db.session.rollback()
        if saved_bill_attachment_ref:
            delete_uploaded_file(VENDOR_BILL_UPLOAD_FOLDER, saved_bill_attachment_ref)
        app.logger.exception(
            "Vendor purchase save failed with database error for vendor_id=%s invoice_no=%s",
            vendor.id,
            invoice_no,
        )
        return purchase_error(
            f"Unable to save purchase right now. {summarize_exception_message(exc)}",
            500,
        )
    except Exception as exc:
        db.session.rollback()
        if saved_bill_attachment_ref:
            delete_uploaded_file(VENDOR_BILL_UPLOAD_FOLDER, saved_bill_attachment_ref)
        app.logger.exception(
            "Vendor purchase save failed unexpectedly for vendor_id=%s invoice_no=%s",
            vendor.id,
            invoice_no,
        )
        return purchase_error(
            f"Unable to save purchase right now. {summarize_exception_message(exc)}",
            500,
        )

    success_message = "Purchase saved. Stock updated."
    cost_warning = ""
    if costly_lines:
        cost_warning = (
            "Check rates: cost incl. GST is above MRP for "
            + ", ".join(costly_lines[:5])
            + ("..." if len(costly_lines) > 5 else "")
        )
        success_message = f"{success_message} WARNING: {cost_warning}"
    if accepts_json:
        return jsonify({
            "ok": True,
            "message": success_message,
            "warnings": [cost_warning] if cost_warning else [],
            "purchase_id": purchase.id,
            "purchase_no": purchase.purchase_no,
            "redirect_url": f"/vendor/edit/{vendor.id}",
            "totals": {
                "subtotal": subtotal,
                "gst_total": gst_total,
                "discount_total": discount_total,
                "total_amount": total_amount,
                "rounded_total": round(total_amount),
            },
        }), 200
    flash("Purchase saved. Stock updated.", "success")
    if cost_warning:
        flash(cost_warning, "warning")
    return redirect(f"/vendor/edit/{vendor.id}")

@app.route("/vendor/purchase/<int:purchase_id>")
@login_required
@inventory_access_required
def view_vendor_purchase(purchase_id):
    purchase = VendorPurchase.query.get_or_404(purchase_id)
    vendor = Vendor.query.get(purchase.vendor_id)
    items = VendorPurchaseItem.query.filter_by(purchase_id=purchase.id).order_by(VendorPurchaseItem.id.asc()).all()
    mode = (request.args.get("mode") or "view").lower()
    return render_template(
        "vendor_purchase_view.html",
        vendor=vendor,
        purchase=purchase,
        items=items,
        mode=mode
    )

@app.route("/vendor/purchase/<int:purchase_id>/bill-file")
@login_required
@inventory_access_required
def view_vendor_purchase_bill_file(purchase_id):
    purchase = VendorPurchase.query.get_or_404(purchase_id)
    filename = (purchase.bill_attachment_ref or "").strip()
    if not filename:
        return "No bill photo uploaded for this purchase.", 404
    cleaned_name, base_dir, file_path = resolve_tenant_upload_file(VENDOR_BILL_UPLOAD_FOLDER, filename)
    if not cleaned_name:
        return "Bill photo file not found on server.", 404
    if not os.path.exists(file_path):
        return "Bill photo file not found on server.", 404
    return send_from_directory(base_dir, cleaned_name, as_attachment=False)

@app.route("/vendor/purchase/<int:purchase_id>/bill-file/upload", methods=["POST"])
@login_required
@inventory_access_required
def upload_vendor_purchase_bill_file(purchase_id):
    purchase = VendorPurchase.query.get_or_404(purchase_id)
    bill_attachment_file = request.files.get("bill_attachment_file")
    if not bill_attachment_file or not (bill_attachment_file.filename or "").strip():
        flash("Please choose a bill photo or PDF to upload", "danger")
        return redirect(url_for("view_vendor_purchase", purchase_id=purchase.id))
    if not allowed_file(bill_attachment_file.filename):
        flash("Bill photo must be PDF, JPG or PNG", "danger")
        return redirect(url_for("view_vendor_purchase", purchase_id=purchase.id))

    old_attachment = purchase.bill_attachment_ref or ""
    purchase.bill_attachment_ref = save_uploaded_file(
        bill_attachment_file,
        VENDOR_BILL_UPLOAD_FOLDER,
        f"vendorbill_{purchase.vendor_id}_{purchase.id}"
    )
    db.session.commit()
    if old_attachment and old_attachment != purchase.bill_attachment_ref:
        delete_uploaded_file(VENDOR_BILL_UPLOAD_FOLDER, old_attachment)
    flash("Bill photo uploaded successfully", "success")
    return redirect(url_for("view_vendor_purchase", purchase_id=purchase.id))

@app.route("/vendor/purchase/delete/<int:purchase_id>", methods=["POST"])
@login_required
@inventory_access_required
def delete_vendor_purchase(purchase_id):
    purchase = VendorPurchase.query.get_or_404(purchase_id)
    vendor = Vendor.query.get(purchase.vendor_id)
    items = VendorPurchaseItem.query.filter_by(purchase_id=purchase.id).all()
    bill_no = purchase.invoice_no if purchase.invoice_no else (purchase.purchase_no or f"PB-{purchase.id:06d}")

    linked_note = VendorNote.query.filter_by(reference_purchase_id=purchase.id).first()
    if linked_note:
        flash("Cannot delete this bill because vendor note entries are linked to it.", "danger")
        return redirect(f"/vendor/edit/{purchase.vendor_id}")

    item_ids = [it.id for it in items]
    if item_ids:
        linked_alloc = SalesAllocation.query.filter(SalesAllocation.purchase_item_id.in_(item_ids)).first()
        if linked_alloc:
            flash("Cannot delete this bill because invoice/return transactions are linked.", "danger")
            return redirect(f"/vendor/edit/{purchase.vendor_id}")

    for it in items:
        total_qty = to_int(it.qty) + to_int(it.free_qty)
        if total_qty <= 0:
            continue
        med = Medicine.query.get(it.medicine_id) if it.medicine_id else None
        if not med:
            med = find_medicine_by_name_batch(it.medicine_name, it.batch)
        if not med:
            flash(f"Cannot delete bill. Medicine missing: {it.medicine_name} ({it.batch})", "danger")
            return redirect(f"/vendor/edit/{purchase.vendor_id}")
        if to_int(med.qty) < total_qty:
            flash(
                f"Cannot delete bill. Stock already used for {med.name} ({med.batch}). "
                "Return/cancel related sales first.",
                "danger"
            )
            return redirect(f"/vendor/edit/{purchase.vendor_id}")

    purchase_total = to_float(purchase.total_amount)
    status = (purchase.payment_status or "").strip().lower()
    bill_attachment_ref = purchase.bill_attachment_ref or ""
    raw_paid_amount = getattr(purchase, "paid_amount", None)
    paid_amount = to_float(raw_paid_amount)
    if paid_amount < 0:
        paid_amount = 0
    outstanding_reduction = purchase_total
    legacy_partial_unknown = False
    if status == "partial":
        if raw_paid_amount is None:
            legacy_partial_unknown = True
            outstanding_reduction = 0
        else:
            outstanding_reduction = purchase_total - paid_amount
    if outstanding_reduction < 0:
        outstanding_reduction = 0

    purchase_no = purchase.purchase_no or f"PB-{purchase.id:06d}"

    for it in items:
        total_qty = to_int(it.qty) + to_int(it.free_qty)
        if total_qty <= 0:
            continue
        med = Medicine.query.get(it.medicine_id) if it.medicine_id else None
        if not med:
            med = find_medicine_by_name_batch(it.medicine_name, it.batch)
        if not med:
            continue
        old_stock = to_int(med.qty)
        med.qty = old_stock - total_qty
        db.session.add(StockHistory(
            medicine_id=med.id,
            medicine_name=med.name,
            batch=med.batch,
            action="PURCHASE_DELETE",
            stock_before=old_stock,
            qty_change=-total_qty,
            stock_after=med.qty,
            user=session.get("username"),
            remark=f"Purchase bill deleted {bill_no}",
            ref_table="vendor_purchase",
            ref_id=purchase.id
        ))

    if vendor:
        vendor.total_purchases = max((vendor.total_purchases or 0) - purchase_total, 0)
        if status == "unpaid":
            vendor.outstanding_balance = max((vendor.outstanding_balance or 0) - outstanding_reduction, 0)
        elif status == "partial" and not legacy_partial_unknown:
            vendor.outstanding_balance = max((vendor.outstanding_balance or 0) - outstanding_reduction, 0)
        latest_purchase = VendorPurchase.query.filter(
            VendorPurchase.vendor_id == vendor.id,
            VendorPurchase.id != purchase.id
        ).order_by(VendorPurchase.purchase_date.desc(), VendorPurchase.id.desc()).first()
        vendor.last_purchase_date = latest_purchase.purchase_date.date() if latest_purchase and latest_purchase.purchase_date else None
        if (vendor.outstanding_balance or 0) <= 0:
            vendor.payment_status = "Paid"
        elif latest_purchase and latest_purchase.payment_status:
            vendor.payment_status = latest_purchase.payment_status

    StockHistory.query.filter(
        StockHistory.action == "PURCHASE",
        StockHistory.remark.like(f"Purchase {purchase_no}%")
    ).delete(synchronize_session=False)
    if item_ids:
        StockHistory.query.filter(
            StockHistory.action == "PURCHASE_EDIT",
            StockHistory.remark.in_([f"Purchase item {item_id} edited" for item_id in item_ids])
        ).delete(synchronize_session=False)

    VendorLedgerEntry.query.filter_by(ref_table="vendor_purchase", ref_id=purchase.id).delete(synchronize_session=False)
    VendorPurchaseItem.query.filter_by(purchase_id=purchase.id).delete(synchronize_session=False)
    db.session.delete(purchase)

    db.session.commit()
    if bill_attachment_ref:
        delete_uploaded_file(VENDOR_BILL_UPLOAD_FOLDER, bill_attachment_ref)
    if legacy_partial_unknown:
        flash(
            f"Bill {bill_no} deleted. Outstanding balance for old partial bill was not auto-adjusted (paid amount missing).",
            "warning"
        )
    flash(f"Bill {bill_no} deleted. Linked purchase entries and stock updates removed.", "warning")
    return redirect(f"/vendor/edit/{purchase.vendor_id}")

@app.route("/vendor/purchase-item/edit/<int:item_id>", methods=["GET", "POST"])
@login_required
@inventory_access_required
def edit_vendor_purchase_item(item_id):
    item = VendorPurchaseItem.query.get_or_404(item_id)
    purchase = VendorPurchase.query.get(item.purchase_id)
    vendor = Vendor.query.get(item.vendor_id)
    redirect_url = f"/vendor/purchase/{item.purchase_id}?mode=edit"
    async_mode = is_async_request()

    def item_payload(row_item, med_row, sold_units):
        pack_type = (getattr(row_item, "pack_type", "") or "").strip()
        pack_qty = getattr(row_item, "pack_qty", None)
        if pack_type and pack_qty:
            pack_display = f"{pack_type} of {pack_qty}"
        elif pack_type:
            pack_display = pack_type
        elif pack_qty:
            pack_display = str(pack_qty)
        else:
            pack_display = "-"
        return {
            "id": row_item.id,
            "medicine_name": row_item.medicine_name,
            "medicine_code": normalize_medicine_code(getattr(row_item, "medicine_code", "")),
            "barcode": getattr(row_item, "barcode", "") or "",
            "composition": getattr(row_item, "composition", "") or "",
            "company": getattr(row_item, "company", "") or "",
            "distributor_name": getattr(row_item, "distributor_name", "") or "",
            "pack_type": pack_type,
            "pack_qty": pack_qty,
            "pack_display": pack_display,
            "batch": row_item.batch,
            "expiry": row_item.expiry,
            "qty": to_int(row_item.qty),
            "free_qty": to_int(row_item.free_qty),
            "remaining_qty": to_int(getattr(row_item, "remaining_qty", 0)),
            "sold_qty": sold_units,
            "purchase_rate": to_float(row_item.purchase_rate),
            "mrp": to_float(row_item.mrp),
            "gst_percent": to_float(row_item.gst_percent),
            "discount_percent": to_float(row_item.discount_percent),
            "total_value": to_float(getattr(row_item, "total_value", 0)),
            "medicine_master_qty": to_int(getattr(med_row, "qty", 0)) if med_row else None,
        }

    def totals_payload(purchase_row):
        if not purchase_row:
            return {
                "subtotal": 0.0,
                "gst_total": 0.0,
                "discount_total": 0.0,
                "total_amount": 0.0,
            }
        return {
            "subtotal": round(to_float(getattr(purchase_row, "subtotal", 0)), 2),
            "gst_total": round(to_float(getattr(purchase_row, "gst_total", 0)), 2),
            "discount_total": round(to_float(getattr(purchase_row, "discount_total", 0)), 2),
            "total_amount": round(to_float(getattr(purchase_row, "total_amount", 0)), 2),
        }

    def error_response(message):
        if async_mode:
            return jsonify({"ok": False, "message": message}), 400
        flash(message, "danger")
        return redirect(request.url)

    med = Medicine.query.get(item.medicine_id) if item.medicine_id else None
    if not med:
        med = find_medicine_by_name_batch(item.medicine_name, item.batch)

    old_total_qty = to_int(item.qty) + to_int(item.free_qty)
    sold_qty = old_total_qty - to_int(item.remaining_qty)
    if sold_qty < 0:
        sold_qty = 0

    if request.method == "POST":
        name = (request.form.get("medicine_name") or "").strip()
        composition = (request.form.get("composition") or "").strip()
        company = (request.form.get("company") or "").strip()
        distributor_name = (request.form.get("distributor_name") or "").strip()
        pack_type = (request.form.get("pack_type") or "").strip()
        pack_qty_raw = (request.form.get("pack_qty") or "").strip()
        pack_qty = parse_pack_qty(pack_qty_raw)
        batch = (request.form.get("batch") or "").strip()
        barcode = (request.form.get("barcode") or "").strip()
        expiry_raw = (request.form.get("expiry") or "").strip()
        expiry = normalize_expiry(expiry_raw)
        qty = to_int(request.form.get("qty"))
        free_qty = to_int(request.form.get("free_qty"))
        purchase_rate = to_float(request.form.get("purchase_rate"))
        mrp = to_float(request.form.get("mrp"))
        gst_percent = to_float(request.form.get("gst_percent"))
        discount_percent = to_float(request.form.get("discount_percent"))

        if not name:
            return error_response("Medicine name is required")
        if not batch or not expiry:
            return error_response("Batch and expiry are required")
        if qty <= 0:
            return error_response("Quantity must be greater than 0")
        if pack_qty_raw and (pack_qty is None or pack_qty < 1):
            return error_response("Pack quantity must be at least 1")

        new_total_qty = qty + free_qty
        if new_total_qty < sold_qty:
            return error_response(f"Cannot reduce below sold quantity ({sold_qty})")

        old_base = to_float(item.qty) * to_float(item.purchase_rate)
        old_discount = old_base * to_float(item.discount_percent) / 100
        old_taxable = old_base - old_discount
        old_gst = old_taxable * to_float(item.gst_percent) / 100
        old_total = old_taxable + old_gst

        new_base = qty * purchase_rate
        new_discount = new_base * discount_percent / 100
        new_taxable = new_base - new_discount
        new_gst = new_taxable * gst_percent / 100
        new_total = new_taxable + new_gst

        diff_total_qty = new_total_qty - old_total_qty
        old_med_qty = med.qty if med else None

        if med:
            if med.qty + diff_total_qty < 0:
                return error_response("Not enough stock to reduce this purchase quantity")
            med.qty = med.qty + diff_total_qty
            med.name = name
            med.batch = batch
            med.expiry = expiry
            med.mrp = mrp
            med.composition = composition
            med.company = company
            med.pack_type = pack_type
            if pack_qty_raw:
                med.pack_qty = pack_qty
            if barcode:
                med.barcode = barcode

        item.medicine_name = name
        item.medicine_code = normalize_medicine_code(getattr(med, "medicine_code", ""))
        if barcode:
            item.barcode = barcode
        item.composition = composition
        item.company = company
        item.distributor_name = distributor_name
        item.pack_type = pack_type
        if pack_qty_raw:
            item.pack_qty = pack_qty
        item.batch = batch
        item.expiry = expiry
        item.qty = qty
        item.free_qty = free_qty
        item.remaining_qty = new_total_qty - sold_qty
        item.purchase_rate = purchase_rate
        item.mrp = mrp
        item.gst_percent = gst_percent
        item.discount_percent = discount_percent
        item.total_value = new_total

        if purchase:
            purchase.subtotal = max((purchase.subtotal or 0) - old_taxable + new_taxable, 0)
            purchase.gst_total = max((purchase.gst_total or 0) - old_gst + new_gst, 0)
            purchase.discount_total = max((purchase.discount_total or 0) - old_discount + new_discount, 0)
            purchase.total_amount = max((purchase.total_amount or 0) - old_total + new_total, 0)

        if vendor:
            delta_total = new_total - old_total
            vendor.total_purchases = (vendor.total_purchases or 0) + delta_total
            if purchase and (purchase.payment_status or "").lower() in ("unpaid", "partial"):
                vendor.outstanding_balance = (vendor.outstanding_balance or 0) + delta_total

        if diff_total_qty != 0 and med:
            history = StockHistory(
                medicine_id=med.id,
                medicine_name=name,
                batch=batch,
                action="PURCHASE_EDIT",
                stock_before=old_med_qty,
                qty_change=diff_total_qty,
                stock_after=med.qty,
                user=session.get("username"),
                remark=f"Purchase item {item.id} edited"
            )
            db.session.add(history)

        build_scoped_medicine_code_sync([name])
        db.session.commit()
        if async_mode:
            refreshed_item = VendorPurchaseItem.query.get(item.id)
            refreshed_med = Medicine.query.get(refreshed_item.medicine_id) if refreshed_item and refreshed_item.medicine_id else med
            refreshed_sold_qty = (to_int(refreshed_item.qty) + to_int(refreshed_item.free_qty) - to_int(refreshed_item.remaining_qty)) if refreshed_item else sold_qty
            return jsonify({
                "ok": True,
                "message": "Purchase item updated successfully",
                "item": item_payload(refreshed_item, refreshed_med, refreshed_sold_qty),
                "purchase_totals": totals_payload(purchase),
                "purchase_item_count": VendorPurchaseItem.query.filter_by(purchase_id=item.purchase_id).count(),
            }), 200
        flash("Purchase item updated successfully", "success")
        return redirect(redirect_url)

    resolved_barcode = (getattr(item, "barcode", "") or (getattr(med, "barcode", "") if med else "") or "")
    resolved_medicine_code = normalize_medicine_code(
        getattr(item, "medicine_code", "") or (getattr(med, "medicine_code", "") if med else "") or ""
    )
    return render_template(
        "edit_purchase_item.html",
        item=item,
        vendor=vendor,
        purchase=purchase,
        sold_qty=sold_qty,
        resolved_barcode=resolved_barcode,
        resolved_medicine_code=resolved_medicine_code
    )


@app.route("/vendor/purchase-item/delete/<int:item_id>", methods=["POST"])
@login_required
@inventory_access_required
def delete_vendor_purchase_item(item_id):
    item = VendorPurchaseItem.query.get_or_404(item_id)
    purchase = VendorPurchase.query.get(item.purchase_id)
    vendor = Vendor.query.get(item.vendor_id)
    redirect_url = f"/vendor/purchase/{item.purchase_id}?mode=edit"
    async_mode = is_async_request()

    def delete_error(message):
        if async_mode:
            return jsonify({"ok": False, "message": message}), 400
        flash(message, "danger")
        return redirect(redirect_url)

    purchase_item_count = VendorPurchaseItem.query.filter_by(purchase_id=item.purchase_id).count()
    if purchase_item_count <= 1:
        return delete_error("This is the last item in the bill. Delete the full bill instead.")

    linked_note_alloc = VendorNoteAllocation.query.filter_by(purchase_item_id=item.id).first()
    if linked_note_alloc:
        return delete_error("Cannot delete this item because vendor note entries are linked to it.")

    linked_alloc = SalesAllocation.query.filter_by(purchase_item_id=item.id).first()
    if linked_alloc:
        return delete_error("Cannot delete this item because invoice/return transactions are linked.")

    med = Medicine.query.get(item.medicine_id) if item.medicine_id else None
    if not med:
        med = find_medicine_by_name_batch(item.medicine_name, item.batch)
    if not med:
        return delete_error(f"Cannot delete item. Medicine missing: {item.medicine_name} ({item.batch})")

    old_total_qty = to_int(item.qty) + to_int(item.free_qty)
    sold_qty = old_total_qty - to_int(item.remaining_qty)
    if sold_qty < 0:
        sold_qty = 0
    if sold_qty > 0:
        return delete_error(f"Cannot delete this item because {sold_qty} unit(s) are already sold/used.")

    if to_int(med.qty) < old_total_qty:
        return delete_error("Not enough stock available to remove this purchase item safely.")

    old_base = to_float(item.qty) * to_float(item.purchase_rate)
    old_discount = old_base * to_float(item.discount_percent) / 100
    old_taxable = old_base - old_discount
    old_gst = old_taxable * to_float(item.gst_percent) / 100
    old_total = old_taxable + old_gst

    old_med_qty = to_int(med.qty)
    med.qty = old_med_qty - old_total_qty
    db.session.add(StockHistory(
        medicine_id=med.id,
        medicine_name=med.name,
        batch=med.batch,
        action="PURCHASE_ITEM_DELETE",
        stock_before=old_med_qty,
        qty_change=-old_total_qty,
        stock_after=med.qty,
        user=session.get("username"),
        remark=f"Purchase item {item.id} deleted from {purchase.purchase_no if purchase and purchase.purchase_no else item.purchase_id}",
        ref_table="vendor_purchase",
        ref_id=item.purchase_id
    ))

    if purchase:
        purchase.subtotal = max((purchase.subtotal or 0) - old_taxable, 0)
        purchase.gst_total = max((purchase.gst_total or 0) - old_gst, 0)
        purchase.discount_total = max((purchase.discount_total or 0) - old_discount, 0)
        purchase.total_amount = max((purchase.total_amount or 0) - old_total, 0)

    if vendor:
        vendor.total_purchases = max((vendor.total_purchases or 0) - old_total, 0)
        if purchase and (purchase.payment_status or "").lower() in ("unpaid", "partial"):
            vendor.outstanding_balance = max((vendor.outstanding_balance or 0) - old_total, 0)
            if (vendor.outstanding_balance or 0) <= 0:
                vendor.payment_status = "Paid"

    db.session.delete(item)
    db.session.commit()
    if async_mode:
        return jsonify({
            "ok": True,
            "message": "Purchase item deleted successfully. Stock and totals updated.",
            "deleted_item_id": item_id,
            "purchase_totals": {
                "subtotal": round(to_float(getattr(purchase, "subtotal", 0)), 2) if purchase else 0.0,
                "gst_total": round(to_float(getattr(purchase, "gst_total", 0)), 2) if purchase else 0.0,
                "discount_total": round(to_float(getattr(purchase, "discount_total", 0)), 2) if purchase else 0.0,
                "total_amount": round(to_float(getattr(purchase, "total_amount", 0)), 2) if purchase else 0.0,
            },
            "purchase_item_count": VendorPurchaseItem.query.filter_by(purchase_id=item.purchase_id).count(),
        }), 200
    flash("Purchase item deleted successfully. Stock and totals updated.", "success")
    return redirect(redirect_url)

@app.route("/api/vendor-purchases/<int:purchase_id>/items", methods=["GET"])
@login_required
@vendor_note_access_required(api=True)
def api_vendor_purchase_items(purchase_id):
    purchase = VendorPurchase.query.get_or_404(purchase_id)
    items = VendorPurchaseItem.query.filter_by(purchase_id=purchase.id).order_by(VendorPurchaseItem.id.asc()).all()

    payload_items = []
    for it in items:
        payload_items.append({
            "id": it.id,
            "medicine_id": it.medicine_id,
            "medicine_name": it.medicine_name,
            "medicine_code": normalize_medicine_code(getattr(it, "medicine_code", "")),
            "batch": it.batch,
            "barcode": getattr(it, "barcode", "") or "",
            "expiry": it.expiry,
            "qty": to_int(it.qty),
            "free_qty": to_int(it.free_qty),
            "remaining_qty": to_int(it.remaining_qty),
            "purchase_rate": to_float(it.purchase_rate),
            "mrp": to_float(it.mrp),
            "gst_percent": to_float(it.gst_percent),
            "disc_percent": to_float(it.discount_percent),
            "hsn": ""
        })

    return jsonify({
        "purchase_id": purchase.id,
        "vendor_id": purchase.vendor_id,
        "invoice_no": purchase.invoice_no,
        "purchase_no": purchase.purchase_no,
        "items": payload_items
    }), 200

# ---------------- VENDOR NOTES (DEBIT/CREDIT) ----------------
@app.route("/api/vendor-notes", methods=["POST"])
@login_required
@vendor_note_access_required(api=True)
def api_create_vendor_note():
    data = request.get_json(silent=True) or {}
    note_type = (data.get("note_type") or "").strip().upper()
    if note_type not in ("DEBIT", "CREDIT"):
        return jsonify({"error": "Invalid note_type"}), 400

    vendor_id = data.get("vendor_id")
    vendor = Vendor.query.get(vendor_id) if vendor_id else None
    if not vendor:
        return jsonify({"error": "Invalid vendor_id"}), 400

    note_date = parse_date(data.get("note_date"))
    if not note_date:
        return jsonify({"error": "note_date is required (YYYY-MM-DD)"}), 400

    reference_purchase_id = data.get("reference_purchase_id")
    if reference_purchase_id:
        purchase = VendorPurchase.query.get(reference_purchase_id)
        if not purchase:
            return jsonify({"error": "Invalid reference_purchase_id"}), 400
        if purchase.vendor_id != vendor.id:
            return jsonify({"error": "reference_purchase_id does not belong to vendor_id"}), 400

    note = VendorNote(
        note_no=generate_vendor_note_no(note_type),
        note_type=note_type,
        vendor_id=vendor.id,
        reference_purchase_id=reference_purchase_id,
        supplier_bill_no=(data.get("supplier_bill_no") or "").strip() or None,
        note_date=note_date,
        status="DRAFT",
        reason_code=(data.get("reason_code") or "").strip() or None,
        reason_text=(data.get("reason_text") or "").strip() or None,
        remarks=(data.get("remarks") or "").strip() or None,
        created_by=session.get("username"),
        created_at=datetime.utcnow()
    )

    mode = (data.get("mode") or "").strip().upper()
    if note_type == "CREDIT" and mode == "AMOUNT_ONLY":
        amount = data.get("grand_total") if "grand_total" in data else data.get("amount")
        amount_dec = quantize_decimal(amount or 0, "0.0001")
        note.subtotal = amount_dec
        note.gst_total = quantize_decimal(0, "0.0001")
        note.round_off = quantize_decimal(data.get("round_off") or 0, "0.0001")
        note.grand_total = quantize_decimal(note.subtotal + note.round_off, "0.0001")

    db.session.add(note)
    db.session.commit()
    return jsonify(vendor_note_to_dict(note)), 201


@app.route("/api/vendor-notes/<int:note_id>/items", methods=["PUT"])
@login_required
@vendor_note_access_required(api=True)
def api_update_vendor_note_items(note_id):
    note = VendorNote.query.get_or_404(note_id)
    if note.status != "DRAFT":
        return jsonify({"error": "Only DRAFT notes can be edited"}), 400

    data = request.get_json(silent=True) or {}
    items = data.get("items") or []

    if note.note_type == "DEBIT" and not items:
        return jsonify({"error": "DEBIT note requires items"}), 400

    if items:
        for idx, raw in enumerate(items):
            med_id = raw.get("medicine_id")
            if not med_id:
                return jsonify({"error": f"medicine_id missing at item {idx+1}"}), 400
            if note.note_type == "DEBIT" and not (raw.get("batch_no") or "").strip():
                return jsonify({"error": f"batch_no required at item {idx+1}"}), 400
            qty = int(raw.get("qty") or 0)
            if qty <= 0:
                return jsonify({"error": f"qty must be > 0 at item {idx+1}"}), 400

        subtotal, gst_total, prepared = compute_vendor_note_totals(items)
        VendorNoteItem.query.filter_by(note_id=note.id).delete()
        for idx, raw in enumerate(items):
            prepared_item = prepared[idx]
            item = VendorNoteItem(
                note_id=note.id,
                medicine_id=raw.get("medicine_id"),
                batch_no=(raw.get("batch_no") or "").strip() or None,
                expiry=(raw.get("expiry") or "").strip() or None,
                qty=prepared_item["qty"],
                free_qty=prepared_item["free_qty"],
                purchase_rate=prepared_item["purchase_rate"],
                mrp=quantize_decimal(raw.get("mrp") or 0, "0.0001"),
                gst_percent=prepared_item["gst_percent"],
                disc_percent=prepared_item["disc_percent"],
                line_total=prepared_item["line_total"],
                hsn=(raw.get("hsn") or "").strip() or None
            )
            db.session.add(item)

        note.subtotal = subtotal
        note.gst_total = gst_total
        if "round_off" in data:
            note.round_off = quantize_decimal(data.get("round_off") or 0, "0.0001")
        note.grand_total = quantize_decimal(note.subtotal + note.gst_total + to_decimal(note.round_off), "0.0001")
        db.session.add(note)
    else:
        # Amount-only credit note
        amount = data.get("grand_total") if "grand_total" in data else data.get("amount")
        amount_dec = quantize_decimal(amount or 0, "0.0001")
        VendorNoteItem.query.filter_by(note_id=note.id).delete()
        note.subtotal = amount_dec
        note.gst_total = quantize_decimal(0, "0.0001")
        if "round_off" in data:
            note.round_off = quantize_decimal(data.get("round_off") or 0, "0.0001")
        note.grand_total = quantize_decimal(note.subtotal + to_decimal(note.round_off), "0.0001")
        db.session.add(note)

    db.session.commit()
    return jsonify(vendor_note_to_dict(note, include_items=True)), 200


@app.route("/api/vendor-notes/<int:note_id>/post", methods=["POST"])
@login_required
@vendor_note_access_required(api=True)
def api_post_vendor_note(note_id):
    note = VendorNote.query.get_or_404(note_id)
    if note.status != "DRAFT":
        return jsonify({"error": "Only DRAFT notes can be posted"}), 400
    if note.reference_purchase_id:
        purchase = VendorPurchase.query.get(note.reference_purchase_id)
        if not purchase:
            return jsonify({"error": "Invalid reference_purchase_id"}), 400
        if purchase.vendor_id != note.vendor_id:
            return jsonify({"error": "reference_purchase_id does not belong to note vendor"}), 400

    items = VendorNoteItem.query.filter_by(note_id=note.id).all()

    if note.note_type == "DEBIT":
        if not items:
            return jsonify({"error": "DEBIT note requires items"}), 400
        adjustments = []
        allocations = []
        for it in items:
            if not it.batch_no:
                return jsonify({"error": "batch_no required for DEBIT note"}), 400
            total_qty = to_int(it.qty) + to_int(it.free_qty)
            if total_qty <= 0:
                return jsonify({"error": "qty must be > 0"}), 400
            med = Medicine.query.get(it.medicine_id) if it.medicine_id else None
            if not med:
                return jsonify({"error": "Invalid medicine_id in items"}), 400
            if to_int(med.qty) < total_qty:
                return jsonify({"error": f"Insufficient stock for {med.name} ({med.batch})"}), 400

            purchase_items = get_purchase_items_for_return(
                med,
                batch_no=it.batch_no,
                reference_purchase_id=note.reference_purchase_id
            )
            available = sum(to_int(p.remaining_qty) for p in purchase_items)
            if available < total_qty:
                return jsonify({"error": f"Return qty exceeds available purchase stock for {med.name} ({med.batch})"}), 400

            remaining = total_qty
            for pi in purchase_items:
                if remaining <= 0:
                    break
                avail = to_int(pi.remaining_qty)
                if avail <= 0:
                    continue
                take = avail if avail <= remaining else remaining
                allocations.append((it, pi, take))
                remaining -= take
            adjustments.append((med, total_qty))

        for med, total_qty in adjustments:
            old_qty = med.qty
            med.qty = to_int(med.qty) - total_qty
            history = StockHistory(
                medicine_id=med.id,
                medicine_name=med.name,
                batch=med.batch,
                action="V_DEBIT_NOTE",
                stock_before=old_qty,
                qty_change=-total_qty,
                stock_after=med.qty,
                user=session.get("username"),
                remark=f"Vendor debit note {note.note_no}",
                ref_table="vendor_notes",
                ref_id=note.id
            )
            db.session.add(history)

        for it, pi, take in allocations:
            pi.remaining_qty = to_int(pi.remaining_qty) - take
            db.session.add(VendorNoteAllocation(
                note_id=note.id,
                note_item_id=it.id,
                purchase_item_id=pi.id,
                qty=take
            ))

        db.session.add(VendorLedgerEntry(
            vendor_id=note.vendor_id,
            txn_date=datetime.utcnow(),
            txn_type="DEBIT_NOTE",
            ref_table="vendor_notes",
            ref_id=note.id,
            debit=quantize_decimal(note.grand_total or 0, "0.0001"),
            credit=quantize_decimal(0, "0.0001"),
            notes=f"Vendor debit note {note.note_no}"
        ))
        applied = adjust_vendor_outstanding(note.vendor_id, -to_decimal(note.grand_total or 0), return_applied=True)
        note.outstanding_impact = quantize_decimal(applied, "0.0001")

        note.status = "POSTED"
        note.posted_at = datetime.utcnow()
        db.session.add(note)

    elif note.note_type == "CREDIT":
        if to_decimal(note.grand_total) <= 0:
            return jsonify({"error": "grand_total must be > 0"}), 400
        db.session.add(VendorLedgerEntry(
            vendor_id=note.vendor_id,
            txn_date=datetime.utcnow(),
            txn_type="CREDIT_NOTE",
            ref_table="vendor_notes",
            ref_id=note.id,
            debit=quantize_decimal(0, "0.0001"),
            credit=quantize_decimal(note.grand_total or 0, "0.0001"),
            notes=f"Vendor credit note {note.note_no}"
        ))
        applied = adjust_vendor_outstanding(note.vendor_id, to_decimal(note.grand_total or 0), return_applied=True)
        note.outstanding_impact = quantize_decimal(applied, "0.0001")

        note.status = "POSTED"
        note.posted_at = datetime.utcnow()
        db.session.add(note)

    db.session.commit()
    return jsonify(vendor_note_to_dict(note, include_items=True, include_ledger=True)), 200


@app.route("/api/vendor-notes/<int:note_id>/cancel", methods=["POST"])
@login_required
@vendor_note_access_required(api=True)
def api_cancel_vendor_note(note_id):
    note = VendorNote.query.get_or_404(note_id)
    if note.status != "POSTED":
        return jsonify({"error": "Only POSTED notes can be cancelled"}), 400

    data = request.get_json(silent=True) or {}
    cancel_reason = (data.get("cancel_reason") or "").strip() or None

    items = VendorNoteItem.query.filter_by(note_id=note.id).all()
    allocations = VendorNoteAllocation.query.filter_by(note_id=note.id).all()

    reversal_debit = quantize_decimal(0, "0.0001")
    reversal_credit = quantize_decimal(0, "0.0001")
    if note.note_type == "DEBIT":
        for it in items:
            total_qty = to_int(it.qty) + to_int(it.free_qty)
            if total_qty <= 0:
                continue
            med = Medicine.query.get(it.medicine_id) if it.medicine_id else None
            if not med:
                continue
            old_qty = med.qty
            med.qty = to_int(med.qty) + total_qty
            history = StockHistory(
                medicine_id=med.id,
                medicine_name=med.name,
                batch=med.batch,
                action="V_NOTE_REV",
                stock_before=old_qty,
                qty_change=total_qty,
                stock_after=med.qty,
                user=session.get("username"),
                remark=f"Debit note cancel {note.note_no}",
                ref_table="vendor_notes",
                ref_id=note.id
            )
            db.session.add(history)

        if allocations:
            for alloc in allocations:
                pi = VendorPurchaseItem.query.get(alloc.purchase_item_id)
                if not pi:
                    continue
                pi.remaining_qty = to_int(pi.remaining_qty) + to_int(alloc.qty)
        else:
            for it in items:
                total_qty = to_int(it.qty) + to_int(it.free_qty)
                if total_qty <= 0:
                    continue
                med = Medicine.query.get(it.medicine_id) if it.medicine_id else None
                if not med:
                    continue
                purchase_items = get_purchase_items_for_return(
                    med,
                    batch_no=it.batch_no,
                    reference_purchase_id=note.reference_purchase_id
                )
                remaining = total_qty
                for pi in purchase_items:
                    if remaining <= 0:
                        break
                    take = remaining
                    pi.remaining_qty = to_int(pi.remaining_qty) + take
                    remaining -= take
        reversal_credit = quantize_decimal(note.grand_total or 0, "0.0001")
    elif note.note_type == "CREDIT":
        reversal_debit = quantize_decimal(note.grand_total or 0, "0.0001")

    reverse_delta = -get_note_outstanding_impact(note)
    adjust_vendor_outstanding(note.vendor_id, reverse_delta)

    db.session.add(VendorLedgerEntry(
        vendor_id=note.vendor_id,
        txn_date=datetime.utcnow(),
        txn_type="REVERSAL",
        ref_table="vendor_notes",
        ref_id=note.id,
        debit=reversal_debit,
        credit=reversal_credit,
        notes=f"Reversal of {note.note_no}"
    ))

    note.status = "CANCELLED"
    note.cancelled_at = datetime.utcnow()
    note.cancel_reason = cancel_reason
    db.session.add(note)

    db.session.commit()
    return jsonify(vendor_note_to_dict(note, include_items=True, include_ledger=True)), 200


@app.route("/api/vendor-notes", methods=["GET"])
@login_required
@vendor_note_access_required(api=True)
def api_list_vendor_notes():
    vendor_id = request.args.get("vendor_id")
    note_type = (request.args.get("type") or "").strip().upper()
    status = (request.args.get("status") or "").strip().upper()
    date_from = parse_date(request.args.get("date_from"))
    date_to = parse_date(request.args.get("date_to"))
    q = (request.args.get("q") or "").strip()
    page = int(request.args.get("page") or 1)
    per_page = int(request.args.get("per_page") or 50)

    query = VendorNote.query
    if vendor_id:
        query = query.filter(VendorNote.vendor_id == int(vendor_id))
    if note_type:
        query = query.filter(VendorNote.note_type == note_type)
    if status:
        query = query.filter(VendorNote.status == status)
    if date_from:
        query = query.filter(VendorNote.note_date >= date_from)
    if date_to:
        query = query.filter(VendorNote.note_date <= date_to)
    if q:
        like = f"%{q}%"
        query = query.filter(or_(
            VendorNote.note_no.ilike(like),
            VendorNote.supplier_bill_no.ilike(like)
        ))

    total = query.count()
    notes = query.order_by(VendorNote.note_date.desc(), VendorNote.id.desc()).offset((page - 1) * per_page).limit(per_page).all()
    return jsonify({
        "page": page,
        "per_page": per_page,
        "total": total,
        "data": [vendor_note_to_dict(n) for n in notes]
    }), 200


@app.route("/api/vendor-notes/<int:note_id>", methods=["GET"])
@login_required
@vendor_note_access_required(api=True)
def api_view_vendor_note(note_id):
    note = VendorNote.query.get_or_404(note_id)
    return jsonify(vendor_note_to_dict(note, include_items=True, include_ledger=True)), 200


@app.route("/api/vendor-notes/<int:note_id>", methods=["DELETE"])
@login_required
@vendor_note_access_required(api=True)
def api_delete_vendor_note(note_id):
    note = VendorNote.query.get_or_404(note_id)
    items = VendorNoteItem.query.filter_by(note_id=note.id).all()
    allocations = VendorNoteAllocation.query.filter_by(note_id=note.id).all()

    if note.status == "POSTED":
        if note.note_type == "DEBIT":
            stock_restore = []
            purchase_restore = []

            for it in items:
                total_qty = to_int(it.qty) + to_int(it.free_qty)
                if total_qty <= 0:
                    continue
                med = Medicine.query.get(it.medicine_id) if it.medicine_id else None
                if not med:
                    return jsonify({"error": "Cannot delete: linked medicine missing for posted debit note"}), 400
                stock_restore.append((med, total_qty))

            if allocations:
                for alloc in allocations:
                    qty = to_int(alloc.qty)
                    if qty <= 0:
                        continue
                    pi = VendorPurchaseItem.query.get(alloc.purchase_item_id)
                    if not pi:
                        return jsonify({"error": "Cannot delete: linked purchase allocation missing"}), 400
                    purchase_restore.append((pi, qty))
            else:
                for it in items:
                    total_qty = to_int(it.qty) + to_int(it.free_qty)
                    if total_qty <= 0:
                        continue
                    med = Medicine.query.get(it.medicine_id) if it.medicine_id else None
                    if not med:
                        return jsonify({"error": "Cannot delete: linked medicine missing for purchase restore"}), 400
                    purchase_items = get_purchase_items_for_return(
                        med,
                        batch_no=it.batch_no,
                        reference_purchase_id=note.reference_purchase_id
                    )
                    remaining = total_qty
                    for pi in purchase_items:
                        if remaining <= 0:
                            break
                        take = remaining
                        purchase_restore.append((pi, take))
                        remaining -= take
                    if remaining > 0:
                        return jsonify({"error": "Cannot delete: purchase restore mapping failed"}), 400

            for med, qty in stock_restore:
                med.qty = to_int(med.qty) + qty
            for pi, qty in purchase_restore:
                pi.remaining_qty = to_int(pi.remaining_qty) + qty

        reverse_delta = -get_note_outstanding_impact(note)
        adjust_vendor_outstanding(note.vendor_id, reverse_delta)

    StockHistory.query.filter_by(ref_table="vendor_notes", ref_id=note.id).delete(synchronize_session=False)
    VendorLedgerEntry.query.filter_by(ref_table="vendor_notes", ref_id=note.id).delete(synchronize_session=False)
    VendorNoteAllocation.query.filter_by(note_id=note.id).delete(synchronize_session=False)
    VendorNoteItem.query.filter_by(note_id=note.id).delete(synchronize_session=False)
    db.session.delete(note)
    db.session.commit()
    return jsonify({"message": "Vendor note deleted"}), 200

@app.route("/vendor/delete/<int:id>", methods=["POST"])
@login_required
@inventory_access_required
def delete_vendor(id):
    schema_ok, schema_err = ensure_inventory_runtime_schema()
    if not schema_ok:
        flash("Unable to archive vendor because inventory schema update failed.", "danger")
        if schema_err:
            app.logger.error("Inventory schema check failed before delete vendor: %s", schema_err)
        return redirect("/vendor")
    v = active_vendor_query().filter(Vendor.id == id).first_or_404()
    has_purchases = VendorPurchase.query.filter_by(vendor_id=v.id).first()
    if has_purchases:
        flash("Vendor cannot be deleted because purchase history exists.", "danger")
        return redirect("/vendor")
    v.is_active = False
    v.deleted_at = datetime.utcnow()
    v.deleted_by = session.get("username")
    db.session.commit()
    flash("Vendor archived successfully.", "success")
    return redirect("/vendor")

def build_patient_invoice_query(patient):
    patient_name = (patient.name or "").strip()
    mobile_digits = normalize_patient_mobile(patient.mobile)
    conditions = [Invoice.patient_id == patient.id]
    if mobile_digits:
        conditions.append(Invoice.mobile.ilike(f"%{mobile_digits}%"))
    if patient_name:
        conditions.append(
            db.func.lower(db.func.coalesce(Invoice.customer, "")) == patient_name.lower()
        )
    if not conditions:
        return Invoice.query.filter(text("1=0"))
    return active_invoice_query().filter(or_(*conditions))

def build_patient_appointment_query(patient):
    patient_name = (patient.name or "").strip()
    mobile_digits = normalize_patient_mobile(patient.mobile)
    conditions = [Appointment.patient_id == patient.id]
    if mobile_digits:
        conditions.append(Appointment.mobile == mobile_digits)
    if patient_name:
        conditions.append(
            db.func.lower(db.func.coalesce(Appointment.patient_name, "")) == patient_name.lower()
        )
    return active_appointment_query().filter(or_(*conditions))

def build_global_search_results(raw_query, per_group=4):
    query = (raw_query or "").strip()
    if len(query) < 2:
        return []

    query_lower = query.lower()
    search_digits = normalize_patient_mobile(query)
    per_group = max(1, min(to_int_safe(per_group, 4), 8))
    expanded_limit = max(per_group * 3, 8)

    def score_text(value):
        text_value = (value or "").strip().lower()
        if not text_value:
            return 0
        if text_value == query_lower:
            return 120
        if text_value.startswith(query_lower):
            return 90
        if query_lower in text_value:
            return 50
        return 0

    def score_digits(value):
        digits_value = normalize_patient_mobile(value)
        if not search_digits or not digits_value:
            return 0
        if digits_value == search_digits:
            return 110
        if digits_value.startswith(search_digits):
            return 85
        if search_digits in digits_value:
            return 45
        return 0

    patient_filters = [Patient.name.ilike(f"%{query}%")]
    if search_digits:
        patient_filters.append(Patient.mobile.ilike(f"%{search_digits}%"))
    patient_rows = Patient.query.filter(or_(*patient_filters)).order_by(
        Patient.updated_at.desc(),
        Patient.id.desc()
    ).limit(expanded_limit).all()
    patient_rows.sort(
        key=lambda row: (
            -max(score_digits(row.mobile), score_text(row.name)),
            -(row.updated_at.timestamp() if row.updated_at else 0),
            -(row.id or 0)
        )
    )

    can_edit_medicine = bool(
        session.get("role") == "admin" or session.get("can_edit_medicine")
    )
    medicine_filters = [
        Medicine.name.ilike(f"%{query}%"),
        Medicine.batch.ilike(f"%{query}%")
    ]
    if query:
        medicine_filters.append(Medicine.barcode.ilike(f"%{query}%"))
        medicine_filters.append(Medicine.medicine_code.ilike(f"%{query}%"))
    medicine_rows = Medicine.query.filter(or_(*medicine_filters)).order_by(
        db.func.lower(Medicine.name).asc(),
        Medicine.id.desc()
    ).limit(expanded_limit).all()
    medicine_rows.sort(
        key=lambda row: (
            -max(
                score_text(row.name),
                score_text(row.batch),
                score_text(getattr(row, "barcode", "")),
                score_text(getattr(row, "medicine_code", "")),
            ),
            (row.name or "").lower(),
            -(row.id or 0)
        )
    )

    invoice_filters = [
        Invoice.invoice_no.ilike(f"%{query}%"),
        Invoice.customer.ilike(f"%{query}%")
    ]
    if search_digits:
        invoice_filters.append(Invoice.mobile.ilike(f"%{search_digits}%"))
    invoice_rows = Invoice.query.filter(or_(*invoice_filters)).order_by(
        Invoice.created_at.desc(),
        Invoice.id.desc()
    ).limit(expanded_limit).all()
    invoice_rows.sort(
        key=lambda row: (
            -max(score_text(row.invoice_no), score_digits(row.mobile), score_text(row.customer)),
            -(row.created_at.timestamp() if row.created_at else 0),
            -(row.id or 0)
        )
    )

    appointment_filters = [
        Appointment.appointment_no.ilike(f"%{query}%"),
        Appointment.patient_name.ilike(f"%{query}%")
    ]
    if search_digits:
        appointment_filters.append(Appointment.mobile.ilike(f"%{search_digits}%"))
    appointment_rows = active_appointment_query().filter(or_(*appointment_filters)).order_by(
        Appointment.appointment_date.desc(),
        Appointment.id.desc()
    ).limit(expanded_limit).all()
    appointment_rows.sort(
        key=lambda row: (
            -max(score_text(row.appointment_no), score_digits(row.mobile), score_text(row.patient_name)),
            -(row.appointment_date.toordinal() if row.appointment_date else 0),
            -(row.id or 0)
        )
    )

    groups = []
    if patient_rows:
        patient_items = [
            {
                "title": (patient.name or "Unnamed Patient").strip(),
                "subtitle": (patient.mobile or "No mobile").strip() or "No mobile",
                "meta": f"Updated {patient.updated_at.strftime('%d-%m-%Y') if patient.updated_at else '-'}",
                "href": url_for("patient_profile", patient_id=patient.id)
            }
            for patient in patient_rows[:per_group]
        ]
        groups.append({
            "key": "patients",
            "label": "Patients",
            "items": patient_items,
            "hint": f"Showing top {len(patient_items)} patient matches",
            "view_all_href": url_for("customer", search=query)
        })
    if medicine_rows:
        medicine_items = []
        for med in medicine_rows[:per_group]:
            if can_edit_medicine:
                href = url_for("edit_medicine", id=med.id)
            else:
                search_value = " ".join(
                    part for part in (
                        (med.name or "").strip(),
                        normalize_medicine_code(getattr(med, "medicine_code", "")),
                        (med.batch or "").strip(),
                        (getattr(med, "barcode", "") or "").strip()
                    ) if part
                )
                search_kwargs = {"search": search_value}
                if to_int_safe(med.qty, 0) <= 0:
                    search_kwargs["show_archived"] = 1
                href = url_for("medicines", **search_kwargs)
            medicine_items.append({
                "title": (med.name or "Medicine").strip(),
                "subtitle": " · ".join(
                    part for part in (
                        f"Code {normalize_medicine_code(getattr(med, 'medicine_code', ''))}" if normalize_medicine_code(getattr(med, "medicine_code", "")) else "",
                        f"Batch {(med.batch or '-').strip()}",
                        f"Stock {to_int_safe(med.qty, 0)}",
                    ) if part
                ),
                "meta": f"MRP Rs {to_float_safe(med.mrp, 0):.2f}",
                "href": href
            })
        groups.append({
            "key": "medicines",
            "label": "Medicines",
            "items": medicine_items,
            "hint": f"Showing top {len(medicine_items)} medicine matches",
            "view_all_href": url_for("medicines", search=query)
        })
    if invoice_rows:
        invoice_items = [
            {
                "title": (inv.invoice_no or f"Invoice #{inv.id}").strip(),
                "subtitle": f"{(inv.customer or 'Walk-in').strip()} · {(inv.mobile or '-').strip() or '-'}",
                "meta": f"Rs {to_float_safe(inv.total, 0):.2f} · {inv.created_at.strftime('%d-%m-%Y') if inv.created_at else '-'}",
                "href": url_for("view_invoice", id=inv.id)
            }
            for inv in invoice_rows[:per_group]
        ]
        groups.append({
            "key": "invoices",
            "label": "Invoices",
            "items": invoice_items,
            "hint": f"Showing top {len(invoice_items)} invoice matches"
        })
    if appointment_rows:
        appointment_items = [
            {
                "title": (appt.appointment_no or f"Appointment #{appt.id}").strip(),
                "subtitle": f"{(appt.patient_name or 'Patient').strip()} · {(appt.mobile or '-').strip() or '-'}",
                "meta": f"{appt.appointment_date.strftime('%d-%m-%Y') if appt.appointment_date else '-'} · {(appt.status or 'BOOKED').replace('_', ' ').title()}",
                "href": url_for("edit_appointment", id=appt.id)
            }
            for appt in appointment_rows[:per_group]
        ]
        groups.append({
            "key": "appointments",
            "label": "Appointments",
            "items": appointment_items,
            "hint": f"Showing top {len(appointment_items)} appointment matches"
        })
    return groups

@app.route("/customer")
@login_required
def customer():
    search_query = (request.args.get("search") or "").strip()
    with_mobile_only = is_truthy(request.args.get("with_mobile"))
    with_notes_only = is_truthy(request.args.get("with_notes"))
    duplicates_only = is_truthy(request.args.get("duplicates"))
    sort_by = (request.args.get("sort") or "recent").strip().lower() or "recent"
    query = Patient.query
    duplicate_name_counts = build_patient_duplicate_name_counts()
    duplicate_names = sorted(duplicate_name_counts.keys())
    if search_query:
        conditions = [Patient.name.ilike(f"%{search_query}%")]
        digits = normalize_patient_mobile(search_query)
        if digits:
            conditions.append(Patient.mobile.ilike(f"%{digits}%"))
        query = query.filter(or_(*conditions))
    if with_mobile_only:
        query = query.filter(db.func.length(db.func.trim(db.func.coalesce(Patient.mobile, ""))) > 0)
    if with_notes_only:
        query = query.filter(db.func.length(db.func.trim(db.func.coalesce(Patient.notes, ""))) > 0)
    if duplicates_only:
        if duplicate_names:
            query = query.filter(patient_master_name_expression().in_(duplicate_names))
        else:
            query = query.filter(text("1=0"))

    matching_patients = query.count()
    patients = query.order_by(Patient.updated_at.desc(), Patient.id.desc()).limit(300).all()
    customer_rows = build_customer_directory_rows(patients)
    for row in customer_rows:
        normalized_name = normalize_patient_name(row["patient"].name)
        row["duplicate_count"] = max(0, duplicate_name_counts.get(normalized_name, 0) - 1)

    if sort_by == "name":
        customer_rows.sort(key=lambda row: ((row["patient"].name or "").lower(), -(row["patient"].id or 0)))
    elif sort_by == "visits":
        customer_rows.sort(
            key=lambda row: (
                -row["appointment_count"],
                -(row["invoice_count"]),
                -to_float_safe(row["total_billed"], 0),
                (row["patient"].name or "").lower()
            )
        )
    elif sort_by == "billing":
        customer_rows.sort(
            key=lambda row: (
                -to_float_safe(row["total_billed"], 0),
                -row["invoice_count"],
                -row["appointment_count"],
                (row["patient"].name or "").lower()
            )
        )
    else:
        customer_rows.sort(
            key=lambda row: (
                -(row["last_activity_at"].timestamp() if row["last_activity_at"] else 0),
                -(row["patient"].updated_at.timestamp() if row["patient"].updated_at else 0),
                -(row["patient"].id or 0)
            )
        )

    customer_rows = customer_rows[:250]
    customer_stats = {
        "matching_patients": matching_patients,
        "visible_patients": len(customer_rows),
        "with_mobile": sum(1 for row in customer_rows if row["has_mobile"]),
        "with_notes": sum(1 for row in customer_rows if row["has_notes"]),
        "duplicate_patients": sum(1 for row in customer_rows if row["duplicate_count"] > 0),
        "total_visits": sum(row["appointment_count"] for row in customer_rows),
        "total_invoices": sum(row["invoice_count"] for row in customer_rows),
        "total_billed": round(sum(to_float_safe(row["total_billed"], 0) for row in customer_rows), 2)
    }
    return render_template(
        "customers.html",
        customer_rows=customer_rows,
        search_query=search_query,
        customer_stats=customer_stats,
        with_mobile_only=with_mobile_only,
        with_notes_only=with_notes_only,
        duplicates_only=duplicates_only,
        sort_by=sort_by
    )

@app.route("/patients/<int:patient_id>")
@login_required
def patient_profile(patient_id):
    patient = Patient.query.get_or_404(patient_id)
    management_enabled = can_manage_patient_records()
    appointment_query = build_patient_appointment_query(patient)
    invoice_query = build_patient_invoice_query(patient)
    appointment_count = appointment_query.count()
    invoice_count = invoice_query.count()
    total_billed = round(
        invoice_query.with_entities(
            db.func.coalesce(db.func.sum(Invoice.total), 0)
        ).scalar() or 0,
        2
    )
    appointment_status_counts = {status: 0 for status in APPOINTMENT_STATUSES}
    for status, count in appointment_query.with_entities(
        Appointment.status,
        db.func.count(Appointment.id)
    ).group_by(Appointment.status).all():
        normalized_status = (status or "BOOKED").strip().upper()
        if normalized_status in appointment_status_counts:
            appointment_status_counts[normalized_status] = int(count or 0)

    invoice_payment_counts = {}
    for mode, count in invoice_query.with_entities(
        Invoice.payment_mode,
        db.func.count(Invoice.id)
    ).group_by(Invoice.payment_mode).all():
        normalized_mode = (mode or "CASH").strip().upper() or "CASH"
        invoice_payment_counts[normalized_mode] = int(count or 0)

    appointments = appointment_query.order_by(
        Appointment.appointment_date.desc(),
        Appointment.appointment_time.desc(),
        Appointment.id.desc()
    ).limit(40).all()
    invoices = invoice_query.order_by(
        Invoice.created_at.desc(),
        Invoice.id.desc()
    ).limit(40).all()

    invoice_ids = [invoice.id for invoice in invoices]
    invoice_items = []
    if invoice_ids:
        invoice_items = InvoiceItem.query.filter(InvoiceItem.invoice_id.in_(invoice_ids)).all()

    medicine_summary = {}
    for item in invoice_items:
        key = (item.name or "").strip().upper()
        if not key:
            continue
        row = medicine_summary.get(key)
        if not row:
            row = {
                "medicine": (item.name or "").strip(),
                "qty": 0,
                "amount": 0.0,
                "last_batch": (item.batch or "").strip()
            }
            medicine_summary[key] = row
        row["qty"] += to_int_safe(item.qty, 0)
        row["amount"] += to_float_safe(item.net_amount if item.net_amount not in (None, 0) else item.amount, 0)
        if (item.batch or "").strip():
            row["last_batch"] = (item.batch or "").strip()

    medicine_rows = sorted(
        medicine_summary.values(),
        key=lambda row: (-row["qty"], (row["medicine"] or "").lower())
    )[:20]

    timeline = []
    public_arrival_context = public_appointment_display_context()
    for appt in appointments[:12]:
        visit_display = appointment_visit_display_context(appt, public_arrival_context)
        occurred_at = None
        if appt.appointment_date:
            occurred_at = datetime.combine(
                appt.appointment_date,
                # Do not turn the FCFS compatibility marker into a patient
                # timeline timestamp.  Date ordering remains intact while
                # the UI below shows the configured arrival window instead.
                time.min if visit_display["is_public_fcfs"] else (appt.appointment_time or time.min)
            )
        timeline.append({
            "type": "Appointment",
            "title": (appt.appointment_no or f"Appointment #{appt.id}").strip(),
            "subtitle": (
                f"{visit_display['visit_label']} · {visit_display['token_label']} · "
                f"{(appt.status or 'BOOKED').replace('_', ' ').title()}"
                if visit_display["is_public_fcfs"]
                else f"Token {appt.token_no or '-'} · {(appt.status or 'BOOKED').replace('_', ' ').title()}"
            ),
            "amount": round(to_float_safe(appt.consultation_fee, 0), 2),
            "occurred_at": occurred_at,
            "occurred_label": (
                appt.appointment_date.strftime("%d-%m-%Y")
                if visit_display["is_public_fcfs"] and appt.appointment_date
                else ""
            ),
            "href": url_for("edit_appointment", id=appt.id)
        })

    for invoice in invoices[:12]:
        timeline.append({
            "type": "Invoice",
            "title": (invoice.invoice_no or f"Invoice #{invoice.id}").strip(),
            "subtitle": f"{(invoice.payment_mode or 'CASH').strip().upper()} · {(invoice.mobile or patient.mobile or '-').strip() or '-'}",
            "amount": round(to_float_safe(invoice.total, 0), 2),
            "occurred_at": invoice.created_at,
            "occurred_label": "",
            "href": url_for("view_invoice", id=invoice.id)
        })

    timeline.sort(
        key=lambda row: row["occurred_at"] or datetime.min,
        reverse=True
    )
    timeline = timeline[:12]
    duplicate_candidates = build_patient_duplicate_candidates(patient)
    link_summary = build_patient_link_summary(patient)
    profile_search_value = patient.mobile or patient.name or ""
    stats = {
        "appointment_count": appointment_count,
        "invoice_count": invoice_count,
        "medicine_count": len(medicine_summary),
        "total_billed": total_billed,
        "last_invoice_at": invoices[0].created_at if invoices else None,
        "last_appointment_at": appointments[0].appointment_date if appointments else None,
        "completed_visits": appointment_status_counts.get("COMPLETED", 0),
        "cancelled_visits": appointment_status_counts.get("CANCELLED", 0),
        "paid_invoice_count": sum(invoice_payment_counts.values()),
        "cash_invoice_count": invoice_payment_counts.get("CASH", 0),
        "online_invoice_count": sum(
            count for mode, count in invoice_payment_counts.items() if mode != "CASH"
        )
    }
    return render_template(
        "patient_profile.html",
        patient=patient,
        appointments=appointments,
        invoices=invoices,
        medicine_rows=medicine_rows,
        stats=stats,
        management_enabled=management_enabled,
        duplicate_candidates=duplicate_candidates,
        link_summary=link_summary,
        profile_search_value=profile_search_value,
        appointment_status_counts=appointment_status_counts,
        invoice_payment_counts=invoice_payment_counts,
        timeline=timeline
    )

@app.route("/patients/<int:patient_id>/notes", methods=["POST"])
@login_required
def update_patient_notes(patient_id):
    patient = Patient.query.get_or_404(patient_id)
    before_snapshot = build_patient_audit_snapshot(patient)
    patient.notes = (request.form.get("notes") or "").strip()
    db.session.commit()
    record_audit_event(
        action="Updated patient notes",
        entity_type="PATIENT",
        entity_id=patient.id,
        ref_code=patient.mobile or patient.name,
        before=before_snapshot,
        after=build_patient_audit_snapshot(patient)
    )
    flash("Patient notes updated successfully.", "success")
    return redirect(url_for("patient_profile", patient_id=patient.id))

@app.route("/patients/<int:patient_id>/update", methods=["POST"])
@login_required
def update_patient_profile(patient_id):
    patient = Patient.query.get_or_404(patient_id)
    if not can_manage_patient_records():
        flash("Access denied", "danger")
        return redirect(url_for("patient_profile", patient_id=patient.id))

    before_snapshot = build_patient_audit_snapshot(patient)
    old_name = patient.name
    old_mobile = patient.mobile

    name = (request.form.get("name") or "").strip()
    mobile = normalize_patient_mobile(request.form.get("mobile"))
    gender = (request.form.get("gender") or "").strip().upper() or None
    age_raw = (request.form.get("age") or "").strip()
    sync_linked_records = is_truthy(request.form.get("sync_linked_records"))

    if not name:
        flash("Patient name is required.", "danger")
        return redirect(url_for("patient_profile", patient_id=patient.id))

    age_value = None
    if age_raw:
        try:
            age_value = int(age_raw)
        except ValueError:
            flash("Age must be a valid number.", "danger")
            return redirect(url_for("patient_profile", patient_id=patient.id))

    existing_mobile = None
    if mobile:
        existing_mobile = Patient.query.filter(
            Patient.mobile == mobile,
            Patient.id != patient.id
        ).first()
    if existing_mobile:
        flash("This mobile number is already linked to another patient profile.", "danger")
        return redirect(url_for("patient_profile", patient_id=patient.id))

    patient.name = name
    patient.mobile = mobile or None
    patient.gender = gender
    patient.age = age_value

    sync_result = {
        "appointment_relinked": 0,
        "appointment_synced": 0,
        "invoice_relinked": 0,
        "invoice_synced": 0
    }
    if sync_linked_records:
        sync_result = relink_patient_records(
            patient,
            matching_names=[old_name, patient.name],
            matching_mobiles=[old_mobile, patient.mobile],
            sync_display_fields=True
        )

    db.session.commit()
    record_audit_event(
        action="Updated patient profile",
        entity_type="PATIENT",
        entity_id=patient.id,
        ref_code=patient.mobile or patient.name,
        before=before_snapshot,
        after=build_patient_audit_snapshot(patient),
        extra={
            "sync_linked_records": sync_linked_records,
            **sync_result
        }
    )
    flash("Patient profile updated successfully.", "success")
    return redirect(url_for("patient_profile", patient_id=patient.id))

@app.route("/patients/<int:patient_id>/relink", methods=["POST"])
@login_required
def relink_patient_profile(patient_id):
    patient = Patient.query.get_or_404(patient_id)
    if not can_manage_patient_records():
        flash("Access denied", "danger")
        return redirect(url_for("patient_profile", patient_id=patient.id))

    before_snapshot = build_patient_audit_snapshot(patient)
    sync_display_fields = not str(request.form.get("sync_display_fields") or "").strip().lower() == "0"
    relink_result = relink_patient_records(
        patient,
        matching_names=[patient.name],
        matching_mobiles=[patient.mobile],
        sync_display_fields=sync_display_fields
    )
    db.session.commit()
    record_audit_event(
        action="Relinked patient records",
        entity_type="PATIENT",
        entity_id=patient.id,
        ref_code=patient.mobile or patient.name,
        before=before_snapshot,
        after=build_patient_audit_snapshot(patient),
        extra={
            "sync_display_fields": sync_display_fields,
            **relink_result
        }
    )
    flash(
        "Linked records refreshed. "
        f"Appointments relinked: {relink_result['appointment_relinked']}, "
        f"Invoices relinked: {relink_result['invoice_relinked']}.",
        "success"
    )
    return redirect(url_for("patient_profile", patient_id=patient.id))

@app.route("/patients/<int:patient_id>/merge", methods=["POST"])
@login_required
def merge_patient_profile(patient_id):
    target = Patient.query.get_or_404(patient_id)
    if not can_manage_patient_records():
        flash("Access denied", "danger")
        return redirect(url_for("patient_profile", patient_id=target.id))

    source_id = to_int_safe(request.form.get("source_patient_id"), 0)
    source = Patient.query.get_or_404(source_id)
    if source.id == target.id:
        flash("Select a different patient to merge.", "danger")
        return redirect(url_for("patient_profile", patient_id=target.id))

    before_target = build_patient_audit_snapshot(target)
    before_source = build_patient_audit_snapshot(source)
    adopted_source_mobile = None

    if not (target.name or "").strip() and (source.name or "").strip():
        target.name = source.name
    if not (target.gender or "").strip() and (source.gender or "").strip():
        target.gender = source.gender
    if target.age in (None, "") and source.age not in (None, ""):
        target.age = source.age

    if not (target.mobile or "").strip() and (source.mobile or "").strip():
        adopted_source_mobile = source.mobile
        source.mobile = None
        db.session.flush()
        target.mobile = adopted_source_mobile

    merged_note_parts = []
    if (source.notes or "").strip():
        source_note_text = source.notes.strip()
        if source_note_text not in (target.notes or ""):
            merged_note_parts.append(source_note_text)
    if source.mobile and source.mobile != target.mobile:
        merged_note_parts.append(f"Alternate mobile from merged profile: {source.mobile}")
    if merged_note_parts:
        base_notes = (target.notes or "").strip()
        joiner = "\n\n" if base_notes else ""
        merged_note_text = "\n\n".join(merged_note_parts)
        target.notes = f"{base_notes}{joiner}{merged_note_text}".strip()

    merge_result = relink_patient_records(
        target,
        matching_names=[target.name, before_target.get("name"), source.name],
        matching_mobiles=[target.mobile, before_target.get("mobile"), source.mobile, adopted_source_mobile],
        source_patient_ids=[source.id],
        sync_display_fields=True
    )

    db.session.delete(source)
    db.session.commit()
    record_audit_event(
        action="Merged patient records",
        entity_type="PATIENT",
        entity_id=target.id,
        ref_code=target.mobile or target.name,
        before={
            "target": before_target,
            "source": before_source
        },
        after=build_patient_audit_snapshot(target),
        extra=merge_result
    )
    flash(
        f"Merged patient #{source_id} into profile #{target.id}. "
        f"Appointments relinked: {merge_result['appointment_relinked']}, "
        f"Invoices relinked: {merge_result['invoice_relinked']}.",
        "success"
    )
    return redirect(url_for("patient_profile", patient_id=target.id))

@app.route("/api/global-search")
@login_required
def api_global_search():
    query = (request.args.get("q") or "").strip()
    return jsonify({
        "query": query,
        "groups": build_global_search_results(query)
    })

@app.route("/audit-logs")
@login_required
def audit_logs():
    user = active_user_by_id(session.get("user_id"))
    if not user or (
        user.role != "admin"
        and not user.can_manage_users
        and not getattr(user, "can_view_audit_logs", False)
    ):
        flash("Access denied", "danger")
        return redirect("/")

    search_query = (request.args.get("search") or "").strip()
    entity_filter = (request.args.get("entity") or "").strip().upper()
    action_filter = (request.args.get("action") or "").strip().upper()
    query = AuditLog.query
    if search_query:
        like = f"%{search_query}%"
        query = query.filter(or_(
            AuditLog.user.ilike(like),
            AuditLog.action.ilike(like),
            AuditLog.entity_type.ilike(like),
            AuditLog.ref_code.ilike(like)
        ))
    if entity_filter:
        query = query.filter(AuditLog.entity_type == entity_filter)
    if action_filter == "CREATE":
        query = query.filter(or_(
            AuditLog.action.ilike("%create%"),
            AuditLog.action.ilike("%added%"),
            AuditLog.action.ilike("%booked%"),
            AuditLog.action.ilike("new %")
        ))
    elif action_filter == "UPDATE":
        query = query.filter(or_(
            AuditLog.action.ilike("%update%"),
            AuditLog.action.ilike("%edit%"),
            AuditLog.action.ilike("%change%")
        ))
    elif action_filter == "STATUS":
        query = query.filter(or_(
            AuditLog.action.ilike("%status%"),
            AuditLog.action.ilike("%paid%"),
            AuditLog.action.ilike("%cancel%"),
            AuditLog.action.ilike("%posted%"),
            AuditLog.action.ilike("%restored%")
        ))
    elif action_filter == "DELETE":
        query = query.filter(or_(
            AuditLog.action.ilike("%delete%"),
            AuditLog.action.ilike("%remove%")
        ))

    raw_logs = query.order_by(AuditLog.created_at.desc(), AuditLog.id.desc()).limit(250).all()
    logs = []
    entity_values = set()
    action_stats = {
        "CREATE": 0,
        "UPDATE": 0,
        "STATUS": 0,
        "DELETE": 0,
        "OTHER": 0
    }
    for row in raw_logs:
        before_data = parse_json_text(row.before_json)
        after_data = parse_json_text(row.after_json)
        extra_data = parse_json_text(row.extra_json)
        action_category = classify_audit_action(row.action)
        entity_values.add((row.entity_type or "").strip().upper())
        change_rows, change_count = build_audit_change_rows(before_data, after_data)
        action_stats[action_category] = action_stats.get(action_category, 0) + 1
        logs.append({
            "id": row.id,
            "user": row.user,
            "action": row.action,
            "action_category": action_category,
            "entity_type": row.entity_type,
            "entity_id": row.entity_id,
            "ref_code": row.ref_code,
            "before_data": before_data,
            "after_data": after_data,
            "extra_data": extra_data,
            "change_rows": change_rows,
            "change_count": change_count,
            "created_at": row.created_at
        })

    return render_template(
        "audit_logs.html",
        logs=logs,
        search_query=search_query,
        entity_filter=entity_filter,
        action_filter=action_filter,
        action_options=("CREATE", "UPDATE", "STATUS", "DELETE", "OTHER"),
        entity_options=sorted(value for value in entity_values if value),
        audit_stats={
            "visible_logs": len(logs),
            "create_count": action_stats.get("CREATE", 0),
            "update_count": action_stats.get("UPDATE", 0) + action_stats.get("STATUS", 0),
            "delete_count": action_stats.get("DELETE", 0),
            "other_count": action_stats.get("OTHER", 0)
        }
    )

@app.route("/appointments")
@login_required
def appointments():
    public_settings = get_public_appointment_booking_settings()
    arrival_window = public_appointment_arrival_window_context(public_settings)
    return render_appointments_page(
        request.args,
        all_statuses=APPOINTMENT_STATUSES,
        build_appointment_report_payload=build_appointment_report_payload,
        build_appointment_summary=build_appointment_summary,
        build_live_queue_snapshot=build_live_queue_snapshot,
        build_appointment_calendar_days=build_appointment_calendar_days,
        clinic_now=clinic_now,
        arrival_window_start=arrival_window["arrival_window_start"],
        arrival_window_end=arrival_window["arrival_window_end"],
    )

@app.route("/appointments/queue/live")
@login_required
def appointments_queue_live():
    target_date = parse_date(request.args.get("date")) or clinic_now().date()
    queue_snapshot = build_live_queue_snapshot(target_date)
    return render_template(
        "queue_board.html",
        queue_snapshot=queue_snapshot,
        target_date=target_date
    )

def normalize_patient_mobile(raw_mobile):
    raw = (raw_mobile or "").strip()
    digits = "".join(ch for ch in raw if ch.isdigit())
    return digits if digits else ""


def normalize_portal_mobile(raw_mobile):
    """Return the ten-digit Indian mobile identity used by public portals.

    Internal records historically retain whatever digit string staff entered.
    The patient-facing portals must be less ambiguous: ``+91 98...`` and
    ``098...`` should authenticate the same ten-digit mobile number.
    """
    digits = normalize_patient_mobile(raw_mobile)
    if len(digits) == 12 and digits.startswith("91"):
        return digits[-10:]
    if len(digits) == 11 and digits.startswith("0"):
        return digits[-10:]
    return digits

def appointment_net_amount(appt):
    fee = to_float_safe(appt.consultation_fee, 0)
    discount = to_float_safe(appt.doctor_discount, 0)
    net = fee - discount
    return round(net if net > 0 else 0, 2)

def build_appointment_summary(appointments):
    counts = {
        "BOOKED": 0,
        "WAITING": 0,
        "CHECKED_IN": 0,
        "IN_CONSULTATION": 0,
        "COMPLETED": 0,
        "CANCELLED": 0
    }
    cash_total = 0.0
    online_total = 0.0
    cash_count = 0
    online_count = 0

    for appt in appointments:
        status = (appt.status or "").strip().upper()
        if status in counts:
            counts[status] += 1

        payment_status = (appt.payment_status or "UNPAID").strip().upper()
        if payment_status != "PAID":
            continue

        net_amount = appointment_net_amount(appt)
        if is_cash_payment_mode(appt.payment_mode):
            cash_total += net_amount
            cash_count += 1
        else:
            online_total += net_amount
            online_count += 1

    cash_total = round(cash_total, 2)
    online_total = round(online_total, 2)
    return {
        "counts": counts,
        "revenue": round(cash_total + online_total, 2),
        "revenue_breakdown": {
            "cash_total": cash_total,
            "online_total": online_total,
            "cash_count": cash_count,
            "online_count": online_count,
            "total": round(cash_total + online_total, 2)
        }
    }

def build_live_queue_snapshot(target_date):
    selected_date = target_date or clinic_now().date()
    arrival_context = public_appointment_display_context()
    appointments = active_appointment_query().filter(
        Appointment.appointment_date == selected_date
    ).order_by(
        Appointment.token_no.asc(),
        Appointment.appointment_time.asc(),
        Appointment.id.asc()
    ).all()

    lanes = {
        "scheduled": [],
        "waiting": [],
        "consulting": [],
        "completed": [],
        "cancelled": []
    }
    active_queue = []

    for appt in appointments:
        status = (appt.status or "BOOKED").strip().upper()
        visit_display = appointment_visit_display_context(appt, arrival_context)
        # An online FCFS booking reserves clinic capacity, not a queue place.
        # It must stay off the active token board until reception gives it an
        # actual token, even if a legacy/status update left it as BOOKED.
        unarrived_public_reservation = (
            visit_display["is_public_fcfs"] and not visit_display["token_assigned"]
        )
        item = {
            "id": appt.id,
            "appointment_no": appt.appointment_no,
            "patient_id": appt.patient_id,
            "patient_name": appt.patient_name,
            "mobile": appt.mobile,
            "token_no": appt.token_no,
            "appointment_time": appt.appointment_time,
            "status": status,
            "payment_status": (appt.payment_status or "UNPAID").strip().upper(),
            "payment_mode": (appt.payment_mode or "CASH").strip().upper(),
            "consultation_fee": round(to_float_safe(appt.consultation_fee, 0), 2),
            "is_public_fcfs": visit_display["is_public_fcfs"],
            "token_assigned": visit_display["token_assigned"],
            "unarrived_public_reservation": unarrived_public_reservation,
            "visit_label": visit_display["visit_label"],
            "token_label": visit_display["token_label"],
        }

        if status == "BOOKED":
            lanes["scheduled"].append(item)
            if not unarrived_public_reservation:
                active_queue.append(item)
        elif status in {"WAITING", "CHECKED_IN"}:
            lanes["waiting"].append(item)
            if not unarrived_public_reservation:
                active_queue.append(item)
        elif status == "IN_CONSULTATION":
            lanes["consulting"].append(item)
            if not unarrived_public_reservation:
                active_queue.append(item)
        elif status == "COMPLETED":
            lanes["completed"].append(item)
        else:
            lanes["cancelled"].append(item)

    active_consulting = [item for item in lanes["consulting"] if not item["unarrived_public_reservation"]]
    current_serving = active_consulting[0] if active_consulting else (active_queue[0] if active_queue else None)
    next_tokens = [
        item["token_no"]
        for item in active_queue[:6]
        if item["token_no"] not in (None, "", " ")
    ]
    summary = build_appointment_summary(appointments)

    return {
        "target_date": selected_date,
        "lanes": lanes,
        "summary": summary,
        "current_serving": current_serving,
        "next_tokens": next_tokens,
        "board_stats": {
            "total": len(appointments),
            "active": len(active_queue),
            "scheduled": len(lanes["scheduled"]),
            "waiting": len(lanes["waiting"]),
            "consulting": len(lanes["consulting"]),
            "completed": len(lanes["completed"]),
            "cancelled": len(lanes["cancelled"])
        }
    }

def calculate_appointment_revenue(from_date=None, to_date=None):
    query = active_appointment_query().filter(
        db.func.upper(db.func.coalesce(Appointment.payment_status, "UNPAID")) == "PAID"
    )
    if from_date:
        query = query.filter(Appointment.appointment_date >= from_date)
    if to_date:
        query = query.filter(Appointment.appointment_date <= to_date)
    total = 0.0
    for appt in query.all():
        total += appointment_net_amount(appt)
    return round(total, 2)

def calculate_appointment_revenue_breakdown(from_date=None, to_date=None):
    query = active_appointment_query().filter(
        db.func.upper(db.func.coalesce(Appointment.payment_status, "UNPAID")) == "PAID"
    )
    if from_date:
        query = query.filter(Appointment.appointment_date >= from_date)
    if to_date:
        query = query.filter(Appointment.appointment_date <= to_date)

    cash_total = 0.0
    online_total = 0.0
    cash_count = 0
    online_count = 0

    for appt in query.all():
        net_amount = appointment_net_amount(appt)
        if is_cash_payment_mode(appt.payment_mode):
            cash_total += net_amount
            cash_count += 1
        else:
            online_total += net_amount
            online_count += 1

    return {
        "cash_total": round(cash_total, 2),
        "online_total": round(online_total, 2),
        "cash_count": cash_count,
        "online_count": online_count,
        "total": round(cash_total + online_total, 2)
    }

def get_next_daily_token(appt_date, exclude_appointment_id=None):
    query = db.session.query(db.func.max(Appointment.token_no)).filter(
        falsey_or_null_column_expr(Appointment.is_deleted),
        Appointment.appointment_date == appt_date
    )
    if exclude_appointment_id:
        query = query.filter(Appointment.id != exclude_appointment_id)
    max_token = query.scalar() or 0
    return int(max_token) + 1

def upsert_patient_profile(form_data):
    patient_name = (form_data.get("patient_name") or "").strip()
    mobile = normalize_patient_mobile(form_data.get("mobile"))
    age_raw = (form_data.get("age") or "").strip()
    gender = form_data.get("gender")
    previous_visit_notes = (form_data.get("previous_visit_notes") or "").strip()
    age_val = None
    if age_raw:
        try:
            age_val = int(age_raw)
        except ValueError:
            age_val = None

    patient = None
    if mobile:
        # When mobile is provided, treat it as primary identity.
        patient = Patient.query.filter_by(mobile=mobile).first()
        if not patient:
            patient = Patient(name=patient_name, mobile=mobile)
            db.session.add(patient)
    else:
        if patient_name:
            patient = Patient.query.filter(
                db.func.lower(Patient.name) == patient_name.lower()
            ).order_by(Patient.id.desc()).first()
        if not patient:
            patient = Patient(name=patient_name, mobile=None)
            db.session.add(patient)

    patient.name = patient_name
    if mobile:
        patient.mobile = mobile
    patient.age = age_val
    patient.gender = gender
    if previous_visit_notes:
        patient.notes = previous_visit_notes
    return patient, mobile

def safe_upsert_patient_profile(form_data, current_patient_id=None):
    mobile = normalize_patient_mobile(form_data.get("mobile"))
    try:
        patient, mobile = upsert_patient_profile(form_data)
        db.session.flush()
        return patient, mobile, None
    except SQLAlchemyError as exc:
        db.session.rollback()
        app.logger.exception("Patient profile upsert failed; continuing appointment flow")
        patient = None
        if mobile:
            try:
                patient = Patient.query.filter_by(mobile=mobile).first()
            except Exception:
                patient = None
        if not patient and current_patient_id:
            try:
                patient = Patient.query.get(current_patient_id)
            except Exception:
                patient = None
        return patient, mobile, exc

def ensure_appointment_runtime_schema():
    # Defensive runtime check for deployments where migration block was skipped.
    required = {
        "appointment": [
            ("payment_mode", "TEXT"),
            ("payment_status", "TEXT"),
            ("doctor_discount", "REAL"),
            ("consultation_fee", "REAL"),
            ("token_no", "INTEGER"),
            ("patient_id", "INTEGER"),
            ("age", "INTEGER"),
            ("gender", "TEXT"),
            ("symptoms", "TEXT"),
            ("previous_visit_notes", "TEXT"),
            ("reason", "TEXT"),
            ("checked_in_at", "TIMESTAMP"),
            ("completed_at", "TIMESTAMP"),
            ("cancelled_at", "TIMESTAMP"),
            ("is_deleted", "BOOLEAN DEFAULT FALSE"),
            ("deleted_at", "TIMESTAMP"),
            ("deleted_by", "TEXT"),
        ],
        "patient": [
            ("age", "INTEGER"),
            ("gender", "TEXT"),
            ("notes", "TEXT"),
            ("updated_at", "TIMESTAMP")
        ]
    }
    return ensure_runtime_schema_requirements(
        required,
        postgres_boolean_columns={
            "appointment": {"is_deleted": False},
            "hold_bill": {"is_deleted": False},
            "return_bill": {"is_cancelled": False},
            "user": {"is_active": True},
            "medicine": {"is_active": True},
            "vendor": {"is_active": True},
            "login_security_event": {"is_suspicious": False},
        },
        log_label="appointment",
    )


def ensure_public_appointment_runtime_schema():
    """Additive compatibility upgrade for the FCFS public portal policy."""
    return ensure_runtime_schema_requirements(
        {
            "appointment_booking_settings": [
                ("arrival_window_start", "TEXT DEFAULT '17:30'"),
                ("arrival_window_end", "TEXT DEFAULT '19:45'"),
            ],
        },
        log_label="public appointment",
    )


def ensure_runtime_schema_requirements(required, *, postgres_boolean_columns=None, log_label="runtime"):
    dialect = (db.session.bind.dialect.name if db.session.bind else "").lower()
    errors = []
    try:
        for table_name, cols in required.items():
            for col_name, col_def in cols:
                try:
                    if dialect == "postgresql":
                        db.session.execute(
                            text(f'ALTER TABLE "{table_name}" ADD COLUMN IF NOT EXISTS "{col_name}" {col_def}')
                        )
                        db.session.commit()
                        continue

                    insp = inspect(db.engine)
                    existing = {c["name"] for c in insp.get_columns(table_name)}
                    if col_name in existing:
                        continue
                    db.session.execute(
                        text(f'ALTER TABLE "{table_name}" ADD COLUMN "{col_name}" {col_def}')
                    )
                    db.session.commit()
                except Exception as exc:
                    db.session.rollback()
                    err_text = str(getattr(exc, "orig", exc))
                    low = err_text.lower()
                    if "duplicate column" in low or "already exists" in low:
                        continue
                    errors.append(f"{table_name}.{col_name}: {err_text}")
        if dialect == "postgresql" and postgres_boolean_columns:
            pg_insp = inspect(db.engine)
            for table_name, columns in postgres_boolean_columns.items():
                if not pg_insp.has_table(table_name):
                    continue
                existing = {c["name"]: c for c in pg_insp.get_columns(table_name)}
                for col_name, default_value in columns.items():
                    column_meta = existing.get(col_name)
                    if not column_meta:
                        continue
                    type_name = column_meta["type"].__class__.__name__.lower()
                    if "bool" in type_name:
                        continue
                    default_sql = "TRUE" if default_value else "FALSE"
                    db.session.execute(text(
                        f'ALTER TABLE "{table_name}" ALTER COLUMN "{col_name}" '
                        'TYPE BOOLEAN USING ('
                        f'CASE WHEN "{col_name}" IS NULL THEN NULL '
                        f'WHEN LOWER(TRIM(CAST("{col_name}" AS TEXT))) IN '
                        "('1', 'true', 't', 'yes', 'on') THEN TRUE ELSE FALSE END)"
                    ))
                    db.session.execute(text(
                        f'ALTER TABLE "{table_name}" ALTER COLUMN "{col_name}" SET DEFAULT {default_sql}'
                    ))
            db.session.commit()
    except Exception:
        db.session.rollback()
        app.logger.exception("Runtime %s schema check failed", log_label)
        return False, "Schema check failed"
    if errors:
        app.logger.error("Runtime %s schema errors: %s", log_label, " | ".join(errors))
        return False, errors[0]
    return True, ""


def ensure_inventory_runtime_schema():
    return ensure_runtime_schema_requirements(
        {
            "medicine": [
                ("is_active", "BOOLEAN DEFAULT TRUE"),
                ("gst_percent", "REAL DEFAULT 5"),
                ("schedule_type", "TEXT DEFAULT ''"),
            ],
            "vendor": [
                ("is_active", "BOOLEAN DEFAULT TRUE"),
                ("deleted_at", "TIMESTAMP"),
                ("deleted_by", "TEXT"),
            ],
        },
        postgres_boolean_columns={
            "medicine": {"is_active": True},
            "vendor": {"is_active": True},
        },
        log_label="inventory",
    )


def ensure_ai_clinic_lab_runtime_schema():
    """Additive compatibility upgrade for the AI doctor/lab profile fields."""
    return ensure_runtime_schema_requirements(
        {
            "clinician": [
                ("sub_specialties_json", "TEXT DEFAULT '[]'"),
                ("languages_json", "TEXT DEFAULT '[]'"),
                ("conditions_treated_json", "TEXT DEFAULT '[]'"),
                ("services_offered_json", "TEXT DEFAULT '[]'"),
            ],
            "lab_test": [
                ("aliases_json", "TEXT DEFAULT '[]'"),
                ("fasting_required", "BOOLEAN DEFAULT FALSE"),
                ("turnaround_text", "TEXT"),
            ],
            "clinic_schedule_rule": [
                ("individual_time_slots", "BOOLEAN DEFAULT TRUE"),
            ],
        },
        postgres_boolean_columns={
            "lab_test": {"fasting_required": False},
            "clinic_schedule_rule": {"individual_time_slots": True},
        },
        log_label="AI clinic/lab profile",
    )


def create_appointment_record(*, appointment_no, patient, mobile, validated, form_data):
    common_values = {
        "appointment_no": appointment_no,
        "token_no": get_next_daily_token(validated["appointment_date"]),
        "patient_id": patient.id if patient else None,
        "patient_name": form_data["patient_name"],
        "mobile": mobile,
        "age": None,
        "gender": validated["gender"],
        "doctor_name": APPOINTMENT_DEFAULT_DOCTOR,
        "appointment_date": validated["appointment_date"],
        "appointment_time": validated["appointment_time"],
        "payment_mode": form_data["payment_mode"],
        "payment_status": "UNPAID",
        "doctor_discount": validated["doctor_discount"],
        "consultation_fee": validated["consultation_fee"],
        "status": "BOOKED",
        "source": "ADMIN",
        "symptoms": form_data["symptoms"],
        "previous_visit_notes": form_data["previous_visit_notes"],
        "notes": form_data["notes"],
        "created_by": session.get("username"),
        "created_at": datetime.utcnow(),
    }
    use_legacy_integer = appointment_soft_delete_uses_legacy_integer()
    insert_values = dict(common_values)
    insert_values["is_deleted"] = 0 if use_legacy_integer else False

    if use_legacy_integer:
        appointment_columns = table_runtime_columns("appointment")
        filtered_values = {
            key: sql_text_bindable_value(value)
            for key, value in insert_values.items()
            if not appointment_columns or key in appointment_columns
        }
        column_names = list(filtered_values.keys())
        placeholders = [f":{name}" for name in column_names]
        quoted_columns = [f'"{name}"' for name in column_names]
        db.session.execute(
            text(
                'INSERT INTO "appointment" '
                f'({", ".join(quoted_columns)}) '
                f'VALUES ({", ".join(placeholders)})'
            ),
            filtered_values,
        )
        db.session.commit()
        return

    try:
        db.session.execute(Appointment.__table__.insert().values(**insert_values))
        db.session.commit()
    except SQLAlchemyError as exc:
        db.session.rollback()
        err_text = str(getattr(exc, "orig", exc) or exc).lower()
        if "of type integer but expression is of type boolean" in err_text:
            appointment_columns = table_runtime_columns("appointment")
            retry_values = {
                key: sql_text_bindable_value(value)
                for key, value in insert_values.items()
                if not appointment_columns or key in appointment_columns
            }
            retry_values["is_deleted"] = 0
            column_names = list(retry_values.keys())
            placeholders = [f":{name}" for name in column_names]
            quoted_columns = [f'"{name}"' for name in column_names]
            db.session.execute(
                text(
                    'INSERT INTO "appointment" '
                    f'({", ".join(quoted_columns)}) '
                    f'VALUES ({", ".join(placeholders)})'
                ),
                retry_values,
            )
            db.session.commit()
            return
        if "of type boolean but expression is of type integer" in err_text:
            retry_values = dict(insert_values)
            retry_values["is_deleted"] = False
            db.session.execute(Appointment.__table__.insert().values(**retry_values))
            db.session.commit()
            return
        raise


def table_runtime_columns(table_name):
    try:
        inspector = inspect(db.engine)
        if not inspector.has_table(table_name):
            return {}
        return {
            (column.get("name") or ""): column
            for column in inspector.get_columns(table_name)
            if column.get("name")
        }
    except Exception:
        app.logger.exception("Unable to inspect %s table columns", table_name)
    return {}


def postgres_runtime_column_data_type(table_name, column_name):
    try:
        if (db.session.bind.dialect.name if db.session.bind else "").lower() != "postgresql":
            return ""
        row = db.session.execute(
            text(
                """
                SELECT data_type
                FROM information_schema.columns
                WHERE table_schema = current_schema()
                  AND table_name = :table_name
                  AND column_name = :column_name
                LIMIT 1
                """
            ),
            {
                "table_name": (table_name or "").strip(),
                "column_name": (column_name or "").strip(),
            },
        ).fetchone()
        return str(row[0] or "").strip().lower() if row else ""
    except Exception:
        app.logger.exception(
            "Unable to inspect PostgreSQL data type for %s.%s",
            table_name,
            column_name,
        )
    return ""


def sql_text_bindable_value(value):
    if isinstance(value, datetime):
        return value.isoformat(sep=" ")
    if isinstance(value, date):
        return value.isoformat()
    if isinstance(value, time):
        return value.strftime("%H:%M:%S")
    return value


def appointment_soft_delete_uses_legacy_integer():
    try:
        dialect = (db.session.bind.dialect.name if db.session.bind else "").lower()
        if dialect != "postgresql":
            return False
        data_type = postgres_runtime_column_data_type("appointment", "is_deleted")
        if data_type:
            return data_type in {"smallint", "integer", "bigint"}
        column = table_runtime_columns("appointment").get("is_deleted")
        if not column:
            return False
        type_name = column["type"].__class__.__name__.lower()
        return "bool" not in type_name
    except Exception:
        app.logger.exception("Unable to inspect appointment.is_deleted column type")
    return False


USER_RUNTIME_BOOLEAN_COLUMNS = ("is_active",) + USER_PERMISSION_FIELDS


def user_boolean_storage_mode_map():
    storage_map = {}
    try:
        runtime_columns = table_runtime_columns("user")
        for column_name in USER_RUNTIME_BOOLEAN_COLUMNS:
            data_type = postgres_runtime_column_data_type("user", column_name)
            if data_type in {"smallint", "integer", "bigint"}:
                storage_map[column_name] = "integer"
                continue
            if data_type == "boolean":
                storage_map[column_name] = "boolean"
                continue
            column_meta = runtime_columns.get(column_name)
            if not column_meta:
                continue
            type_name = column_meta["type"].__class__.__name__.lower()
            storage_map[column_name] = "boolean" if "bool" in type_name else "integer"
    except Exception:
        app.logger.exception("Unable to inspect user boolean storage modes")
    return storage_map


def bind_user_boolean_value(column_name, enabled, storage_map):
    if storage_map.get(column_name) == "integer":
        return 1 if bool(enabled) else 0
    return bool(enabled)


def runtime_boolean_storage_mode(table_name, column_name):
    try:
        data_type = postgres_runtime_column_data_type(table_name, column_name)
        if data_type in {"smallint", "integer", "bigint"}:
            return "integer"
        if data_type == "boolean":
            return "boolean"
        column_meta = table_runtime_columns(table_name).get(column_name)
        if not column_meta:
            return "boolean"
        type_name = column_meta["type"].__class__.__name__.lower()
        return "boolean" if "bool" in type_name else "integer"
    except Exception:
        app.logger.exception("Unable to inspect boolean storage mode for %s.%s", table_name, column_name)
    return "boolean"


def bind_runtime_boolean_value(enabled, storage_mode):
    if storage_mode == "integer":
        return 1 if bool(enabled) else 0
    return bool(enabled)


def persist_new_medicine_record(med):
    tenant_id = current_tenant_id()
    if not tenant_id:
        raise RuntimeError("Cannot persist a medicine without an active tenant context.")
    med.tenant_id = tenant_id

    storage_mode = runtime_boolean_storage_mode("medicine", "is_active")
    if storage_mode != "integer":
        db.session.add(med)
        db.session.flush()
        if not med.id or med.id <= 0:
            raise RuntimeError("New medicine was not assigned a database ID.")
        persisted = Medicine.query.filter(
            Medicine.id == med.id,
            Medicine.tenant_id == tenant_id,
        ).first()
        if persisted is None:
            raise RuntimeError("New medicine could not be retrieved for the active tenant.")
        return persisted

    runtime_columns = table_runtime_columns("medicine")
    if runtime_columns and "tenant_id" not in runtime_columns:
        raise RuntimeError("Medicine table is missing required tenant ownership storage.")
    insert_values = {
        "tenant_id": tenant_id,
        "name": getattr(med, "name", ""),
        "medicine_code": getattr(med, "medicine_code", ""),
        "composition": getattr(med, "composition", ""),
        "company": getattr(med, "company", ""),
        "pack_type": getattr(med, "pack_type", ""),
        "pack_qty": getattr(med, "pack_qty", None),
        "batch": getattr(med, "batch", ""),
        "expiry": getattr(med, "expiry", ""),
        "mrp": getattr(med, "mrp", 0),
        "qty": getattr(med, "qty", 0),
        "discount_percent": getattr(med, "discount_percent", 0),
        "barcode": getattr(med, "barcode", ""),
        "reorder_level": getattr(med, "reorder_level", 10),
        "gst_percent": getattr(med, "gst_percent", 5),
        "schedule_type": getattr(med, "schedule_type", ""),
        "is_active": bind_runtime_boolean_value(getattr(med, "is_active", True), storage_mode),
        "created_at": sql_text_bindable_value(getattr(med, "created_at", None) or datetime.utcnow()),
    }
    filtered_values = {
        key: sql_text_bindable_value(value)
        for key, value in insert_values.items()
        if not runtime_columns or key in runtime_columns
    }
    column_names = list(filtered_values.keys())
    quoted_columns = ", ".join(f'"{column_name}"' for column_name in column_names)
    placeholders = ", ".join(f":{column_name}" for column_name in column_names)
    dialect = (db.session.bind.dialect.name if db.session.bind else "").lower()
    if dialect == "postgresql":
        result = db.session.execute(
            text(
                'INSERT INTO "medicine" '
                f'({quoted_columns}) VALUES ({placeholders}) '
                'RETURNING "id"'
            ),
            filtered_values,
        )
        row = result.fetchone()
        medicine_id = row[0] if row else None
    else:
        result = db.session.execute(
            text(
                'INSERT INTO "medicine" '
                f'({quoted_columns}) VALUES ({placeholders})'
            ),
            filtered_values,
        )
        medicine_id = getattr(result, "lastrowid", None)

    if not medicine_id or medicine_id <= 0:
        raise RuntimeError("New medicine was not assigned a database ID.")
    persisted = Medicine.query.filter(
        Medicine.id == medicine_id,
        Medicine.tenant_id == tenant_id,
    ).first()
    if persisted is None:
        raise RuntimeError("New medicine could not be retrieved for the active tenant.")
    return persisted


def persist_user_update(user, payload):
    permission_values = {
        field_name: bool(payload["permissions"].get(field_name))
        for field_name in USER_PERMISSION_FIELDS
    }
    next_session_version = int(user.session_version or 0) + 1
    storage_map = user_boolean_storage_mode_map()

    if not any(mode == "integer" for mode in storage_map.values()):
        user.username = payload["username"]
        user.role = payload["role"]
        user.access_profile = payload["access_profile"]
        for field_name, enabled in permission_values.items():
            setattr(user, field_name, enabled)
        user.session_version = next_session_version
        db.session.commit()
        return user

    update_values = {
        "user_id": user.id,
        "username": payload["username"],
        "role": payload["role"],
        "access_profile": payload["access_profile"],
        "session_version": next_session_version,
        "is_active": bind_user_boolean_value("is_active", getattr(user, "is_active", True), storage_map),
    }
    for field_name in USER_PERMISSION_FIELDS:
        update_values[field_name] = bind_user_boolean_value(field_name, permission_values[field_name], storage_map)

    set_columns = [
        "username",
        "role",
        "access_profile",
        "session_version",
        "is_active",
        *USER_PERMISSION_FIELDS,
    ]
    set_clause = ", ".join(f'"{column_name}" = :{column_name}' for column_name in set_columns)
    db.session.execute(
        text(f'UPDATE "user" SET {set_clause} WHERE "id" = :user_id'),
        update_values,
    )
    db.session.commit()
    refreshed_user = db.session.get(User, user.id)
    return refreshed_user or user


def persist_new_user(payload):
    permission_values = {
        field_name: bool(payload["permissions"].get(field_name))
        for field_name in USER_PERMISSION_FIELDS
    }
    storage_map = user_boolean_storage_mode_map()
    user = User(
        tenant_id=payload.get("tenant_id") or session.get("tenant_id"),
        username=payload["username"],
        role=payload["role"],
        access_profile=payload["access_profile"],
        **permission_values,
    )
    user.set_password(payload["password"])

    if not any(mode == "integer" for mode in storage_map.values()):
        db.session.add(user)
        db.session.commit()
        return user

    insert_values = {
        "tenant_id": payload.get("tenant_id") or session.get("tenant_id"),
        "username": payload["username"],
        "password_hash": user.password_hash,
        "role": payload["role"],
        "access_profile": payload["access_profile"],
        "session_version": 0,
        "is_active": bind_user_boolean_value("is_active", True, storage_map),
        "created_at": sql_text_bindable_value(datetime.utcnow()),
    }
    for field_name in USER_PERMISSION_FIELDS:
        insert_values[field_name] = bind_user_boolean_value(field_name, permission_values[field_name], storage_map)

    insert_columns = list(insert_values.keys())
    columns_sql = ", ".join(f'"{column_name}"' for column_name in insert_columns)
    placeholders_sql = ", ".join(f':{column_name}' for column_name in insert_columns)
    db.session.execute(
        text(f'INSERT INTO "user" ({columns_sql}) VALUES ({placeholders_sql})'),
        insert_values,
    )
    db.session.commit()
    return active_user_query().filter(db.func.lower(User.username) == payload["username"].lower()).first()


def archive_user_account(user):
    next_session_version = int(user.session_version or 0) + 1
    deleted_at = datetime.utcnow()
    deleted_by = session.get("username")
    storage_map = user_boolean_storage_mode_map()

    if storage_map.get("is_active") == "integer":
        db.session.execute(
            text(
                'UPDATE "user" '
                'SET "is_active" = :is_active, '
                '"deleted_at" = :deleted_at, '
                '"deleted_by" = :deleted_by, '
                '"session_version" = :session_version '
                'WHERE "id" = :user_id'
            ),
            {
                "user_id": user.id,
                "is_active": bind_user_boolean_value("is_active", False, storage_map),
                "deleted_at": sql_text_bindable_value(deleted_at),
                "deleted_by": deleted_by,
                "session_version": next_session_version,
            },
        )
        db.session.commit()
        return

    user.is_active = False
    user.deleted_at = deleted_at
    user.deleted_by = deleted_by
    user.session_version = next_session_version
    db.session.commit()

def build_appointment_calendar_days(appointments, calendar_view, focus_date):
    by_date = {}
    for appt in appointments:
        if not appt.appointment_date:
            continue
        by_date.setdefault(appt.appointment_date, []).append(appt)
    for slots in by_date.values():
        slots.sort(key=lambda x: (x.appointment_time or time(0, 0), x.id))

    days = []
    if calendar_view == "week":
        week_start = focus_date - timedelta(days=focus_date.weekday())
        for i in range(7):
            d = week_start + timedelta(days=i)
            days.append({
                "date": d,
                "label": d.strftime("%a, %d %b"),
                "slots": by_date.get(d, [])
            })
    else:
        d = focus_date
        days.append({
            "date": d,
            "label": d.strftime("%A, %d %B %Y"),
            "slots": by_date.get(d, [])
        })
    return days

def appointment_matches_search(appointment, search_query):
    """Prefix match for the appointments search box.

    Mirrored by the live filter in appointments.html so the table, Excel export
    and print show the same rows: any word of the patient name, the appointment
    number, or (for numeric input) the mobile number must start with the text.
    """
    term = " ".join((search_query or "").lower().split())
    if not term:
        return True
    name = " ".join((appointment.patient_name or "").lower().split())
    if name.startswith(term) or any(word.startswith(term) for word in name.split()):
        return True
    if (appointment.appointment_no or "").lower().startswith(term):
        return True
    if re.fullmatch(r"[\d\s+\-]+", term):
        term_digits = normalize_patient_mobile(term)
        mobile_digits = normalize_patient_mobile(appointment.mobile)
        if term_digits and mobile_digits and (
            mobile_digits.startswith(term_digits) or mobile_digits[-10:].startswith(term_digits)
        ):
            return True
    return False

def build_appointment_report_payload(args, flash_errors=False, include_search=True):
    today = date.today()
    legacy_date = parse_date(args.get("date"))
    report_type = (args.get("appointment_report_type") or "day").strip().lower()
    day_date_raw = (args.get("appointment_day_date") or "").strip()
    if not day_date_raw and legacy_date:
        day_date_raw = legacy_date.isoformat()
    month = to_int_safe(args.get("appointment_month"), 0)
    year = to_int_safe(args.get("appointment_year"), 0)
    from_date_raw = (args.get("appointment_from_date") or "").strip()
    to_date_raw = (args.get("appointment_to_date") or "").strip()
    quick_filter = (args.get("quick_filter") or "").strip().lower()
    search_query = (args.get("search") or "").strip()
    calendar_view = (args.get("calendar_view") or "day").strip().lower()
    if calendar_view not in ("day", "week"):
        calendar_view = "day"

    query = active_appointment_query()
    report_label = "Today"
    focus_date = today

    if quick_filter == "today":
        query = query.filter(Appointment.appointment_date == today)
        report_label = "Today"
        focus_date = today
    elif quick_filter == "tomorrow":
        target = today + timedelta(days=1)
        query = query.filter(Appointment.appointment_date == target)
        report_label = "Tomorrow"
        focus_date = target
    elif quick_filter == "this_week":
        week_start = today - timedelta(days=today.weekday())
        week_end = week_start + timedelta(days=6)
        query = query.filter(
            Appointment.appointment_date >= week_start,
            Appointment.appointment_date <= week_end
        )
        report_label = f"This Week ({week_start.strftime('%d %b')} - {week_end.strftime('%d %b')})"
        focus_date = week_start
        calendar_view = "week"
    elif quick_filter == "pending":
        query = query.filter(Appointment.status.in_(("BOOKED", "WAITING", "CHECKED_IN", "IN_CONSULTATION")))
        report_label = "Pending Appointments"
    elif quick_filter == "completed":
        query = query.filter(Appointment.status == "COMPLETED")
        report_label = "Completed Appointments"
    elif quick_filter == "cancelled":
        query = query.filter(Appointment.status == "CANCELLED")
        report_label = "Cancelled Appointments"
    else:
        if report_type == "day":
            selected_date = parse_date(day_date_raw) or today
            query = query.filter(Appointment.appointment_date == selected_date)
            report_label = selected_date.strftime("%d-%m-%Y")
            focus_date = selected_date
            day_date_raw = selected_date.isoformat()
        elif report_type == "month":
            if month < 1 or month > 12 or year < 1900:
                if flash_errors:
                    flash("Please select a valid month and year for appointment report.", "danger")
                month = today.month
                year = today.year
            query = query.filter(
                db.extract("month", Appointment.appointment_date) == month,
                db.extract("year", Appointment.appointment_date) == year
            )
            report_label = date(year, month, 1).strftime("%B %Y")
            focus_date = date(year, month, 1)
        elif report_type == "date_range":
            start_date = parse_date(from_date_raw)
            end_date = parse_date(to_date_raw)
            if not start_date or not end_date:
                if flash_errors:
                    flash("Please select both From Date and To Date.", "danger")
                start_date = today
                end_date = today
            if end_date < start_date:
                if flash_errors:
                    flash("To Date must be greater than or equal to From Date.", "danger")
                start_date = today
                end_date = today
            query = query.filter(
                Appointment.appointment_date >= start_date,
                Appointment.appointment_date <= end_date
            )
            report_label = f"{start_date.strftime('%d-%m-%Y')} to {end_date.strftime('%d-%m-%Y')}"
            focus_date = start_date
            from_date_raw = start_date.isoformat()
            to_date_raw = end_date.isoformat()
        elif report_type == "all":
            report_label = "All Appointments"
            focus_date = today
        else:
            selected_date = today
            query = query.filter(Appointment.appointment_date == selected_date)
            report_type = "day"
            day_date_raw = selected_date.isoformat()
            report_label = selected_date.strftime("%d-%m-%Y")
            focus_date = selected_date

    appointments = query.order_by(
        Appointment.appointment_date.asc(),
        Appointment.appointment_time.asc(),
        Appointment.id.asc()
    ).all()
    if include_search and search_query:
        appointments = [a for a in appointments if appointment_matches_search(a, search_query)]

    return {
        "appointments": appointments,
        "report_label": report_label,
        "report_filters": {
            "appointment_report_type": report_type,
            "appointment_day_date": day_date_raw or today.isoformat(),
            "appointment_month": month if month > 0 else "",
            "appointment_year": year if year > 0 else "",
            "appointment_from_date": from_date_raw,
            "appointment_to_date": to_date_raw
        },
        "quick_filter": quick_filter,
        "search_query": search_query,
        "calendar_view": calendar_view,
        "focus_date": focus_date
    }

def build_appointment_form_data(appt=None):
    form_data = {
        "patient_name": "",
        "mobile": "",
        "gender": "OTHER",
        "appointment_date": date.today().isoformat(),
        "appointment_time": "",
        "payment_mode": "CASH",
        "doctor_discount": "0",
        "consultation_fee": APPOINTMENT_CONSULTATION_FEES[0],
        "symptoms": "",
        "previous_visit_notes": "",
        "notes": ""
    }
    if appt:
        consultation_fee = to_float_safe(appt.consultation_fee, 0)
        consultation_fee_value = APPOINTMENT_CONSULTATION_FEES[0]
        for allowed_fee in APPOINTMENT_CONSULTATION_FEES:
            if abs(consultation_fee - float(allowed_fee)) < 0.01:
                consultation_fee_value = allowed_fee
                break
        form_data.update({
            "patient_name": appt.patient_name or "",
            "mobile": appt.mobile or "",
            "gender": (appt.gender or "OTHER").upper(),
            "appointment_date": appt.appointment_date.isoformat() if appt.appointment_date else date.today().isoformat(),
            "appointment_time": appt.appointment_time.strftime("%H:%M") if appt.appointment_time else "",
            "payment_mode": (appt.payment_mode or "CASH").strip().upper(),
            "doctor_discount": str(appt.doctor_discount or 0),
            "consultation_fee": consultation_fee_value,
            "symptoms": appt.symptoms or "",
            "previous_visit_notes": appt.previous_visit_notes or "",
            "notes": appt.notes or ""
        })
    if form_data["payment_mode"] not in APPOINTMENT_PAYMENT_MODES:
        form_data["payment_mode"] = "CASH"
    if form_data["gender"] not in APPOINTMENT_GENDERS:
        form_data["gender"] = "OTHER"
    return form_data

def read_appointment_form_data(form_data):
    form_data["patient_name"] = (request.form.get("patient_name") or "").strip()
    form_data["mobile"] = normalize_patient_mobile(request.form.get("mobile"))
    form_data["gender"] = (request.form.get("gender") or "OTHER").strip().upper()
    form_data["appointment_date"] = (request.form.get("appointment_date") or "").strip()
    form_data["appointment_time"] = (request.form.get("appointment_time") or "").strip()
    form_data["payment_mode"] = (request.form.get("payment_mode") or "CASH").strip().upper()
    form_data["doctor_discount"] = (request.form.get("doctor_discount") or "0").strip()
    form_data["consultation_fee"] = (request.form.get("consultation_fee") or "0").strip()
    form_data["symptoms"] = (request.form.get("symptoms") or "").strip()
    form_data["previous_visit_notes"] = (request.form.get("previous_visit_notes") or "").strip()
    form_data["notes"] = (request.form.get("notes") or "").strip()
    return form_data

def validate_appointment_form(form_data):
    appt_date = parse_date(form_data["appointment_date"])
    appt_time = parse_time_value(form_data["appointment_time"])
    if not form_data["patient_name"] or not appt_date or not appt_time:
        return None, "Patient, appointment date and valid time are required."

    if form_data["mobile"] and not form_data["mobile"].isdigit():
        return None, "Mobile number should contain digits only."

    if form_data["payment_mode"] not in APPOINTMENT_PAYMENT_MODES:
        return None, "Invalid payment mode selected."

    gender = (form_data.get("gender") or "OTHER").upper()
    if gender not in APPOINTMENT_GENDERS:
        return None, "Invalid gender selected."

    try:
        doctor_discount = float(form_data["doctor_discount"] or 0)
    except ValueError:
        return None, "Doctor discount should be a valid number."
    if doctor_discount < 0:
        return None, "Doctor discount cannot be negative."

    consultation_fee_raw = (form_data["consultation_fee"] or "").strip()
    if consultation_fee_raw not in APPOINTMENT_CONSULTATION_FEES:
        return None, "Consultation fee must be 600 or 1000."
    consultation_fee = float(consultation_fee_raw)

    return {
        "appointment_date": appt_date,
        "appointment_time": appt_time,
        "gender": gender,
        "doctor_discount": doctor_discount,
        "consultation_fee": consultation_fee
    }, None

def get_patient_suggestions(limit=200):
    return Patient.query.order_by(Patient.updated_at.desc(), Patient.id.desc()).limit(limit).all()


# ---------------- PUBLIC QR APPOINTMENT BOOKING ----------------
# This public flow deliberately sits alongside (rather than inside) the
# staff appointment screen.  It reserves capacity while an OTP is pending,
# then creates the same Appointment record the reception team already uses.
PUBLIC_APPOINTMENT_SESSION_KEY = "public_appointment_booking_ref"
PUBLIC_APPOINTMENT_RESERVATION_MINUTES = max(
    5,
    min(30, to_int_safe(os.environ.get("PUBLIC_APPOINTMENT_RESERVATION_MINUTES"), 10)),
)
PUBLIC_APPOINTMENT_ACTIVE_STATUSES = {"OTP_PENDING", "PAYMENT_PENDING", "BOOKED"}
PUBLIC_APPOINTMENT_ARRIVAL_WINDOW_START = "17:30"
PUBLIC_APPOINTMENT_ARRIVAL_WINDOW_END = "19:45"


def get_public_appointment_booking_settings():
    """Return the singleton policy row, creating the safe 15-patient default."""
    # Existing live databases can predate the arrival-window fields.  The
    # runtime upgrade is additive and leaves staff appointment tables alone.
    ensure_public_appointment_runtime_schema()
    settings = AppointmentBookingSettings.query.order_by(AppointmentBookingSettings.id.asc()).first()
    if settings:
        return settings
    settings = AppointmentBookingSettings(
        booking_enabled=True,
        normal_daily_limit=15,
        priority_daily_limit=2,
        normal_fee=600,
        priority_fee=1000,
        opening_time=PUBLIC_APPOINTMENT_ARRIVAL_WINDOW_START,
        slot_minutes=20,
        arrival_window_start=PUBLIC_APPOINTMENT_ARRIVAL_WINDOW_START,
        arrival_window_end=PUBLIC_APPOINTMENT_ARRIVAL_WINDOW_END,
        max_days_ahead=14,
        booking_cutoff_minutes=30,
    )
    try:
        db.session.add(settings)
        db.session.commit()
        return settings
    except IntegrityError:
        # Two first visitors can reach this branch at the same time.
        db.session.rollback()
        return AppointmentBookingSettings.query.order_by(AppointmentBookingSettings.id.asc()).first()
    except SQLAlchemyError:
        db.session.rollback()
        app.logger.exception("Unable to initialize public appointment settings")
        return settings


def public_appointment_settings_value(settings, field_name, default, *, minimum=None, maximum=None):
    value = getattr(settings, field_name, default) if settings else default
    try:
        value = int(value)
    except (TypeError, ValueError):
        value = default
    if minimum is not None:
        value = max(minimum, value)
    if maximum is not None:
        value = min(maximum, value)
    return value


def public_appointment_arrival_window(settings):
    """Return a validated, clinic-controlled FCFS arrival window.

    The public form never chooses an individual appointment time.  These two
    values instead tell every online patient when to arrive at reception.
    """
    start = parse_time_value(
        getattr(settings, "arrival_window_start", PUBLIC_APPOINTMENT_ARRIVAL_WINDOW_START)
    ) or time(17, 30)
    end = parse_time_value(
        getattr(settings, "arrival_window_end", PUBLIC_APPOINTMENT_ARRIVAL_WINDOW_END)
    ) or time(19, 45)
    if end <= start:
        start, end = time(17, 30), time(19, 45)
    return start, end


def public_appointment_arrival_window_context(settings):
    """Presentation-safe values shared by public and staff appointment pages."""
    start, end = public_appointment_arrival_window(settings)
    start_label = start.strftime("%I:%M %p").lstrip("0")
    end_label = end.strftime("%I:%M %p").lstrip("0")
    return {
        "arrival_window_start": start_label,
        "arrival_window_end": end_label,
        "arrival_window_start_value": start.strftime("%H:%M"),
        "arrival_window_end_value": end.strftime("%H:%M"),
        "arrival_window_label": f"{start_label} to {end_label}",
    }


def is_public_fcfs_appointment(appointment):
    """Whether an Appointment came from the public first-come flow."""
    return (getattr(appointment, "created_by", "") or "").strip().upper() == "PUBLIC_QR"


def public_appointment_display_context(settings=None):
    """Return FCFS copy for staff-facing pages without exposing a marker time.

    Public QR rows retain a non-null ``appointment_time`` only because legacy
    database columns require it.  This helper deliberately gives downstream
    pages a safe, configured arrival window instead of ever rendering that
    implementation marker as a personal appointment time.
    """
    fallback = {
        "arrival_window_start": "5:30 PM",
        "arrival_window_end": "7:45 PM",
        "arrival_window_label": "5:30 PM to 7:45 PM",
    }
    try:
        active_settings = settings if settings is not None else get_public_appointment_booking_settings()
        context = public_appointment_arrival_window_context(active_settings)
        return {
            **fallback,
            **{
                key: value
                for key, value in context.items()
                if key in fallback and value
            },
        }
    except (AttributeError, TypeError, ValueError, SQLAlchemyError):
        # Reporting and the live queue must remain usable during a partial
        # legacy-schema upgrade.  The fallback is the clinic's safe default.
        return fallback


def appointment_visit_display_context(appointment, arrival_context=None):
    """Normalize schedule/token display for manual and public appointments."""
    is_public_fcfs = is_public_fcfs_appointment(appointment)
    token_no = getattr(appointment, "token_no", None)
    token_assigned = token_no not in (None, "", " ")
    if is_public_fcfs:
        arrival_context = arrival_context or public_appointment_display_context()
        return {
            "is_public_fcfs": True,
            "token_assigned": token_assigned,
            "visit_label": f"Arrival window: {arrival_context['arrival_window_label']}",
            "token_label": (
                f"Reception token #{token_no}"
                if token_assigned
                else "Token issued at the reception counter on arrival"
            ),
        }
    appointment_time = getattr(appointment, "appointment_time", None)
    return {
        "is_public_fcfs": False,
        "token_assigned": token_assigned,
        "visit_label": appointment_time.strftime("%I:%M %p") if appointment_time else "-",
        "token_label": f"Token #{token_no}" if token_assigned else "No token assigned",
    }


def public_appointment_server_time_marker(settings):
    """Non-null compatibility marker for legacy Appointment time columns.

    It is deliberately selected by the server and is *not* a booked slot or
    a token.  All FCFS public bookings for a date share the window-start
    marker until reception issues a real token on arrival.
    """
    return public_appointment_arrival_window(settings)[0]


def public_appointment_same_day_booking_closed(selected_date, settings, now=None):
    if selected_date != (now or clinic_now()).date():
        return False
    current = now or clinic_now()
    _start, window_end = public_appointment_arrival_window(settings)
    cutoff_minutes = public_appointment_settings_value(
        settings, "booking_cutoff_minutes", 30, minimum=0, maximum=240
    )
    close_at = datetime.combine(selected_date, window_end) - timedelta(minutes=cutoff_minutes)
    return current.replace(tzinfo=None) >= close_at


def public_appointment_slot_values(_settings, _selected_date, _taken_times=None):
    """Compatibility shim: public bookings no longer expose individual slots."""
    return []


def public_appointment_booking_is_active(booking, now=None):
    if not booking:
        return False
    status = (booking.status or "").strip().upper()
    if status not in PUBLIC_APPOINTMENT_ACTIVE_STATUSES:
        return False
    if status in {"OTP_PENDING", "PAYMENT_PENDING"}:
        current_time = now or datetime.utcnow()
        return bool(booking.reservation_expires_at and booking.reservation_expires_at >= current_time)
    return True


def get_public_appointment_availability(selected_date, settings=None, exclude_booking_id=None):
    """Calculate FCFS quota server-side so browser changes cannot oversell."""
    settings = settings or get_public_appointment_booking_settings()
    now = datetime.utcnow()
    normal_limit = public_appointment_settings_value(settings, "normal_daily_limit", 15, minimum=1, maximum=100)
    priority_limit = public_appointment_settings_value(settings, "priority_daily_limit", 2, minimum=0, maximum=20)

    bookings_query = PublicAppointmentBooking.query.filter(
        PublicAppointmentBooking.appointment_date == selected_date
    )
    if exclude_booking_id:
        bookings_query = bookings_query.filter(PublicAppointmentBooking.id != exclude_booking_id)
    public_bookings = bookings_query.order_by(PublicAppointmentBooking.id.asc()).all()
    active_public_bookings = [
        booking for booking in public_bookings
        if public_appointment_booking_is_active(booking, now)
    ]

    priority_appointment_ids = {
        booking.appointment_id
        for booking in active_public_bookings
        if (booking.booking_type or "").upper() == "PRIORITY"
        and (booking.status or "").upper() == "BOOKED"
        and booking.appointment_id
    }
    active_appointments = active_appointment_query().filter(
        Appointment.appointment_date == selected_date,
        db.func.upper(db.func.coalesce(Appointment.status, "BOOKED")) != "CANCELLED",
    ).all()
    normal_confirmed_count = sum(
        1 for appointment in active_appointments if appointment.id not in priority_appointment_ids
    )
    normal_pending_count = sum(
        1 for booking in active_public_bookings
        if (booking.booking_type or "").upper() == "NORMAL"
        and (booking.status or "").upper() == "OTP_PENDING"
    )
    priority_count = sum(
        1 for booking in active_public_bookings
        if (booking.booking_type or "").upper() == "PRIORITY"
    )
    normal_used = normal_confirmed_count + normal_pending_count
    normal_remaining = max(0, normal_limit - normal_used)
    priority_remaining = max(0, priority_limit - priority_count)
    normal_full = normal_remaining <= 0
    priority_full = priority_remaining <= 0
    priority_available = bool(normal_full and not priority_full)
    same_day_booking_closed = public_appointment_same_day_booking_closed(selected_date, settings)
    message = ""
    if not getattr(settings, "booking_enabled", True):
        message = "Online appointment booking is currently unavailable."
    elif same_day_booking_closed:
        message = "Online booking for today is closed. Please choose another date."
    elif normal_full and priority_full:
        message = "Appointments are full for this date. Please choose another date."
    elif normal_full:
        message = "Regular appointments are full. A limited priority same-day option is available."
    availability = {
        "normal_remaining": normal_remaining,
        "priority_remaining": priority_remaining,
        "normal_full": normal_full,
        "priority_full": priority_full,
        "priority_available": priority_available,
        "normal_used": normal_used,
        "priority_used": priority_count,
        # Kept as an empty list for older callers.  Individual public slots
        # are intentionally no longer generated or accepted.
        "slots": [],
        "same_day_booking_closed": same_day_booking_closed,
        "booking_open": bool(
            getattr(settings, "booking_enabled", True)
            and not same_day_booking_closed
            and (normal_remaining > 0 or priority_available)
        ),
        "message": message,
    }
    availability.update(public_appointment_arrival_window_context(settings))
    return availability


def public_appointment_form_data(source=None):
    source = source or {}
    read_value = source.get if hasattr(source, "get") else lambda _key, default="": default
    return {
        "patient_name": (read_value("patient_name", "") or "").strip()[:120],
        "mobile": normalize_portal_mobile(read_value("mobile", "")),
        "gender": (read_value("gender", "") or "").strip().upper()[:10],
        "appointment_date": (read_value("appointment_date", "") or "").strip()[:10],
        # Ignore a legacy/malicious appointment_time form field.  The server
        # supplies a non-null compatibility marker after validating capacity.
        "appointment_time": "",
        "booking_type": (read_value("booking_type", "NORMAL") or "NORMAL").strip().upper()[:20],
        "symptoms": (read_value("symptoms", "") or "").strip()[:1000],
    }


def validate_public_appointment_request(form_data, settings, availability):
    patient_name = form_data["patient_name"]
    mobile = form_data["mobile"]
    gender = form_data["gender"]
    appointment_date = parse_date(form_data["appointment_date"])
    booking_type = form_data["booking_type"]
    today = clinic_now().date()
    max_days_ahead = public_appointment_settings_value(settings, "max_days_ahead", 14, minimum=0, maximum=90)

    if not getattr(settings, "booking_enabled", True):
        return None, "Online appointment booking is currently unavailable."
    if not patient_name:
        return None, "Please enter the patient's full name."
    if len(mobile) != 10 or not mobile.isdigit():
        return None, "Please enter a valid 10-digit mobile number."
    if gender not in APPOINTMENT_GENDERS:
        return None, "Please select a valid gender."
    if not appointment_date or appointment_date < today or appointment_date > today + timedelta(days=max_days_ahead):
        return None, "Please choose an available appointment date."
    if booking_type not in {"NORMAL", "PRIORITY"}:
        return None, "Please choose a valid booking type."
    if availability.get("same_day_booking_closed"):
        return None, "Online booking for today is closed. Please choose another date."
    capacity_error = public_appointment_capacity_error(booking_type, availability)
    if capacity_error:
        return None, capacity_error

    return {
        "patient_name": patient_name,
        "mobile": mobile,
        "gender": gender,
        "appointment_date": appointment_date,
        "appointment_time": public_appointment_server_time_marker(settings),
        "booking_type": booking_type,
        "symptoms": form_data["symptoms"],
        "amount": round(
            to_float_safe(
                getattr(settings, "priority_fee" if booking_type == "PRIORITY" else "normal_fee", 0),
                0,
            ),
            2,
        ),
    }, ""


def public_appointment_capacity_error(booking_type, availability):
    """Return a patient-safe capacity error for a public booking type."""
    if booking_type == "NORMAL" and availability.get("normal_full"):
        return "Regular appointments are full for this date. Please choose another date."
    if booking_type == "PRIORITY":
        if not availability.get("normal_full"):
            return "Priority booking opens only after regular appointments are full."
        if not availability.get("priority_available"):
            return "Priority appointment capacity is full for this date."
    return ""


def ensure_public_appointment_day_lock(appointment_date):
    """Persist a deterministic lock row before an FCFS capacity mutation."""
    if not appointment_date:
        return None
    existing = PublicAppointmentDayLock.query.filter_by(appointment_date=appointment_date).first()
    if existing:
        return existing
    try:
        lock_row = PublicAppointmentDayLock(appointment_date=appointment_date)
        db.session.add(lock_row)
        db.session.commit()
        return lock_row
    except IntegrityError:
        # Another request created the date row first.  Roll back this empty
        # bootstrap transaction and fetch the shared lock row below.
        db.session.rollback()
        return PublicAppointmentDayLock.query.filter_by(appointment_date=appointment_date).first()
    except SQLAlchemyError:
        db.session.rollback()
        app.logger.exception("Unable to initialize public appointment capacity lock")
        return None


def lock_public_appointment_capacity(appointment_date):
    """Lock one visit date for the duration of a capacity-changing request."""
    if not ensure_public_appointment_day_lock(appointment_date):
        return None
    try:
        return PublicAppointmentDayLock.query.filter_by(
            appointment_date=appointment_date
        ).with_for_update().first()
    except SQLAlchemyError:
        db.session.rollback()
        app.logger.exception("Unable to lock public appointment capacity for %s", appointment_date)
        return None


def create_public_appointment_reservation(payload, settings=None):
    """Reserve one FCFS capacity place while OTP verification is pending."""
    settings = settings or get_public_appointment_booking_settings()
    if not lock_public_appointment_capacity(payload.get("appointment_date")):
        return None, "Unable to reserve an appointment right now. Please try again."

    # Recalculate *inside* the per-date lock; client-provided time data is
    # ignored and a concurrent request cannot oversell the daily quota.
    availability = get_public_appointment_availability(payload["appointment_date"], settings)
    if availability.get("same_day_booking_closed"):
        db.session.rollback()
        return None, "Online booking for today is closed. Please choose another date."
    capacity_error = public_appointment_capacity_error(payload["booking_type"], availability)
    if capacity_error:
        db.session.rollback()
        return None, capacity_error

    booking = PublicAppointmentBooking(
        booking_ref=secrets.token_urlsafe(18),
        patient_name=payload["patient_name"],
        mobile=payload["mobile"],
        gender=payload["gender"],
        appointment_date=payload["appointment_date"],
        # Legacy columns are non-null.  This server-controlled marker means
        # "arrival window begins"; it is not a promised time slot.
        appointment_time=public_appointment_server_time_marker(settings),
        symptoms=payload["symptoms"],
        booking_type=payload["booking_type"],
        amount=payload["amount"],
        status="OTP_PENDING",
        reservation_expires_at=datetime.utcnow() + timedelta(minutes=PUBLIC_APPOINTMENT_RESERVATION_MINUTES),
        source_ip=portal_request_ip(),
    )
    try:
        db.session.add(booking)
        db.session.commit()
        return booking, ""
    except IntegrityError:
        db.session.rollback()
        return None, "Unable to reserve the appointment. Please try again."
    except SQLAlchemyError:
        db.session.rollback()
        app.logger.exception("Unable to create public appointment reservation")
        return None, "Unable to start the appointment request right now. Please try again."
def confirm_public_normal_appointment(booking, settings):
    """Create the clinic's real Appointment record after OTP, never before."""
    if not lock_public_appointment_capacity(booking.appointment_date):
        return None, "Unable to confirm the appointment right now. Please try again."
    availability = get_public_appointment_availability(
        booking.appointment_date,
        settings,
        exclude_booking_id=booking.id,
    )
    if availability.get("same_day_booking_closed"):
        db.session.rollback()
        return None, "Online booking for today is closed. Please choose another date."
    if public_appointment_capacity_error("NORMAL", availability):
        db.session.rollback()
        return None, "Regular appointment capacity was just filled. Please choose another date."

    patient = Patient.query.filter_by(mobile=booking.mobile).first()
    if not patient:
        patient = Patient(
            name=booking.patient_name,
            mobile=booking.mobile,
            gender=booking.gender,
        )
        db.session.add(patient)
        db.session.flush()
    else:
        # Keep a mature patient profile intact, while filling missing details.
        if not (patient.name or "").strip():
            patient.name = booking.patient_name
        if not (patient.gender or "").strip():
            patient.gender = booking.gender

    appointment = Appointment(
        appointment_no=generate_appointment_no(),
        # The actual queue token is issued only when reception checks the
        # patient in.  Public confirmation must not reserve a queue position.
        token_no=None,
        patient_id=patient.id,
        patient_name=booking.patient_name,
        mobile=booking.mobile,
        gender=booking.gender,
        doctor_name=APPOINTMENT_DEFAULT_DOCTOR,
        appointment_date=booking.appointment_date,
        appointment_time=public_appointment_server_time_marker(settings),
        payment_mode="CASH",
        payment_status="UNPAID",
        doctor_discount=0,
        consultation_fee=booking.amount,
        status="BOOKED",
        symptoms=booking.symptoms,
        notes="Booked through public QR portal. Token will be issued at reception on arrival.",
        created_by="PUBLIC_QR",
        is_deleted=False,
    )
    try:
        db.session.add(appointment)
        db.session.flush()
        booking.appointment_id = appointment.id
        booking.patient_id = patient.id
        booking.otp_verified_at = booking.otp_verified_at or datetime.utcnow()
        booking.status = "BOOKED"
        booking.reservation_expires_at = None
        db.session.commit()
    except IntegrityError:
        db.session.rollback()
        return None, "That appointment could not be confirmed. Please try again."
    except SQLAlchemyError:
        db.session.rollback()
        app.logger.exception("Unable to confirm public appointment %s", booking.booking_ref)
        return None, "Unable to confirm the appointment right now. Please try again."

    record_audit_event(
        action="Created public QR appointment",
        entity_type="APPOINTMENT",
        entity_id=appointment.id,
        ref_code=appointment.appointment_no,
        before=None,
        after=build_appointment_audit_snapshot(appointment),
        extra={"booking_ref": booking.booking_ref, "booking_type": "NORMAL", "source": "PUBLIC_QR"},
    )
    return appointment, ""


def confirm_public_priority_appointment(booking, settings, payment_mode, payment_reference):
    """Finalize a priority booking only after staff verifies the payment.

    A gateway webhook can call this same service after signature verification.
    The temporary staff action exists for clinic-verified UPI/card payments; it
    is intentionally admin-only and records the reference for audit.
    """
    if (booking.status or "").upper() != "PAYMENT_PENDING":
        return None, "This priority request is no longer awaiting payment verification."
    if not public_appointment_booking_is_active(booking):
        booking.status = "EXPIRED"
        db.session.commit()
        return None, "This priority payment reservation has expired. Ask the patient to make a new request."
    if payment_mode not in {"ONLINE", "UPI", "CARD"}:
        return None, "Choose the verified online payment method."
    if not payment_reference or len(payment_reference) > 120:
        return None, "Enter a valid payment reference before confirming the priority appointment."

    if not lock_public_appointment_capacity(booking.appointment_date):
        return None, "Unable to confirm the priority appointment right now. Please try again."

    availability = get_public_appointment_availability(
        booking.appointment_date,
        settings,
        exclude_booking_id=booking.id,
    )
    if availability.get("same_day_booking_closed"):
        db.session.rollback()
        return None, "Online booking for today is closed. Please choose another date."
    if public_appointment_capacity_error("PRIORITY", availability):
        db.session.rollback()
        return None, "Priority capacity was just filled. Do not confirm this payment without a replacement booking."

    patient = Patient.query.filter_by(mobile=booking.mobile).first()
    if not patient:
        patient = Patient(name=booking.patient_name, mobile=booking.mobile, gender=booking.gender)
        db.session.add(patient)
        db.session.flush()
    else:
        if not (patient.name or "").strip():
            patient.name = booking.patient_name
        if not (patient.gender or "").strip():
            patient.gender = booking.gender

    appointment = Appointment(
        appointment_no=generate_appointment_no(),
        token_no=None,
        patient_id=patient.id,
        patient_name=booking.patient_name,
        mobile=booking.mobile,
        gender=booking.gender,
        doctor_name=APPOINTMENT_DEFAULT_DOCTOR,
        appointment_date=booking.appointment_date,
        appointment_time=public_appointment_server_time_marker(settings),
        payment_mode=payment_mode,
        payment_status="PAID",
        doctor_discount=0,
        consultation_fee=booking.amount,
        status="BOOKED",
        symptoms=booking.symptoms,
        notes="Priority appointment booked through public QR portal. Token will be issued at reception on arrival.",
        created_by="PUBLIC_QR",
        is_deleted=False,
    )
    now = datetime.utcnow()
    try:
        db.session.add(appointment)
        db.session.flush()
        booking.appointment_id = appointment.id
        booking.patient_id = patient.id
        booking.status = "BOOKED"
        booking.payment_provider = "MANUAL_VERIFIED"
        booking.payment_id = payment_reference
        booking.payment_verified_at = now
        booking.reservation_expires_at = None
        db.session.commit()
    except IntegrityError:
        db.session.rollback()
        return None, "Unable to confirm the priority appointment. Please try again."
    except SQLAlchemyError:
        db.session.rollback()
        app.logger.exception("Unable to finalize priority booking %s", booking.booking_ref)
        return None, "Unable to confirm the priority appointment right now. Please try again."

    record_audit_event(
        action="Confirmed priority appointment payment",
        entity_type="APPOINTMENT",
        entity_id=appointment.id,
        ref_code=appointment.appointment_no,
        before=None,
        after=build_appointment_audit_snapshot(appointment),
        extra={
            "booking_ref": booking.booking_ref,
            "booking_type": "PRIORITY",
            "payment_reference": payment_reference,
            "payment_mode": payment_mode,
            "verified_by": session.get("username"),
        },
    )
    return appointment, ""


def render_public_appointment_booking_form(*, form_data=None, selected_date=None, status_code=200):
    settings = get_public_appointment_booking_settings()
    today = clinic_now().date()
    requested_date = selected_date or (form_data or {}).get("appointment_date") or today.isoformat()
    selected = parse_date(requested_date)
    max_days_ahead = public_appointment_settings_value(settings, "max_days_ahead", 14, minimum=0, maximum=90)
    if not selected or selected < today or selected > today + timedelta(days=max_days_ahead):
        selected = today
    availability = get_public_appointment_availability(selected, settings)
    available_dates = []
    for day_offset in range(max_days_ahead + 1):
        candidate = today + timedelta(days=day_offset)
        candidate_availability = availability if candidate == selected else get_public_appointment_availability(candidate, settings)
        can_book = bool(
            getattr(settings, "booking_enabled", True)
            and candidate_availability.get("booking_open")
        )
        available_dates.append({
            "value": candidate.isoformat(),
            "label": candidate.strftime("%a, %d %b %Y"),
            "available": can_book,
        })
    return render_template(
        "public_appointment_booking.html",
        settings=settings,
        availability=availability,
        selected_date=selected.isoformat(),
        available_dates=available_dates,
        form_data=form_data or {},
        **public_appointment_arrival_window_context(settings),
    ), status_code


@app.route("/book-appointment", methods=["GET", "POST"])
def public_appointment_booking():
    if request.method == "GET":
        requested_date = (request.args.get("date") or "").strip()
        return render_public_appointment_booking_form(selected_date=requested_date)

    form_data = public_appointment_form_data(request.form)
    settings = get_public_appointment_booking_settings()
    selected_date = parse_date(form_data.get("appointment_date"))
    availability = get_public_appointment_availability(selected_date or clinic_now().date(), settings)
    payload, error = validate_public_appointment_request(form_data, settings, availability)
    if error:
        flash(error, "danger")
        return render_public_appointment_booking_form(
            form_data=form_data,
            selected_date=form_data.get("appointment_date"),
            status_code=400,
        )

    booking, error = create_public_appointment_reservation(payload, settings)
    if error:
        flash(error, "danger")
        return render_public_appointment_booking_form(
            form_data=form_data,
            selected_date=form_data.get("appointment_date"),
            status_code=409,
        )
    challenge, _development_code, error = create_portal_otp_challenge(
        mobile=booking.mobile,
        purpose="PUBLIC_APPOINTMENT",
        context_ref=booking.booking_ref,
    )
    if not challenge:
        try:
            db.session.delete(booking)
            db.session.commit()
        except SQLAlchemyError:
            db.session.rollback()
        flash(error or "Unable to send the verification code. Please try again.", "danger")
        return render_public_appointment_booking_form(
            form_data=form_data,
            selected_date=form_data.get("appointment_date"),
            status_code=503,
        )

    session[PUBLIC_APPOINTMENT_SESSION_KEY] = booking.booking_ref
    session.modified = True
    return redirect(url_for("public_appointment_verify"))


def get_public_appointment_session_booking():
    booking_ref = (session.get(PUBLIC_APPOINTMENT_SESSION_KEY) or "").strip()
    if not booking_ref:
        return None
    return PublicAppointmentBooking.query.filter_by(booking_ref=booking_ref).first()


@app.route("/book-appointment/verify", methods=["GET", "POST"])
def public_appointment_verify():
    booking = get_public_appointment_session_booking()
    if not booking:
        flash("Please start a new appointment request.", "warning")
        return redirect(url_for("public_appointment_booking"))
    if (booking.status or "").upper() != "OTP_PENDING" or not public_appointment_booking_is_active(booking):
        if (booking.status or "").upper() == "OTP_PENDING":
            booking.status = "EXPIRED"
            db.session.commit()
        flash("This appointment request has expired. Please start a new booking request.", "warning")
        return redirect(url_for("public_appointment_booking"))

    if request.method == "GET":
        settings = get_public_appointment_booking_settings()
        return render_template(
            "public_appointment_verify.html",
            booking=booking,
            masked_mobile=mask_mobile(booking.mobile),
            **public_appointment_arrival_window_context(settings),
        )

    challenge, error = verify_portal_otp_challenge(
        mobile=booking.mobile,
        purpose="PUBLIC_APPOINTMENT",
        context_ref=booking.booking_ref,
        otp_code=request.form.get("otp_code"),
    )
    if error:
        settings = get_public_appointment_booking_settings()
        flash(error, "danger")
        return render_template(
            "public_appointment_verify.html",
            booking=booking,
            masked_mobile=mask_mobile(booking.mobile),
            **public_appointment_arrival_window_context(settings),
        ), 400

    settings = get_public_appointment_booking_settings()
    booking_type = (booking.booking_type or "NORMAL").upper()
    if booking_type == "NORMAL":
        appointment, error = confirm_public_normal_appointment(booking, settings)
        if error:
            fresh_booking = PublicAppointmentBooking.query.get(booking.id)
            if fresh_booking and fresh_booking.status == "OTP_PENDING":
                fresh_booking.status = "EXPIRED"
                db.session.commit()
            flash(error, "danger")
            return redirect(url_for("public_appointment_booking"))
        return render_template(
            "public_appointment_confirmation.html",
            booking=booking,
            appointment=appointment,
            **public_appointment_arrival_window_context(settings),
        )

    if not lock_public_appointment_capacity(booking.appointment_date):
        flash("Unable to confirm the priority request right now. Please try again.", "danger")
        return redirect(url_for("public_appointment_booking"))
    availability = get_public_appointment_availability(
        booking.appointment_date,
        settings,
        exclude_booking_id=booking.id,
    )
    capacity_error = public_appointment_capacity_error("PRIORITY", availability)
    if availability.get("same_day_booking_closed") or capacity_error:
        booking.status = "EXPIRED"
        db.session.commit()
        flash(capacity_error or "Online booking for today is closed. Please choose another date.", "warning")
        return redirect(url_for("public_appointment_booking"))

    # A browser callback must never be treated as payment proof.  Until a
    # signed gateway webhook is configured, keep this as a visible staff
    # review/payment-pending request instead of creating a paid appointment.
    booking.otp_verified_at = challenge.verified_at or datetime.utcnow()
    booking.status = "PAYMENT_PENDING"
    booking.reservation_expires_at = datetime.utcnow() + timedelta(minutes=PUBLIC_APPOINTMENT_RESERVATION_MINUTES)
    db.session.commit()
    record_audit_event(
        action="Created priority appointment payment request",
        entity_type="PUBLIC_APPOINTMENT_BOOKING",
        entity_id=booking.id,
        ref_code=booking.booking_ref,
        before=None,
        after={
            "booking_type": "PRIORITY",
            "status": booking.status,
            "amount": booking.amount,
            "appointment_date": booking.appointment_date.isoformat(),
        },
        extra={"source": "PUBLIC_QR", "payment_provider": "NOT_CONFIGURED"},
    )
    return render_template(
        "public_appointment_confirmation.html",
        booking=booking,
        appointment=None,
        **public_appointment_arrival_window_context(settings),
    )


@app.route("/book-appointment/confirmation")
def public_appointment_confirmation():
    booking = get_public_appointment_session_booking()
    if not booking:
        return redirect(url_for("public_appointment_booking"))
    appointment = Appointment.query.get(booking.appointment_id) if booking.appointment_id else None
    settings = get_public_appointment_booking_settings()
    return render_template(
        "public_appointment_confirmation.html",
        booking=booking,
        appointment=appointment,
        **public_appointment_arrival_window_context(settings),
    )


@app.route("/appointment")
def public_appointment_landing():
    """Public QR destination with a clear hand-off to the booking form."""
    settings = get_public_appointment_booking_settings()
    return render_template(
        "public_appointment_landing.html",
        settings=settings,
        booking_url=url_for("public_appointment_booking"),
        **public_appointment_arrival_window_context(settings),
    )


def public_appointment_booking_url():
    """Use the configured public HTTPS origin when sharing a reception QR."""
    configured_base = (os.environ.get("PUBLIC_BOOKING_BASE_URL") or "").strip().rstrip("/")
    if configured_base.startswith(("https://", "http://")):
        return f"{configured_base}{url_for('public_appointment_landing')}", True
    return f"{request.url_root.rstrip('/')}{url_for('public_appointment_landing')}", False


def appointment_qr_library():
    try:
        import qrcode  # type: ignore
        return qrcode
    except ImportError:
        return None


@app.route("/appointment-booking/qr")
@login_required
@public_appointment_admin_required
def public_appointment_qr_page():
    booking_url, using_configured_public_url = public_appointment_booking_url()
    return render_template(
        "appointment_booking_qr.html",
        booking_url=booking_url,
        using_configured_public_url=using_configured_public_url,
        qr_available=bool(appointment_qr_library()),
        qr_image_url=url_for("public_appointment_qr_png"),
    )


@app.route("/appointment-booking/qr.png")
@login_required
@public_appointment_admin_required
def public_appointment_qr_png():
    qrcode = appointment_qr_library()
    if not qrcode:
        abort(503, description="QR generation is not installed. Install the updated application requirements first.")
    booking_url, _using_configured_public_url = public_appointment_booking_url()
    qr = qrcode.QRCode(
        version=None,
        error_correction=qrcode.constants.ERROR_CORRECT_M,
        box_size=9,
        border=4,
    )
    qr.add_data(booking_url)
    qr.make(fit=True)
    image = qr.make_image(fill_color="#0f172a", back_color="white")
    image_stream = BytesIO()
    image.save(image_stream, format="PNG")
    image_stream.seek(0)
    return send_file(
        image_stream,
        mimetype="image/png",
        as_attachment=False,
        download_name="appointment-booking-qr.png",
        max_age=0,
    )


def get_active_priority_payment_requests():
    now = datetime.utcnow()
    pending_requests = PublicAppointmentBooking.query.filter(
        PublicAppointmentBooking.status == "PAYMENT_PENDING"
    ).order_by(
        PublicAppointmentBooking.appointment_date.asc(),
        PublicAppointmentBooking.id.asc(),
    ).all()
    expired_any = False
    active_requests = []
    for booking in pending_requests:
        if public_appointment_booking_is_active(booking, now):
            active_requests.append(booking)
        else:
            booking.status = "EXPIRED"
            expired_any = True
    if expired_any:
        try:
            db.session.commit()
        except SQLAlchemyError:
            db.session.rollback()
            app.logger.exception("Unable to expire stale priority payment requests")
    return active_requests


@app.route("/appointment-booking/priority-requests")
@login_required
@public_appointment_admin_required
def public_appointment_priority_requests():
    settings = get_public_appointment_booking_settings()
    return render_template(
        "appointment_priority_requests.html",
        pending_requests=get_active_priority_payment_requests(),
        **public_appointment_arrival_window_context(settings),
    )


@app.route("/appointment-booking/priority-requests/<int:booking_id>/confirm", methods=["POST"])
@login_required
@public_appointment_admin_required
def confirm_public_appointment_priority_request(booking_id):
    booking = PublicAppointmentBooking.query.get_or_404(booking_id)
    settings = get_public_appointment_booking_settings()
    payment_mode = (request.form.get("payment_mode") or "").strip().upper()
    payment_reference = (request.form.get("payment_reference") or "").strip()
    appointment, error = confirm_public_priority_appointment(
        booking,
        settings,
        payment_mode,
        payment_reference,
    )
    if error:
        flash(error, "danger")
        return redirect(url_for("public_appointment_priority_requests"))
    flash(
        f"Priority appointment {appointment.appointment_no} confirmed after payment verification.",
        "success",
    )
    return redirect(url_for("public_appointment_priority_requests"))


@app.route("/appointment-booking/settings", methods=["GET", "POST"])
@login_required
@public_appointment_admin_required
def public_appointment_booking_settings():
    settings = get_public_appointment_booking_settings()
    if request.method == "POST":
        normal_daily_limit = to_int_safe(request.form.get("normal_daily_limit"), 0)
        priority_daily_limit = to_int_safe(request.form.get("priority_daily_limit"), -1)
        # Slot settings are legacy-only. Keep their stored value when an
        # updated FCFS settings form no longer sends the old input.
        slot_minutes_raw = (request.form.get("slot_minutes") or "").strip()
        slot_minutes = to_int_safe(
            slot_minutes_raw,
            public_appointment_settings_value(settings, "slot_minutes", 20, minimum=5, maximum=180),
        )
        max_days_ahead = to_int_safe(request.form.get("max_days_ahead"), -1)
        booking_cutoff_minutes = to_int_safe(request.form.get("booking_cutoff_minutes"), -1)
        normal_fee = to_float_safe(request.form.get("normal_fee"), -1)
        priority_fee = to_float_safe(request.form.get("priority_fee"), -1)
        arrival_start = parse_time_value(
            request.form.get("arrival_window_start")
            or request.form.get("opening_time")
            or getattr(settings, "arrival_window_start", PUBLIC_APPOINTMENT_ARRIVAL_WINDOW_START)
        )
        arrival_end = parse_time_value(
            request.form.get("arrival_window_end")
            or getattr(settings, "arrival_window_end", PUBLIC_APPOINTMENT_ARRIVAL_WINDOW_END)
        )

        if not 1 <= normal_daily_limit <= 100:
            flash("Regular daily capacity must be between 1 and 100.", "danger")
        elif not 0 <= priority_daily_limit <= 20:
            flash("Priority daily capacity must be between 0 and 20.", "danger")
        elif slot_minutes_raw and not 5 <= slot_minutes <= 180:
            flash("Slot duration must be between 5 and 180 minutes.", "danger")
        elif not 0 <= max_days_ahead <= 90:
            flash("Advance booking window must be between 0 and 90 days.", "danger")
        elif not 0 <= booking_cutoff_minutes <= 240:
            flash("Same-day cutoff must be between 0 and 240 minutes.", "danger")
        elif normal_fee < 0 or normal_fee > 100000 or priority_fee < 0 or priority_fee > 100000:
            flash("Please enter valid consultation amounts.", "danger")
        elif not arrival_start or not arrival_end or arrival_end <= arrival_start:
            flash("Arrival window end time must be after its start time.", "danger")
        else:
            before_snapshot = {
                "booking_enabled": bool(settings.booking_enabled),
                "normal_daily_limit": settings.normal_daily_limit,
                "priority_daily_limit": settings.priority_daily_limit,
                "normal_fee": settings.normal_fee,
                "priority_fee": settings.priority_fee,
                "opening_time": settings.opening_time,
                "slot_minutes": settings.slot_minutes,
                "arrival_window_start": getattr(settings, "arrival_window_start", ""),
                "arrival_window_end": getattr(settings, "arrival_window_end", ""),
                "max_days_ahead": settings.max_days_ahead,
                "booking_cutoff_minutes": settings.booking_cutoff_minutes,
            }
            settings.booking_enabled = "booking_enabled" in request.form
            settings.normal_daily_limit = normal_daily_limit
            settings.priority_daily_limit = priority_daily_limit
            settings.normal_fee = round(normal_fee, 2)
            settings.priority_fee = round(priority_fee, 2)
            # Mirror the start only for legacy settings consumers. The public
            # portal reads the explicit arrival window instead of slots.
            settings.opening_time = arrival_start.strftime("%H:%M")
            settings.slot_minutes = slot_minutes
            settings.arrival_window_start = arrival_start.strftime("%H:%M")
            settings.arrival_window_end = arrival_end.strftime("%H:%M")
            settings.max_days_ahead = max_days_ahead
            settings.booking_cutoff_minutes = booking_cutoff_minutes
            settings.updated_by = session.get("username")
            try:
                db.session.commit()
                record_audit_event(
                    action="Updated public appointment booking settings",
                    entity_type="APPOINTMENT_BOOKING_SETTINGS",
                    entity_id=settings.id,
                    ref_code="PUBLIC_QR",
                    before=before_snapshot,
                    after={
                        "booking_enabled": bool(settings.booking_enabled),
                        "normal_daily_limit": settings.normal_daily_limit,
                        "priority_daily_limit": settings.priority_daily_limit,
                        "normal_fee": settings.normal_fee,
                        "priority_fee": settings.priority_fee,
                        "opening_time": settings.opening_time,
                        "slot_minutes": settings.slot_minutes,
                        "arrival_window_start": settings.arrival_window_start,
                        "arrival_window_end": settings.arrival_window_end,
                        "max_days_ahead": settings.max_days_ahead,
                        "booking_cutoff_minutes": settings.booking_cutoff_minutes,
                    },
                )
                flash("Online appointment booking settings saved.", "success")
                return redirect(url_for("public_appointment_booking_settings"))
            except SQLAlchemyError:
                db.session.rollback()
                app.logger.exception("Unable to update public appointment booking settings")
                flash("Unable to save booking settings. Please try again.", "danger")

    return render_template(
        "appointment_booking_settings.html",
        settings=settings,
        pending_priority_count=len(get_active_priority_payment_requests()),
        **public_appointment_arrival_window_context(settings),
    )

@app.route("/appointments/add", methods=["GET", "POST"])
@login_required
def add_appointment():
    form_data = build_appointment_form_data()
    patient_suggestions = get_patient_suggestions()

    if request.method == "POST":
        schema_ok, schema_err = ensure_appointment_runtime_schema()
        if not schema_ok:
            flash("Unable to save appointment because database schema update failed.", "danger")
            return render_template(
                "add_appointment.html",
                form_data=form_data,
                payment_modes=APPOINTMENT_PAYMENT_MODES,
                genders=APPOINTMENT_GENDERS,
                consultation_fee_options=APPOINTMENT_CONSULTATION_FEES,
                patient_suggestions=patient_suggestions,
                edit_mode=False
            )
        form_data = read_appointment_form_data(form_data)
        validated, error_msg = validate_appointment_form(form_data)
        if error_msg:
            flash(error_msg, "danger")
            return render_template(
                "add_appointment.html",
                form_data=form_data,
                payment_modes=APPOINTMENT_PAYMENT_MODES,
                genders=APPOINTMENT_GENDERS,
                consultation_fee_options=APPOINTMENT_CONSULTATION_FEES,
                patient_suggestions=patient_suggestions,
                edit_mode=False
            )

        appointment_saved = False
        created_appointment_no = None
        for attempt in range(2):
            try:
                patient, mobile, _patient_err = safe_upsert_patient_profile(form_data)
                appointment_no = generate_appointment_no()
                create_appointment_record(
                    appointment_no=appointment_no,
                    patient=patient,
                    mobile=mobile,
                    validated=validated,
                    form_data=form_data,
                )
                created_appointment_no = appointment_no
                appointment_saved = True
                break
            except IntegrityError as exc:
                db.session.rollback()
                err_text = str(getattr(exc, "orig", exc)).lower()
                if "appointment_no" in err_text and attempt == 0:
                    # Rare race: regenerate appointment number once.
                    continue
                if "mobile" in err_text:
                    flash("Unable to save appointment. Mobile number is already used in another patient profile.", "danger")
                else:
                    flash("Unable to save appointment due to duplicate data. Please try again.", "danger")
                return render_template(
                    "add_appointment.html",
                    form_data=form_data,
                    payment_modes=APPOINTMENT_PAYMENT_MODES,
                    genders=APPOINTMENT_GENDERS,
                    consultation_fee_options=APPOINTMENT_CONSULTATION_FEES,
                    patient_suggestions=patient_suggestions,
                    edit_mode=False
                )
            except SQLAlchemyError as exc:
                db.session.rollback()
                # Auto-repair + retry once when DB reports missing columns.
                try:
                    err_text = str(getattr(exc, "orig", exc))
                except Exception:
                    err_text = str(exc)
                low = err_text.lower()
                if (
                    "undefined column" in low
                    or "does not exist" in low
                    or ("type integer but expression is of type boolean" in low)
                    or ("datatype mismatch" in low and "boolean" in low and "integer" in low)
                ) and attempt == 0:
                    schema_retry_ok, _ = ensure_appointment_runtime_schema()
                    if schema_retry_ok:
                        continue
                app.logger.exception("Appointment create failed")
                short_err = (err_text or "database error").replace("\n", " ").strip()
                if len(short_err) > 140:
                    short_err = short_err[:140] + "..."
                flash(f"Unable to save appointment due to a database error. {short_err}", "danger")
                return render_template(
                    "add_appointment.html",
                    form_data=form_data,
                    payment_modes=APPOINTMENT_PAYMENT_MODES,
                    genders=APPOINTMENT_GENDERS,
                    consultation_fee_options=APPOINTMENT_CONSULTATION_FEES,
                    patient_suggestions=patient_suggestions,
                    edit_mode=False
                )
        if not appointment_saved:
            flash("Unable to save appointment. Please try again.", "danger")
            return render_template(
                "add_appointment.html",
                form_data=form_data,
                payment_modes=APPOINTMENT_PAYMENT_MODES,
                genders=APPOINTMENT_GENDERS,
                consultation_fee_options=APPOINTMENT_CONSULTATION_FEES,
                patient_suggestions=patient_suggestions,
                edit_mode=False
            )

        flash("Appointment booked successfully.", "success")
        created_appointment = active_appointment_query().filter_by(
            appointment_no=created_appointment_no
        ).first() if appointment_saved else None
        if created_appointment:
            record_audit_event(
                action="Created appointment",
                entity_type="APPOINTMENT",
                entity_id=created_appointment.id,
                ref_code=created_appointment.appointment_no,
                before=None,
                after=build_appointment_audit_snapshot(created_appointment)
            )
        return redirect(url_for(
            "appointments",
            appointment_report_type="day",
            appointment_day_date=validated["appointment_date"].isoformat()
        ))

    return render_template(
        "add_appointment.html",
        form_data=form_data,
        payment_modes=APPOINTMENT_PAYMENT_MODES,
        genders=APPOINTMENT_GENDERS,
        consultation_fee_options=APPOINTMENT_CONSULTATION_FEES,
        patient_suggestions=patient_suggestions,
        edit_mode=False
    )

@app.route("/appointments/<int:id>/edit", methods=["GET", "POST"])
@login_required
def edit_appointment(id):
    appointment = active_appointment_query().filter(Appointment.id == id).first_or_404()
    form_data = build_appointment_form_data(appointment)
    patient_suggestions = get_patient_suggestions()

    if request.method == "POST":
        before_snapshot = build_appointment_audit_snapshot(appointment)
        schema_ok, schema_err = ensure_appointment_runtime_schema()
        if not schema_ok:
            flash("Unable to update appointment because database schema update failed.", "danger")
            return render_template(
                "add_appointment.html",
                form_data=form_data,
                payment_modes=APPOINTMENT_PAYMENT_MODES,
                genders=APPOINTMENT_GENDERS,
                consultation_fee_options=APPOINTMENT_CONSULTATION_FEES,
                patient_suggestions=patient_suggestions,
                edit_mode=True,
                appt_id=appointment.id
            )
        form_data = read_appointment_form_data(form_data)
        validated, error_msg = validate_appointment_form(form_data)
        if error_msg:
            flash(error_msg, "danger")
            return render_template(
                "add_appointment.html",
                form_data=form_data,
                payment_modes=APPOINTMENT_PAYMENT_MODES,
                genders=APPOINTMENT_GENDERS,
                consultation_fee_options=APPOINTMENT_CONSULTATION_FEES,
                patient_suggestions=patient_suggestions,
                edit_mode=True,
                appt_id=appointment.id
            )

        try:
            patient, mobile, patient_err = safe_upsert_patient_profile(
                form_data,
                current_patient_id=appointment.patient_id
            )
            if patient_err:
                # Rollback in safe_upsert may detach loaded row; reload it.
                appointment = active_appointment_query().filter(Appointment.id == id).first_or_404()
            old_date = appointment.appointment_date
            appointment.patient_name = form_data["patient_name"]
            appointment.patient_id = patient.id if patient else appointment.patient_id
            appointment.mobile = mobile
            appointment.gender = validated["gender"]
            appointment.appointment_date = validated["appointment_date"]
            appointment.appointment_time = validated["appointment_time"]
            public_qr_unarrived = (
                (appointment.created_by or "").strip().upper() == "PUBLIC_QR"
                and not appointment.checked_in_at
                and not appointment.token_no
            )
            if not public_qr_unarrived and (old_date != appointment.appointment_date or not appointment.token_no):
                appointment.token_no = get_next_daily_token(
                    appointment.appointment_date,
                    exclude_appointment_id=appointment.id
                )
            appointment.payment_mode = form_data["payment_mode"]
            appointment.doctor_discount = validated["doctor_discount"]
            appointment.consultation_fee = validated["consultation_fee"]
            appointment.symptoms = form_data["symptoms"]
            appointment.previous_visit_notes = form_data["previous_visit_notes"]
            appointment.notes = form_data["notes"]
            if (appointment.payment_status or "").strip().upper() not in APPOINTMENT_PAYMENT_STATUSES:
                appointment.payment_status = "UNPAID"

            db.session.commit()
            record_audit_event(
                action="Updated appointment",
                entity_type="APPOINTMENT",
                entity_id=appointment.id,
                ref_code=appointment.appointment_no,
                before=before_snapshot,
                after=build_appointment_audit_snapshot(appointment)
            )
        except IntegrityError as exc:
            db.session.rollback()
            err_text = str(getattr(exc, "orig", exc)).lower()
            if "mobile" in err_text:
                flash("Unable to update appointment. Mobile number is already used in another patient profile.", "danger")
            else:
                flash("Unable to update appointment due to duplicate data. Please check entries.", "danger")
            return render_template(
                "add_appointment.html",
                form_data=form_data,
                payment_modes=APPOINTMENT_PAYMENT_MODES,
                genders=APPOINTMENT_GENDERS,
                consultation_fee_options=APPOINTMENT_CONSULTATION_FEES,
                patient_suggestions=patient_suggestions,
                edit_mode=True,
                appt_id=appointment.id
            )
        except SQLAlchemyError as exc:
            db.session.rollback()
            try:
                err_text = str(getattr(exc, "orig", exc))
            except Exception:
                err_text = str(exc)
            low = err_text.lower()
            if (
                "undefined column" in low
                or "does not exist" in low
                or ("type integer but expression is of type boolean" in low)
                or ("datatype mismatch" in low and "boolean" in low and "integer" in low)
            ):
                ensure_appointment_runtime_schema()
            app.logger.exception("Appointment update failed")
            short_err = (err_text or "database error").replace("\n", " ").strip()
            if len(short_err) > 140:
                short_err = short_err[:140] + "..."
            flash(f"Unable to update appointment due to a database error. {short_err}", "danger")
            return render_template(
                "add_appointment.html",
                form_data=form_data,
                payment_modes=APPOINTMENT_PAYMENT_MODES,
                genders=APPOINTMENT_GENDERS,
                consultation_fee_options=APPOINTMENT_CONSULTATION_FEES,
                patient_suggestions=patient_suggestions,
                edit_mode=True,
                appt_id=appointment.id
            )

        flash("Appointment updated successfully.", "success")
        return redirect(url_for(
            "appointments",
            appointment_report_type="day",
            appointment_day_date=validated["appointment_date"].isoformat()
        ))

    return render_template(
        "add_appointment.html",
        form_data=form_data,
        payment_modes=APPOINTMENT_PAYMENT_MODES,
        genders=APPOINTMENT_GENDERS,
        consultation_fee_options=APPOINTMENT_CONSULTATION_FEES,
        patient_suggestions=patient_suggestions,
        edit_mode=True,
        appt_id=appointment.id
    )

@app.route("/appointments/<int:id>/status", methods=["POST"])
@login_required
def update_appointment_status(id):
    appointment = active_appointment_query().filter(Appointment.id == id).first_or_404()
    before_snapshot = build_appointment_audit_snapshot(appointment)
    new_status = (request.form.get("status") or "").strip().upper()

    if new_status not in APPOINTMENT_STATUSES:
        flash("Invalid appointment status.", "danger")
        return redirect(request.referrer or url_for("appointments"))

    current_status = (appointment.status or "BOOKED").strip().upper()
    if new_status != current_status:
        allowed = APPOINTMENT_STATUS_FLOW.get(current_status, set())
        if new_status not in allowed:
            flash(f"Invalid transition: {current_status.replace('_', ' ')} to {new_status.replace('_', ' ')}", "danger")
            return redirect(request.referrer or url_for("appointments"))

    if new_status == "COMPLETED" and (appointment.payment_status or "").strip().upper() != "PAID":
        flash("Mark payment as PAID before completing appointment.", "danger")
        return redirect(request.referrer or url_for("appointments"))

    if new_status == "CANCELLED" and (appointment.payment_status or "").strip().upper() == "PAID":
        flash("Paid appointment cannot be cancelled directly. Handle refund first.", "danger")
        return redirect(request.referrer or url_for("appointments"))

    now = datetime.utcnow()
    appointment.status = new_status
    if new_status in {"WAITING", "CHECKED_IN", "IN_CONSULTATION"}:
        appointment.checked_in_at = appointment.checked_in_at or now
    # A public QR confirmation reserves only daily capacity.  Reception's
    # arrival action is the moment a real queue token is issued, preserving
    # first-come, first-served order at the counter.
    if (
        new_status in {"WAITING", "CHECKED_IN"}
        and appointment.token_no is None
        and (appointment.created_by or "").strip().upper() == "PUBLIC_QR"
    ):
        appointment.token_no = get_next_daily_token(appointment.appointment_date)
    if new_status == "COMPLETED":
        appointment.completed_at = now
        appointment.checked_in_at = appointment.checked_in_at or now
    elif new_status == "CANCELLED":
        appointment.cancelled_at = now
        appointment.payment_status = "UNPAID"
        appointment.doctor_discount = 0
        appointment.consultation_fee = 0

    db.session.commit()
    record_audit_event(
        action="Updated appointment status",
        entity_type="APPOINTMENT",
        entity_id=appointment.id,
        ref_code=appointment.appointment_no,
        before=before_snapshot,
        after=build_appointment_audit_snapshot(appointment)
    )
    flash("Appointment status updated.", "success")
    return redirect(
        request.referrer or url_for(
            "appointments",
            appointment_report_type="day",
            appointment_day_date=(appointment.appointment_date.isoformat() if appointment.appointment_date else date.today().isoformat())
        )
    )

@app.route("/appointments/<int:id>/payment/paid", methods=["POST"])
@login_required
def mark_appointment_paid(id):
    return handle_mark_appointment_paid(
        id,
        build_appointment_audit_snapshot=build_appointment_audit_snapshot,
        record_audit_event=record_audit_event,
        validate_mark_paid_transition=validate_mark_paid_transition,
    )

@app.route("/appointments/delete/<int:id>", methods=["POST"])
@login_required
def delete_appointment(id):
    selected_date = date.today().isoformat()
    try:
        ensure_appointment_runtime_schema()
        appointment = active_appointment_query().filter(Appointment.id == id).first()
        if not appointment:
            flash("Appointment not found or already archived.", "warning")
            return redirect(
                request.referrer
                or url_for("appointments", appointment_report_type="day", appointment_day_date=selected_date)
            )

        before_snapshot = build_appointment_audit_snapshot(appointment)
        selected_date = appointment.appointment_date.isoformat() if appointment.appointment_date else selected_date
        deleted_at = datetime.utcnow()
        deleted_by = session.get("username")
        appointment_columns = table_runtime_columns("appointment")

        if appointment_columns:
            use_legacy_integer = appointment_soft_delete_uses_legacy_integer()
            set_clauses = ['"is_deleted" = :is_deleted']
            params = {
                "appointment_id": appointment.id,
                "is_deleted": 1 if use_legacy_integer else True,
            }
            if "deleted_at" in appointment_columns:
                set_clauses.append('"deleted_at" = :deleted_at')
                params["deleted_at"] = deleted_at
            if "deleted_by" in appointment_columns:
                set_clauses.append('"deleted_by" = :deleted_by')
                params["deleted_by"] = deleted_by
            update_sql = text(
                'UPDATE "appointment" '
                f'SET {", ".join(set_clauses)} '
                'WHERE "id" = :appointment_id'
            )
            try:
                db.session.execute(update_sql, params)
            except SQLAlchemyError as exc:
                db.session.rollback()
                err_text = str(getattr(exc, "orig", exc) or exc).lower()
                if "of type integer but expression is of type boolean" in err_text:
                    retry_params = dict(params)
                    retry_params["is_deleted"] = 1
                    db.session.execute(update_sql, retry_params)
                elif "of type boolean but expression is of type integer" in err_text:
                    retry_params = dict(params)
                    retry_params["is_deleted"] = True
                    db.session.execute(update_sql, retry_params)
                else:
                    raise
        else:
            appointment.is_deleted = True
            if hasattr(appointment, "deleted_at"):
                appointment.deleted_at = deleted_at
            if hasattr(appointment, "deleted_by"):
                appointment.deleted_by = deleted_by
        db.session.commit()

        record_audit_event(
            action="Archived appointment",
            entity_type="APPOINTMENT",
            entity_id=before_snapshot.get("id") if before_snapshot else None,
            ref_code=before_snapshot.get("appointment_no", "") if before_snapshot else "",
            before=before_snapshot,
            after=None
        )
        flash("Appointment archived successfully.", "success")
    except SQLAlchemyError as exc:
        db.session.rollback()
        err_text = str(getattr(exc, "orig", exc) or exc).replace("\n", " ").strip()
        if len(err_text) > 160:
            err_text = err_text[:160] + "..."
        app.logger.exception("Appointment delete failed")
        flash(f"Unable to archive appointment due to a database error. {err_text}", "danger")
    except Exception:
        db.session.rollback()
        app.logger.exception("Appointment delete failed unexpectedly")
        flash("Unable to archive appointment due to an unexpected error.", "danger")
    return redirect(request.referrer or url_for("appointments", appointment_report_type="day", appointment_day_date=selected_date))

@app.route("/reports", methods=["GET", "POST"])
@login_required
def reports():
    user = active_user_by_id(session.get("user_id"))
    if not user:
        flash("Access denied", "danger")
        return redirect("/")
    if user.role != "admin" and not user.can_view_reports:
        flash("Access denied", "danger")
        return redirect("/")
    report_validation_error = None
    if request.method == "POST":
        report_validation_error = validate_report_request(request.form, parse_date=parse_date)

    return render_reports_page(
        request_method=request.method,
        form_data=request.form if request.method == "POST" else request.args,
        prevalidated_error=report_validation_error,
        clinic_now=clinic_now,
        fresh_start_date=get_operations_fresh_start_date(),
        parse_date=parse_date,
        to_int_safe=to_int_safe,
        local_date_range_to_storage_bounds=local_date_range_to_storage_bounds,
        normalize_patient_mobile=normalize_patient_mobile,
        or_=or_,
        build_patient_medicine_usage_report=build_patient_medicine_usage_report,
        build_profit_report_summary=build_profit_report_summary,
        build_medicine_report_data=build_medicine_report_data,
        build_invoice_payment_breakdown=build_invoice_payment_breakdown,
        summarize_invoice_collection=summarize_invoice_collection,
    )


@app.route("/reports/export")
@login_required
def export_excel():
    user = active_user_by_id(session.get("user_id"))
    if not user:
        flash("Access denied", "danger")
        return redirect("/")
    if user.role != "admin" and not user.can_view_reports:
        flash("Access denied", "danger")
        return redirect("/")
    import pandas as pd
    from flask import send_file
    from io import BytesIO

    now = clinic_now()
    delivery_mode = (request.args.get("delivery") or "").strip().lower()
    if delivery_mode == "background":
        queued_job = queue_report_export_job(
            app,
            {
                "queued_at": datetime.utcnow().isoformat(),
                "queued_by": session.get("username"),
                "route": "/reports/export",
                "query": {key: value for key, value in request.args.items()},
            }
        )
        if is_async_request():
            return jsonify({
                "ok": True,
                "job_id": queued_job["job_id"],
                "message": "Report export queued for background processing."
            }), 202
        flash(f"Report export queued in background. Job ID: {queued_job['job_id']}", "success")
        return redirect(request.referrer or url_for("reports"))
    db_dialect = db.engine.dialect.name if db.engine else "unknown"
    scope = (request.args.get("scope") or "filtered").strip().lower()
    if scope not in ("filtered", "all"):
        scope = "filtered"

    def build_invoice_rows(rows):
        result = []
        for i in rows:
            payment_breakdown = build_invoice_payment_breakdown(i)
            result.append({
                "Invoice ID": i.id,
                "Invoice No": i.invoice_no,
                "Patient Name": i.customer,
                "Mobile": i.mobile,
                "Doctor": i.doctor,
                "Gender": i.gender,
                "Subtotal": i.subtotal,
                "Discount": i.discount,
                "CGST": i.cgst,
                "SGST": i.sgst,
                "Total": i.total,
                "Rounded Amount": payment_breakdown["rounded_amount"],
                "Payment Mode": payment_breakdown["display_mode"],
                "Payment Type": payment_breakdown["payment_type"],
                "Cash Collection": payment_breakdown["cash_amount"],
                "Online Collection": payment_breakdown["online_amount"],
                "Is Split Payment": "Yes" if payment_breakdown["is_split_payment"] else "No",
                "Internal Note": i.internal_note or "",
                "Status": "CANCELLED" if bool(getattr(i, "is_cancelled", False)) else "ACTIVE",
                "Cancel Reason": getattr(i, "cancel_reason", "") or "",
                "Created By": i.created_by,
                "Created At": i.created_at.strftime("%d-%m-%Y %I:%M %p") if i.created_at else ""
            })
        return result

    def build_invoice_rows_legacy(rows):
        result = []
        for i in rows:
            payment_breakdown = build_invoice_payment_breakdown(i)
            result.append({
                "Invoice No": i.invoice_no,
                "Patient Name": i.customer,
                "Mobile": i.mobile,
                "Date": i.created_at.strftime("%d-%m-%Y") if i.created_at else "",
                "Total (ex GST)": i.subtotal,
                "Rounded Amount": payment_breakdown["rounded_amount"],
                "Payment Mode": payment_breakdown["display_mode"],
                "Payment Type": payment_breakdown["payment_type"],
                "Cash Collection": payment_breakdown["cash_amount"],
                "Online Collection": payment_breakdown["online_amount"],
                "Is Split Payment": "Yes" if payment_breakdown["is_split_payment"] else "No",
                "Internal Note": i.internal_note or "",
                "User": i.created_by
            })
        return result

    def build_invoice_item_rows(rows):
        return [{
            "Item ID": it.id,
            "Invoice ID": it.invoice_id,
            "Name": it.name,
            "Batch": it.batch,
            "Expiry": it.expiry,
            "Qty": it.qty,
            "Price": it.price,
            "Amount": it.amount,
            "Discount %": it.discount_percent,
            "Discount Amount": it.discount_amount,
            "Net Amount": it.net_amount,
            "GST %": getattr(it, "gst_percent", None),
            "Taxable Value": getattr(it, "taxable_amount", None),
            "GST Amount": getattr(it, "gst_amount", None),
            "Cost Price": it.cost_price,
            "Cost Amount": it.cost_amount
        } for it in rows]

    if scope == "filtered":
        report_type = (request.args.get("report_type") or "").strip().lower()
        month = to_int_safe(request.args.get("month"), 0)
        year = to_int_safe(request.args.get("year"), 0)
        from_date = (request.args.get("from_date") or "").strip()
        to_date = (request.args.get("to_date") or "").strip()
        patient = (request.args.get("patient") or "").strip()
        mobile_raw = (request.args.get("mobile") or "").strip()
        search_query = (request.args.get("search_query") or "").strip()
        medicine_query = (request.args.get("medicine_query") or "").strip()
        doctor_query = (request.args.get("doctor_query") or "").strip()
        top_n = request.args.get("top_n")

        query = active_invoice_query()
        returns_query = Return.query.filter(falsey_or_null_column_expr(Return.is_cancelled))
        applied_filter = "all"
        if report_type == "daily":
            today = clinic_now().date()
            start_bound, end_bound = local_date_range_to_storage_bounds(today, today)
            query = query.filter(Invoice.created_at >= start_bound, Invoice.created_at < end_bound)
            returns_query = returns_query.filter(Return.created_at >= start_bound, Return.created_at < end_bound)
            applied_filter = f"daily ({today.isoformat()})"
        elif report_type == "monthly":
            if month >= 1 and month <= 12 and year >= 1900:
                start_bound, end_bound = local_month_to_storage_bounds(year, month)
                query = query.filter(
                    Invoice.created_at >= start_bound,
                    Invoice.created_at < end_bound
                )
                returns_query = returns_query.filter(
                    Return.created_at >= start_bound,
                    Return.created_at < end_bound
                )
                applied_filter = f"monthly ({year}-{month:02d})"
            else:
                applied_filter = "monthly (invalid month/year, exported all)"
        elif report_type == "custom":
            from_date_value = parse_date(from_date)
            to_date_value = parse_date(to_date)
            if from_date_value and to_date_value and to_date_value >= from_date_value:
                from_dt, to_dt = local_date_range_to_storage_bounds(from_date_value, to_date_value)
                query = query.filter(Invoice.created_at >= from_dt, Invoice.created_at < to_dt)
                returns_query = returns_query.filter(Return.created_at >= from_dt, Return.created_at < to_dt)
                applied_filter = f"custom ({from_date} to {to_date})"
            else:
                applied_filter = "custom (invalid dates, exported all)"
        elif report_type == "patient":
            if patient:
                query = query.filter(Invoice.customer.ilike(f"%{patient}%"))
                returns_query = returns_query.filter(Return.customer.ilike(f"%{patient}%"))
                applied_filter = f"patient ({patient})"
            else:
                applied_filter = "patient (blank, exported all)"
        elif report_type == "mobile":
            if mobile_raw:
                mobile_digits = normalize_patient_mobile(mobile_raw)
                normalized_mobile = db.func.replace(
                    db.func.replace(
                        db.func.replace(
                            db.func.replace(
                                db.func.replace(
                                    db.func.replace(db.func.coalesce(Invoice.mobile, ""), " ", ""),
                                    "-", ""
                                ),
                                "+", ""
                            ),
                            "(", ""
                        ),
                        ")", ""
                    ),
                    ".", ""
                )
                if mobile_digits:
                    query = query.filter(
                        or_(
                            normalized_mobile.like(f"%{mobile_digits}%"),
                            Invoice.mobile.ilike(f"%{mobile_raw}%")
                        )
                    )
                    normalized_return_mobile = db.func.replace(
                        db.func.replace(
                            db.func.replace(
                                db.func.replace(
                                    db.func.replace(
                                        db.func.replace(db.func.coalesce(Return.mobile, ""), " ", ""),
                                        "-", ""
                                    ),
                                    "+", ""
                                ),
                                "(",
                                ""
                            ),
                            ")",
                            ""
                        ),
                        ".",
                        ""
                    )
                    returns_query = returns_query.filter(
                        or_(
                            normalized_return_mobile.like(f"%{mobile_digits}%"),
                            Return.mobile.ilike(f"%{mobile_raw}%")
                        )
                    )
                else:
                    query = query.filter(Invoice.mobile.ilike(f"%{mobile_raw}%"))
                    returns_query = returns_query.filter(Return.mobile.ilike(f"%{mobile_raw}%"))
                applied_filter = f"mobile ({mobile_raw})"
            else:
                applied_filter = "mobile (blank, exported all)"
        elif report_type == "doctor":
            from_date_value = parse_date(from_date)
            to_date_value = parse_date(to_date)
            output = BytesIO()
            with pd.ExcelWriter(output, engine="openpyxl") as writer:
                if from_date_value and to_date_value and to_date_value >= from_date_value:
                    doctor_report = load_doctor_wise_report(
                        from_date_value,
                        to_date_value,
                        doctor_query=doctor_query,
                        local_date_range_to_storage_bounds=local_date_range_to_storage_bounds,
                        or_=or_,
                        summarize_invoice_collection=summarize_invoice_collection,
                    )
                    pd.DataFrame([{
                        "Doctor": row["doctor"],
                        "Also Written As": ", ".join(row["other_spellings"]),
                        "Bills": row["bill_count"],
                        "Patients": row["patient_count"],
                        "Sale": row["sale_total"],
                        "Returns": row["return_total"],
                        "Net Sale": row["net_sale"],
                        "Avg Bill": row["avg_bill"],
                        "Share %": row["share_percent"],
                    } for row in doctor_report["rows"]], columns=[
                        "Doctor", "Also Written As", "Bills", "Patients", "Sale",
                        "Returns", "Net Sale", "Avg Bill", "Share %",
                    ]).to_excel(writer, sheet_name="DoctorWise", index=False)
                    pd.DataFrame([{
                        "Invoice No": i.invoice_no,
                        "Date": i.created_at.strftime("%d-%m-%Y") if i.created_at else "",
                        "Patient Name": i.customer,
                        "Mobile": i.mobile,
                        "Doctor": i.doctor or "",
                        "Total": i.total,
                    } for i in doctor_report["invoices"]], columns=[
                        "Invoice No", "Date", "Patient Name", "Mobile", "Doctor", "Total",
                    ]).to_excel(writer, sheet_name="DoctorBills", index=False)
                else:
                    pd.DataFrame([{"Error": "Please select a valid from date and to date."}]).to_excel(
                        writer,
                        sheet_name="DoctorWise",
                        index=False
                    )
            output.seek(0)
            filename = f"Doctor_Wise_Report_{now.strftime('%Y%m%d_%H%M%S')}.xlsx"
            return send_file(
                output,
                as_attachment=True,
                download_name=filename,
                mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                max_age=0
            )
        elif report_type == "profit":
            profit_summary, profit_error = build_profit_report_summary(from_date, to_date)
            output = BytesIO()
            with pd.ExcelWriter(output, engine="openpyxl") as writer:
                if profit_summary:
                    pd.DataFrame([{
                        "From Date": profit_summary["from_date"],
                        "To Date": profit_summary["to_date"],
                        "Sales (ex GST)": profit_summary["sales_total"],
                        "Returns (ex GST)": profit_summary["returns_total"],
                        "Net Sales": profit_summary["net_sales"],
                        "COGS": profit_summary["cogs"],
                        "Return COGS": profit_summary["return_cogs"],
                        "Net COGS": profit_summary["net_cogs"],
                        "Gross Profit": profit_summary["gross_profit"],
                        "Gross Profit %": profit_summary["gross_profit_percentage"]
                    }]).to_excel(writer, sheet_name="ProfitSummary", index=False)
                else:
                    pd.DataFrame([{"Error": profit_error or "Unable to build profit report."}]).to_excel(
                        writer,
                        sheet_name="ProfitSummary",
                        index=False
                    )
            output.seek(0)
            filename = f"Profit_Report_{now.strftime('%Y%m%d_%H%M%S')}.xlsx"
            return send_file(
                output,
                as_attachment=True,
                download_name=filename,
                mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                max_age=0
            )
        elif report_type == "medicine":
            medicine_report, medicine_errors = build_medicine_report_data(
                from_date,
                to_date,
                medicine_query=medicine_query,
                top_n=top_n
            )
            totals = medicine_report["medicine_totals"] or {
                "count": 0,
                "purchase_qty": 0,
                "free_qty": 0,
                "inward_qty": 0,
                "sold_qty": 0,
                "return_qty": 0,
                "net_sold_qty": 0,
                "current_stock": 0,
                "inward_purchase_value": 0.0,
                "purchase_amount": 0.0,
                "return_purchase_amount": 0.0,
                "net_purchase_amount": 0.0,
                "gross_sales_value": 0.0,
                "return_sales_value": 0.0,
                "sales_value": 0.0,
                "net_profit": 0.0,
                "period_days": 0
            }
            summary_rows = [{
                "From Date": from_date,
                "To Date": to_date,
                "Medicine Filter": medicine_query,
                "Top N": medicine_report["top_n"],
                "Medicines": totals["count"],
                "Purchase Qty": totals["purchase_qty"],
                "Free Qty": totals["free_qty"],
                "Inward Qty": totals["inward_qty"],
                "Sold Qty": totals["sold_qty"],
                "Return Qty": totals["return_qty"],
                "Net Sold Qty": totals["net_sold_qty"],
                "Current Stock": totals["current_stock"],
                "Inward Purchase Value": totals["inward_purchase_value"],
                "Purchase Amount": totals["net_purchase_amount"],
                "Sales Amount": totals["sales_value"],
                "Net Profit": totals["net_profit"],
                "Period Days": totals["period_days"],
                "Errors": " | ".join(medicine_errors)
            }]
            movement_rows = [{
                "Medicine": row["medicine"],
                "Purchased": row["purchase_qty"],
                "Free": row["free_qty"],
                "Inward": row["inward_qty"],
                "Sold": row["sold_qty"],
                "Returned": row["return_qty"],
                "Net Sold": row["net_sold_qty"],
                "Current Stock": row["current_stock"],
                "Inward Purchase Value": row["inward_purchase_value"],
                "Purchase Amount": row["net_purchase_amount"],
                "Sales Amount": row["sales_value"],
                "Net Profit": row["net_profit"],
                "Profit %": row["profit_percent"],
                "Avg Daily Sale": row["avg_daily_sale"]
            } for row in medicine_report["medicine_summary"]]
            fast_rows = [{
                "Rank": idx + 1,
                "Medicine": row["medicine"],
                "Net Sold": row["net_sold_qty"],
                "Avg Daily Sale": row["avg_daily_sale"],
                "Current Stock": row["current_stock"],
                "Sales Amount": row["sales_value"],
                "Net Profit": row["net_profit"]
            } for idx, row in enumerate(medicine_report["fast_movers"])]

            output = BytesIO()
            with pd.ExcelWriter(output, engine="openpyxl") as writer:
                pd.DataFrame(summary_rows).to_excel(writer, sheet_name="Summary", index=False)
                pd.DataFrame(movement_rows).to_excel(writer, sheet_name="MedicineMovement", index=False)
                pd.DataFrame(fast_rows).to_excel(writer, sheet_name="FastMovers", index=False)
            output.seek(0)
            filename = f"Medicine_Report_{now.strftime('%Y%m%d_%H%M%S')}.xlsx"
            return send_file(
                output,
                as_attachment=True,
                download_name=filename,
                mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                max_age=0
            )
        elif report_type == "patient_medicine":
            patients, detail_rows, usage_summary, _usage_error = build_patient_medicine_usage_report(
                from_date,
                to_date,
                search_query=search_query
            )

            patient_rows = [{
                "Patient Name": row["patient_name"],
                "Mobile": row["mobile"],
                "Invoice Count": row["invoice_count"],
                "Purchase Count": row["purchase_count"],
                "Distinct Medicines": row["distinct_medicines"],
                "Total Qty": row["total_qty"],
                "Invoice Nos": row["invoice_nos"]
            } for row in patients]

            medicine_rows = [{
                "Patient Name": row["patient_name"],
                "Mobile": row["mobile"],
                "Medicine": row["medicine"],
                "Purchase Count": row["purchase_count"],
                "Total Qty": row["total_qty"],
                "Last Purchase Date": row["last_purchase_date"],
                "Invoice Nos": row["invoice_nos"]
            } for row in detail_rows]

            summary_rows = [{
                "From Date": usage_summary["from_date"] if usage_summary else from_date,
                "To Date": usage_summary["to_date"] if usage_summary else to_date,
                "Search Filter": usage_summary["search_filter"] if usage_summary else (request.args.get("search_query") or ""),
                "Patients": usage_summary["patient_count"] if usage_summary else 0,
                "Patient-Medicine Rows": usage_summary["patient_medicine_count"] if usage_summary else 0,
                "Purchase Count": usage_summary["purchase_count"] if usage_summary else 0,
                "Total Qty": usage_summary["total_qty"] if usage_summary else 0
            }]

            output = BytesIO()
            with pd.ExcelWriter(output, engine="openpyxl") as writer:
                pd.DataFrame(summary_rows).to_excel(writer, sheet_name="Summary", index=False)
                pd.DataFrame(patient_rows).to_excel(writer, sheet_name="Patients", index=False)
                pd.DataFrame(medicine_rows).to_excel(writer, sheet_name="PatientMedicines", index=False)
            output.seek(0)

            filename = f"Patient_Medicine_Usage_{now.strftime('%Y%m%d_%H%M%S')}.xlsx"
            return send_file(
                output,
                as_attachment=True,
                download_name=filename,
                mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                max_age=0
            )
        elif report_type:
            applied_filter = f"{report_type} (not invoice list type, exported all)"

        invoices = query.order_by(Invoice.created_at.desc(), Invoice.id.desc()).all()
        returns = returns_query.order_by(Return.created_at.desc(), Return.id.desc()).all()
        invoice_ids = [i.id for i in invoices]
        invoice_items = []
        if invoice_ids:
            invoice_items = InvoiceItem.query.filter(
                InvoiceItem.invoice_id.in_(invoice_ids)
            ).order_by(InvoiceItem.invoice_id.asc(), InvoiceItem.id.asc()).all()

        collection_summary = summarize_invoice_collection(invoices, returns)
        output = BytesIO()
        with pd.ExcelWriter(output, engine="openpyxl") as writer:
            pd.DataFrame([{
                "Applied Filter": applied_filter,
                "Invoice Count": collection_summary["invoice_count"],
                "Sales Total": collection_summary["sale_total"],
                "Refund Total": collection_summary["refund_total"],
                "Net Sale Total": collection_summary["net_sale_total"],
                "Cash Collection": collection_summary["cash_collection"],
                "Online Collection": collection_summary["online_collection"],
                "Cash Refund": collection_summary["cash_refund_total"],
                "Online Refund": collection_summary["online_refund_total"],
                "Adjusted Payment": collection_summary["adjusted_payment_total"],
                "Refund Due": collection_summary["refund_due_total"],
                "Split Payment Count": collection_summary["split_payment_count"],
                "Cash Received Invoices": collection_summary["cash_invoice_count"],
                "Online Received Invoices": collection_summary["online_invoice_count"],
                "Return Count": collection_summary["return_count"],
            }]).to_excel(writer, sheet_name="Summary", index=False)
            pd.DataFrame(build_invoice_rows_legacy(invoices)).to_excel(writer, sheet_name="Reports", index=False)
        output.seek(0)

        filename = f"Pharmacy_Reports_{now.strftime('%Y%m%d_%H%M%S')}.xlsx"
        return send_file(
            output,
            as_attachment=True,
            download_name=filename,
            mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            max_age=0
        )

    invoices = Invoice.query.order_by(Invoice.created_at.desc(), Invoice.id.desc()).all()
    invoice_items = InvoiceItem.query.order_by(InvoiceItem.id.asc()).all()
    appointments = active_appointment_query().order_by(
        Appointment.appointment_date.desc(),
        Appointment.appointment_time.desc(),
        Appointment.id.desc()
    ).all()
    public_arrival_context = public_appointment_display_context()
    patients = Patient.query.order_by(Patient.updated_at.desc(), Patient.id.desc()).all()
    medicines = Medicine.query.order_by(Medicine.name.asc(), Medicine.batch.asc(), Medicine.id.asc()).all()
    medicine_purchase_rate_lookup = build_medicine_purchase_rate_lookup(medicines)
    returns = Return.query.order_by(Return.created_at.desc(), Return.id.desc()).all()
    return_items = ReturnItem.query.order_by(ReturnItem.id.asc()).all()

    appointment_rows = []
    for a in appointments:
        visit_display = appointment_visit_display_context(a, public_arrival_context)
        appointment_rows.append({
            "Appointment ID": a.id,
            "Appointment No": a.appointment_no,
            "Token No": a.token_no,
            "Token Status": visit_display["token_label"],
            "Visit Type": "Public FCFS" if visit_display["is_public_fcfs"] else "Scheduled",
            "Patient ID": a.patient_id,
            "Patient Name": a.patient_name,
            "Mobile": a.mobile,
            "Age": a.age,
            "Gender": a.gender,
            "Doctor": a.doctor_name,
            "Appointment Date": a.appointment_date.strftime("%d-%m-%Y") if a.appointment_date else "",
            "Visit Time / Arrival Window": visit_display["visit_label"],
            "Payment Mode": a.payment_mode,
            "Payment Status": a.payment_status,
            "Doctor Discount": a.doctor_discount,
            "Consultation Fee": a.consultation_fee,
            "Status": a.status,
            "Symptoms": a.symptoms,
            "Previous Visit Notes": a.previous_visit_notes,
            "Notes": a.notes,
            "Created By": a.created_by,
            "Created At": a.created_at.strftime("%d-%m-%Y %I:%M %p") if a.created_at else ""
        })

    patient_rows = [{
        "Patient ID": p.id,
        "Name": p.name,
        "Mobile": p.mobile,
        "Age": p.age,
        "Gender": p.gender,
        "Notes": p.notes,
        "Created At": p.created_at.strftime("%d-%m-%Y %I:%M %p") if p.created_at else "",
        "Updated At": p.updated_at.strftime("%d-%m-%Y %I:%M %p") if p.updated_at else ""
    } for p in patients]

    medicine_rows = [{
        "Medicine ID": m.id,
        "Name": m.name,
        "Batch": m.batch,
        "Expiry": m.expiry,
        "Composition": m.composition,
        "Company": m.company,
        "Pack Type": m.pack_type,
        "Pack Qty": m.pack_qty,
        "Purchase Rate": round(to_float_safe(medicine_purchase_rate_lookup.get(m.id), 0), 4),
        "MRP": m.mrp,
        "Qty": m.qty,
        "Discount %": m.discount_percent,
        "Created At": m.created_at.strftime("%d-%m-%Y %I:%M %p") if m.created_at else ""
    } for m in medicines]

    return_rows = []
    for r in returns:
        refund_breakdown = build_return_payment_breakdown(r)
        return_rows.append({
            "Return ID": r.id,
            "Return No": r.return_no,
            "Invoice ID": r.invoice_id,
            "Invoice No": r.invoice_no,
            "Customer": r.customer,
            "Mobile": r.mobile,
            "Total Refund": r.total_refund,
            "Adjusted Invoice ID": getattr(r, "adjusted_invoice_id", None),
            "Adjusted Amount": getattr(r, "adjusted_amount", 0),
            "Refund Due": getattr(r, "refund_amount", 0),
            "Cash Refund": refund_breakdown["cash_refund_amount"],
            "Online Refund": refund_breakdown["online_refund_amount"],
            "Refund Type": refund_breakdown["refund_type"],
            "CGST": r.cgst,
            "SGST": r.sgst,
            "Payment Mode": r.payment_mode,
            "Is Cancelled": r.is_cancelled,
            "Cancelled By": r.cancelled_by,
            "Cancelled At": r.cancelled_at.strftime("%d-%m-%Y %I:%M %p") if r.cancelled_at else "",
            "Created By": r.created_by,
            "Created At": r.created_at.strftime("%d-%m-%Y %I:%M %p") if r.created_at else ""
        })

    return_item_rows = [{
        "Return Item ID": ri.id,
        "Return ID": ri.return_id,
        "Invoice Item ID": ri.invoice_item_id,
        "Medicine ID": ri.medicine_id,
        "Medicine Name": ri.medicine_name,
        "Batch": ri.batch,
        "Expiry": ri.expiry,
        "Qty": ri.qty,
        "Price": ri.price,
        "Amount": ri.amount,
        "Net Amount": ri.net_amount,
        "Cost Amount": ri.cost_amount
    } for ri in return_items]

    meta_rows = [
        {"Metric": "Generated At", "Value": now.strftime("%d-%m-%Y %I:%M:%S %p")},
        {"Metric": "Database Dialect", "Value": db_dialect},
        {"Metric": "Scope", "Value": "all"},
        {"Metric": "Invoices", "Value": len(invoices)},
        {"Metric": "Invoice Items", "Value": len(invoice_items)},
        {"Metric": "Appointments", "Value": len(appointments)},
        {"Metric": "Patients", "Value": len(patients)},
        {"Metric": "Medicines", "Value": len(medicines)},
        {"Metric": "Returns", "Value": len(returns)},
        {"Metric": "Return Items", "Value": len(return_items)}
    ]

    output = BytesIO()
    with pd.ExcelWriter(output, engine="openpyxl") as writer:
        pd.DataFrame(meta_rows).to_excel(writer, sheet_name="Meta", index=False)
        pd.DataFrame(build_invoice_rows(invoices)).to_excel(writer, sheet_name="Invoices", index=False)
        pd.DataFrame(build_invoice_item_rows(invoice_items)).to_excel(writer, sheet_name="InvoiceItems", index=False)
        pd.DataFrame(appointment_rows).to_excel(writer, sheet_name="Appointments", index=False)
        pd.DataFrame(patient_rows).to_excel(writer, sheet_name="Patients", index=False)
        pd.DataFrame(medicine_rows).to_excel(writer, sheet_name="Medicines", index=False)
        pd.DataFrame(return_rows).to_excel(writer, sheet_name="Returns", index=False)
        pd.DataFrame(return_item_rows).to_excel(writer, sheet_name="ReturnItems", index=False)

    output.seek(0)
    filename = f"Pharmacy_Reports_Full_{now.strftime('%Y%m%d_%H%M%S')}.xlsx"
    return send_file(
        output,
        as_attachment=True,
        download_name=filename,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        max_age=0
    )

@app.route("/reports/appointments/export")
@login_required
def export_appointments_excel():
    user = active_user_by_id(session.get("user_id"))
    if not user:
        flash("Access denied", "danger")
        return redirect("/")
    if user.role != "admin" and not user.can_view_reports:
        flash("Access denied", "danger")
        return redirect("/")

    import pandas as pd
    from flask import send_file
    from io import BytesIO

    payload = build_appointment_report_payload(request.args, flash_errors=False)
    appointments = payload["appointments"]
    report_type = payload["report_filters"]["appointment_report_type"]
    filter_label = payload["report_label"].replace(" ", "_")
    public_arrival_context = public_appointment_display_context()

    rows = []
    for appt in appointments:
        visit_display = appointment_visit_display_context(appt, public_arrival_context)
        consultation_fee = to_float_safe(appt.consultation_fee, 0)
        doctor_discount = to_float_safe(appt.doctor_discount, 0)
        net_fee = consultation_fee - doctor_discount
        if net_fee < 0:
            net_fee = 0
        payment_status = (
            appt.payment_status
            or ("PAID" if (appt.payment_mode or "").strip().upper() == "PAID" else "UNPAID")
        )
        rows.append({
            "Appointment No": appt.appointment_no or "",
            "Token No": appt.token_no or "",
            "Token Status": visit_display["token_label"],
            "Visit Type": "Public FCFS" if visit_display["is_public_fcfs"] else "Scheduled",
            "Date": appt.appointment_date.strftime("%d-%m-%Y") if appt.appointment_date else "",
            "Visit Time / Arrival Window": visit_display["visit_label"],
            "Patient Name": appt.patient_name or "",
            "Mobile": appt.mobile or "",
            "Gender": appt.gender or "",
            "Status": appt.status or "",
            "Payment Mode": appt.payment_mode or "",
            "Payment Status": str(payment_status).upper(),
            "Consultation Fee": round(consultation_fee, 2),
            "Doctor Discount": round(doctor_discount, 2),
            "Net Fee": round(net_fee, 2),
            "Created By": appt.created_by or ""
        })

    columns = [
        "Appointment No",
        "Token No",
        "Token Status",
        "Visit Type",
        "Date",
        "Visit Time / Arrival Window",
        "Patient Name",
        "Mobile",
        "Gender",
        "Status",
        "Payment Mode",
        "Payment Status",
        "Consultation Fee",
        "Doctor Discount",
        "Net Fee",
        "Created By"
    ]
    df = pd.DataFrame(rows, columns=columns)

    output = BytesIO()
    with pd.ExcelWriter(output, engine="openpyxl") as writer:
        df.to_excel(writer, sheet_name="Appointments", index=False)
    output.seek(0)

    safe_label = filter_label.replace("/", "-").replace(" ", "_")
    filename = f"Appointment_Report_{report_type}_{safe_label}.xlsx"
    return send_file(
        output,
        as_attachment=True,
        download_name=filename,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )

@app.route("/reports/appointments/print")
@login_required
def print_appointments_report():
    user = active_user_by_id(session.get("user_id"))
    if not user:
        flash("Access denied", "danger")
        return redirect("/")
    if user.role != "admin" and not user.can_view_reports:
        flash("Access denied", "danger")
        return redirect("/")

    payload = build_appointment_report_payload(request.args, flash_errors=False)
    appointments = payload["appointments"]
    total_net = round(sum(appointment_net_amount(a) for a in appointments), 2)
    mode = (request.args.get("mode") or "print").strip().lower()
    if mode not in ("print", "pdf"):
        mode = "print"
    public_arrival_context = public_appointment_display_context()
    return render_template(
        "appointment_report_print.html",
        appointments=appointments,
        report_label=payload["report_label"],
        total_net=total_net,
        mode=mode,
        generated_at=datetime.now(),
        public_arrival_window_label=public_arrival_context["arrival_window_label"],
    )


def parse_optional_date(value):
    cleaned = (value or "").strip()
    if not cleaned:
        return None
    try:
        return datetime.strptime(cleaned, "%Y-%m-%d").date()
    except ValueError:
        return None


def subscription_form_payload(form):
    plan_ref = normalize_plan_ref(form.get("plan_ref") or form.get("subscription_plan_ref") or "trial")
    plan = plan_definition(plan_ref)
    start_date = parse_optional_date(form.get("subscription_start")) or clinic_now().date()
    expiry_date = parse_optional_date(form.get("subscription_expiry"))
    if not expiry_date:
        expiry_date = start_date + timedelta(days=int(plan.get("days") or 30))
    user_limit_raw = form.get("user_limit")
    user_limit = user_limit_raw if user_limit_raw not in (None, "", " ") else plan.get("user_limit")
    feature_names = ("pos", "inventory", "reports", "exports", "lab", "appointments")
    features = dict(plan.get("features") or {})
    for feature in feature_names:
        field_name = f"feature_{feature}"
        if field_name in form:
            features[feature] = bool(form.get(field_name))
    return {
        "plan_ref": plan_ref,
        "start_date": start_date,
        "expiry_date": expiry_date,
        "amount": parse_subscription_amount(form.get("amount"), plan.get("amount", 0)),
        "payment_mode": (form.get("payment_mode") or "Manual").strip(),
        "payment_reference": (form.get("payment_reference") or "").strip(),
        "user_limit": user_limit,
        "features": features,
        "notes": (form.get("subscription_notes") or form.get("notes") or "").strip(),
        "status": (form.get("status") or "Active").strip().title(),
    }


def tenant_admin_permissions():
    return {field_name: True for field_name in USER_PERMISSION_FIELDS}


def create_tenant_admin_user(tenant, username, email=""):
    user = User(
        tenant_id=tenant.id,
        username=(username or "").strip(),
        role="admin",
        access_profile="admin",
        **tenant_admin_permissions(),
    )
    user.set_password(secrets.token_urlsafe(32))
    db.session.add(user)
    db.session.flush()
    return user


def super_admin_dashboard_stats():
    today_value = clinic_now().date()
    expiring_until = today_value + timedelta(days=14)
    tenants = Tenant.query.order_by(Tenant.created_at.desc(), Tenant.id.desc()).all()
    for tenant in tenants:
        refresh_tenant_subscription_status(tenant)
    db.session.flush()
    by_status = {}
    for tenant in tenants:
        key = (tenant.status or "").strip().lower()
        by_status[key] = by_status.get(key, 0) + 1
    active_subscriptions = sum(
        1 for tenant in tenants
        if (tenant.status or "").strip().lower() in {"trial", "active"}
        and (not tenant.subscription_expiry or tenant.subscription_expiry >= today_value)
    )
    expiring_subscriptions = sum(
        1 for tenant in tenants
        if tenant.subscription_expiry
        and today_value <= tenant.subscription_expiry <= expiring_until
        and (tenant.status or "").strip().lower() in {"trial", "active"}
    )
    revenue = db.session.query(db.func.coalesce(db.func.sum(SubscriptionHistory.amount), 0)).scalar() or 0
    return {
        "total_tenants": len(tenants),
        "active_tenants": by_status.get("active", 0),
        "trial_tenants": by_status.get("trial", 0),
        "expired_tenants": by_status.get("expired", 0),
        "suspended_tenants": by_status.get("suspended", 0),
        "active_subscriptions": active_subscriptions,
        "expiring_subscriptions": expiring_subscriptions,
        "recorded_subscription_revenue": float(revenue),
    }, tenants


def render_super_admin(template_name="super_admin.html", **context):
    with tenant_scope_disabled():
        stats, tenants = super_admin_dashboard_stats()
        recent_subscriptions = SubscriptionHistory.query.order_by(
            SubscriptionHistory.created_at.desc(),
            SubscriptionHistory.id.desc(),
        ).limit(12).all()
    context.setdefault("stats", stats)
    context.setdefault("tenants", tenants)
    context.setdefault("recent_subscriptions", recent_subscriptions)
    context.setdefault("plans", SUBSCRIPTION_PLAN_DEFINITIONS)
    context.setdefault("status_options", TENANT_STATUS_OPTIONS)
    return render_template(template_name, **context)


@app.route("/activate-account/<token>", methods=["GET", "POST"])
def activate_account(token):
    payload = read_admin_activation_token(token)
    if not payload:
        flash("Activation link is invalid or expired.", "danger")
        return redirect("/login")
    tenant_id = to_int_safe(payload.get("tenant_id"), 0)
    user_id = to_int_safe(payload.get("user_id"), 0)
    with tenant_context(tenant_id):
        user = active_user_query().filter(User.id == user_id, User.tenant_id == tenant_id).first()
    if not user or int(user.session_version or 0) != to_int_safe(payload.get("session_version"), -1):
        flash("Activation link is no longer valid.", "danger")
        return redirect("/login")
    if request.method == "POST":
        password = (request.form.get("password") or "").strip()
        confirm = (request.form.get("confirm_password") or "").strip()
        if not password:
            flash("Password is required.", "danger")
            return render_template("activate_account.html", token=token, user=user)
        if password != confirm:
            flash("Password and confirmation do not match.", "danger")
            return render_template("activate_account.html", token=token, user=user)
        with tenant_context(tenant_id):
            user.set_password(password)
            user.session_version = int(user.session_version or 0) + 1
            db.session.commit()
        flash("Account activated. Please sign in with your pharmacy code.", "success")
        return redirect("/login")
    return render_template("activate_account.html", token=token, user=user)


@app.route("/super-admin")
@login_required
@super_admin_required
def super_admin_dashboard():
    return render_super_admin()


@app.route("/super-admin/tenants/create", methods=["POST"])
@login_required
@super_admin_required
def super_admin_create_tenant():
    pharmacy_name = (request.form.get("pharmacy_name") or "").strip()
    tenant_code = normalize_tenant_code(request.form.get("tenant_code") or pharmacy_name)
    admin_username = (request.form.get("admin_username") or "admin").strip()
    if not pharmacy_name or not admin_username:
        flash("Pharmacy name and administrator username are required.", "danger")
        return redirect("/super-admin")
    with tenant_scope_disabled():
        if Tenant.query.filter(db.func.lower(Tenant.tenant_code) == tenant_code.lower()).first():
            flash("Tenant code already exists.", "danger")
            return redirect("/super-admin")
        if User.query.filter(User.tenant_id.is_(None), db.func.lower(User.username) == admin_username.lower()).first():
            flash("That username is reserved for the platform.", "danger")
            return redirect("/super-admin")
        try:
            settings = TenantSettings(settings_json="{}")
            tenant = Tenant(
                tenant_uid=generate_tenant_uid(),
                tenant_code=tenant_code,
                pharmacy_name=pharmacy_name,
                owner_name=(request.form.get("owner_name") or "").strip(),
                contact_number=(request.form.get("contact_number") or "").strip(),
                email=(request.form.get("email") or "").strip(),
                business_address=(request.form.get("business_address") or "").strip(),
                gstin=(request.form.get("gstin") or "").strip(),
                drug_license=(request.form.get("drug_license") or "").strip(),
                settings=settings,
                status="Trial",
            )
            db.session.add(settings)
            db.session.add(tenant)
            db.session.flush()
            update_tenant_settings(tenant, {
                "invoice_prefix": re.sub(r"[^A-Za-z0-9]+", "", (request.form.get("invoice_prefix") or "INV").upper())[:8] or "INV",
                "purchase_prefix": re.sub(r"[^A-Za-z0-9]+", "", (request.form.get("purchase_prefix") or "PB").upper())[:8] or "PB",
                "return_prefix": re.sub(r"[^A-Za-z0-9]+", "", (request.form.get("return_prefix") or "RB").upper())[:8] or "RB",
                "invoice_format": "standard",
                "tax_preference": "inclusive",
                "billing_preference": "standard",
                "stock_preference": "fifo",
            })
            subscription_payload = subscription_form_payload(request.form)
            if subscription_payload["plan_ref"] == "trial":
                subscription_payload["status"] = "Trial"
            apply_subscription_to_tenant(tenant, created_by=session.get("username"), **subscription_payload)
            with tenant_context(tenant.id):
                admin_user = create_tenant_admin_user(
                    tenant,
                    admin_username,
                    email=(request.form.get("admin_email") or tenant.email or ""),
                )
                db.session.commit()
                activation_url = url_for(
                    "activate_account",
                    token=build_admin_activation_token(admin_user),
                    _external=True,
                )
        except Exception:
            db.session.rollback()
            app.logger.exception("Tenant provisioning failed")
            flash("Tenant could not be created. No partial pharmacy setup was kept.", "danger")
            return redirect("/super-admin")
    flash(f"Pharmacy created. Activation link: {activation_url}", "success")
    return redirect(url_for("super_admin_tenant_detail", tenant_id=tenant.id))


@app.route("/super-admin/tenants/<int:tenant_id>", methods=["GET", "POST"])
@login_required
@super_admin_required
def super_admin_tenant_detail(tenant_id):
    with tenant_scope_disabled():
        tenant = Tenant.query.get_or_404(tenant_id)
        if request.method == "POST":
            tenant.pharmacy_name = (request.form.get("pharmacy_name") or tenant.pharmacy_name).strip()
            tenant.owner_name = (request.form.get("owner_name") or "").strip()
            tenant.contact_number = (request.form.get("contact_number") or "").strip()
            tenant.email = (request.form.get("email") or "").strip()
            tenant.business_address = (request.form.get("business_address") or "").strip()
            tenant.gstin = (request.form.get("gstin") or "").strip()
            tenant.drug_license = (request.form.get("drug_license") or "").strip()
            status = (request.form.get("status") or tenant.status or "Trial").strip().title()
            if status in TENANT_STATUS_OPTIONS:
                previous = (tenant.status or "").lower()
                tenant.status = status
                if previous != "active" and status == "Active":
                    tenant.activated_at = datetime.utcnow()
            db.session.commit()
            flash("Tenant details updated.", "success")
            return redirect(url_for("super_admin_tenant_detail", tenant_id=tenant.id))
        settings = tenant_settings_dict(tenant)
        with tenant_context(tenant.id):
            admins = active_user_query().filter(User.tenant_id == tenant.id, User.role == "admin").order_by(User.username.asc()).all()
            audit_logs = AuditLog.query.order_by(AuditLog.created_at.desc(), AuditLog.id.desc()).limit(25).all()
        history = SubscriptionHistory.query.filter_by(tenant_id=tenant.id).order_by(
            SubscriptionHistory.created_at.desc(), SubscriptionHistory.id.desc()
        ).all()
    return render_super_admin(
        selected_tenant=tenant,
        selected_settings=settings,
        selected_admins=admins,
        selected_history=history,
        selected_audit_logs=audit_logs,
    )


@app.route("/super-admin/tenants/<int:tenant_id>/status", methods=["POST"])
@login_required
@super_admin_required
def super_admin_tenant_status(tenant_id):
    status = (request.form.get("status") or "").strip().title()
    if status not in TENANT_STATUS_OPTIONS:
        flash("Invalid tenant status.", "danger")
        return redirect(url_for("super_admin_tenant_detail", tenant_id=tenant_id))
    with tenant_scope_disabled():
        tenant = Tenant.query.get_or_404(tenant_id)
        tenant.status = status
        if status == "Active" and not tenant.activated_at:
            tenant.activated_at = datetime.utcnow()
        db.session.commit()
    flash(f"Tenant marked {status}.", "success")
    return redirect(url_for("super_admin_tenant_detail", tenant_id=tenant_id))


@app.route("/super-admin/tenants/<int:tenant_id>/subscription", methods=["POST"])
@login_required
@super_admin_required
def super_admin_tenant_subscription(tenant_id):
    with tenant_scope_disabled():
        tenant = Tenant.query.get_or_404(tenant_id)
        try:
            payload = subscription_form_payload(request.form)
            apply_subscription_to_tenant(tenant, created_by=session.get("username"), **payload)
            db.session.commit()
        except Exception:
            db.session.rollback()
            app.logger.exception("Subscription update failed for tenant_id=%s", tenant_id)
            flash("Subscription could not be updated.", "danger")
            return redirect(url_for("super_admin_tenant_detail", tenant_id=tenant_id))
    flash("Subscription updated and history recorded.", "success")
    return redirect(url_for("super_admin_tenant_detail", tenant_id=tenant_id))


@app.route("/super-admin/tenants/<int:tenant_id>/admin", methods=["POST"])
@login_required
@super_admin_required
def super_admin_manage_tenant_admin(tenant_id):
    username = (request.form.get("admin_username") or "").strip()
    if not username:
        flash("Administrator username is required.", "danger")
        return redirect(url_for("super_admin_tenant_detail", tenant_id=tenant_id))
    with tenant_scope_disabled():
        tenant = Tenant.query.get_or_404(tenant_id)
        try:
            with tenant_context(tenant.id):
                user = active_user_query().filter(
                    User.tenant_id == tenant.id,
                    db.func.lower(User.username) == username.lower(),
                ).first()
                if not user:
                    if tenant_user_limit_reached(tenant):
                        flash("User limit reached for this subscription.", "danger")
                        return redirect(url_for("super_admin_tenant_detail", tenant_id=tenant_id))
                    user = create_tenant_admin_user(tenant, username)
                else:
                    user.role = "admin"
                    user.access_profile = "admin"
                    for field_name in USER_PERMISSION_FIELDS:
                        setattr(user, field_name, True)
                user.session_version = int(user.session_version or 0) + 1
                db.session.flush()
                activation_url = url_for("activate_account", token=build_admin_activation_token(user), _external=True)
            db.session.commit()
        except Exception:
            db.session.rollback()
            app.logger.exception("Tenant administrator update failed for tenant_id=%s", tenant_id)
            flash("Tenant administrator could not be updated.", "danger")
            return redirect(url_for("super_admin_tenant_detail", tenant_id=tenant_id))
    flash(f"Tenant administrator ready. Activation link: {activation_url}", "success")
    return redirect(url_for("super_admin_tenant_detail", tenant_id=tenant_id))


@app.route("/super-admin/tenants/<int:tenant_id>/audit")
@login_required
@super_admin_required
def super_admin_tenant_audit(tenant_id):
    with tenant_scope_disabled():
        tenant = Tenant.query.get_or_404(tenant_id)
    with tenant_context(tenant.id):
        logs = AuditLog.query.order_by(AuditLog.created_at.desc(), AuditLog.id.desc()).limit(250).all()
    return render_template("super_admin_audit.html", tenant=tenant, logs=logs)


@app.route("/tenant-master", methods=["GET", "POST"])
@login_required
@admin_required
def tenant_master():
    tenant = current_tenant()
    if not tenant:
        flash("Tenant context is unavailable. Please login again.", "danger")
        return redirect("/login")

    if request.method == "POST":
        pharmacy_name = (request.form.get("pharmacy_name") or "").strip()
        status = (request.form.get("status") or tenant.status or "Trial").strip().title()
        if status not in TENANT_STATUS_OPTIONS:
            status = tenant.status or "Trial"
        if not pharmacy_name:
            flash("Pharmacy name is required.", "danger")
            return render_template(
                "tenant_master.html",
                tenant=tenant,
                status_options=TENANT_STATUS_OPTIONS,
                tenant_settings=tenant_settings_dict(tenant),
                business_identity=tenant_business_identity(tenant),
                business_setup_only=False,
            )

        previous_status = (tenant.status or "").strip().lower()
        tenant.pharmacy_name = pharmacy_name
        tenant.owner_name = (request.form.get("owner_name") or "").strip()
        tenant.contact_number = (request.form.get("contact_number") or "").strip()
        tenant.email = (request.form.get("email") or "").strip()
        tenant.business_address = (request.form.get("business_address") or "").strip()
        tenant.gstin = (request.form.get("gstin") or "").strip()
        tenant.drug_license = (request.form.get("drug_license") or "").strip()
        tenant.subscription_plan_ref = (request.form.get("subscription_plan_ref") or "").strip()
        tenant.subscription_start = parse_optional_date(request.form.get("subscription_start"))
        tenant.subscription_expiry = parse_optional_date(request.form.get("subscription_expiry"))
        tenant.status = status
        invoice_prefix = re.sub(r"[^A-Za-z0-9]+", "", (request.form.get("invoice_prefix") or "INV").upper())[:8] or "INV"
        purchase_prefix = re.sub(r"[^A-Za-z0-9]+", "", (request.form.get("purchase_prefix") or "PB").upper())[:8] or "PB"
        return_prefix = re.sub(r"[^A-Za-z0-9]+", "", (request.form.get("return_prefix") or "RB").upper())[:8] or "RB"
        update_tenant_settings(tenant, {
            "invoice_prefix": invoice_prefix,
            "purchase_prefix": purchase_prefix,
            "return_prefix": return_prefix,
            "invoice_format": (request.form.get("invoice_format") or "standard").strip()[:40],
            "tax_preference": (request.form.get("tax_preference") or "inclusive").strip()[:40],
            "billing_preference": (request.form.get("billing_preference") or "standard").strip()[:80],
            "stock_preference": (request.form.get("stock_preference") or "fifo").strip()[:40],
        })
        if previous_status != "active" and status.lower() == "active":
            tenant.activated_at = datetime.utcnow()
        db.session.commit()
        session["tenant_name"] = tenant.pharmacy_name
        flash("Tenant Master updated successfully.", "success")
        return redirect("/tenant-master")

    return render_template(
        "tenant_master.html",
        tenant=tenant,
        status_options=TENANT_STATUS_OPTIONS,
        tenant_settings=tenant_settings_dict(tenant),
        business_identity=tenant_business_identity(tenant),
        business_setup_only=False,
    )


def _business_setup_template(tenant, *, business_setup_only=True):
    return render_template(
        "tenant_master.html",
        tenant=tenant,
        status_options=TENANT_STATUS_OPTIONS,
        tenant_settings=tenant_settings_dict(tenant),
        business_identity=tenant_business_identity(tenant),
        business_setup_only=business_setup_only,
    )


def _validate_business_setup(form, logo_file):
    values = {
        "pharmacy_name": (form.get("pharmacy_name") or "").strip(),
        "legal_business_name": (form.get("legal_business_name") or "").strip(),
        "owner_name": (form.get("owner_name") or "").strip(),
        "contact_number": (form.get("contact_number") or "").strip(),
        "alternate_mobile": (form.get("alternate_mobile") or "").strip(),
        "email": (form.get("email") or "").strip(),
        "business_address": (form.get("business_address") or "").strip(),
        "city": (form.get("city") or "").strip(),
        "state": (form.get("state") or "").strip(),
        "pin_code": (form.get("pin_code") or "").strip(),
        "gstin": (form.get("gstin") or "").strip().upper(),
        "drug_license": (form.get("drug_license") or "").strip(),
        "business_type": (form.get("business_type") or "").strip(),
        "invoice_header": (form.get("invoice_header") or "").strip(),
        "invoice_footer": (form.get("invoice_footer") or "").strip(),
        "invoice_terms": (form.get("invoice_terms") or "").strip(),
        "authorized_signatory": (form.get("authorized_signatory") or "").strip(),
        "invoice_prefix": re.sub(
            r"[^A-Za-z0-9]+", "", (form.get("invoice_prefix") or "INV").upper()
        )[:8] or "INV",
    }
    limits = {
        "pharmacy_name": 160,
        "legal_business_name": 160,
        "owner_name": 120,
        "contact_number": 30,
        "alternate_mobile": 30,
        "email": 160,
        "business_address": 2000,
        "city": 100,
        "state": 100,
        "pin_code": 20,
        "gstin": 30,
        "drug_license": 80,
        "business_type": 80,
        "invoice_header": 500,
        "invoice_footer": 500,
        "invoice_terms": 2000,
        "authorized_signatory": 120,
    }
    for field, maximum in limits.items():
        if len(values[field]) > maximum:
            return None, f"{field.replace('_', ' ').title()} cannot exceed {maximum} characters."
    if not values["pharmacy_name"]:
        return None, "Pharmacy name is required."
    if values["email"] and not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", values["email"]):
        return None, "Enter a valid business email address."
    gstin = values["gstin"]
    if gstin and not re.fullmatch(r"[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][1-9A-Z]Z[0-9A-Z]", gstin):
        return None, "Enter a valid GSTIN or leave it blank for a non-GST business."

    uploaded_logo = ""
    if logo_file and (logo_file.filename or "").strip():
        extension = os.path.splitext(secure_filename(logo_file.filename))[1].lower()
        if extension not in {".png", ".jpg", ".jpeg"}:
            return None, "Logo must be a PNG or JPEG image."
        try:
            image_header = logo_file.stream.read(2 * 1024 * 1024 + 1)
            logo_file.stream.seek(0)
        except (OSError, ValueError) as exc:
            app.logger.warning("Unable to read pharmacy logo upload: %s", exc)
            return None, "Unable to read the selected logo."
        if len(image_header) > 2 * 1024 * 1024:
            return None, "Logo must be 2 MB or smaller."
        from PIL import Image, UnidentifiedImageError
        try:
            with Image.open(BytesIO(image_header)) as uploaded_image:
                matches_extension = (
                    (extension == ".png" and uploaded_image.format == "PNG")
                    or (extension in {".jpg", ".jpeg"} and uploaded_image.format == "JPEG")
                )
                if (
                    not matches_extension
                    or uploaded_image.width * uploaded_image.height > 16_000_000
                ):
                    return None, "The uploaded file is not a supported pharmacy logo image."
                uploaded_image.verify()
        except (UnidentifiedImageError, OSError, ValueError, Image.DecompressionBombError):
            return None, "The uploaded file is not a valid PNG or JPEG image."
        try:
            uploaded_logo = save_uploaded_file(logo_file, UPLOAD_FOLDER, "pharmacy-logo")
        except OSError:
            app.logger.exception("Unable to save pharmacy logo upload.")
            return None, "The selected logo could not be saved."
        if not uploaded_logo:
            return None, "The selected logo could not be saved."
    values["_uploaded_logo"] = uploaded_logo
    return values, ""


@app.route("/settings/pharmacy-business", methods=["GET", "POST"])
@login_required
@admin_required
def pharmacy_business_setup():
    tenant = current_tenant()
    if not tenant:
        flash("Tenant context is unavailable. Please login again.", "danger")
        return redirect("/login")

    if request.method == "POST":
        values, error = _validate_business_setup(
            request.form, request.files.get("pharmacy_logo")
        )
        if error:
            flash(error, "danger")
            return _business_setup_template(tenant)

        for field in (
            "pharmacy_name",
            "owner_name",
            "contact_number",
            "email",
            "business_address",
            "gstin",
            "drug_license",
        ):
            setattr(tenant, field, values[field])
        settings_updates = {
            field: values[field]
            for field in (
                "legal_business_name",
                "alternate_mobile",
                "city",
                "state",
                "pin_code",
                "business_type",
                "invoice_header",
                "invoice_footer",
                "invoice_terms",
                "authorized_signatory",
                "invoice_prefix",
            )
        }
        existing_identity = tenant_business_identity(tenant)
        uploaded_logo = values.pop("_uploaded_logo")
        if uploaded_logo:
            settings_updates["logo_path"] = url_for(
                "tenant_business_logo", filename=uploaded_logo
            )
        elif request.form.get("remove_logo") == "1":
            settings_updates["logo_path"] = ""
        else:
            settings_updates["logo_path"] = existing_identity["logo_path"]

        update_tenant_settings(tenant, settings_updates)
        try:
            db.session.commit()
        except SQLAlchemyError:
            db.session.rollback()
            app.logger.exception(
                "Pharmacy business setup save failed for tenant_id=%s", tenant.id
            )
            flash("Business settings could not be saved. Please try again.", "danger")
            return _business_setup_template(tenant)
        session["tenant_name"] = tenant.pharmacy_name
        session["tenant_logo_path"] = settings_updates["logo_path"]
        flash("Pharmacy Business Setup saved.", "success")
        return redirect(url_for("pharmacy_business_setup"))

    return _business_setup_template(tenant)


@app.route("/tenant-business-logo/<filename>")
def tenant_business_logo(filename):
    cleaned_name = _safe_stored_filename(filename)
    if not cleaned_name or not cleaned_name.lower().endswith((".png", ".jpg", ".jpeg")):
        abort(404)
    tenant_id = current_tenant_id()
    if not tenant_id:
        try:
            share = URLSafeSerializer(
                app.secret_key, salt="tenant-business-logo-v1"
            ).loads(request.args.get("share") or "")
        except BadSignature:
            abort(404)
        if not isinstance(share, dict) or share.get("filename") != cleaned_name:
            abort(404)
        tenant_id = to_int_safe(share.get("tenant_id"), 0)
    if not tenant_id:
        abort(404)
    tenant_dir = _tenant_storage_dir(UPLOAD_FOLDER, tenant_id)
    file_path = os.path.join(tenant_dir, cleaned_name)
    if not os.path.isfile(file_path):
        abort(404)
    response = send_from_directory(tenant_dir, cleaned_name, as_attachment=False)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["Cache-Control"] = "private, no-store"
    return response


@app.route("/users")
@login_required
@admin_required
def users():
    users_query = active_user_query()
    if session.get("tenant_id"):
        users_query = users_query.filter(User.tenant_id == session.get("tenant_id"))
    users = users_query.order_by(User.username.asc()).all()
    for listed_user in users:
        if listed_user.role == "admin":
            listed_user.access_profile = "admin"
        elif not listed_user.access_profile:
            listed_user.access_profile = derive_access_profile(
                {field_name: getattr(listed_user, field_name, False) for field_name in USER_PERMISSION_FIELDS}
            )
    return render_template(
        "users.html",
        users=users,
        permission_fields=USER_PERMISSION_FIELDS
    )
@app.route("/users/edit/<int:user_id>", methods=["GET", "POST"])
@login_required
@admin_required
def edit_user(user_id):
    scoped_query = active_user_query().filter(User.id == user_id)
    if session.get("tenant_id"):
        scoped_query = scoped_query.filter(User.tenant_id == session.get("tenant_id"))
    user = scoped_query.first_or_404()

    if request.method == "POST":
        payload = validate_user_form(request.form, is_create=False)
        if payload["errors"]:
            for error in payload["errors"]:
                flash(error, "danger")
            return render_template(
                "user_form.html",
                user=user,
                form_title="Edit User",
                submit_label="Save Changes",
                profile_options=ACCESS_PROFILE_PRESETS
            )
        duplicate = active_user_query().filter(
            db.func.lower(User.username) == payload["username"].lower(),
            User.id != user.id
        ).first()
        if duplicate:
            flash("Username already exists.", "danger")
            return render_template(
                "user_form.html",
                user=user,
                form_title="Edit User",
                submit_label="Save Changes",
                profile_options=ACCESS_PROFILE_PRESETS
            )
        try:
            user = persist_user_update(user, payload)
        except Exception:
            db.session.rollback()
            app.logger.exception("Unable to update user %s", user_id)
            flash("Unable to update user due to a database error. Please try again.", "danger")
            return render_template(
                "user_form.html",
                user=user,
                form_title="Edit User",
                submit_label="Save Changes",
                profile_options=ACCESS_PROFILE_PRESETS
            )
        flash("User updated successfully", "success")
        return redirect("/users")

    if not user.access_profile:
        user.access_profile = derive_access_profile({field: getattr(user, field, False) for field in USER_PERMISSION_FIELDS})
    return render_template(
        "user_form.html",
        user=user,
        form_title="Edit User",
        submit_label="Save Changes",
        profile_options=ACCESS_PROFILE_PRESETS
    )
@app.route("/users/add", methods=["GET", "POST"])
@login_required
@admin_required
def add_user():
    if request.method == "POST":
        payload = validate_user_form(request.form, is_create=True)
        if payload["errors"]:
            for error in payload["errors"]:
                flash(error, "danger")
            return render_template(
                "user_form.html",
                user=None,
                form_title="Add User",
                submit_label="Create User",
                profile_options=ACCESS_PROFILE_PRESETS
            )
        if active_user_query().filter(db.func.lower(User.username) == payload["username"].lower()).first():
            flash("Username already exists.", "danger")
            return render_template(
                "user_form.html",
                user=None,
                form_title="Add User",
                submit_label="Create User",
                profile_options=ACCESS_PROFILE_PRESETS
            )
        tenant = current_tenant()
        if tenant and tenant_user_limit_reached(tenant):
            flash("User limit reached for this subscription. Upgrade the plan to add more users.", "danger")
            return render_template(
                "user_form.html",
                user=None,
                form_title="Add User",
                submit_label="Create User",
                profile_options=ACCESS_PROFILE_PRESETS
            )
        try:
            payload["tenant_id"] = session.get("tenant_id")
            persist_new_user(payload)
        except Exception:
            db.session.rollback()
            app.logger.exception("Unable to create user %s", payload["username"])
            flash("Unable to create user due to a database error. Please try again.", "danger")
            return render_template(
                "user_form.html",
                user=None,
                form_title="Add User",
                submit_label="Create User",
                profile_options=ACCESS_PROFILE_PRESETS
            )
        flash("User created", "success")
        return redirect("/users")

    return render_template(
        "user_form.html",
        user=None,
        form_title="Add User",
        submit_label="Create User",
        profile_options=ACCESS_PROFILE_PRESETS
    )
@app.route("/users/change-password/<int:user_id>", methods=["GET","POST"])
@login_required
@admin_required
def change_user_password(user_id):
    scoped_query = active_user_query().filter(User.id == user_id)
    if session.get("tenant_id"):
        scoped_query = scoped_query.filter(User.tenant_id == session.get("tenant_id"))
    user = scoped_query.first_or_404()

    if request.method == "POST":
        new_password = (request.form.get("new_password") or request.form.get("password") or "").strip()
        confirm_password = (request.form.get("confirm_password") or "").strip()
        if not new_password:
            flash("Password is required", "danger")
            return redirect(request.url)
        if confirm_password and new_password != confirm_password:
            flash("New password and confirm password do not match", "danger")
            return redirect(request.url)
        user.set_password(new_password)
        user.session_version = int(user.session_version or 0) + 1
        db.session.commit()
        flash("Password updated")
        return redirect("/users")

    return render_template(
        "change_password.html",
        user=user,
        require_current_password=False,
        page_title=f"Change Password - {user.username}"
    )
@app.route("/users/delete/<int:user_id>", methods=["POST"])
@login_required
@admin_required
def delete_user(user_id):
    scoped_query = active_user_query().filter(User.id == user_id)
    if session.get("tenant_id"):
        scoped_query = scoped_query.filter(User.tenant_id == session.get("tenant_id"))
    user = scoped_query.first_or_404()
    if user.username == "admin":
        flash("Admin user cannot be deleted", "danger")
        return redirect("/users")

    try:
        archive_user_account(user)
    except Exception:
        db.session.rollback()
        app.logger.exception("Unable to archive user %s", user_id)
        flash("Unable to archive user due to a database error. Please try again.", "danger")
        return redirect("/users")
    flash("User archived successfully", "success")
    return redirect("/users")

@app.route("/medicines/export")
@login_required
def export_medicines():
    user = active_user_by_id(session.get("user_id"))
    if not user:
        flash("Access denied", "danger")
        return redirect("/")
    if user.role != "admin" and not (
        user.can_view_medicine or user.can_add_medicine or user.can_edit_medicine or user.can_delete_medicine
    ):
        flash("Access denied", "danger")
        return redirect("/medicines")
    import pandas as pd
    from flask import send_file
    from io import BytesIO

    medicines = Medicine.query.order_by(Medicine.name).all()
    purchase_rate_lookup = build_medicine_purchase_rate_lookup(medicines)

    data = []
    for m in medicines:
        pack_display = ""
        if m.pack_type and m.pack_qty:
            pack_display = f"{m.pack_type} of {m.pack_qty}"
        elif m.pack_type:
            pack_display = m.pack_type
        elif m.pack_qty:
            pack_display = str(m.pack_qty)
        data.append({
            "Medicine Name": m.name,
            "Batch": m.batch,
            "Expiry (MM/YYYY)": f"{m.expiry[5:7]}/{m.expiry[0:4]}",
            "Purchase Rate": round(to_float_safe(purchase_rate_lookup.get(m.id), 0), 4),
            "MRP": m.mrp,
            "Stock": m.qty,
            "Pack Type": m.pack_type,
            "Pack Qty": m.pack_qty,
            "Pack": pack_display
        })

    df = pd.DataFrame(data)

    output = BytesIO()
    df.to_excel(output, index=False)
    output.seek(0)

    return send_file(
        output,
        as_attachment=True,
        download_name="medicine_list.xlsx",
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )
@app.route("/export-low-stock")
@login_required
def export_low_stock():
    import pandas as pd
    from flask import send_file
    from io import BytesIO

    meds = get_low_stock_items(limit=LOW_STOCK_LIMIT)

    data = []
    for m in meds:
        mrp_value = m["mrp"] if m["mrp"] is not None else "Multiple"
        data.append({
            "Medicine Name": m["name"],
            "Batch": m["batch"],
            "Current Stock": m["stock"],
            "MRP": mrp_value,
            "Expiry": m["expiry"],
            "Suggested Order Qty": m["suggested"]
        })

    df = pd.DataFrame(data)

    output = BytesIO()
    df.to_excel(output, index=False)
    output.seek(0)

    return send_file(
        output,
        as_attachment=True,
        download_name="low_stock_medicines.xlsx",
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )

from datetime import datetime, time

@app.route("/stock-history")
@login_required
def stock_history():
    user = active_user_by_id(session.get("user_id"))
    if not user:
        flash("Access denied", "danger")
        return redirect("/")
    if user.role != "admin" and not user.can_view_stock_history:
        flash("Access denied", "danger")
        return redirect("/")

    search = request.args.get("search")
    from_date = request.args.get("from_date")
    to_date = request.args.get("to_date")

    query = StockHistory.query

    # 🔍 SEARCH
    if search:
        query = query.filter(
            StockHistory.medicine_name.ilike(f"%{search}%") |
            StockHistory.user.ilike(f"%{search}%") |
            StockHistory.action.ilike(f"%{search}%")
        )

    # 📅 FROM DATE
    if from_date:
        from_dt = datetime.strptime(from_date, "%Y-%m-%d")
        query = query.filter(StockHistory.created_at >= from_dt)

    # 📅 TO DATE (IMPORTANT FIX)
    if to_date:
        to_dt = datetime.strptime(to_date, "%Y-%m-%d")
        to_dt = datetime.combine(to_dt.date(), time(23, 59, 59))
        query = query.filter(StockHistory.created_at <= to_dt)

    history = query.order_by(StockHistory.created_at.desc()).all()

    return render_template("stock_history.html", history=history)

@app.route("/stock-history/export")
@login_required
def export_stock_history():
    user = active_user_by_id(session.get("user_id"))
    if not user:
        flash("Access denied", "danger")
        return redirect("/")
    if user.role != "admin" and not user.can_view_stock_history:
        flash("Access denied", "danger")
        return redirect("/")
    import pandas as pd
    from flask import send_file
    from io import BytesIO

    history = StockHistory.query.order_by(StockHistory.created_at.desc()).all()

    data = []
    for h in history:
        data.append({
            "Date": h.created_at.strftime("%d-%m-%Y"),
            "Medicine": h.medicine_name,
            "Batch": h.batch,
            "Type": h.action,
            "Old Stock": h.stock_before,
            "Change": h.qty_change,
            "New Stock": h.stock_after,
            "User": h.user,
            "Remark": h.remark
        })

    df = pd.DataFrame(data)
    output = BytesIO()
    df.to_excel(output, index=False)
    output.seek(0)

    return send_file(
        output,
        as_attachment=True,
        download_name="stock_history.xlsx",
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )

@app.route("/stock-history/delete/<int:id>", methods=["POST"])
@login_required
@admin_required
def delete_stock_history(id):
    h = StockHistory.query.get_or_404(id)
    db.session.delete(h)
    db.session.commit()
    flash("Stock history deleted successfully", "success")
    return redirect("/stock-history")



# ---------------- RUN ----------------
if __name__ == "__main__":
    # Debug mode exposes an interactive console; keep it off unless explicitly enabled.
    debug_flag = (os.environ.get("FLASK_DEBUG") or os.environ.get("DEBUG") or "0").strip().lower()
    debug = (not IS_PROD) and debug_flag in {"1", "true", "yes", "on"}
    port = prepare_local_server(is_production=IS_PROD)
    schedule_browser_open(is_production=IS_PROD)
    app.run(host="0.0.0.0", port=port, debug=debug)
