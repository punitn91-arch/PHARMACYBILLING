import importlib
import io
import json
import os
import sys
import tempfile
import unittest
from datetime import datetime

from PIL import Image
from sqlalchemy.exc import IntegrityError
from werkzeug.datastructures import FileStorage


class TenantAuthTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp_dir = tempfile.TemporaryDirectory()
        cls.db_path = os.path.join(cls.temp_dir.name, "tenant_auth.db")
        os.environ["DATABASE_URL"] = f"sqlite:///{cls.db_path}"
        os.environ["SECRET_KEY"] = "tenant-auth-test-secret"
        os.environ["CSRF_PROTECTION"] = "0"
        os.environ["APP_TIMEZONE"] = "Asia/Kolkata"
        os.environ["ENABLE_BACKGROUND_JOBS"] = "0"
        os.environ["APP_STORAGE_ROOT"] = os.path.join(cls.temp_dir.name, "uploads")
        os.environ["APP_BACKUP_ROOT"] = os.path.join(cls.temp_dir.name, "backups")

        project_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        if project_dir not in sys.path:
            sys.path.insert(0, project_dir)
        if "app" in sys.modules:
            cls.app_module = importlib.reload(sys.modules["app"])
        else:
            cls.app_module = importlib.import_module("app")
        cls.app = cls.app_module.app
        cls.db = cls.app_module.db
        cls.app.config["TESTING"] = True

    @classmethod
    def tearDownClass(cls):
        cls.temp_dir.cleanup()

    def setUp(self):
        self.client = self.app.test_client()
        with self.app.app_context():
            self.db.drop_all()
            self.db.create_all()

    def _seed_user(self, username="admin", password="Admin@123", tenant=None):
        with self.app_module.tenant_scope_disabled():
            user = self.app_module.User(
                tenant_id=(tenant.id if tenant else None),
                username=username,
                role="admin",
                access_profile="admin",
                can_manage_users=True,
                can_view_reports=True,
                can_invoice_action=True,
                can_edit_invoice=True,
                can_delete_invoice=True,
                can_view_medicine=True,
                can_add_medicine=True,
                can_edit_medicine=True,
                can_delete_medicine=True,
                can_view_stock_history=True,
                can_manage_purchases=True,
                can_view_audit_logs=True,
                can_view_profit_dashboard=True,
            )
            user.set_password(password)
            self.db.session.add(user)
            self.db.session.commit()
        return user

    def _seed_tenant(self, code="alpha", status="Active"):
        settings = self.app_module.TenantSettings(settings_json="{}")
        tenant = self.app_module.Tenant(
            tenant_uid=self.app_module.generate_tenant_uid(),
            tenant_code=code,
            pharmacy_name=f"{code.title()} Pharmacy",
            subscription_plan_ref="test",
            status=status,
            settings=settings,
        )
        self.db.session.add(settings)
        self.db.session.add(tenant)
        self.db.session.commit()
        return tenant

    def _seed_admin_for_tenant(self, tenant, username, password="Admin@123"):
        return self._seed_user(username=username, password=password, tenant=tenant)

    def _seed_medicine(self, tenant, name, batch):
        with self.app_module.tenant_scope_disabled():
            medicine = self.app_module.Medicine(
                tenant_id=tenant.id,
                name=name,
                batch=batch,
                expiry="2027-12-31",
                mrp=25.0,
                qty=10,
                is_active=True,
            )
            self.db.session.add(medicine)
            self.db.session.commit()
        return medicine

    def _login(self, tenant_code, username, password="Admin@123"):
        response = self.client.post(
            "/login",
            data={"tenant": tenant_code, "username": username, "password": password},
            follow_redirects=False,
        )
        self.assertEqual(response.status_code, 302)
        return response

    def _seed_super_admin(self, username="owner", password="Owner@123"):
        with self.app_module.tenant_scope_disabled():
            user = self.app_module.User(
                tenant_id=None,
                username=username,
                role=self.app_module.PLATFORM_SUPER_ADMIN_ROLE,
                access_profile="platform_owner",
                can_manage_users=True,
                can_view_reports=True,
                can_view_audit_logs=True,
            )
            user.set_password(password)
            self.db.session.add(user)
            self.db.session.commit()
        return user

    def _login_super_admin(self, username="owner", password="Owner@123"):
        response = self.client.post(
            "/login",
            data={"username": username, "password": password},
            follow_redirects=False,
        )
        self.assertEqual(response.status_code, 302)
        self.assertIn("/super-admin", response.headers.get("Location", ""))
        return response

    def test_legacy_login_creates_default_tenant_and_scopes_session(self):
        with self.app.app_context():
            user = self._seed_user()
            self.assertIsNone(user.tenant_id)

        response = self.client.post(
            "/login",
            data={"username": "admin", "password": "Admin@123"},
            follow_redirects=False,
        )
        self.assertEqual(response.status_code, 302)
        with self.client.session_transaction() as session:
            tenant_id = session.get("tenant_id")
            self.assertIsNotNone(tenant_id)
            self.assertEqual(session.get("tenant_code"), "default")

        with self.app.app_context():
            tenant = self.app_module.Tenant.query.filter_by(tenant_code="default").one()
            user = self.app_module.User.query.filter_by(username="admin").one()
            self.assertEqual(user.tenant_id, tenant.id)

    def test_suspended_tenant_cannot_login(self):
        with self.app.app_context():
            tenant = self._seed_tenant(status="Suspended")
            self._seed_user(tenant=tenant)

        response = self.client.post(
            "/login",
            data={"tenant": "alpha", "username": "admin", "password": "Admin@123"},
            follow_redirects=True,
        )
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"pharmacy account is not active", response.data)
        with self.client.session_transaction() as session:
            self.assertIsNone(session.get("user_id"))

    def test_multiple_tenants_require_tenant_code(self):
        with self.app.app_context():
            tenant = self._seed_tenant(code="alpha")
            self._seed_user(tenant=tenant)
            self._seed_tenant(code="beta")

        response = self.client.post(
            "/login",
            data={"username": "admin", "password": "Admin@123"},
            follow_redirects=True,
        )
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"pharmacy tenant code", response.data)

        response = self.client.post(
            "/login",
            data={"tenant": "alpha", "username": "admin", "password": "Admin@123"},
            follow_redirects=False,
        )
        self.assertEqual(response.status_code, 302)

    def test_tenant_master_updates_current_tenant(self):
        with self.app.app_context():
            tenant = self._seed_tenant(code="alpha")
            self._seed_user(tenant=tenant)

        login_response = self.client.post(
            "/login",
            data={"tenant": "alpha", "username": "admin", "password": "Admin@123"},
        )
        self.assertEqual(login_response.status_code, 302)
        response = self.client.post(
            "/tenant-master",
            data={
                "pharmacy_name": "Alpha Care Pharmacy",
                "owner_name": "Dr. Alpha",
                "contact_number": "9876543210",
                "email": "alpha@example.test",
                "business_address": "Clinic Road",
                "gstin": "22AAAAA0000A1Z5",
                "drug_license": "DL-123",
                "subscription_plan_ref": "pro",
                "subscription_start": "2026-10-09",
                "subscription_expiry": "2027-10-09",
                "status": "Active",
            },
            follow_redirects=False,
        )
        self.assertEqual(response.status_code, 302)

        with self.app.app_context():
            tenant = self.app_module.Tenant.query.filter_by(tenant_code="alpha").one()
            self.assertEqual(tenant.pharmacy_name, "Alpha Care Pharmacy")
            self.assertEqual(tenant.owner_name, "Dr. Alpha")
            self.assertEqual(tenant.subscription_plan_ref, "pro")

    def test_pharmacy_business_setup_is_tenant_scoped_and_invoice_identity_is_snapshotted(self):
        with self.app.app_context():
            alpha = self._seed_tenant(code="alpha")
            beta = self._seed_tenant(code="beta")
            self._seed_admin_for_tenant(alpha, "alpha_admin")
            self._seed_admin_for_tenant(beta, "beta_admin")
            alpha_id, beta_id = alpha.id, beta.id

        client_a = self.app.test_client()
        client_b = self.app.test_client()
        for client, code, username in (
            (client_a, "alpha", "alpha_admin"),
            (client_b, "beta", "beta_admin"),
        ):
            response = client.post(
                "/login",
                data={"tenant": code, "username": username, "password": "Admin@123"},
            )
            self.assertEqual(response.status_code, 302)

        dashboard_a = client_a.get("/")
        self.assertIn(b"/settings/pharmacy-business", dashboard_a.data)
        setup_a = client_a.get("/settings/pharmacy-business")
        self.assertEqual(setup_a.status_code, 200)
        self.assertIn(b"Legal Business Name", setup_a.data)
        self.assertIn(b"Invoice Footer Message", setup_a.data)

        png_file = io.BytesIO()
        Image.new("RGBA", (1, 1), (20, 80, 140, 255)).save(png_file, format="PNG")
        png = png_file.getvalue()
        response = client_a.post(
            "/settings/pharmacy-business",
            data={
                "pharmacy_name": "Alpha Community Pharmacy",
                "legal_business_name": "Alpha Community Healthcare LLP",
                "owner_name": "Alpha Owner",
                "contact_number": "9111111111",
                "alternate_mobile": "9222222222",
                "email": "alpha@example.test",
                "business_address": "1 Alpha Street",
                "city": "Jaipur",
                "state": "Rajasthan",
                "pin_code": "302001",
                "gstin": "08ABAFT0637R1ZP",
                "drug_license": "ALPHA-DL-01",
                "business_type": "Retail pharmacy",
                "invoice_header": "Alpha header",
                "invoice_footer": "Alpha footer",
                "invoice_terms": "Alpha terms",
                "authorized_signatory": "Alpha Signatory",
                "invoice_prefix": "ALP",
                "pharmacy_logo": (io.BytesIO(png), "alpha.png"),
            },
            follow_redirects=True,
        )
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Pharmacy Business Setup saved.", response.data)
        self.assertIn(b"Alpha Community Pharmacy", client_a.get("/").data)

        with self.app.app_context(), self.app_module.tenant_context(alpha_id):
            alpha_invoice = self.app_module.Invoice(
                tenant_id=alpha_id,
                invoice_no="ALP-00001",
                customer="Alpha Patient",
                subtotal=100,
                total=100,
                created_at=datetime.utcnow(),
            )
            self.app_module.apply_invoice_print_profile(alpha_invoice, alpha_invoice.created_at)
            self.db.session.add(alpha_invoice)
            self.db.session.commit()
            alpha_invoice_id = alpha_invoice.id
            saved_identity = self.app_module.tenant_business_identity(
                self.app_module.Tenant.query.get(alpha_id)
            )
            self.assertEqual(saved_identity["legal_business_name"], "Alpha Community Healthcare LLP")
            self.assertEqual(saved_identity["invoice_footer"], "Alpha footer")
            alpha_logo_path = saved_identity["logo_path"]

        dashboard_a = client_a.get("/")
        self.assertIn(alpha_logo_path.encode(), dashboard_a.data)
        setup_reload = client_a.get("/settings/pharmacy-business")
        self.assertIn(b"Alpha Community Healthcare LLP", setup_reload.data)
        logo_response = client_a.get(alpha_logo_path)
        self.assertEqual(logo_response.status_code, 200)
        self.assertEqual(logo_response.headers.get("X-Content-Type-Options"), "nosniff")
        self.assertIn(b"\x89PNG", logo_response.data)

        response = client_a.post(
            "/settings/pharmacy-business",
            data={
                "pharmacy_name": "Alpha Updated Pharmacy",
                "legal_business_name": "Alpha Updated Healthcare LLP",
                "owner_name": "Alpha Owner",
                "contact_number": "9111111111",
                "email": "alpha@example.test",
                "business_address": "1 Alpha Street",
                "city": "Jaipur",
                "state": "Rajasthan",
                "pin_code": "302001",
                "gstin": "08ABAFT0637R1ZP",
                "drug_license": "ALPHA-DL-01",
                "invoice_header": "Updated header",
                "invoice_footer": "Updated footer",
                "invoice_prefix": "ALP",
            },
            follow_redirects=True,
        )
        self.assertEqual(response.status_code, 200)
        old_invoice_response = client_a.get(f"/invoice/{alpha_invoice_id}")
        self.assertIn(b"Alpha Community Pharmacy", old_invoice_response.data)
        self.assertIn(b"Alpha footer", old_invoice_response.data)
        self.assertNotIn(b"Alpha Updated Pharmacy", old_invoice_response.data)

        with self.app.app_context(), self.app_module.tenant_context(alpha_id):
            new_invoice = self.app_module.Invoice(
                tenant_id=alpha_id,
                invoice_no="ALP-00002",
                customer="Alpha Patient 2",
                subtotal=100,
                total=100,
                created_at=datetime.utcnow(),
            )
            self.app_module.apply_invoice_print_profile(new_invoice, new_invoice.created_at)
            self.db.session.add(new_invoice)
            self.db.session.commit()
            new_invoice_id = new_invoice.id
        new_invoice_response = client_a.get(f"/invoice/{new_invoice_id}")
        self.assertIn(b"Alpha Updated Pharmacy", new_invoice_response.data)
        self.assertIn(b"Updated header", new_invoice_response.data)
        self.assertIn(b"Updated footer", new_invoice_response.data)

        response = client_b.post(
            "/settings/pharmacy-business",
            data={
                "pharmacy_name": "Beta Independent Pharmacy",
                "legal_business_name": "Beta Health Limited",
                "owner_name": "Beta Owner",
                "contact_number": "9333333333",
                "email": "beta@example.test",
                "business_address": "2 Beta Road",
                "city": "Udaipur",
                "state": "Rajasthan",
                "pin_code": "313001",
                "drug_license": "BETA-DL-01",
                "invoice_prefix": "BET",
            },
            follow_redirects=True,
        )
        self.assertEqual(response.status_code, 200)
        dashboard_b = client_b.get("/")
        self.assertIn(b"Beta Independent Pharmacy", dashboard_b.data)
        self.assertNotIn(b"Alpha Updated Pharmacy", dashboard_b.data)
        with self.app.app_context(), self.app_module.tenant_context(beta_id):
            beta_invoice = self.app_module.Invoice(
                tenant_id=beta_id,
                invoice_no="BET-00001",
                customer="Beta Patient",
                subtotal=100,
                total=100,
                created_at=datetime.utcnow(),
            )
            self.app_module.apply_invoice_print_profile(beta_invoice, beta_invoice.created_at)
            self.db.session.add(beta_invoice)
            self.db.session.commit()
            beta_invoice_id = beta_invoice.id
        beta_invoice_response = client_b.get(f"/invoice/{beta_invoice_id}")
        self.assertIn(b"Beta Independent Pharmacy", beta_invoice_response.data)
        self.assertNotIn(b"Alpha Updated Pharmacy", beta_invoice_response.data)
        self.assertEqual(client_b.get(alpha_logo_path).status_code, 404)
        self.assertEqual(
            self.app.test_client().get(alpha_logo_path).status_code,
            404,
        )

    def test_orm_reads_are_scoped_to_current_tenant(self):
        with self.app.app_context():
            alpha = self._seed_tenant(code="alpha")
            beta = self._seed_tenant(code="beta")
            self._seed_admin_for_tenant(alpha, "alpha_admin")
            self._seed_admin_for_tenant(beta, "beta_admin")
            alpha_med = self._seed_medicine(alpha, "ALPHA MED", "A1")
            beta_med = self._seed_medicine(beta, "BETA MED", "B1")
            alpha_tenant_id = alpha.id
            alpha_id, beta_id = alpha_med.id, beta_med.id

        self._login("alpha", "alpha_admin")
        with self.app.app_context(), self.app_module.tenant_context(alpha_tenant_id):
            names = [row.name for row in self.app_module.Medicine.query.order_by(self.app_module.Medicine.id).all()]
            self.assertEqual(names, ["ALPHA MED"])
            self.assertIsNotNone(self.app_module.Medicine.query.filter_by(id=alpha_id).first())
            self.assertIsNone(self.app_module.Medicine.query.filter_by(id=beta_id).first())

    def test_cross_tenant_update_delete_and_reference_are_blocked(self):
        with self.app.app_context():
            alpha = self._seed_tenant(code="alpha")
            beta = self._seed_tenant(code="beta")
            self._seed_admin_for_tenant(alpha, "alpha_admin")
            alpha_med = self._seed_medicine(alpha, "ALPHA MED", "A1")
            beta_med = self._seed_medicine(beta, "BETA MED", "B1")
            with self.app_module.tenant_scope_disabled():
                beta_invoice = self.app_module.Invoice(
                    tenant_id=beta.id,
                    invoice_no="BETA-INV-1",
                    customer="Beta Patient",
                    total=10,
                    created_by="beta_admin",
                )
                self.db.session.add(beta_invoice)
                self.db.session.commit()
            alpha_tenant_id = alpha.id
            alpha_med_name = alpha_med.name
            beta_med_id = beta_med.id
            beta_invoice_id = beta_invoice.id

        with self.app.app_context(), self.app_module.tenant_context(alpha_tenant_id):
            with self.app_module.tenant_scope_disabled():
                beta_med = self.db.session.get(self.app_module.Medicine, beta_med_id)
            beta_med.qty = 99
            with self.assertRaises(PermissionError):
                self.db.session.commit()
            self.db.session.rollback()

            with self.app_module.tenant_scope_disabled():
                beta_med = self.db.session.get(self.app_module.Medicine, beta_med_id)
            self.db.session.delete(beta_med)
            with self.assertRaises(PermissionError):
                self.db.session.commit()
            self.db.session.rollback()

            bad_item = self.app_module.InvoiceItem(
                invoice_id=beta_invoice_id,
                name=alpha_med_name,
                qty=1,
                price=10,
                amount=10,
            )
            self.db.session.add(bad_item)
            with self.assertRaises(PermissionError):
                self.db.session.commit()
            self.db.session.rollback()

    def test_connection_reuse_does_not_leak_tenant_context(self):
        with self.app.app_context():
            alpha = self._seed_tenant(code="alpha")
            beta = self._seed_tenant(code="beta")
            self._seed_admin_for_tenant(alpha, "alpha_admin")
            self._seed_admin_for_tenant(beta, "beta_admin")
            self._seed_medicine(alpha, "ALPHA MED", "A1")
            self._seed_medicine(beta, "BETA MED", "B1")

        self._login("alpha", "alpha_admin")
        self.assertIn(b"ALPHA MED", self.client.get("/api/global-search?q=med").data)
        self.assertNotIn(b"BETA MED", self.client.get("/api/global-search?q=med").data)

        self.client.get("/logout")
        self._login("beta", "beta_admin")
        self.assertIn(b"BETA MED", self.client.get("/api/global-search?q=med").data)
        self.assertNotIn(b"ALPHA MED", self.client.get("/api/global-search?q=med").data)

    def test_unauthorized_tenant_switching_is_rejected(self):
        with self.app.app_context():
            alpha = self._seed_tenant(code="alpha")
            beta = self._seed_tenant(code="beta")
            self._seed_admin_for_tenant(alpha, "alpha_admin")
            beta_tenant_id = beta.id

        self._login("alpha", "alpha_admin")
        with self.client.session_transaction() as session:
            session["tenant_id"] = beta_tenant_id
            session["tenant_code"] = "beta"
        response = self.client.get("/", follow_redirects=False)
        self.assertEqual(response.status_code, 302)
        self.assertIn("/login", response.headers.get("Location", ""))

    def test_business_numbers_are_tenant_scoped_and_settings_driven(self):
        with self.app.app_context():
            alpha = self._seed_tenant(code="alpha")
            beta = self._seed_tenant(code="beta")
            alpha.settings.settings_json = json.dumps({
                "invoice_prefix": "AX",
                "purchase_prefix": "AP",
                "return_prefix": "AR",
            })
            self.db.session.commit()

            with self.app_module.tenant_scope_disabled():
                self.db.session.add(self.app_module.Invoice(
                    tenant_id=alpha.id,
                    invoice_no="DUP-1",
                    customer="Alpha",
                    created_at=datetime(2026, 10, 9),
                ))
                self.db.session.add(self.app_module.Invoice(
                    tenant_id=beta.id,
                    invoice_no="DUP-1",
                    customer="Beta",
                    created_at=datetime(2026, 10, 9),
                ))
                self.db.session.commit()

            with self.app_module.tenant_context(alpha.id):
                invoice = self.app_module.Invoice(customer="Alpha Seq", created_at=datetime(2026, 10, 9))
                self.db.session.add(invoice)
                self.db.session.flush()
                self.assertEqual(self.app_module.assign_invoice_number(invoice, datetime(2026, 10, 9)), "AX-00001")
                self.db.session.rollback()

            with self.app_module.tenant_context(beta.id):
                invoice = self.app_module.Invoice(customer="Beta Seq", created_at=datetime(2026, 10, 9))
                self.db.session.add(invoice)
                self.db.session.flush()
                self.assertEqual(self.app_module.assign_invoice_number(invoice, datetime(2026, 10, 9)), "INV-00001")
                self.db.session.rollback()

            with self.app_module.tenant_scope_disabled():
                self.db.session.add(self.app_module.Invoice(
                    tenant_id=alpha.id,
                    invoice_no="DUP-1",
                    customer="Alpha Duplicate",
                    created_at=datetime(2026, 10, 9),
                ))
                with self.assertRaises(IntegrityError):
                    self.db.session.commit()
                self.db.session.rollback()

    def test_uploaded_files_are_written_under_tenant_directory(self):
        with self.app.app_context():
            alpha = self._seed_tenant(code="alpha")
            beta = self._seed_tenant(code="beta")

            with self.app_module.tenant_context(alpha.id):
                stored_name = self.app_module.save_uploaded_file(
                    FileStorage(stream=io.BytesIO(b"pdf-ish"), filename="bill.pdf"),
                    self.app_module.VENDOR_BILL_UPLOAD_FOLDER,
                    "vendorbill",
                )
                alpha_name, alpha_base, alpha_path = self.app_module.resolve_tenant_upload_file(
                    self.app_module.VENDOR_BILL_UPLOAD_FOLDER,
                    stored_name,
                )
                self.assertEqual(alpha_name, stored_name)
                self.assertIn(f"tenant-{alpha.id}", alpha_base)
                self.assertTrue(os.path.exists(alpha_path))

            with self.app_module.tenant_context(beta.id):
                _beta_name, beta_base, beta_path = self.app_module.resolve_tenant_upload_file(
                    self.app_module.VENDOR_BILL_UPLOAD_FOLDER,
                    stored_name,
                )
                self.assertIn(f"tenant-{beta.id}", beta_base)
                self.assertFalse(os.path.exists(beta_path))

    def test_super_admin_can_create_tenant_and_subscription_history(self):
        with self.app.app_context():
            self._seed_super_admin()

        self._login_super_admin()
        response = self.client.post(
            "/super-admin/tenants/create",
            data={
                "pharmacy_name": "Gamma Pharmacy",
                "tenant_code": "gamma",
                "owner_name": "Gamma Owner",
                "admin_username": "gamma_admin",
                "plan_ref": "monthly",
                "amount": "1999",
                "user_limit": "4",
                "payment_reference": "MANUAL-1",
            },
            follow_redirects=False,
        )
        self.assertEqual(response.status_code, 302)

        with self.app.app_context(), self.app_module.tenant_scope_disabled():
            tenant = self.app_module.Tenant.query.filter_by(tenant_code="gamma").one()
            self.assertEqual(tenant.subscription_plan_ref, "monthly")
            self.assertEqual(tenant.status, "Active")
            history = self.app_module.SubscriptionHistory.query.filter_by(tenant_id=tenant.id).one()
            self.assertEqual(history.plan_ref, "monthly")
            with self.app_module.tenant_context(tenant.id):
                admin = self.app_module.User.query.filter_by(username="gamma_admin").one()
                self.assertEqual(admin.role, "admin")
                self.assertTrue(admin.check_password("not-the-password") is False)

    def test_expired_subscription_blocks_mutations_but_allows_reads(self):
        with self.app.app_context():
            tenant = self._seed_tenant(code="alpha", status="Expired")
            self._seed_admin_for_tenant(tenant, "alpha_admin")
            tenant_id = tenant.id

        self._login("alpha", "alpha_admin")
        read_response = self.client.get("/billing")
        self.assertEqual(read_response.status_code, 200)

        write_response = self.client.post(
            "/users/add",
            data={
                "username": "blocked_user",
                "password": "Admin@123",
                "confirm_password": "Admin@123",
                "role": "staff",
                "access_profile": "custom",
            },
            follow_redirects=False,
        )
        self.assertEqual(write_response.status_code, 302)
        with self.app.app_context(), self.app_module.tenant_context(tenant_id):
            self.assertIsNone(self.app_module.User.query.filter_by(username="blocked_user").first())
